import pathlib,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
from raw_query_find_prefix_model import query_prefix,shape_guard,TEMPLATE
class PrefixTests(unittest.TestCase):
 def test_selected(self):
  r=query_prefix(b'se%61rch=x')['calls'];self.assertEqual(len(r),1);self.assertEqual(r[0]['input_bytes'],8);self.assertEqual(r[0]['decoded_hex'],b'search'.hex());self.assertTrue(r[0]['decoding_branch_present'])
 def test_original_witness(self):self.assertTrue(query_prefix(b'%73earch=x')['calls'][0]['comparison_to_search'])
 def test_no_escape_does_not_force_decode_allocation(self):self.assertFalse(query_prefix(b'search=x')['calls'][0]['decoding_branch_present'])
 def test_malformed_percent(self):self.assertFalse(query_prefix(b'se%XXrch=x')['calls'][0]['decoding_branch_present'])
 def test_empty_value(self):self.assertEqual(query_prefix(b'se%61rch=')['calls'],[])
 def test_empty_key(self):self.assertEqual(query_prefix(b'=x')['calls'],[])
 def test_missing_equal(self):self.assertEqual(query_prefix(b'se%61rch')['calls'],[])
 def test_positive_split_limit(self):self.assertEqual(len(query_prefix(b'se%61rch=x=y')['calls']),1)
 def test_duplicate_stops_at_first(self):self.assertEqual(len(query_prefix(b'search=x&se%61rch=y')['calls']),1)
 def test_prior_nonmatching_candidate(self):self.assertEqual(len(query_prefix(b'other=x&se%61rch=y')['calls']),2)
 def test_blank(self):self.assertEqual(query_prefix(b'')['calls'],[])
 def test_html_outside_scope(self):self.assertEqual(query_prefix(b'se%61rch=x',format='html')['status'],'outside_selected_json_prefix')
 def test_admission_unknown(self):self.assertEqual(query_prefix(b'se%61rch=x',admitted=False)['calls'],[])
 def test_nonascii_unknown(self):self.assertEqual(query_prefix(b'\xff=x')['status'],'unsupported_input_encoding')
 def test_source_template(self):self.assertTrue(shape_guard(TEMPLATE.replace('METHOD','scan'),'scan'))
 def test_source_changes_failclosed(self):
  for old,new in [("split('=', 2)","split('=')"),('.find do','.each do'),('&& !value.empty?','|| !value.empty?'),("split('&')","split(';')")]:self.assertFalse(shape_guard(TEMPLATE.replace('METHOD','scan').replace(old,new),'scan'))
if __name__=='__main__':unittest.main()
