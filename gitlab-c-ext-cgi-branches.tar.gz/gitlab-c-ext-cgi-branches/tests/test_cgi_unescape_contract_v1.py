import unittest,importlib.util
from pathlib import Path
p=Path(__file__).parents[1]/'scripts/cgi_unescape_contract_v1.py';s=importlib.util.spec_from_file_location('cgi_contract',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Transfers(unittest.TestCase):
 def test_witness(self):
  r=m.transfers(b'%73earch');self.assertEqual(r['output_hex'],b'search'.hex());self.assertEqual(r['events'][0]['capacity_argument'],8);self.assertEqual([e['count'] for e in r['events'][1:]],[0,1,5])
 def test_middle_escape(self):
  r=m.transfers(b'se%61rch');self.assertEqual([e['count'] for e in r['events'][1:]],[2,1,3]);self.assertEqual(r['output_length'],6)
 def test_noescape(self):self.assertEqual(m.transfers(b'search')['status'],'dup_fallback_no_selected_constructor')
 def test_malformed(self):
  for v in [b'%GG',b'%',b'%7',b'%G3',b'%3G']:self.assertEqual(m.transfers(v)['events'],[])
 def test_plus(self):
  r=m.transfers(b'a+b');self.assertEqual(r['output_hex'],b'a b'.hex());self.assertEqual(r['events'][2]['byte'],32)
 def test_plus_disabled(self):self.assertEqual(m.transfers(b'a+b',unescape_plus=False)['events'],[])
 def test_ascii_incompatible(self):self.assertEqual(m.transfers(b'%73',ascii_compatible=False)['status'],'ruby_super_fallback')
 def test_ascii_unknown(self):self.assertEqual(m.transfers(b'%73',ascii_compatible=None)['events'],[])
 def test_charset_unknown(self):self.assertEqual(m.transfers(b'%73',charset_valid=None)['status'],'unresolved_runtime_charset')
 def test_charset_invalid(self):self.assertEqual(m.transfers(b'%73',charset_valid=False)['events'],[])
 def test_arity(self):
  for n in [0,3]:self.assertEqual(m.transfers(b'%73',argc=n)['status'],'arity_error')
  self.assertEqual(m.transfers(b'%73',argc=2)['output_hex'],'73')
 def test_unknown_data(self):self.assertEqual(m.transfers(None)['status'],'unresolved_input_bytes')
 def test_zero_and_mixed_case_hex(self):self.assertEqual(m.transfers(b'%00%4a%4A')['output_hex'],'004a4a')
 def test_incomplete_after_success(self):self.assertEqual(m.transfers(b'%73%7')['output_hex'],b's%7'.hex())
 def test_general_bounds(self):
  for raw in [b'',b'%',b'abc',b'%41',b'%41%42',b'%00a+b%7',b'abc%FFdef',b'%GG+']:
   r=m.transfers(raw);self.assertLessEqual(r['output_length'],len(raw))
   for e in r['events']:
    if e.get('source')=='input_slice':self.assertGreaterEqual(e['count'],0);self.assertLessEqual(e['start']+e['count'],len(raw))
if __name__=='__main__':unittest.main()
