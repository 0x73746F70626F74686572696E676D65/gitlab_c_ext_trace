import unittest,importlib.util
from pathlib import Path
p=Path(__file__).parents[1]/'scripts/c_module_composition_v2.py';s=importlib.util.spec_from_file_location('composition',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def parse(text):return m.analyze(list(enumerate(text.splitlines(),1)))
PREFIX='c = rb_define_class("Container", rb_cObject);\nm = rb_define_module_under(c, "Mixin");\nrb_define_method(m, "work", work, 1);\n'
class RuleTests(unittest.TestCase):
 def test_generic_extend(self):
  r=parse(PREFIX+'rb_extend_object(c, m);')['facts'][0];self.assertEqual(r['target']['name'],'Container');self.assertEqual(len(r['registrations']),1)
 def test_generic_prepend(self):self.assertEqual(parse(PREFIX+'rb_prepend_module(c, m);')['facts'][0]['relation'],'module_precedes_receiver_instance_method_origin')
 def test_wrong_receiver_not_reassigned(self):
  r=parse(PREFIX+'other = rb_define_class("Other", rb_cObject);\nrb_extend_object(other, m);')['facts'][0];self.assertEqual(r['target']['name'],'Other');self.assertNotEqual(r['target']['name'],'Container')
 def test_module_rebinding_unknown(self):
  r=parse(PREFIX+'m = other;\nrb_extend_object(c, m);')['facts'][0];self.assertEqual(r['status'],'unresolved_objects');self.assertEqual(r['registrations'],[])
 def test_new_module_identity_no_old_methods(self):
  r=parse(PREFIX+'m = rb_define_module("Replacement");\nrb_extend_object(c, m);')['facts'][0];self.assertEqual(r['registrations'],[])
 def test_unknown_module(self):self.assertEqual(parse(PREFIX+'rb_extend_object(c, absent);')['facts'][0]['status'],'unresolved_objects')
 def test_class_not_module(self):self.assertEqual(parse(PREFIX+'rb_extend_object(c, c);')['facts'][0]['status'],'unresolved_objects')
 def test_conditional_initializer(self):
  r=parse('if (flag) {\n'+PREFIX+'}\nrb_extend_object(c, m);');self.assertEqual(r['facts'][0]['status'],'unresolved_initializer_construct');self.assertEqual(r['facts'][0]['registrations'],[])
 def test_preprocessor_unknown(self):self.assertTrue(parse('#ifdef UNKNOWN\n'+PREFIX+'#endif\nrb_extend_object(c, m);')['unsupported'])
 def test_unknown_mutating_call(self):self.assertEqual(parse(PREFIX+'mutate(c);\nrb_extend_object(c, m);')['facts'][0]['status'],'unresolved_initializer_construct')
 def test_receiver_rebound(self):self.assertEqual(parse(PREFIX+'c = other;\nrb_extend_object(c, m);')['facts'][0]['status'],'unresolved_objects')
 def test_later_registration_not_retrospective(self):
  r=parse('c = rb_define_class("Container", rb_cObject);\nm = rb_define_module("Mixin");\nrb_extend_object(c, m);\nrb_define_method(m, "work", work, 1);');self.assertEqual(r['facts'][0]['registrations'],[])
class OverwriteTests(unittest.TestCase):
 def test_direct_duplicate_different_c_target(self):
  r=parse(PREFIX+'rb_define_method(m, "work", different_work, 1);\nrb_extend_object(c, m);')['facts'][0];self.assertEqual(r['registrations'],[])
 def test_alias_replaces_direct(self):
  r=parse(PREFIX+'rb_define_method(m, "other", other_work, 1);\nrb_define_alias(m, "work", "other");\nrb_extend_object(c, m);')['facts'][0];self.assertEqual([x['ruby_name'] for x in r['registrations']],['other'])
 def test_later_overwrite_invalidates_earlier_composition(self):
  r=parse(PREFIX+'rb_extend_object(c, m);\nrb_define_method(m, "work", different_work, 1);')['facts'][0];self.assertEqual(r['registrations'],[])
 def test_later_alias_invalidates_earlier_composition(self):
  r=parse(PREFIX+'rb_extend_object(c, m);\nrb_define_alias(m, "work", "other");')['facts'][0];self.assertEqual(r['registrations'],[])
 def test_other_name_unchanged(self):
  r=parse(PREFIX+'rb_define_alias(m, "other", "work");\nrb_extend_object(c, m);')['facts'][0];self.assertEqual([x['ruby_name'] for x in r['registrations']],['work'])
 def test_alias_then_define_still_unknown(self):
  r=parse(PREFIX+'rb_define_alias(m, "future", "work");\nrb_define_method(m, "future", new_work, 1);\nrb_extend_object(c, m);')['facts'][0];self.assertEqual([x['ruby_name'] for x in r['registrations']],['work'])
if __name__=='__main__':unittest.main()
