#!/usr/bin/env python3
import json,hashlib,re,itertools,sys
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');B=Path('/workspace/gitlab_c_ext_trace');sys.path.insert(0,str(V/'scripts'));import cgi_unescape_contract_v1 as m
checks=0;errors=[];opened={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(c,msg):
 global checks
 checks+=1
 if not c:errors.append(msg)
f=V/'reports/cgi_unescape_native_freeze_v1.json';fr=json.loads(f.read_text())
for x in fr['files']:ck(sha(V/x['path'])==x['sha256'],'frozen:'+x['path'])
cp=V/'tables/cgi_unescape_native_contract_v1.jsonl';c=json.loads(cp.read_text())
for e in c['source_evidence']:
 p=B/e['file'];opened[e['file']]=sha(p);ck(opened[e['file']]==e['sha256'],'sourcehash');ck('\n'.join(p.read_text().splitlines()[e['line']-1:e['end_line']]).rstrip('\n')==e['excerpt'].rstrip('\n'),'excerpt')
for table,key,values in [('primitive_sites','site_id',{x['site_id'] for x in c['site_bindings']}),('c_primitives','primitive_id',{x['primitive_id'] for x in c['site_bindings']}),('c_registrations','registration_id',{c['registration_id']})]:
 found={}
 for l in (B/'tables'/f'{table}.jsonl').open():
  x=json.loads(l)
  if x.get(key) in values:found[x[key]]=x
 ck(set(found)==values,'nativejoin:'+table)
# Independent regex-token oracle: incomplete '%' in last1/2bytes terminates scan;
# valid percent triples or enabled plus are replacement tokens, malformed others literal.
def oracle(raw,plus):
 pattern=rb'%[0-9a-fA-F]{2}|'+(rb'\+|' if plus else b'')+rb'%.?$'
 out=bytearray();cursor=0;replacements=[]
 for hit in re.finditer(pattern,raw):
  token=hit.group();out.extend(raw[cursor:hit.start()])
  if token==b'+':out.append(32);replacements.append((hit.start(),hit.end(),32))
  elif len(token)==3:out.append(int(token[1:],16));replacements.append((hit.start(),hit.end(),int(token[1:],16)))
  else:out.extend(token)
  cursor=hit.end()
 out.extend(raw[cursor:]);return bytes(out),replacements
n=0
for size in range(5):
 for chars in itertools.product(b'a%061G+',repeat=size):
  raw=bytes(chars)
  for plus in [False,True]:
   got=m.transfers(raw,unescape_plus=plus);want,replacements=oracle(raw,plus);n+=1
   ck(got['output_hex']==want.hex(),'oracle_output:'+raw.hex()+':'+str(plus));ck(bool(got['events'])==bool(replacements),'oracle_selected_branch:'+raw.hex())
   if replacements:
    ck(got['events'][0]['capacity_argument']==len(raw),'encodedcapacity')
    decoded=[e['byte'] for e in got['events'] if e.get('source')=='decoded_fixed_stack_byte'];ck(decoded==[r[2] for r in replacements],'decodedbytes')
    ck(all(e.get('count')==1 for e in got['events'] if e.get('source')=='decoded_fixed_stack_byte'),'fixedcount1')
for args,status in [({'ascii_compatible':False},'ruby_super_fallback'),({'ascii_compatible':None},'unresolved_input_encoding'),({'charset_valid':False},'encoding_resolution_error'),({'charset_valid':None},'unresolved_runtime_charset'),({'argc':0},'arity_error'),({'argc':3},'arity_error')]:ck(m.transfers(b'se%61rch',**args)['status']==status,'guard:'+status)
w=c['witness'];ck(w['input_ascii']=='se%61rch' and w['input_byte_length']==8 and w['output_length']==6,'witness');ck([e.get('count') for e in w['events'][1:]]==[2,1,3],'prefix_decoded_tail')
r={'status':'PASS' if not errors else 'FAIL','checks':checks,'errors':errors,'contract_sha256':sha(cp),'freeze_sha256':sha(f),'source_files':len(opened),'source_manifest':opened,'independent_finite_byte_cases':n,'finite_case_domain':'Every0–4byte string over a,% ,0,6,1,G,+ (space excluded), both plus modes; regex token oracle independently models valid escapes/incomplete tail. Finite static model comparison, not CGI execution or production recall.','semantic_judgments':['Native activation needs successful nonTruffle require escape.so; Init_escape→InitVM macro→InitVM_escape registers method then prepends/extends exactCGI receiver modules. LoadError rescue leaves Ruby fallback, so not unconditional.','cgiesc_unescape arity1/2 and StringValue precede ASCII-compatibility branch; charset rb_to_encoding must succeed before buffer. ASCII-incompatible falls back to super.','se%61rch raw8 gives constructor capacity8; literal prefix2, fixed stack decoded byte0x61 count1, tail3 produce search length6. No decoded6-as-capacity or arbitrary stacksize interpretation.','rb_str_cat count0 returns without positive copy; malformed/incomplete escapes without successful replacement use duplicate fallback, not selected bufferconstructor.','Capacity may be embeddedGCstorage; API append may resize/copy conditionally. No exact heapbytes, pointercontrol, vulnerability or runtime request feasibility claimed.'],'frontend_assembly_status':'pending_separate_frozen_Ruby_recipe','target_execution':False,'frozen_inputs_modified':False}
p=V/'reports/cgi_unescape_native_independent_review.json';p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'checks':checks,'errors':errors[:5],'finite_cases':n,'report_sha256':sha(p)}))
