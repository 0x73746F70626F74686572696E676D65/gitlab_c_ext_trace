"""Bounded static ASCII byte-transfer model, never runs Ruby or HTTP requests."""
import re
from ruby_argument_flow_iteration5 import Source
TEMPLATE='''def METHOD
return if request.query_string.blank?
part = request.query_string.split('&').find do |p|
key, value = p.split('=', 2)
key && value && !key.empty? && !value.empty? && CGI.unescape(key) == 'search'
end
return unless part
_, value = part.split('=', 2)
unescape_value_preserving_plus(value).presence
end'''
def shape_guard(source,method):
 s=Source(source);nodes=s.methods.get(method,[])
 if len(nodes)!=1 or nodes[0].has_error:return False
 actual='\n'.join(x.strip() for x in s.text(nodes[0]).splitlines() if x.strip())
 expected=TEMPLATE.replace('METHOD',method)
 return actual==expected

def decode_ascii(key):
 # Selected ASCII CGI percent/plus semantics only; no encoding fallback model.
 out=bytearray();i=0;escaped=False
 while i<len(key):
  if key[i:i+1]==b'%' and i+2>=len(key):
   # Native loop breaks; the remaining suffix is copied unchanged or duped.
   out.extend(key[i:]);break
  if key[i:i+1]==b'%' and re.fullmatch(b'[0-9a-fA-F]{2}',key[i+1:i+3]):
   out.append(int(key[i+1:i+3],16));i+=3;escaped=True
  elif key[i:i+1]==b'+':out.append(32);i+=1;escaped=True
  else:out.append(key[i]);i+=1
 return bytes(out),escaped

def query_prefix(raw,*,admitted=True,format='json'):
 if not admitted:return dict(status='admission_not_established',calls=[])
 if format!='json':return dict(status='outside_selected_json_prefix',calls=[])
 if not isinstance(raw,bytes) or any(c>127 for c in raw):return dict(status='unsupported_input_encoding',calls=[])
 if not raw or not raw.strip():return dict(status='blank_query_short_circuit',calls=[])
 calls=[]
 for index,part in enumerate(raw.split(b'&')):
  # Ruby positive limit2 preserves an empty remainder; && short-circuits.
  pieces=part.split(b'=',1)
  if len(pieces)!=2 or not pieces[0] or not pieces[1]:continue
  key,value=pieces;decoded,forced=decode_ascii(key)
  calls.append(dict(component_index=index,input_ascii=key.decode('ascii'),input_bytes=len(key),decoded_hex=decoded.hex(),decoding_branch_present=forced,comparison_to_search=decoded==b'search'))
  if decoded==b'search':break # immediate find stops, later components not reached
 return dict(status='bounded_static_prefix',calls=calls)
