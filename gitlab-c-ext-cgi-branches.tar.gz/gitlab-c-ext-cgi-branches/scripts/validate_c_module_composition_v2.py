#!/usr/bin/env python3
import hashlib,json,unittest
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_trace');V=Path('/workspace/gitlab_c_ext_v3');read=lambda p:[json.loads(x) for x in p.open()]
rows=read(V/'tables/c_module_composition_v2.jsonl');ns={x['namespace_id']:x for x in read(R/'tables/c_namespaces.jsonl')};regs={x['registration_id']:x for x in read(R/'tables/c_registrations.jsonl')};checks=0
assert len({x['composition_id'] for x in rows})==len(rows);checks+=1
for row in rows:
 d=(R/row['file']).read_bytes();assert hashlib.sha256(d).hexdigest()==row['source_sha256'];assert d.decode().split('\n')[row['line']-1]==row['source_line'];checks+=2
 for obj in [row['target'],row['module']]:assert obj['namespace_id'] in ns and ns[obj['namespace_id']]['line']==obj['line'];checks+=1
 for reg in row['registrations']:
  old=regs[reg['registration_id']];assert old['ruby_name']==reg['ruby_name'] and old['c_function_id']==reg['c_function_id'];assert reg['owner']['identity']==row['module']['identity'];checks+=2
for e in json.loads((V/'reports/c_module_composition_v2.json').read_text())['source_evidence']:
 d=(R/e['file']).read_bytes();assert hashlib.sha256(d).hexdigest()==e['sha256'];excerpt='\n'.join(d.decode().split('\n')[e['line']-1:e['end_line']]);assert excerpt==e['excerpt'];assert e['required_anchor'] in excerpt;checks+=3
freeze=json.loads((V/'reports/cgi_unescape_native_freeze_v1.json').read_text())
for f in freeze['files']:assert hashlib.sha256((V/f['path']).read_bytes()).hexdigest()==f['sha256'];checks+=1
result=unittest.TextTestRunner().run(unittest.defaultTestLoader.discover(str(V/'tests'),pattern='test_c_module_composition_v2.py'));assert result.wasSuccessful()
(V/'reports/c_module_composition_validation_v2.json').write_text(json.dumps({'checks':checks,'errors':0,'tests':result.testsRun,'frozen_cgi_inputs_unchanged':True,'independent_review':'pending'},indent=2)+'\n');print(checks)
