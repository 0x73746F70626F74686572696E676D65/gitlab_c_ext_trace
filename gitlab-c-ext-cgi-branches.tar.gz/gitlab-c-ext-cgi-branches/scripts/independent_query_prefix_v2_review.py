"""Independent reduced-domain comparison against regex token semantics; no target execution."""
import pathlib,hashlib,json,importlib.util,itertools,re,sys
V=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(V/'scripts'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def oracle(raw):
 out=bytearray();cursor=0;changed=False
 for hit in re.finditer(rb'%[0-9a-fA-F]{2}|\+|%.?$',raw):
  token=hit.group();out.extend(raw[cursor:hit.start()])
  if token==b'+':out.append(32);changed=True
  elif len(token)==3:out.append(int(token[1:],16));changed=True
  else:out.extend(token)
  cursor=hit.end()
 out.extend(raw[cursor:]);return bytes(out),changed

def main():
 freeze=V/'reports/cgi_query_prefix_correction_freeze_v2.json'
 for item in json.loads(freeze.read_text())['files']:assert sha(V/item['path'])==item['sha256']
 p=V/'scripts/raw_query_find_prefix_model_v2.py';spec=importlib.util.spec_from_file_location('qp2',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 n=0;fail=[]
 for size in range(5):
  for chars in itertools.product(b'a%061G+',repeat=size):
   raw=bytes(chars);got=m.decode_ascii(raw);want=oracle(raw);n+=1
   if got!=want:fail.append(dict(raw_hex=raw.hex(),actual=repr(got),expected=repr(want)))
 selected=m.query_prefix(b'se%61rch=x')['calls'];assert len(selected)==1 and selected[0]['input_bytes']==8 and selected[0]['decoded_hex']==b'search'.hex()
 assert m.decode_ascii(b'%+')==(b'%+',False)
 assert m.decode_ascii(b'a%61%+')==(b'aa%+',True)
 r=dict(status='PASS' if not fail else 'FAIL',script_sha256=sha(p),freeze_sha256=sha(freeze),finite_cases=n,errors=fail[:10],oracle='Independent regex-token complete percent/plus replacement and incomplete-percent trailing scan stop, all0–4bytes over a%061G+.',selected_recipe_changed=False,scope='Reduced-domain static model correctness; not target-runtime test, frontend recall or deployment proof.',source_reference='sources/gems/cgi-0.5.1/ext/cgi/escape/escape.c:264-317',source_sha256=sha(pathlib.Path('/workspace/gitlab_c_ext_trace/sources/gems/cgi-0.5.1/ext/cgi/escape/escape.c')),source_semantics='remaining fewer than3 at percent breaks loop, preserving suffix; valid earlier replacements still retained',runtime_execution=False)
 out=V/'reports/query_prefix_v2_independent_review.json';out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(status=r['status'],sha256=sha(out),cases=n)))
if __name__=='__main__':main()
