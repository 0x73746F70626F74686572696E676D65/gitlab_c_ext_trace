#!/usr/bin/env python3
"""Static byte/argument transfer model; never loads or executes CGI/Ruby."""
import json,hashlib
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_trace');V=Path('/workspace/gitlab_c_ext_v3')
C='sources/gems/cgi-0.5.1/ext/cgi/escape/escape.c';S='sources/runtime/ruby-v3_3_11/'
def transfers(data,argc=1,ascii_compatible=True,charset_valid=True,unescape_plus=True):
 if argc not in (1,2):return {'status':'arity_error','events':[]}
 if ascii_compatible is False:return {'status':'ruby_super_fallback','events':[]}
 if ascii_compatible is not True:return {'status':'unresolved_input_encoding','events':[]}
 if charset_valid is False:return {'status':'encoding_resolution_error','events':[]}
 if charset_valid is not True:return {'status':'unresolved_runtime_charset','events':[]}
 if data is None:return {'status':'unresolved_input_bytes','events':[]}
 assert isinstance(data,bytes)
 i=beg=0;n=len(data);dest=False;events=[];out=bytearray();hexes=b'0123456789abcdefABCDEF'
 while i<n:
  c=data[i];clen=0
  if c==37:
   if i+3>n:break
   if data[i+1] not in hexes or data[i+2] not in hexes:i+=1;continue
   byte=int(data[i+1:i+3],16);clen=2
  elif unescape_plus and c==43:byte=32
  else:i+=1;continue
  if not dest:events.append({'line':295,'operation':'rb_str_buf_new','capacity_argument':n});dest=True
  events.append({'line':298,'operation':'rb_str_cat','source':'input_slice','start':beg,'count':i-beg});out.extend(data[beg:i]);i+=clen;beg=i+1
  events.append({'line':302,'operation':'rb_str_cat','source':'decoded_fixed_stack_byte','count':1,'byte':byte});out.append(byte);i+=1
 if dest:
  events.append({'line':306,'operation':'rb_str_cat','source':'input_slice','start':beg,'count':n-beg});out.extend(data[beg:]);return {'status':'conditional_optimized_branch','events':events,'output_hex':out.hex(),'output_length':len(out),'capacity_not_heap_bytes':True}
 return {'status':'dup_fallback_no_selected_constructor','events':[],'output_hex':data.hex(),'output_length':n}

def emit():
 evidence=[]
 specs=[(C,1,9,['char_to_number(c)']),(C,264,304,['RSTRING_LEN(str)','char buf[1]','i + 3 > len','ISXDIGIT','rb_str_buf_new(len)','rb_str_cat(dest, buf, 1)']),(C,305,324,['len - beg','rb_str_dup(str)','rb_enc_associate_index']),(C,387,416,['rb_cvar_get(CLASS_OF(self), id_accept_charset)','rb_check_arity(argc, 1, 2)','rb_enc_str_asciicompat_p(str)','optimized_unescape(str, enc, 1)','rb_call_super(argc, argv)']),(C,461,487,['InitVM(escape)','"unescape", cgiesc_unescape, -1','rb_prepend_module(rb_mEscape, rb_mEscapeExt)','rb_extend_object(rb_cCGI, rb_mEscapeExt)']),('sources/gems/cgi-0.5.1/lib/cgi/escape.rb',1,15,['@@accept_charset = Encoding::UTF_8 unless defined?(@@accept_charset)']),('sources/gems/cgi-0.5.1/lib/cgi/escape.rb',169,176,["unless RUBY_ENGINE == 'truffleruby'","require 'cgi/escape.so'","rescue LoadError"]),(S+'include/ruby/ruby.h',231,231,['InitVM_##ext();']),(S+'string.c',1508,1525,['STR_EMBEDDABLE_P(capa, 1)','ALLOC_N(char, (size_t)capa + 1)']),(S+'string.c',3195,3251,['str_buf_cat4','memcpy(sptr + olen, ptr, len)','if (len == 0) return str;'])]
 checks=0
 for path,a,b,anchors in specs:
  d=(R/path).read_bytes();text='\n'.join(d.decode().split('\n')[a-1:b])
  for anchor in anchors:assert anchor in text,(path,a,anchor);checks+=1
  evidence.append(dict(file=path,line=a,end_line=b,sha256=hashlib.sha256(d).hexdigest(),excerpt=text,required_anchors=anchors))
 sites={295:('site_2a484c2e0d24f6386492956a','primitive_138469ae62f11435db032d0f'),298:('site_e99067b8065ce78012e330a4','primitive_1e4c60868b0b03cef63be2fa'),302:('site_a91ab0507cdc0c1711850a50','primitive_172618f38c9909478b7e7fef'),306:('site_e9ea437961bf983cba0458b9','primitive_76cb267dc9e10d7ffaa10dac')}
 witness=transfers(b'se%61rch')
 for event in witness['events']:event['site_id'],event['primitive_id']=sites[event['line']]
 row=dict(model_id='cgi051_unescape_percent_capacity_v1',status='source_supported_conditional_native_argument_contract',gem='cgi',version='0.5.1',gem_id='f10b8e2bad57b6dc1c0961ba',registration_id='reg_6ce31c46242b5cc94c6f3935',c_function_id='fn_9fb62f9d9d3622ca9a57e2fe',terminal_site_id=sites[295][0],terminal_primitive_id=sites[295][1],site_bindings=[{'line':line,'site_id':ids[0],'primitive_id':ids[1]} for line,ids in sites.items()],source_evidence=evidence,witness={'input_ascii':'se%61rch','input_byte_length':8,'output_ascii':'search',**witness},activation='escape.rb attempts escape.so except TruffleRuby and rescues LoadError. On successful Init_escape→InitVM_escape, unescape instance registration on EscapeExt is made available through prepending into Escape and extending CGI. Runtime method replacement/loading is not proven.',conditions=['Ordinary String source with ASCII-compatible input encoding; method dispatch reaches retained native CGI0.5.1 implementation.','One argument uses runtime @@accept_charset from CLASS_OF(self); it must exist and rb_to_encoding must succeed before selected buffer constructor. Default initialization is conditional, not immutable runtime proof.','Normal allocation and mutation success; no source mutation/reentrant override changes selected bytes before scan.','Ruby3.3.11 source model applies to constructor/append semantics; deployed runtime/build not established.'],argument_semantics={'capacity':'RSTRING_LEN(str) = encoded input byte length8; not decoded length6, actual heapbytes or unbounded allocation claim.','prefix_append':'line298 called with source cstr+0,count2 (se); in alternative first-percent witness %73earch count0 is no copy due Ruby early return.','decoded_append':'line302 consumes one byte0x61 from fixed char buf[1]; contents request-derived, count1 and stack size fixed by source.','tail_append':'line306 source cstr+5,count8-5=3 (rch), appended after se+a.','storage':'rb_str_buf_new may use embedded GC String storage or separate buffer; rb_str_cat positive lengths copy and may expand if needed, exact allocation bytes unresolved.','bounds':'For general supported bytes, decoded length≤encoded length; valid percent consumes3/emits1, plus consumes1/emits1. Input-length capacity does not imply heapbytes.','encoding':'Result may be retagged to requested encoding and revert if invalid; scalar byte-transfer witness prior to retag remains distinct from runtime character interpretation.'},negative_cases=['Malformed/incomplete percent without any valid percent or plus reaches rb_str_dup fallback, not selected capacity site.','Plus selects same capacity site and emits space when unescape_plus true.','ASCII-incompatible String invokes rb_call_super; no optimized-branch assertion.','Unknown runtime accept charset leaves optimized constructor feasibility unresolved; invalid encoding resolution precedes constructor.'],limits=['No frontend request reachability encoded here; Ruby prefix joined separately.','Zero-count append is an invocation, not positive copy. No new baseline IDs or graph mutations.','Python transfer fixtures exercise source-derived model, not Ruby/CGI runtime behavior.'])
 out=V/'tables/cgi_unescape_native_contract_v1.jsonl';out.write_text(json.dumps(row,sort_keys=True)+'\n')
 (V/'reports/cgi_unescape_native_contract_v1.json').write_text(json.dumps({'model_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'required_anchor_checks':checks,'source_evidence_records':len(evidence),'independent_review':'pending','witness':row['witness']},indent=2)+'\n')
 schema={'table':'cgi_unescape_native_contract_v1','primary_key':'model_id','foreign_keys':{'site_bindings.site_id':'primitive_sites.site_id','site_bindings.primitive_id':'c_primitives.primitive_id','registration_id':'c_registrations.registration_id'},'events':'Ordered source-model API invocations; source,count/capacity arguments, not dynamic execution or actualheapbytes.','source_evidence':'file,line,end_line,sha256,excerpt,required_anchors','conditions':'Applicability predicates; not inferred runtime facts.'}
 (V/'reports/cgi_unescape_native_schema_v1.json').write_text(json.dumps(schema,indent=2)+'\n')
if __name__=='__main__':emit()
