import pathlib,json,hashlib,importlib.util
V=pathlib.Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 f=V/'reports/c_module_composition_freeze_v3.json';freeze=json.loads(f.read_text());checks=0
 for x in freeze['files']:assert sha(V/x['path'])==x['sha256'];checks+=1
 s=importlib.util.spec_from_file_location('m',V/'scripts/c_module_composition_v3.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
 prefix='c = rb_define_class("Container", rb_cObject);\nm = rb_define_module_under(c, "Mixin");\nrb_define_method(m, "work", first, 1);\n'
 cases=[]
 examples=[('method_redefinition',prefix+'rb_define_method(m, "work", second, 1);\nrb_extend_object(c, m);'),('alias_overwrite',prefix+'rb_define_method(m, "other", second, 1);\nrb_define_alias(m, "work", "other");\nrb_extend_object(c, m);'),('post_extend_overwrite',prefix+'rb_extend_object(c, m);\nrb_define_method(m, "work", second, 1);'),('duplicate_namespace_alias',prefix+'n = rb_define_module_under(c, "Mixin");\nrb_define_method(n, "work", second, 1);\nrb_extend_object(c, m);')]
 examples.append(('unknown_alias_receiver_mutation',prefix+'n = m;\nrb_define_method(n, \"work\", second, 1);\nrb_extend_object(c, m);'))
 for label,src in examples:
  r=m.analyze(list(enumerate(src.splitlines(),1)));stale=[x for fact in r['facts'] for x in fact['registrations'] if x['ruby_name']=='work' and x['c_function']=='first'];assert not stale;checks+=1;cases.append(dict(case=label,source=src,status='PASS_obsolete_link_not_promoted',facts=r['facts']))
 facts=[json.loads(x) for x in (V/'tables/c_module_composition_v3.jsonl').read_text().splitlines()];assert len(facts)==2 and sum(len(x['registrations']) for x in facts)==12;checks+=1
 original=[json.loads(x) for x in (V/'tables/c_module_composition_v1.jsonl').read_text().splitlines()];assert [(x['composition_id'],[r['registration_id'] for r in x['registrations']]) for x in facts]==[(x['composition_id'],[r['registration_id'] for r in x['registrations']]) for x in original];checks+=1
 r=dict(status='PASS_bounded_corrected_model',freeze_sha256=sha(f),checks=checks,counterexample_regressions=cases,selected_CGI_composition_ids_and_registration_links_unchanged=True,source_semantics_review='Prior v1 independent actual-source semantics review still applies: extend adds singleton ancestors; prepend precedes local origin. V3 changes conservative source identity/name invalidation only.',prior_source_review_sha256=sha(V/'reports/c_module_composition_independent_review_v1.json'),limits=['Only actual CGI initializer application source reviewed; generic fixture pass is not production precision/recall.','Unknown constructs and duplicate namespace identities reject; overwritten names are discarded, not guessed last-write bindings.','Conditional on normal initializer and selected runtime APIs; no deployment load, method replacement closure or finaldispatch proof.'],runtime_execution=False)
 out=V/'reports/c_module_composition_independent_review_v3.json';out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(status=r['status'],sha256=sha(out),checks=checks)))
if __name__=='__main__':main()
