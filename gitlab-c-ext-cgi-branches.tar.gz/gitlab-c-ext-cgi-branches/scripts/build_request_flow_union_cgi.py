#!/usr/bin/env python3
"""Add four reviewed terminal records for one CGI source case; no baseline mutation."""
import argparse,copy,hashlib,json,collections
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');B=Path('/workspace/gitlab_c_ext_trace')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return [json.loads(l) for l in p.open() if l.strip()]
def ref(n):return {'path':n,'sha256':sha(V/n)}
def write(n,r):
 p=V/n;p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');return p
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--prefix-review',required=True);ap.add_argument('--prefix-review-sha256',required=True);args=ap.parse_args()
 prefix_review=json.loads((V/args.prefix_review).read_text());assert sha(V/args.prefix_review)==args.prefix_review_sha256
 assert prefix_review['status']=='PASS', 'Corrected generic prefix review required'
 assembly_name='reports/cgi_branches_independent_assembly_review.json';assembly=json.loads((V/assembly_name).read_text());assert assembly['status']=='PASS_selected_conditional_source_chain'
 recipe_name=assembly['recipe_path'];assert sha(V/recipe_name)==assembly['recipe_sha256'];recipe=rows(V/recipe_name)[0]
 supplement=assembly['required_supplement'];assert sha(V/supplement['path'])==supplement['sha256']
 native_name=recipe['native_contract']['path'];assert sha(V/native_name)==recipe['native_contract']['sha256'];native=rows(V/native_name)[0]
 nr=assembly['native_review'];assert sha(V/nr['path'])==nr['sha256'];native_review=json.loads((V/nr['path']).read_text());assert native_review['status']=='PASS';assert native_review['contract_sha256']==sha(V/native_name)
 prior_name='tables/request_flow_index_activity_pub_final.jsonl';prior_hash=sha(V/prior_name);prior=rows(V/prior_name);assert len(prior)==21
 events=native['witness']['events'];assert [(x['line'],x.get('count',x.get('capacity_argument'))) for x in events]==[(295,8),(298,2),(302,1),(306,3)]
 bindings={r['site_id']:r for r in native['site_bindings']};assert len(bindings)==4
 sites={r['site_id']:r for r in rows(B/'tables/primitive_sites.jsonl') if r['site_id'] in bindings}
 primitives={r['primitive_id']:r for r in rows(B/'tables/c_primitives.jsonl') if r['primitive_id'] in {e['primitive_id'] for e in events}}
 regs={r['registration_id']:r for r in rows(B/'tables/c_registrations.jsonl') if r['registration_id']==native['registration_id']};assert len(regs)==1
 source_binding=[]
 for e in events:
  s=sites[e['site_id']];p=primitives[e['primitive_id']];assert s['line']==e['line']==p['line'];assert s['operation']==e['operation'];assert native['gem_id'] in s['gem_ids'];assert sha(B/s['canonical_source_path'])==s['source_sha256'];source_binding.append({'site':s,'primitive':p})
 chosen=[r for r in recipe['route_scope_binding_candidates'] if r['api']=='resources' and r['line']==58 and r['method']=='index'];assert chosen
 mechanism='cgi_percent_unescape_native_buffer_and_append';case='branches_index_raw_query_cgi_key';flow_name='tables/cgi_branches_terminal_flows.jsonl';new=[]
 for e,role in zip(events,['encoded_capacity','literal_prefix','decoded_byte','literal_tail']):
  flow=copy.deepcopy(recipe);flow['historical_recipe_status']=flow.pop('status');flow['historical_recipe_review_status']=flow.pop('review_status',None);flow['review_status']='independent_selected_chain_and_corrected_prefix_pass';flow.update(flow_id=recipe['flow_id']+'_'+role,case_id=case,status='source_supported_conditional_recipe_with_independent_review',gitlab_sha='8d0e57e5f49543c53614b299aef70f7e5bb916ac',entrypoint_kind='rails_controller',phase='branches_index_json_response_block_raw_query_key_decode',selected_route_binding=chosen[0],source_recipe_reference=ref(recipe_name),independent_assembly_review=ref(assembly_name),required_forcing_supplement=supplement,corrected_prefix_review=ref(args.prefix_review),terminal_site_id=e['site_id'],terminal_primitive_ids=[e['primitive_id']],registration_ids=[native['registration_id']],terminal_operation=e['operation'],terminal_event=copy.deepcopy(e),argument_position_convention='1-based C primitive arguments',counting='One source case/mechanism represented by four existing physical terminal sites; not four independent routes or mechanisms.',vulnerability_claim=False)
  if role=='encoded_capacity':flow['terminal_arguments']=[{'position':1,'value':8,'influence':'derived_capacity_hint','derivation':'RSTRING_LEN(encoded key se%61rch); not decoded length6 or exact heap bytes'}]
  else:flow['terminal_arguments']=[{'position':2,'influence':'request_derived_content','source':e['source'],'start':e.get('start'),'byte':e.get('byte')},{'position':3,'value':e['count'],'influence':'source_fixed_count' if role=='decoded_byte' else 'derived_length_or_count','derivation':'fixed char buf[1] emits one byte; client controls decoded content, not this count' if role=='decoded_byte' else 'selected input scan offsets; prefix2 or remaining input8-5=3'}]
  flow['selected_route_binding_qualification']='Standard extensionless resource index at repository.rb58; alternative filtered/relative-root route candidates retained as historical evidence, not additional selected routes.'
  new.append(flow)
 (V/flow_name).write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in new))
 out=copy.deepcopy(prior)
 for i,f in enumerate(new,1):
  out.append(dict(flow_id=f['flow_id'],profile='ce',gitlab_sha=f['gitlab_sha'],scope_ledger='primary_source_profile',ledger_category='conditional_source_flow',original_status=f['status'],record_reference=dict(path=flow_name,file_sha256=sha(V/flow_name),line=i,flow_id=f['flow_id']),frontend_source_case_family=case,frontend_phase_case_id=case,frontend_phase=f['phase'],conditional_memory_influence_mechanism=mechanism,terminal_site_id=f['terminal_site_id'],terminal_primitive_ids=f['terminal_primitive_ids'],terminal_operation=f['terminal_operation'],registration_ids=f['registration_ids'],influence_class=[x['influence'] for x in f['terminal_arguments']],current_route_evidence=dict(selected_route=f['selected_request']['path_template'],source_binding=chosen[0],runtime_exposure_proven=False),source_model_applicability=dict(source_recipe_reference=ref(recipe_name),native_contract_reference=ref(native_name),forcing_supplement=supplement,corrected_prefix_review=ref(args.prefix_review),conditions=f['conditions']),automatic_verified_label=False,current_runtime_execution_claim=False,vulnerability_claim=False,counting_qualification=f['counting']))
 assert len(out)==len({x['flow_id'] for x in out})==25
 checks=[];cache={}
 for x in out:
  rr=x['record_reference'];p=V/rr['path'];assert sha(p)==rr['file_sha256'];cache.setdefault(str(p),rows(p));f=cache[str(p)][rr['line']-1]
  for k in ['flow_id','profile','terminal_site_id']:assert f[k]==x[k]
  checks.append({'flow_id':x['flow_id'],'hash_line_id_profile_site':'PASS'})
 primary=[r for r in out if r['ledger_category']=='conditional_source_flow'];partial=[r for r in out if r['ledger_category']=='partial'];aux=[r for r in out if r['ledger_category']=='auxiliary_version_conditioned_flow'];main_sites={r['terminal_site_id'] for r in primary};old_sites={r['terminal_site_id'] for r in prior if r['ledger_category']=='conditional_source_flow'}
 counts=dict(total_reference_rows=len(out),main_conditional_terminal_flow_records=len(primary),main_partial_records=len(partial),main_conditional_by_profile=dict(collections.Counter(r['profile'] for r in primary)),main_conditional_physical_sites=len(main_sites),main_conditional_native_mechanisms=len({r['conditional_memory_influence_mechanism'] for r in primary}),auxiliary_version_conditioned_flows=len(aux),auxiliary_physical_sites=len({r['terminal_site_id'] for r in aux}),new_conditional_terminal_records=4,new_source_cases=1,new_conditional_physical_sites=len(main_sites-old_sites),new_native_mechanisms=1,main_conditional_source_case_families=len({r['frontend_source_case_family'] for r in primary}),independent_external_route_count=None,actual_deployed_union_proven=False)
 assert [counts[k] for k in ['main_conditional_terminal_flow_records','main_partial_records','main_conditional_physical_sites','main_conditional_native_mechanisms','auxiliary_version_conditioned_flows']]==[22,2,9,5,1]
 output='tables/request_flow_index_cgi_final.jsonl';(V/output).write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in out));assert sha(V/prior_name)==prior_hash
 base='reports/request_flow_index_cgi_final_';paths=[V/output,V/flow_name]
 paths.append(write(base+'counts.json',{'counts':counts,'main_sites':sorted(main_sites),'new_sites':sorted(main_sites-old_sites),'not_recall_estimate':True}))
 paths.append(write(base+'integrity.json',dict(status='PASS',checks=checks,native_existing_id_checks=source_binding,registration=regs[native['registration_id']],prior_index_sha256_preserved=prior_hash,input_references=[ref(prior_name),ref(recipe_name),ref(native_name),ref(assembly_name),supplement,ref(args.prefix_review)],frozen_inputs_mutated=False)))
 paths.append(write(base+'schema.json',dict(table=output,primary_key='flow_id',flow_table=flow_name,reference='V3-relative path+whole-file SHA256+1-based line+flow_id; profile/site exact joins',argument_positions='1-based C primitive arguments',scope='Four physical terminal records, one source case/mechanism; conditional dispatch and runtime assumptions retained')))
 paths.append(write('schemas/cgi_branches_terminal_flows.schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','type':'object','required':['flow_id','profile','terminal_site_id','terminal_primitive_ids','terminal_arguments','required_forcing_supplement','corrected_prefix_review'],'properties':{'flow_id':{'type':'string'},'profile':{'const':'ce'},'runtime_execution':{'const':False},'automatic_verified_label':{'const':False},'terminal_site_id':{'type':'string'},'terminal_arguments':{'type':'array','minItems':1}}}))
 paths.append(Path(__file__));write(base+'checksums.json',{'files':[dict(path=str(p.relative_to(V)),sha256=sha(p),bytes=p.stat().st_size) for p in paths],'reproduce_command':f'python scripts/build_request_flow_union_cgi.py --prefix-review {args.prefix_review} --prefix-review-sha256 {args.prefix_review_sha256}'})
 print(json.dumps(counts))
if __name__=='__main__':main()
