import hashlib,json,pathlib
from raw_query_find_prefix_model import query_prefix,shape_guard
V=pathlib.Path(__file__).resolve().parents[1];B=pathlib.Path('/workspace/gitlab_c_ext_trace');checks=0
def check(x):
 global checks
 checks+=1;assert x
r=json.loads((V/'tables/request_memory_flows_cgi_branches.jsonl').read_text());m=json.loads((V/'tables/raw_query_find_prefix_transfer_model.jsonl').read_text())
for e in r['source_evidence']+m['source_evidence']:
 d=(B/e['file']).read_bytes();check(hashlib.sha256(d).hexdigest()==e['sha256']);check('\n'.join(d.decode().splitlines()[e['line']-1:e['end_line']])==e['excerpt'])
check(shape_guard((B/'sources/gitlab/app/controllers/projects/branches_controller.rb').read_bytes(),'search_param_from_raw_query_string'))
check(r['selected_transfer']==query_prefix(r['selected_request']['QUERY_STRING'].encode()))
check(r['selected_request']['path_template'].endswith('/branches'));check(r['selected_request']['HTTP_ACCEPT']=='application/json');check(not r['runtime_execution'] and not r['automatic_verified_label'] and not r['baseline_graphs_mutated']);check(r['argument_transfer']['encoded_byte_length']==8)
p=V/r['native_contract']['path'];check(hashlib.sha256(p.read_bytes()).hexdigest()==r['native_contract']['sha256']);n=json.loads(p.read_text());check(n['model_id']==r['native_contract']['model_id']);check(n['registration_id']==r['native_contract']['registration_id']);check(n['site_bindings']==r['native_contract']['site_bindings'])
report=dict(status='pass',checks=checks,errors=0,scope='Source evidence/hash, exact template guard, transfer and native contract reference; independent semantic review still required')
(V/'reports/cgi_branches_recipe_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
