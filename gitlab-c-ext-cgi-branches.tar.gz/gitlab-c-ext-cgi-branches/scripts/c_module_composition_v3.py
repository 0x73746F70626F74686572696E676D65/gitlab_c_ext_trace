#!/usr/bin/env python3
"""Narrow straight-line C initializer model. Generic rules, CGI-only application."""
import hashlib,json,re
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_trace');V=Path('/workspace/gitlab_c_ext_v3')
IDENT=r'[A-Za-z_]\w*'
def analyze(lines):
 env={};definitions=[];regs=[];facts=[];unsupported=[];invalidated=set()
 for line,text in lines:
  t=text.strip()
  if not t:continue
  m=re.fullmatch(r'('+IDENT+r')\s*=\s*(rb_define_class|rb_define_module)\("([A-Za-z_]\w*)"(?:,\s*'+IDENT+r')?\);',t)
  if m:
   var,api,name=m.groups();obj={'identity':f'object_at_{line}','name':name,'kind':'class' if api=='rb_define_class' else 'module','line':line};env[var]=obj;definitions.append(dict(variable=var,**obj));continue
  m=re.fullmatch(r'('+IDENT+r')\s*=\s*(rb_define_module_under|rb_define_class_under)\(('+IDENT+r'),\s*"([A-Za-z_]\w*)"(?:,\s*'+IDENT+r')?\);',t)
  if m:
   var,api,parent,name=m.groups();base=env.get(parent);obj=None if not base else {'identity':f'object_at_{line}','name':base['name']+'::'+name,'kind':'module' if api=='rb_define_module_under' else 'class','line':line};env[var]=obj
   if obj:definitions.append(dict(variable=var,**obj))
   continue
  m=re.fullmatch(r'('+IDENT+r')\s*=\s*('+IDENT+r');',t)
  if m:env[m[1]]=None;continue # alias/rebinding not proved; fail closed
  m=re.fullmatch(r'rb_define_method\(('+IDENT+r'),\s*"([^"\\]+)",\s*('+IDENT+r'),\s*(-?\d+)\);',t)
  if m:
   owner=env.get(m[1])
   if not owner:unsupported.append(dict(line=line,text=t,reason='method mutation through unresolved receiver may alias known object'))
   key=(owner['identity'],m[2]) if owner else None
   if key and any(r['owner'] and (r['owner']['identity'],r['ruby_name'])==key for r in regs):invalidated.add(key)
   regs.append(dict(owner=owner,receiver_variable=m[1],ruby_name=m[2],c_function=m[3],arity=m[4],line=line));continue
  m=re.fullmatch(r'rb_define_alias\(('+IDENT+r'),\s*"([^"\\]+)",\s*"[^"\\]+"\);',t)
  if m:
   owner=env.get(m[1])
   if owner:invalidated.add((owner['identity'],m[2]))
   else:unsupported.append(dict(line=line,text=t,reason='alias mutation through unresolved receiver may affect known object'))
   continue # alias target not resolved; invalidate alias name conservatively
  m=re.fullmatch(r'(rb_extend_object|rb_prepend_module)\(('+IDENT+r'),\s*('+IDENT+r')\);',t)
  if m:
   api,a,b=m.groups();target=env.get(a);module=env.get(b);known=bool(target and module and module['kind']=='module');bindings=[]
   if known:bindings=[r for r in regs if r['owner'] and r['owner']['identity']==module['identity'] and (module['identity'],r['ruby_name']) not in invalidated]
   facts.append(dict(line=line,api=api,target_variable=a,module_variable=b,target=target,module=module,status='conditional_source_composition' if known else 'unresolved_objects',relation='module_instance_methods_available_via_receiver_singleton_class' if api=='rb_extend_object' else 'module_precedes_receiver_instance_method_origin',registrations=bindings));continue
  unsupported.append(dict(line=line,text=t,reason='outside narrow straight-line initializer grammar; control/unknown effects not resolved'))
 names=[d['name'] for d in definitions]
 if len(names)!=len(set(names)):unsupported.append(dict(line=None,text=None,reason='duplicate qualified namespace definitions may alias one runtime object'))
 for fact in facts:
  fact['registrations']=[r for r in fact['registrations'] if (r['owner']['identity'],r['ruby_name']) not in invalidated]
 if unsupported:
  for fact in facts:fact['status']='unresolved_initializer_construct';fact['registrations']=[]
 return dict(definitions=definitions,facts=facts,unsupported=unsupported,invalidated_method_keys=[list(x) for x in sorted(invalidated)])

def emit():
 source='sources/gems/cgi-0.5.1/ext/cgi/escape/escape.c';d=(R/source).read_bytes();all_lines=d.decode().split('\n');result=analyze(list(enumerate(all_lines[473:486],474)))
 # Narrow selected initializer body independently anchored before extraction.
 assert all_lines[471]=='InitVM_escape(void)' and all_lines[472]=='{' and all_lines[486]=='}'
 fid='file_cea9420e2c8b2abd7fdf7dc6'
 regs={x['line']:x for x in map(json.loads,(R/'tables/c_registrations.jsonl').open()) if x['file_id']==fid and x['registration_api']=='rb_define_method'}
 ns={x['line']:x for x in map(json.loads,(R/'tables/c_namespaces.jsonl').open()) if x['file_id']==fid}
 calls={}
 for text in (R/'tables/c_calls.jsonl').open():
  if fid not in text:continue
  x=json.loads(text)
  if x['line'] in (485,486):calls[x['line']]=x
 facts=[]
 for fact in result['facts']:
  call=calls[fact['line']];assert call['callee']==fact['api'] and call['arguments']==[fact['target_variable'],fact['module_variable']]
  fact.update(composition_id='composition_'+hashlib.sha256(call['call_id'].encode()).hexdigest()[:24],call_id=call['call_id'],function_id=call['function_id'],file_id=fid,file=source,source_sha256=hashlib.sha256(d).hexdigest(),source_line=all_lines[fact['line']-1],activation='Conditional on this initializer executing normally after successful extension loading; InitVM mapping supported by frozen CGI contract.',limitations=['No inter-TU/global mutation closure or runtime method replacement proof.','Exact direct registration matches only; aliases and later method definitions not enumerated.','Extend adds module into singleton ancestors; existing singleton methods or other ancestors may override, so not proven final dispatch.','Prepend precedence is local origin order, not full ancestor graph or runtime dispatch.'])
  for which in ['target','module']:
   obj=fact[which]
   if obj:obj['namespace_id']=ns[obj['line']]['namespace_id']
  for reg in fact['registrations']:
   original=regs[reg['line']];assert original['ruby_name']==reg['ruby_name'] and original['c_function_expression']==reg['c_function'];reg['registration_id']=original['registration_id'];reg['c_function_id']=original['c_function_id']
  facts.append(fact)
 ev=[dict(file=source,line=472,end_line=487,sha256=hashlib.sha256(d).hexdigest(),excerpt='\n'.join(all_lines[471:487]),required_anchor='rb_extend_object(rb_cCGI, rb_mEscapeExt);')]
 for file,a,b,anchor in [('sources/runtime/ruby-v3_3_11/eval.c',1712,1716,'rb_include_module(rb_singleton_class(obj), module)'),('sources/runtime/ruby-v3_3_11/class.c',1429,1445,'do_include_modules_at(klass, klass, module, FALSE, false)')]:
  raw=(R/file).read_bytes();excerpt='\n'.join(raw.decode().split('\n')[a-1:b]);assert anchor in excerpt;ev.append(dict(file=file,line=a,end_line=b,sha256=hashlib.sha256(raw).hexdigest(),excerpt=excerpt,required_anchor=anchor))
 (V/'tables/c_module_composition_v3.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in facts))
 report=dict(scope='Only CGI0.5.1 InitVM_escape applied; generic rules tested with unrelated names',facts=len(facts),direct_registration_links=sum(len(f['registrations']) for f in facts),source_evidence=ev,unsupported=result['unsupported'],invalidated_method_keys=result['invalidated_method_keys'],supersedes='v1 same-name method overwrite and v2 duplicate namespace aliases could retain obsolete C links; v3 fails closed; selected CGI unchanged',runtime='Ruby3.3.11 API model applicability conditional; no actual load/dispatch proof',existing_frozen_contract_unchanged=True)
 (V/'reports/c_module_composition_v3.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='source_evidence'}))
if __name__=='__main__':emit()
