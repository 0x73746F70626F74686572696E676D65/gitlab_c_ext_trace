import pathlib,json,hashlib,importlib.util
V=pathlib.Path(__file__).resolve().parents[1];B=pathlib.Path('/workspace/gitlab_c_ext_trace')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 f=V/'reports/c_module_composition_freeze_v1.json';freeze=json.loads(f.read_text());checks=0
 for x in freeze['files']:assert sha(V/x['path'])==x['sha256'];checks+=1
 report=json.loads((V/'reports/c_module_composition_v1.json').read_text())
 for e in report['source_evidence']:
  p=B/e['file'];assert sha(p)==e['sha256'];assert '\n'.join(p.read_text().splitlines()[e['line']-1:e['end_line']])==e['excerpt'];checks+=2
 s=importlib.util.spec_from_file_location('m',V/'scripts/c_module_composition_v1.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
 prefix='c = rb_define_class("Container", rb_cObject);\nm = rb_define_module_under(c, "Mixin");\nrb_define_method(m, "work", first, 1);\n'
 cases=[]
 for label,extra in [('method_redefinition','rb_define_method(m, "work", second, 1);'),('alias_overwrite','rb_define_method(m, "other", second, 1);\nrb_define_alias(m, "work", "other");')]:
  src=prefix+extra+'\nrb_extend_object(c, m);';r=m.analyze(list(enumerate(src.splitlines(),1)));old=[x for x in r['facts'][0]['registrations'] if x['ruby_name']=='work' and x['c_function']=='first'];assert old;cases.append(dict(case=label,source=src,obsolete_direct_registration_retained=True))
 facts=[json.loads(x) for x in (V/'tables/c_module_composition_v1.jsonl').read_text().splitlines()];assert len(facts)==2 and sum(len(x['registrations']) for x in facts)==12
 for fact in facts:
  names=[x['ruby_name'] for x in fact['registrations']];assert len(names)==len(set(names))==6;checks+=1
 d=dict(status='PASS_selected_CGI_application_only',freeze_sha256=sha(f),checks=checks,source_semantics=['Ruby rb_extend_object includes module in receiver singleton class; availability does not outrank existing singleton definitions.','Ruby rb_prepend_module checks cycles and inserts ahead of origin; no full dynamic ancestor graph or activation proof.','Actual CGI initializer has six unique direct method names; two alias destinations differ from all six and do not invalidate emitted links.'],generic_model_status='KNOWN_UNSAFE_for_same_name_redefinition_or_alias_overwrite',counterexamples=cases,limits=['Do not apply v1 generically without explicit no-overwrite qualification or corrected model.','Conditional on successful normal initializer, pinned selected API behavior and no later replacement.','This is source composition, not proven final Ruby method dispatch.'],runtime_execution=False)
 p=V/'reports/c_module_composition_independent_review_v1.json';p.write_text(json.dumps(d,indent=2)+'\n');print(sha(p))
if __name__=='__main__':main()
