import json,pathlib,collections
B=pathlib.Path('/workspace/gitlab_c_ext_trace');D=B/'audit/end_to_end_20260930'
rs=[]
for p in [D/'sample_ruby_analysis.jsonl',*D.glob('duplicate_*_ruby_analysis.jsonl')]:rs.extend(json.loads(l) for l in p.open())
want={h.get('target_id') for r in rs for h in r['ruby_hops'] if h.get('target_type')=='ruby_method'}|{h.get('method_id') for r in rs for h in r['ruby_hops']}
mid={};inh={};aliases={};need_i={i for r in rs for h in r['ruby_hops'] for i in h.get('receiver_inheritance_ids',[])};need_a={i for r in rs for h in r['ruby_hops'] for i in h.get('receiver_alias_ids',[])}
for root in [pathlib.Path('/workspace/gitlab_c_ext_ruby_expanded'),pathlib.Path('/workspace/gitlab_c_ext_ee_profile')]:
 for name,key,ids,dest in [('ruby_methods','method_id',want,mid),('ruby_inheritance','inheritance_id',need_i,inh),('ruby_constant_aliases','alias_id',need_a,aliases)]:
  for l in (root/'tables'/(name+'.jsonl')).open():
   r=json.loads(l)
   if r[key] in ids:dest[r[key]]=r
cache={}
def span(file,line,before=4,after=7):
 if file not in cache:cache[file]=(B/file).read_text(errors='replace').splitlines()
 lines=cache[file];return '\n'.join(f'{i+1}: {lines[i]}' for i in range(max(0,line-before-1),min(len(lines),line+after)))
for r in rs:
 parts=[r['audit_id']+' '+r['path']['path_id']]
 for ev in r['entrypoint'].get('route_evidence',[])+r['exposure'].get('registration_evidence',[]):
  if ev.get('file') and ev.get('line'):parts+=['EXPOSURE '+ev['file'],span(ev['file'],ev['line'],5,8)]
 for h in r['ruby_hops']:
  parts+=['RUBY '+json.dumps(h),span(h['file'],h['line'],5,8)]
  m=mid.get(h.get('target_id'))
  if m:parts+=['TARGET '+json.dumps(m),span(m['file'],m['line'],1,min(25,m['end_line']-m['line']))]
  for i in h.get('receiver_inheritance_ids',[]):
   v=inh[i];parts+=['INHERIT '+json.dumps(v),span(v['file'],v['line'],1,2)]
  for i in h.get('receiver_alias_ids',[]):
   v=aliases[i];parts+=['ALIAS '+json.dumps(v),span(v['file'],v['line'],1,2)]
 for h in r['native_hops']:
  parts+=['NATIVE '+json.dumps(h),span(h['file'],h['line'],4,7)]
  if h.get('target_file'):parts+=['NATIVE TARGET',span(h['target_file'],h['target_line'],1,5)]
 (D/(r['audit_id']+'_ruby_dossier.txt')).write_text('\n'.join(parts))
(D/'ruby_review_support.json').write_text(json.dumps(dict(methods=mid,inheritance=inh,aliases=aliases)))
print('Wrote',len(rs),'source dossiers')
