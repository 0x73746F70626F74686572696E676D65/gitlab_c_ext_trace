import pathlib,json,collections
R=pathlib.Path('/workspace/gitlab_c_ext_trace');A=R/'audit/end_to_end_20260930'
rows=[json.loads(l) for p in [A/'sample_provenance_validation.jsonl',*sorted(A.glob('duplicate_*_provenance_validation.jsonl'))] for l in p.open()]
m=json.loads((A/'provenance_targets.json').read_text());O='sources/gems/oj-3.17.6/ext/oj/';J='sources/gems/json-2.21.2/lib/json/common.rb';N='sources/gems/nokogiri-1.19.4/lib/nokogiri/';Z='sources/gems/zlib-3.2.3/ext/zlib/zlib.c';out=[]
def evidence(f,l):
 lines=(R/f).read_text(errors='replace').split('\n');return {'file':f,'line':l,'context':lines[l-1]}
for s in rows:
 aid=s['audit_id']; hs=[];base='sources/gitlab/' if s['profile']=='ce' else 'sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/'
 for h in s['ruby_hops']+s['native_hops']:
  f,l=h['file'],h['line']; typ=h.get('type',h.get('kind')); v='supported';why='';ev=[evidence(f,l)]
  if typ=='entrypoint':
   why='Actual source declares this route/mutation/middleware; this supports conditional static exposure only, not runtime mounting, authorization, or request feasibility.'
   for e in s['exposure'].get('registration_evidence',[]):
    if 'file' in e and 'line' in e:ev.append(evidence(e['file'],e['line']))
  elif typ=='method_body':why='Source contains the selected handler body; inherited mutation handlers remain conditioned on the recorded subclass declaration and framework dispatch.'
  elif typ=='ruby_dispatch':
   t=m.get(h.get('target_id'))
   if t:ev.append(evidence(t['file'],t['line']));why=f"Source call expression and selected definition {t['namespace']}#{t['method']} agree structurally; receiver is {h.get('receiver') or 'lexical self'}. This is a local call relation, not a proof all guards on the composed path are feasible."
   else:why='Ruby call names the native receiver/API; C registration is inspected in the next hop. Native extension loading and build remain conditional.'
  elif typ=='registration_to_function':
   why='Actual rb_define registration binds this Ruby method to the named C function; C definition location also checked. Installation/execution of the registration is a separate condition.'
   if h.get('target_file'):ev.append(evidence(h['target_file'],h['target_line']))
  elif typ=='c_call':
   why='Actual C call expression names the selected function and argument expression; target definition inspected. Preprocessor/build selection and guards remain conditional.'
   ev.append(evidence(h['target_file'],h['target_line']))
  else:why='Primitive expression exists in the selected C function at this source line; API classification is an operation candidate, not proof it allocates or is user-controlled.'
  if f.endswith('lib/json_schemer.rb') and l==253:
   v='contradicted';why='Composed path passes Event.json_schema, the parsed object from the retained json_schema_draft07.json (top-level object). resolve only executes this JSON.parse call for String; the Hash argument selects the other branch. The syntactic call exists but cannot be this continuation.'
   ev += [evidence(base+'lib/gitlab/event_store/event.rb',87 if s['profile']=='ce' else 81),evidence(base+'lib/gitlab/event_store/json_schema_draft07.json',1),evidence(f,252)]
  if f==N+'html5.rb' and l==29:
   v='contradicted';why='HTML5::Document defines its own singleton parse, so ancestor HTML4::Document.parse is not the selected receiver method. The own method dispatches do_parse to Nokogiri::Gumbo.parse. Ancestor-union lookup creates this false continuation.'
   ev += [evidence(N+'html5/document.rb',103),evidence(N+'html5/document.rb',123),evidence(N+'html5/document.rb',153)]
  if f==N+'html4/document.rb' and l==215 and aid in {'A067','A062'}:
   v='contradicted';why='Even as an HTML4 receiver, read_io has an own HTML4 native registration (html4_document.c164), overriding XML::Document.read_io selected here. In the actual incoming path HTML5 also defines its own read_io.'
   ev += [evidence('sources/gems/nokogiri-1.19.4/ext/nokogiri/html4_document.c',164),evidence(N+'html5/document.rb',129)]
  if f==J and l==363:
   v='contradicted';why='Caller JSONSchemer invokes JSON.parse(schema) with no options. opts defaults nil, so the unless opts.nil? guard skips ParserOptions.prepare.';ev += [evidence(J,362)]
  if f==J and l==74:
   v='unresolved';why='This call is inside the lambda assigned to opts[:on_load] at line62. Calling create_additions_proc constructs a callback; the listed chain lacks an invocation edge for that lambda. It is not an immediate method-body continuation.';ev += [evidence(J,62)]
  if f.endswith('jwt/decode.rb') and l==66:
   v='contradicted';why='set_key returns at64 unless options[:x5c]. HMACToken.decode supplies only leeway, verify_iat and algorithm; JWT DecodeConfiguration#to_h enumerates keys without x5c. The retained call/configuration cannot select this X5cKeyFinder branch.'
   ev += [evidence('sources/gitlab/lib/json_web_token/hmac_token.rb',17),evidence('sources/expansion/jwt-2.10.3--jwt/lib/jwt/configuration/decode_configuration.rb',54),evidence(f,64)]
  if f==Z and l==2965:
   v='contradicted';why='CompressedJson calls read(length) with one argument. rb_scan_args("02") leaves second outbuf nil, passed unchanged to gzfile_read. This terminal requires !NIL_P(outbuf), hence cannot execute for the sampled call.';ev += [evidence(Z,4088),evidence(Z,2964)]
  if f==O+'oj.c' and l==1499:
   v='contradicted';why='Gitlab::Json.adapter_load calls standardize_opts, which sets mode=:rails. load reads that explicit mode and selects RailsMode -> oj_compat_parse at1501; sampled StrictMode/NullMode -> oj_strict_parse is infeasible.';ev += [evidence(base+'gems/gitlab-utils/lib/gitlab/json.rb',204),evidence(O+'oj.c',1484),evidence(O+'oj.c',1501)]
  if f==O+'strict.c' and l==172:
   v='contradicted';why='Incoming input is File.read of the schema, a String; strict parser dispatch at169 selects oj_pi_parse, not non-String sparse branch. This is independent of the earlier wrong-mode edge.';ev += [evidence(O+'strict.c',169)]
  if f==O+'mimic_json.c' and l==390:
   v='contradicted';why='Gitlab::Json calls Oj.generate(object, opts), so argc is2 and preserved by oj_mimic_generate. mimic_generate_core selects argc>1 at382; sampled implicit-mimic call390 exists only in the else branch.';ev += [evidence(base+'gems/gitlab-utils/lib/gitlab/json.rb',194),evidence(O+'mimic_json.c',382)]
  if f==O+'dump_compat.c' and l==895:
   v='contradicted';why='The selected preceding direct call passes depth=0. Options from Gitlab::Json.generate(graph) contain no max_nesting; oj_parse_mimic_dump_options sets max_depth=MAX_DEPTH (positive). Guard max_depth<=depth at890 is false for this root call; recursive nested calls would be a different witness.';ev += [evidence(O+'dump.c',818),evidence(O+'mimic_json.c',100),evidence(O+'dump_compat.c',890)]
  if f==O+'dump.c' and l==827:
   v='unresolved';why='This assure_size call requires out->indent>0. Oj initial default indent is0 and Gitlab passes no indent; a global default-options mutation could change this. No activation evidence for positive indent on this path was found, so actual predicate support is unresolved.';ev += [evidence(O+'oj.c',182),evidence(O+'dump.c',824)]
  if typ=='ruby_dispatch' and h.get('target_type')=='registration' and h.get('receiver') in {'JSON','::JSON'}:
   if v!='contradicted':v='unresolved';why='Selected Oj mimic registration replaces JSON methods only when mimic_JSON installation runs. Merely requiring Oj does not establish activation. No installer path is included; Gitlab Json pretty_generate explicitly calls standard JSON. Actual binding remains unresolved.'
   ev += [evidence(O+'oj.c',2288),evidence(O+'mimic_json.c',910)]
  if f==O+'parse.c' and l==1340 and aid=='A011':
   v='unresolved';why='Terminal is error-only and requires CompatMode/RailsMode plus an error. This chain reads the retained valid schema; sc_parse copies mutable Oj defaults. Neither the needed mode nor error feasibility is established by the sampled hops.';ev += [evidence(O+'parse.c',1326),evidence(O+'parse.c',1331),evidence(O+'scp.c',129)]
  if f==O+'parse.c' and l==1266 and aid in {'A015','A043'}:
   v='unresolved';why='This is specifically the Empty-input branch requiring Qundef at stack.head, not a generic parser-error edge. The sampled subsequent key/array stack formatting needs separate stack-state feasibility. Static call matching does not establish those compatible predicates.';ev += [evidence(O+'parse.c',1264),evidence(O+'parse.c',1116)]
  if aid=='A075' and f==Z and l==925:
   why='Source-supported conditional terminal: gzip header reads into hidden internal string via gzfile_read_raw_ensure -> zstream_append_input (rb_obj_hide); discarding10 bytes leaves positive newlen when input has payload, satisfying this branch. rb_str_set_len is length mutation, not itself allocation proof.';ev += [evidence(Z,2626),evidence(Z,891),evidence(Z,909)]
  hs.append({'hop_id':h['hop_id'],'kind':typ,'verdict':v,'evidence':ev,'reason':why})
 statuses={h['verdict'] for h in hs};status='contradicted' if 'contradicted' in statuses else 'unresolved' if 'unresolved' in statuses else 'supported_static_chain'
 out.append({'audit_id':aid,'path_id':s['path']['path_id'],'dataset_id':s['dataset_id'],'profile':s['profile'],'status':status,'reviewer':'provenance_validation','review_method':'Manual inspection of actual LF-numbered source call/registration/terminal windows, target definitions, and named guard/override contexts; shared hop inspections reused across samples. No execution.','hops':hs,'runtime_exposure':'unknown','authorization':'unknown','attacker_data_control':'unknown','runtime_feasibility':'Not proven; concrete contradictory predicates flagged separately from general unknown execution conditions.','conditional_compilation_and_loading':'unknown','source_package_equivalence':'version-associated retained source, not published-package byte proof','limitations':'Supporting local relations does not resolve every possible prepend/monkeypatch or indirect callback; no absence-of-other-definitions proof. Overall supported_static_chain is conditional static source support, not runtime reachability.'})
with (A/'review_provenance_validation.jsonl').open('w') as f:
 for x in out:f.write(json.dumps(x)+'\n')
counts=collections.Counter(x['status'] for x in out);print(dict(counts));print([(x['audit_id'],x['status']) for x in out]);(A/'provenance_review_summary.json').write_text(json.dumps({'rows':len(out),'counts':counts,'hop_count':sum(len(x['hops']) for x in out),'all_assigned_ids_present':True},indent=2))
