import json,pathlib,hashlib,collections
R=pathlib.Path('/workspace/gitlab_c_ext_trace');D=R/'audit/end_to_end_20260930'
A=[json.loads(s) for p in [D/'sample_native_analysis.jsonl',*D.glob('duplicate_*_native_analysis.jsonl')] for s in p.open()]
M=json.loads((D/'native_review_target_methods.json').read_text()); cache={}
def ev(f,n,end=None):
 if f not in cache:cache[f]=(R/f).read_text(errors='replace').split('\n')
 return {'file':f,'line':n,'end_line':end or n,'source':'\n'.join(cache[f][n-1:end or n])}
S='sources/gems/';E='sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/';J='sources/expansion/json_schemer-2.4.0--davishmcclurg/lib/json_schemer.rb'
manual={}
def add(aid,match,status,reason,evidence):manual.setdefault(aid,[]).append((match,status,reason,evidence))
for x in A:
 aid=x['audit_id']
 if any(h['file']==J and h['line']==253 for h in x['ruby_hops']):
  pre='sources/gitlab/' if x['profile']=='ce' else E
  event=pre+'lib/gitlab/event_store/event.rb';lines=(R/event).read_text().split('\n');ln=next(i+1 for i,v in enumerate(lines)if '@json_schema ||=' in v)
  add(aid,lambda h:h['file']==J and h['line']==253,'contradicted','The caller passes Event.json_schema, the parsed retained draft07 JSON object (Hash); resolve only invokes JSON.parse in its String arm. Hash follows else/schema. These real call sites cannot compose for this argument.',[ev(event,ln),ev(pre+'lib/gitlab/event_store/json_schema_draft07.json',1,4),ev(J,250,253),ev(J,264,266)])
for aid in ['A024','A028','A023']:
 add(aid,lambda h:h['file'].endswith('/nokogiri/html5.rb') and h['line']==29,'contradicted','HTML5::Document declares its own singleton parse; inherited HTML4::Document.parse is shadowed. The selected target method belongs to HTML4. HTML5 routes to do_parse/Gumbo, not the selected libxml read_memory/read_io registrations.',[ev(S+'nokogiri-1.19.4/lib/nokogiri/html5/document.rb',103,110),ev(S+'nokogiri-1.19.4/lib/nokogiri/html5/document.rb',123,145),ev(S+'nokogiri-1.19.4/lib/nokogiri/html5/document.rb',149,154)])
add('A020',lambda h:h.get('primitive')=='rb_intern','contradicted','StringScanner.new(str) supplies one positional argument. rb_scan_args("11") leaves optional options nil; selected rb_intern is guarded by !NIL_P(options), so this terminal is excluded for the shown call.',[ev('sources/expansion/parslet-1.8.2--kschiess/lib/parslet/source.rb',18),ev(S+'strscan-3.1.8/ext/strscan/strscan.c',297,303)])
for aid in ['A032','A072']:
 add(aid,lambda h:h['file'].endswith('/jwt/decode.rb') and h['line']==66,'contradicted','Selected X5c path requires @options[:x5c]. HMACToken.decode passes only leeway/verify_iat/algorithm; JWT decode merges these with DecodeConfiguration.to_h, whose enumerated keys do not contain x5c. No x5c option enters this chain under the retained definitions.',[ev(('sources/gitlab/' if aid=='A032' else E)+'lib/json_web_token/hmac_token.rb',16,17),ev('sources/expansion/jwt-2.10.3--jwt/lib/jwt.rb',49,51),ev('sources/expansion/jwt-2.10.3--jwt/lib/jwt/configuration/decode_configuration.rb',56,70),ev('sources/expansion/jwt-2.10.3--jwt/lib/jwt/decode.rb',61,66)])
add('A032',lambda h:h.get('primitive')=='rb_intern','contradicted','Even if the earlier x5c hole were supplied, Certificate.new receives Base64-decoded String. The selected rb_intern(read) occurs only when obj is T_FILE; StringValue path bypasses it.',[ev('sources/expansion/jwt-2.10.3--jwt/lib/jwt/x5c_key_finder.rb',47),ev('sources/expansion/jwt-2.10.3--jwt/lib/jwt/base64.rb',20,21),ev(S+'openssl-3.3.3/ext/openssl/ossl_bio.c',13,22)])
add('A040',lambda h:h.get('callee')=='oj_define_mimic_json','contradicted','Gitlab adapter always passes Oj.generate(object, opts), so argc=2. Selected initialization call lies in else of argc>1 and cannot execute for that arity.',[ev('sources/gitlab/gems/gitlab-utils/lib/gitlab/json.rb',191,194),ev(S+'oj-3.17.6/ext/oj/mimic_json.c',382,390)])
add('A044',lambda h:h.get('callee')=='oj_err_set','contradicted','This predecessor is the String oj_pi_parse path, which sets pi->json to RSTRING_PTR. Selected oj_set_error_at branch calls oj_err_set only when pi->json==0 (stream input); string path takes _oj_err_set_with_location instead.',[ev(S+'oj-3.17.6/ext/oj/scp.c',180,183),ev(S+'oj-3.17.6/ext/oj/parse.c',1153,1161),ev(S+'oj-3.17.6/ext/oj/parse.c',1192,1199),ev(S+'oj-3.17.6/ext/oj/parse.c',1138,1142)])
add('A048',lambda h:h['file'].endswith('/gitlab/json.rb') and h['line']==116,'unresolved','Literal JSON receiver is supported, but selecting optional yajl/json_gem/encoding monkeypatch over the JSON gem definition needs load/override evidence absent from this witness. Source declaration in an optional compatibility file is not sufficient to establish active receiver binding.',[ev(S+'yajl-ruby-1.4.3/lib/yajl/json_gem/encoding.rb',1,5),ev(S+'yajl-ruby-1.4.3/lib/yajl/json_gem/encoding.rb',32,37)])
add('A064',lambda h:h.get('callee')=='oj_pi_sparse','contradicted','Even if earlier Hash contradiction were ignored, JSONSchemer JSON.parse call is only in String arm. mimic_parse_core routes String inputs to oj_pi_parse, not selected oj_pi_sparse else branch.',[ev(J,250,253),ev(S+'oj-3.17.6/ext/oj/mimic_json.c',587,593)])
add('A068',lambda h:h['file'].endswith('/json/common.rb') and h['line']==363,'contradicted','JSONSchemer passes one JSON.parse argument. opts defaults nil, so ParserOptions.prepare is skipped by unless opts.nil?. The later create_additions lambda body also is not executed merely by constructing that lambda.',[ev(J,253),ev(S+'json-2.21.2/lib/json/common.rb',362,364),ev(S+'json-2.21.2/lib/json/common.rb',62,74)])
add('A076',lambda h:h.get('primitive')=='rb_enc_str_new','contradicted','Selected empty-string constructor is in else if (!argc), but CompressedJson passes one input argument. argc cannot be zero on this shown call; omitted optional mode is not omitted string.',[ev(E+'lib/gitlab/middleware/compressed_json.rb',41),ev(S+'stringio-3.2.0/ext/stringio/stringio.c',341,348)])
add('A080',lambda h:h.get('primitive')=='rb_obj_as_string','contradicted','StringIO.new(\'{}\') has no block. Selected rb_obj_as_string is only in rb_block_given_p warning branch; it is excluded by this concrete call syntax.',[ev(E+'lib/gitlab/middleware/json_validation.rb',415,417),ev(S+'stringio-3.2.0/ext/stringio/stringio.c',415,423)])
rows=[]
for x in A:
 aid=x['audit_id'];hs=[]
 for h in x['ruby_hops']+x['native_hops']:
  evidence=[ev(h['file'],h['line'])];kind=h.get('type',h.get('kind'))
  verdict='supported_static_link';reason='Source contains the indicated explicit call and receiver; this is a static dispatch candidate, conditional on normal loading and the retained definitions, not runtime execution.'
  if kind in ['entrypoint','method_body']:reason='Source declaration/body exists. Entry registration and lexical handler selection are separate from proof that a request invokes it.'
  elif kind=='registration_to_function':reason='Actual rb_define registration names this C function; defining function is retained. Registration/load/compile activation is conditional.'
  elif kind=='c_call':reason='Actual direct C call/macro token matches retained definition. Caller/callee source inspected; no function-pointer substitution is used for this edge. Branch composition is checked separately below.'
  elif kind=='function_to_primitive':reason='Operation token/declarator occurs at the cited source line in selected function. Ruby constructor/conversion may avoid allocation depending on value; allocation amount and runtime execution unknown.'
  target=M.get(h.get('target_id'))
  if target:evidence.append(ev(target['file'],target['line']));reason+=' Target definition: '+target.get('name','')+'.'
  if h.get('target_file'):evidence.append(ev(h['target_file'],h['target_line']))
  if kind=='entrypoint':
   for z in x['exposure'].get('registration_evidence',[]):evidence.append(ev(z['file'],z['line']))
  for match,status,msg,extra in manual.get(aid,[]):
   if match(h):verdict=status;reason=msg;evidence+=extra
  hs.append({'hop_id':h['hop_id'],'kind':kind,'verdict':verdict,'file':h['file'],'line':h['line'],'reason':reason,'source_evidence':evidence,'target_id':h.get('target_id',h.get('to_id'))})
 statuses={h['verdict']for h in hs};status='contradicted' if 'contradicted'in statuses else 'unresolved'if'unresolved'in statuses else 'supported_static_chain'
 rows.append({'audit_id':aid,'dataset_id':x['dataset_id'],'path_id':x['path']['path_id'],'profile':x['profile'],'reviewer':'native_analysis','status':status,'review_scope':'All supplied frontend/Ruby/native hop source locations read; dispatch binding and concrete argument/branch contradictions reviewed independently of graph labels. Static source only. No corpus mutations.','syntactic_connectivity':'contradicted_target_lookup'if aid in ['A024','A028','A023'] else 'unresolved_active_monkeypatch'if aid=='A048' else 'source_call_tokens_present','branch_composition':'source_provable_contradiction'if status=='contradicted'else'no_concrete_contradiction_found_runtime_feasibility_unknown','per_hop':hs,'runtime_reachability':'unknown','authorization':'unknown','attacker_data_control':'unknown','allocation_occurrence':'unknown','finding_summary':[h['reason'] for h in hs if h['verdict']in ['contradicted','unresolved']],'residual_limitations':['No runtime/build execution; external loading, callbacks, configuration and framework activation remain conditional.','supported_static_chain means inspected source linkage without a discovered contradiction, not proof of execution or exploitable allocation.'],'duplicate_review':x['design']!='stratified_SRSWOR'})
with (D/'review_native_analysis.jsonl').open('w')as f:
 for x in rows:f.write(json.dumps(x,sort_keys=True)+'\n')
summary={'records':len(rows),'status_counts':dict(collections.Counter(x['status']for x in rows)),'unique_hops':len({h['hop_id']for x in rows for h in x['per_hop']}),'hop_reviews':sum(len(x['per_hop'])for x in rows),'dataset_id':A[0]['dataset_id'],'source_files_read':len(cache),'no_dataset_modifications':True}
(D/'review_native_analysis_summary.json').write_text(json.dumps(summary,indent=2));print(summary)
