Independent source audit of frozen dataset 97267dd258e01a46620e45d398eee914e53c46e431bae5b4ff5f1354bab1a849

Reviewed 20 random paths and two duplicate assignments; all reported hop sites were opened, along with relevant receiver, definition, registration and branch evidence. No target code executed and no frozen dataset changed.

Results: {'contradicted': 16, 'supported_static_chain': 5, 'unresolved': 1}. These counts apply only to these assignments, not the full population.

Main defects: Event passes a parsed Hash to JSONSchemer but selected paths take its String-only parse branch; HTML5 methods are incorrectly dispatched to shadowed HTML4/XML ancestors; known nil options, absent x5c, zero-argument and NULL-prefix branches are selected despite incompatible arguments. Optional Oj mimic_JSON registration is not established by mere library presence. The RE2 fresh-object delete path remains unresolved because its allocator macro definition is outside the retained source.

Contradicted means this specific selected chain is inconsistent with source/propagated values; another route to the same native primitive may exist. Supported chains are conditional source connections, not runtime, authorization, input-control or allocation proofs. Primitive categories include non-allocating-on-some-input API sites and small fixed arrays. Per-hop evidence and qualifications are in review_ruby_analysis.jsonl; original source dossiers retain broader inspection context.
