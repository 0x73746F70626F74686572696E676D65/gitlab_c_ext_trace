import json,pathlib,sys
B=pathlib.Path('/workspace/gitlab_c_ext_trace');D=B/'audit/end_to_end_20260930';rs=[]
for p in [D/'sample_ruby_analysis.jsonl',*D.glob('duplicate_*_ruby_analysis.jsonl')]:rs.extend(json.loads(l) for l in p.open())
meta=json.loads((D/'ruby_review_support.json').read_text());seen=set(tuple(x) for x in json.loads((D/'shown_spans.json').read_text())) if (D/'shown_spans.json').exists() else set()
def show(f,line,label,after=7):
 print(label,f,line)
 if (f,line) in seen:print('[same source span reviewed earlier]');return
 seen.add((f,line));ls=(B/f).read_text(errors='replace').splitlines()
 print('\n'.join(f'{i+1}:{ls[i]}' for i in range(max(0,line-4),min(len(ls),line+after))))
for r in rs:
 if r['audit_id'] not in sys.argv[1:]:continue
 print('\nAUDIT',r['audit_id'],r['path']['path_id'])
 for ev in r['exposure'].get('registration_evidence',[]):
  if ev.get('file') and ev.get('line'):show(ev['file'],ev['line'],'EXPOSURE')
 for h in r['ruby_hops']:
  show(h['file'],h['line'],'R '+h.get('method',h['type']))
  m=meta['methods'].get(h.get('target_id'))
  if m:show(m['file'],m['line'],'TARGET '+m['namespace']+'.'+m['method'])
 for h in r['native_hops']:
  show(h['file'],h['line'],'C '+h.get('callee',h['kind']))
  if h.get('target_file'):show(h['target_file'],h['target_line'],'C TARGET '+h.get('target_function_name',''))
(D/'shown_spans.json').write_text(json.dumps(sorted(seen)))
