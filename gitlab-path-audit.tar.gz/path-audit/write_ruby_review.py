import json,pathlib,collections
B=pathlib.Path('/workspace/gitlab_c_ext_trace'); A=B/'audit/end_to_end_20260930'
rows=[json.loads(l) for p in [A/'sample_ruby_analysis.jsonl',*sorted(A.glob('duplicate_*_ruby_analysis.jsonl'))] for l in p.open()]
support=json.load(open(A/'ruby_review_support.json')); cache={}
def ev(f,l,n=3):
 if not f or not l:return None
 if f not in cache:cache[f]=(B/f).read_text(errors='replace').splitlines()
 s=cache[f];lo=max(1,l-n);hi=min(len(s),l+n)
 return dict(file=f,line=l,start_line=lo,end_line=hi,source_context='\n'.join(f'{i}: {s[i-1]}' for i in range(lo,hi+1)))
def find(f,needle,n=3):
 if f not in cache: ev(f,1)
 for i,line in enumerate(cache[f],1):
  if needle in line:return ev(f,i,n)
 return dict(file=f,needle=needle,not_found=True)
shared='sources/expansion/json_schemer-2.4.0--davishmcclurg/lib/json_schemer.rb'
jsonc='sources/gems/json-2.21.2/ext/json/ext/parser/parser.c'
html='sources/gems/nokogiri-1.19.4/lib/nokogiri/html5/document.rb'
eventids={'A001','A005','A008','A013','A017','A041','A045','A049','A053','A065'}
wronghtml={'A021','A025','A061'}
results=[]
for r in sorted(rows,key=lambda r:r['audit_id']):
 aid=r['audit_id'];facts=[];hops=[]
 def fact(code,reason,evidence,status='contradicted'):
  facts.append(dict(code=code,status=status,reason=reason,evidence=[x for x in evidence if x]))
 if aid in eventids:
  f=next(h['file'] for h in r['ruby_hops'] if h['file'].endswith('/event_store/event.rb'))
  fact('fixed_schema_hash_not_string','Event passes Event.json_schema, parsed from a fixed JSON object file, into JSONSchemer.schema. resolve receives a Hash and takes its else branch; the selected JSON.parse(schema) call is only in when String. An alternative native parse while constructing Event.json_schema does not validate this selected trace.',[find(f,'JSONSchemer.schema',4),find(f,'@json_schema ||=',4),ev(shared,250,16),ev(f.rsplit('/',1)[0]+'/json_schema_draft07.json',1,3)])
 if aid in wronghtml:
  fact('overridden_html5_dispatch','Nokogiri::HTML5::Document defines its own parse and do_parse leading to Gumbo. The sampled HTML4 parse body and XML read_memory/read_io registration are ancestors shadowed by HTML5 implementations; ancestor membership does not establish Ruby dispatch.',[ev(html,103,23),ev(html,129,25)])
 if aid=='A009':
  f=r['ruby_hops'][2]['file'];h=next(h for h in r['ruby_hops'] if h.get('method')=='read_memory')
  fact('tempfile_selects_io_branch','The uploaded manifest tempfile is passed unchanged into Nokogiri::XML. Its read-capable IO receiver selects read_io, whereas this trace selects the else/read_memory branch.',[ev(f,30,5),ev(h['file'],74,13)])
 if aid=='A001':fact('nil_options_decimal_class','JSON.parse(schema) supplies no options. The native zero-initialized config and nil-options early return leave decimal_class unset; selected rb_str_new is guarded by config->decimal_class.',[ev(jsonc,2196,9),ev(jsonc,2071,5),ev(jsonc,1143,10)])
 if aid in {'A017','A008'}:fact('nil_options_unknown_keywords','The one-argument JSON.parse call supplies nil options. parser_config_init returns before option enumeration; unknown-keyword error string allocation is not reachable for these arguments.',[ev(jsonc,2196,9),ev(jsonc,2071,16)])
 if aid in {'A005','A045'}:fact('nonresumable_parser_branch','cParser_parse zero-initializes state without a parser member. The selected parse_error_new call at line 693 is in if(state->parser); another parse_error_new call exists in the else branch but is not this selected edge.',[ev(jsonc,2149,10),ev(jsonc,690,13)])
 if aid=='A049':
  f=next(h['file'] for h in r['ruby_hops'] if h['file'].endswith('/common.rb'))
  fact('nil_options_and_deferred_proc','JSON.parse one-argument call has opts=nil, skipping ParserOptions.prepare. Additionally JSON.create_id is inside the deferred Proc returned by create_additions_proc, not an immediate invocation merely because that method constructs the Proc.',[ev(f,360,8),ev(f,21,6),ev(f,67,15)])
 if aid=='A021':
  h=next(h for h in r['native_hops'] if h.get('callee')=='xmlDictAddQString')
  fact('known_null_dictionary_prefix','xmlDictLookup passes NULL prefix into xmlDictLookupInternal. The selected xmlDictAddQString call is the non-NULL-prefix else branch; NULL uses xmlDictAddString.',[ev(h['file'],847,4),ev(h['file'],787,8)])
 if aid=='A025':
  p='sources/gitlab/app/graphql/mutations/notes/create/image_diff_note.rb';d='sources/gitlab/app/models/diff_note.rb'
  fact('image_note_not_suggestible','ImageDiffNote creation sets position_type=image; DiffNote supports_suggestion? requires on_text?. Suggestions::CreateService returns unless supports_suggestion?, so this selected suggestions parse is also inconsistent with the image-note path.',[find(p,"position_type",4),find(d,'def supports_suggestion?',6),ev('sources/gitlab/app/services/suggestions/create_service.rb',10,6)])
 if aid=='A076':
  f=r['native_hops'][-1]['file']
  fact('stringio_one_argument_zero_argument_branch','StringIO.new(input) passes one argument; strio_initialize forwards argc unchanged. rb_enc_str_new at line347 is only the !argc branch, which cannot hold for the sampled call.',[ev(r['ruby_hops'][2]['file'],41,4),ev(f,264,6),ev(f,341,12),ev(f,415,5)])
 if aid=='A073':
  jf=next(h['file'] for h in r['ruby_hops'] if h['file'].endswith('/jwt.rb'))
  dec=next(h['file'] for h in r['ruby_hops'] if h['file'].endswith('/decode.rb'))
  hm=next(h['file'] for h in r['ruby_hops'] if h['file'].endswith('/hmac_token.rb'))
  cfg=jf.rsplit('/',1)[0]+'/jwt/configuration/decode_configuration.rb'
  fact('absent_x5c_option','HMACToken passes only leeway, verify_iat and algorithm options. JWT merges its decode configuration hash, whose explicit keys omit x5c. set_key returns unless @options[:x5c], so the sampled X5cKeyFinder call does not follow these arguments.',[ev(hm,17,10),ev(jf,51,5),ev(cfg,54,22),ev(dec,64,7)])
 if aid=='A057':
  f=r['native_hops'][-1]['file']
  fact('fresh_re2_allocation_macro_contract','The delete site exists but requires a pre-existing p->pattern. The sampled call constructs a fresh RE2::Regexp through TypedData_Make_Struct. The standard Ruby API zero-initializes this struct, making deletion inappropriate for fresh initialization; however the defining Ruby allocator macro/header is outside the retained target source, so this review leaves that API-contract-dependent edge unresolved rather than claiming source-only proof.',[ev(f,888,7),ev(f,1381,7)],'unresolved')
 if aid in {'A041','A049','A053','A065'}:
  f=r['native_hops'][0]['file']
  fact('optional_oj_mimic_installation','The selected JSON method registration occurs in Oj mimic_JSON installation. Ordinary presence of Oj does not establish replacement of JSON methods. No actual mimic_JSON activation was found in the inspected GitLab lib/config/gem setup; the selected optional binding remains unresolved independently of upstream contradictory branch.',[ev(f,r['native_hops'][0]['line'],6)],'unresolved')
 for h in r['ruby_hops']+r['native_hops']:
  typ=h.get('type',h.get('kind'));f=h.get('file');line=h.get('line');e=[ev(f,line)]
  target=support['methods'].get(h.get('target_id',h.get('method_id')))
  if target:e.append(ev(target['file'],target['line'],4))
  if h.get('target_file'):e.append(ev(h['target_file'],h['target_line'],4))
  for k in ['receiver_inheritance_ids','receiver_alias_ids']:
   for ident in h.get(k,[]):
    for group in ['inheritance','aliases']:
     v=support.get(group,{}).get(ident)
     if v and v.get('file'):e.append(ev(v['file'],v['line'],2))
  applicable=[]
  if aid in eventids and f==shared and line==253: applicable.append('fixed_schema_hash_not_string')
  if aid in wronghtml and ((f.endswith('/html5.rb') and line==29) or (f.endswith('/html4/document.rb'))):applicable.append('overridden_html5_dispatch')
  if aid=='A009' and h.get('method')=='read_memory':applicable.append('tempfile_selects_io_branch')
  if aid=='A001' and line==1147 and f==jsonc:applicable.append('nil_options_decimal_class')
  if aid in {'A017','A008'} and line==2084:applicable.append('nil_options_unknown_keywords')
  if aid in {'A005','A045'} and line==693:applicable.append('nonresumable_parser_branch')
  if aid=='A049' and f.endswith('/common.rb') and line in (363,21,74):applicable.append('nil_options_and_deferred_proc')
  if aid=='A021' and h.get('callee')=='xmlDictAddQString':applicable.append('known_null_dictionary_prefix')
  if aid=='A025' and f.endswith('/suggestions/create_service.rb') and line==13:applicable.append('image_note_not_suggestible')
  if aid=='A076' and line==347:applicable.append('stringio_one_argument_zero_argument_branch')
  if aid=='A073' and f.endswith('/decode.rb') and line==66:applicable.append('absent_x5c_option')
  if aid=='A057' and typ=='function_to_primitive':applicable.append('fresh_re2_allocation_macro_contract')
  if aid in {'A041','A049','A053','A065'} and typ=='registration_to_function':applicable.append('optional_oj_mimic_installation')
  relevant=[x for x in facts if x['code'] in applicable]
  status='contradicted' if any(x['status']=='contradicted' for x in relevant) else 'unresolved' if relevant else 'supported_syntactic_conditional'
  reason='Actual source site and target declaration inspected; static connection is conditional on ordinary dispatch, loading and enclosing guards. This is not proof of runtime traversal.'
  if relevant:reason=' '.join(x['reason'] for x in relevant)
  hops.append(dict(hop_id=h['hop_id'],layer='ruby' if h in r['ruby_hops'] else 'native',kind=typ,status=status,reason=reason,finding_codes=applicable,evidence=[x for x in e if x]))
 exposure=[]
 def walk(x):
  if isinstance(x,dict):
   if x.get('file') and x.get('line'):exposure.append(ev(x['file'],x['line'],3))
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 walk(r['exposure'])
 status='contradicted' if any(x['status']=='contradicted' for x in facts) else 'unresolved' if any(x['status']=='unresolved' for x in facts) else 'supported_static_chain'
 notes=[]
 if aid=='A029':notes.append('CreateNote can reply to a diff discussion: Notes::BuildService merges discussion reply attributes before Note.new, permitting a DiffNote subtype. Suggestions eligibility remains conditional; correct HTML5 own parse/do_parse/Gumbo path verified. Gumbo values[sizeof keywords/sizeof keywords[0]] is a small constant-size array, not necessarily VLA/large-stack risk.')
 if aid in {'A037','A077'}:notes.append('StackProf.run results branch needs block/start/available-frame conditions; these are possible source conditions, not known contradictions. rb_hash_aset is a present memory-related API site; allocation on every call is not established.')
 if aid=='A069':notes.append('StringValue is present but checkpoint.to_json already returns a String under normal semantics; no allocation is proved by this selected macro site.')
 if aid=='A033':notes.append('Middleware body is read to a String and explicit StreamValidator instance invokes Oj.sc_parse; nonempty whitespace can take empty-document error path. Request gates remain conditional.')
 results.append(dict(audit_id=aid,dataset_id=r['dataset_id'],path_id=r['path']['path_id'],reviewer='ruby_analysis',sample_role='duplicate' if aid in {'A008','A076'} else 'random',status=status,review_scope='All reported Ruby/native hop source sites and relevant target definitions inspected; exposure declarations and receiver/branch evidence reviewed. C bodies after the first contradictory edge still inspected. No target execution; no whole-program feasibility proof.',hop_count=len(hops),hops=hops,findings=facts,exposure_review=dict(status='source_declaration_supported_conditional',evidence=exposure),runtime_feasibility='unknown; selected source-level contradictions separately recorded',authorization='unknown',input_control='unknown',memory_effect='Primitive source site is present; actual allocation, size, attacker control and safety not established.',notes=notes,source_dossier=str(A/f'{aid}_ruby_dossier.txt')))
with (A/'review_ruby_analysis.jsonl').open('w') as out:
 for row in results:out.write(json.dumps(row,sort_keys=True)+'\n')
counts=collections.Counter(r['status'] for r in results)
(A/'review_ruby_analysis_notes.md').write_text('Independent source audit of frozen dataset '+rows[0]['dataset_id']+'\n\nReviewed 20 random paths and two duplicate assignments; all reported hop sites were opened, along with relevant receiver, definition, registration and branch evidence. No target code executed and no frozen dataset changed.\n\nResults: '+str(dict(counts))+'. These counts apply only to these assignments, not the full population.\n\nMain defects: Event passes a parsed Hash to JSONSchemer but selected paths take its String-only parse branch; HTML5 methods are incorrectly dispatched to shadowed HTML4/XML ancestors; known nil options, absent x5c, zero-argument and NULL-prefix branches are selected despite incompatible arguments. Optional Oj mimic_JSON registration is not established by mere library presence. The RE2 fresh-object delete path remains unresolved because its allocator macro definition is outside the retained source.\n\nContradicted means this specific selected chain is inconsistent with source/propagated values; another route to the same native primitive may exist. Supported chains are conditional source connections, not runtime, authorization, input-control or allocation proofs. Primitive categories include non-allocating-on-some-input API sites and small fixed arrays. Per-hop evidence and qualifications are in review_ruby_analysis.jsonl; original source dossiers retain broader inspection context.\n')
print(dict(counts));print('rows',len(results),'hops',sum(x['hop_count'] for x in results))
