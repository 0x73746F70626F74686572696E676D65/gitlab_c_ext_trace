#!/usr/bin/env python3
import pathlib,json,re,collections,hashlib
R=pathlib.Path('/workspace/gitlab_c_ext_trace');A=R/'audit/end_to_end_20260930';B=R/'reports/independent_baselines';unmatched=[json.loads(l) for l in (B/'native_lexical_candidates.jsonl').open() if not json.loads(l)['line_evidence_overlap']];cache={};results=[]
pat=re.compile(r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\[\s\S]|[^"\\])*"|\'(?:\\[\s\S]|[^\'\\])*\'')
for r in unmatched:
 f=r['file']
 if f not in cache:
  s=(R/f).read_text();offsets=[0]
  for m in re.finditer('\n',s):offsets.append(m.end())
  cache[f]=(s,offsets,[(m.start(),m.end(),'comment' if m[0].startswith(('/',)) else 'string') for m in pat.finditer(s)])
 s,offsets,spans=cache[f];start=offsets[r['line']-1];m=re.search(r'\b'+re.escape(r['operation'])+r'\s*\(',s[start:s.find('\n',start) if '\n' in s[start:] else len(s)]);pos=start+m.start();hit=next((kind for lo,hi,kind in spans if lo<=pos<hi),None)
 if hit:status='lexical_false_candidate_'+hit;reason='Operation text occurs inside a C comment/string, not an executable call site.'
 elif 'ffi_c/AbstractMemory.c' in f and 840<=r['line']<=855:status='unexpanded_alias_macro_registration_gap';reason='ALIAS(name,old) macro body contains16 rb_define_alias templates, invoked for char/short/int/long_long at858–861. Templates lack c_registrations rows; macro expansion/name binding remains unsupported. This is not proof these aliases execute under a build.'
 else:status='unresolved_candidate_requires_review';reason='Lexical candidate could not be classified by bounded independent comment/string and inspected macro context.'
 results.append({**r,'review_status':status,'review_reason':reason,'source_sha256':hashlib.sha256((R/f).read_bytes()).hexdigest()})
(A/'native_baseline_mismatch_review.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in results));summary={'reviewed_unmatched_candidates':len(results),'by_kind_and_status':{k:dict(collections.Counter(r['review_status'] for r in results if r['kind']==k)) for k in ['memory','registration']},'line_count_convention':'LF-based source lines. Initial Python splitlines baseline overcounted form-feed separators in generated pg_query source by3; corrected audit rerun restored3 legitimate overlaps, no source/table change.','limits':'Lexical denominator is bounded primary extension .c/.cc/.cpp subset; overlapping line evidence is not semantic recall or operation-equivalence proof. All unmatched candidates triaged; supported macro expansion remains unresolved.'};(A/'native_baseline_mismatch_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
# Record AST manifest error files separately from manifest inclusion coverage.
errs=[]
for label,base,prefix in [('ce',pathlib.Path('/workspace/gitlab_c_ext_ruby_expanded'),'sources/gitlab/'),('ee',pathlib.Path('/workspace/gitlab_c_ext_ee_profile'),'sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/')]:
 for l in (base/'tables/ruby_files.jsonl').open():
  r=json.loads(l)
  if r.get('file','').startswith(prefix) and r.get('has_parse_error'):
   rel=r['file'][len(prefix):];prod=rel.endswith('.rb') and rel.split('/')[0] in {'app','lib','config','gems','ee'} and not any(x in rel.split('/') for x in ['spec','specs','test','tests','fixtures']);errs.append({'profile':label,'file':r['file'],'production_filter_match':prod,'has_parse_error':True})
(A/'parser_manifest_error_files.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in errs));print(json.dumps(errs))
