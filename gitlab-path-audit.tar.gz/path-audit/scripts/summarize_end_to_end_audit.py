#!/usr/bin/env python3
"""Summarize frozen stratified SRSWOR semantic review. Never modifies audited data."""
import json,collections,hashlib
from pathlib import Path
from scipy.stats import hypergeom
A=Path('/workspace/gitlab_c_ext_trace/audit/end_to_end_20260930')
def rows(p):
 return [json.loads(l) for l in p.open() if l.strip()]
sample=rows(A/'path_sample.jsonl');design=json.loads((A/'sampling_design.json').read_text())
assert len({s['audit_id'] for s in sample})==len(sample)
ds_by={d['stratum']:d for d in design['strata']}
for s in sample:
 d=ds_by[s['stratum']];assert s['dataset_id']==design['dataset_id'];assert (s['profile'],s['population_size'],s['sample_size'])==(d['profile'],d['N'],d['n'])
reviews=[]
for p in sorted(A.glob('review_*.jsonl')):
 if p.name in ['review_unique_edges.jsonl','review_coverage.jsonl']:continue
 for r in rows(p):r['_review_file']=p.name;reviews.append(r)
by=collections.defaultdict(list)
for r in reviews:
 if 'audit_id' in r:by[r['audit_id']].append(r)
def ci(N,n,k,alpha):
 # Exact hypergeometric test inversion for finite population count M.
 if k==0:lo=0
 else:
  l,h=0,N
  while l<h:
   m=(l+h)//2
   if hypergeom.sf(k-1,N,m,n)>=alpha/2:h=m
   else:l=m+1
  lo=l
 if k==n:hi=N
 else:
  l,h=0,N
  while l<h:
   m=(l+h+1)//2
   if hypergeom.cdf(k,N,m,n)>=alpha/2:l=m
   else:h=m-1
  hi=l
 return lo/N,hi/N
statuses=['supported_static_chain','contradicted','unresolved'];strata=collections.defaultdict(list);missing=[]
selected=[]
for s in sample:
 rr=[r for r in by[s['audit_id']] if r['_review_file']=='review_'+s['reviewer']+'.jsonl']
 if not rr:missing.append(s['audit_id']);continue
 assert len(rr)==1,(s['audit_id'],len(rr))
 r=rr[0];assert r['status'] in statuses,r
 assert r['dataset_id']==design['dataset_id'],r['audit_id']
 assert r['path_id']==s['path']['path_id'],r['audit_id']
 strata[s['stratum']].append(r);selected.append(dict(sampling=s,review=r))
if missing:raise SystemExit('Incomplete reviews: '+','.join(missing))
res={'dataset_id':design['dataset_id'],'seed':design['seed'],'n':len(selected),'profiles':{},'method':'Stratified SRSWOR. Weighted reviewer verdict frequencies. Conservative 95% simultaneous finite-population hypergeometric intervals across 3 outcomes and all strata in each profile via Bonferroni; conditional on reviewer labels, not an independently known truth oracle. Unresolved remains separate.'}
for profile in ['ce','ee']:
 ds=[d for d in design['strata'] if d['profile']==profile];N=sum(d['N'] for d in ds);out={'N_paths':N,'n_reviewed':sum(d['n'] for d in ds),'raw_counts':dict(collections.Counter(r['status'] for d in ds for r in strata[d['stratum']])),'weighted':{},'strata':[]}
 for status in statuses:
  point=lower=upper=0
  for d in ds:
   rr=strata[d['stratum']];assert len(rr)==d['n'];k=sum(r['status']==status for r in rr);lo,hi=ci(d['N'],d['n'],k,.05/(3*len(ds)));w=d['N']/N;point+=w*k/d['n'];lower+=w*lo;upper+=w*hi
  out['weighted'][status]={'estimate':point,'conservative_simultaneous_95_interval':[lower,upper]}
 out['unresolved_assumption_bounds_point_estimate']=[out['weighted']['supported_static_chain']['estimate'],1-out['weighted']['contradicted']['estimate']]
 for d in ds:out['strata'].append(dict(d,observed=dict(collections.Counter(r['status'] for r in strata[d['stratum']]))))
 res['profiles'][profile]=out
# Distinct units and sample feature scope; paths reuse many edges.
res['sample_scope']={'gems':dict(collections.Counter(s['gem'].get('name') for s in sample)),'unique_entrypoints':len(set((s['profile'],s['path']['entrypoint_id']) for s in sample)),'unique_ruby_prefixes':len(set((s['profile'],s['path']['ruby_prefix_id']) for s in sample)),'unique_native_tails':len(set(s['path']['native_tail_id'] for s in sample)),'unique_hops':len(set((s['profile'] if key=='ruby_hops' else 'shared',h['hop_id']) for s in sample for key in ['ruby_hops','native_hops'] for h in s[key])),'length_min':min(s['length'] for s in sample),'length_max':max(s['length'] for s in sample)}
res['global_path_recall']='unknown: no exhaustive oracle; loops/dynamic dispatch/bounds/omitted callbacks and source gaps preclude global denominator'
(A/'audit_statistics.json').write_text(json.dumps(res,indent=2))
print(json.dumps(res,indent=2))
