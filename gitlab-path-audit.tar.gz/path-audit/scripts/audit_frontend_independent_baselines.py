#!/usr/bin/env python3
"""Independent lexical/source baselines. Candidate overlap is NOT semantic recall."""
import argparse,collections,hashlib,json,pathlib,re,subprocess
R=pathlib.Path('/workspace/gitlab_c_ext_trace');PRO={'ce':R.parent/'gitlab_c_ext_frontend_v2','ee':R.parent/'gitlab_c_ext_ee_profile'}

def rows(p):
 if p.exists():
  for l in p.open():
   if l.strip():yield json.loads(l)
def out(p,rs):
 with p.open('w') as f:
  for r in rs:f.write(json.dumps(r)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def production(p):return p.endswith('.rb') and p.split('/')[0] in {'app','lib','config','gems','ee'} and not any(x in p.split('/') for x in ['spec','specs','test','tests','fixtures'])
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--confirm-frozen',action='store_true');ap.add_argument('--freeze-manifest',required=True);a=ap.parse_args();assert a.confirm_frozen
 dest=R/'reports/independent_baselines';dest.mkdir(exist_ok=True);fm=pathlib.Path(a.freeze_manifest);assert fm.is_file();inputs={str(fm):sha(fm)};reports={};candidates=[];source_gaps=[]
 def tracked(p):inputs[str(p)]=sha(p);return rows(p)
 for label,base in PRO.items():
  contractp=base/'reports/frontend_input_contract.json';inputs[str(contractp)]=sha(contractp);contract=json.loads(contractp.read_text());prefix=contract['gitlab_source_prefixes'][0];source=R/prefix
  paths=subprocess.check_output(['git','ls-tree','-r','--name-only','HEAD'],cwd=source,text=True).split('\n');rb=[p for p in paths if p.endswith('.rb')];prod=[p for p in paths if production(p)];parsed={}
  for fp in contract['tables']['ruby_files']:
   for r in tracked(pathlib.Path(fp)):
    if r.get('file','').startswith(prefix):parsed[r['file']]=r
  missing=[p for p in prod if prefix+p not in parsed]
  source_gaps.extend({'profile':label,'file':prefix+p,'gap':'tracked_production_rb_not_in_parser_manifest','classification':'source_scope_gap_requires_review'} for p in missing)
  # Keep direct evidence line identities from registrations and entrypoints, not the extractor implementation.
  evidence=collections.defaultdict(set)
  source_tables={'rails':['frontend_rails_routes','frontend_rails_registrations','frontend_rails_entrypoints'],'grape':['frontend_grape_entrypoints','frontend_grape_registrations'],'graphql':['frontend_graphql_entrypoints']}
  for kind,names in source_tables.items():
   for name in names:
    p=base/'tables'/(name+'.jsonl')
    if not p.exists() and label=='ce':p=R/'tables'/(name+'.jsonl')
    if p.exists():
     for r in tracked(p):
      if isinstance(r.get('line'),int):evidence[kind].add((r.get('file'),r['line']))
  stats=collections.Counter()
  for rel in prod:
   file=prefix+rel;p=source/rel;data=p.read_bytes();parsed_hash=parsed.get(file,{}).get('sha256')
   if parsed_hash and hashlib.sha256(data).hexdigest()!=parsed_hash:
    stats['parser_source_hash_mismatches']+=1;source_gaps.append({'profile':label,'file':file,'gap':'parser_manifest_source_hash_mismatch','classification':'source_identity_mismatch'})
   for ln,s in enumerate(data.decode(errors='replace').split('\n'),1):
    if s.lstrip().startswith('#'):continue
    kind=None
    if '/config/routes/' in '/'+rel or rel in {'config/routes.rb','ee/config/routes.rb'}:
     if re.match(r'^\s*(?:get|post|put|patch|delete|match|resources?|root|mount)\b',s):kind='rails'
    if '/lib/api/' in '/'+rel and re.match(r'^\s*(?:get|post|put|patch|delete|head|options|route)\b',s):kind='grape'
    if '/graphql/' in '/'+rel and re.match(r'^\s*(?:field|mutation|query|subscription|graphql_name)\b',s):kind='graphql'
    if kind:
     matched=(file,ln) in evidence[kind];stats[kind+'_lexical_candidates']+=1;stats[kind+'_exact_line_evidence_overlap']+=matched
     candidates.append({'profile':label,'kind':kind,'file':file,'line':ln,'context':s[:500],'exact_line_evidence_overlap':matched,'classification':'lexical_candidate_only_not_proven_registration_or_exposure','unmatched_interpretation':'requires review: multiline/unsupported DSL, false candidate, or missing extraction'})
  gp=base/'tables/profile_gems.jsonl' if label=='ee' else R/'tables/gems.jsonl';gems=[r for r in tracked(gp) if r.get('lockfile')=='Gemfile.lock'];gc=collections.Counter()
  for r in gems:
   gc['entries']+=1;gc['source_available']+=bool(r.get('source_dir'));gc['source_unknown']+=not r.get('source_dir');gc['raw_native_true_broad_tree_flag']+=r.get('native') is True;gc['native_false_or_no_static_evidence']+=r.get('native') is False;gc['native_unknown']+=r.get('native') is None
  reports[label]={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'tracked_rb_all_scopes':len(rb),'tracked_production_rb_denominator':len(prod),'parsed_production_rb':len(prod)-len(missing),'missing_production_rb':len(missing),'parsed_gitlab_files_all_scopes':len(parsed),'parse_error_files_all_scopes':sum(bool(r.get('has_parse_error')) for r in parsed.values()),'registration_candidate_baselines':dict(stats),'primary_gem_coverage':dict(gc)}
 # Independent C lexical baseline on explicitly bounded primary extension .c/.cc/.cpp files.
 primary={r['gem_id'] for r in rows(R/'tables/gems.jsonl') if r.get('lockfile')=='Gemfile.lock'};files={r['file_id']:r for r in tracked(R/'tables/c_files.jsonl')};reg={(r['file_id'],r['line'],r['registration_api']) for r in tracked(R/'tables/c_registrations.jsonl')};phys={(r.get('canonical_source_path'),r.get('line')) for r in tracked(R/'tables/primitive_sites.jsonl')};nc=collections.Counter();native=[]
 regex=re.compile(r'\b(rb_define_(?:method|singleton_method|module_function|global_function|alloc_func|alias)|malloc|calloc|realloc|free|alloca|memcpy|memmove|memset|ruby_xmalloc|ruby_xcalloc|ruby_xrealloc|ruby_xfree|xmalloc|xcalloc|xrealloc|xfree|ALLOC|ALLOC_N|REALLOC_N)\s*\(')
 seen=set()
 for fid,f in files.items():
  name=f.get('path',f.get('file',''));p=R/name
  if name in seen or f.get('gem_id') not in primary or '/ext/' not in name or p.suffix not in {'.c','.cc','.cpp'}:continue
  seen.add(name);nc['bounded_source_files']+=1
  if not p.is_file():nc['missing_bounded_source_files']+=1;continue
  for ln,s in enumerate(p.read_text(errors='replace').split('\n'),1):
   if s.lstrip().startswith(('//','*')):continue
   for m in regex.finditer(s):
    operation=m[1];registration=operation.startswith('rb_define_');matched=(fid,ln,operation) in reg if registration else (name,ln) in phys;kind='registration' if registration else 'memory'
    nc[kind+'_lexical_candidates']+=1;nc[kind+'_line_evidence_overlap']+=matched;native.append({'file':name,'file_id':fid,'line':ln,'operation':operation,'kind':kind,'context':s[:500],'line_evidence_overlap':matched,'classification':'lexical_candidate_not_ast_site_or_reachability_proof'})
 out(dest/'frontend_registration_candidates.jsonl',candidates);out(dest/'tracked_source_scope_gaps.jsonl',source_gaps);out(dest/'native_lexical_candidates.jsonl',native)
 changed=[p for p,h in inputs.items() if sha(pathlib.Path(p))!=h];out(dest/'audit_input_hashes.jsonl',({'path':p,'sha256':h} for p,h in inputs.items()));report={'profiles':reports,'native_bounded_baseline':dict(nc),'inputs_changed_during_audit':changed,'native_flag_semantics':'raw_native_true_broad_tree_flag counts source-tree C-family presence; includes sibling/test/vendored code and does not count confirmed built C extensions. Refined gem classification is separate.','independent_methods':'Git tracked-path enumeration and anchored lexical source scans, independent of tree-sitter extraction. Exact line overlap is only evidence retention, not semantic precision or recall. Comments/strings/multiline constructs can produce false candidates or shift lines.','production_denominator':'Tracked .rb under app/lib/config/gems/ee excluding spec/specs/test/tests/fixtures path segments. Does not claim embedded Ruby, dynamically generated source, or arbitrary extensionless files.','native_denominator':'Unique primary-gem files listed in c_files with /ext/ and .c/.cc/.cpp suffix; not all vendored/system/native languages. Memory overlap uses same file and line, not operation-equivalence proof.','freeze_manifest':str(fm),'freeze_manifest_sha256':inputs[str(fm)]}
 (dest/'coverage_baselines.json').write_text(json.dumps(report,indent=2));print(json.dumps(report));assert not changed
if __name__=='__main__':main()
