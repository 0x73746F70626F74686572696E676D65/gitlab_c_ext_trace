#!/usr/bin/env python3
import json,hashlib,random,datetime
from pathlib import Path
from collections import defaultdict
BASE=Path('/workspace/gitlab_c_ext_trace'); OUT=BASE/'audit/end_to_end_20260930'; OUT.mkdir(exist_ok=True,parents=True)
ROOTS={'ce':Path('/workspace/gitlab_c_ext_frontend_v2'),'ee':Path('/workspace/gitlab_c_ext_ee_profile')}
SEED=202609300607
rng=random.Random(SEED)
def rows(p):
 with p.open() as f:
  for l in f:
   if l.strip():yield json.loads(l)
def idx(p,k):return {r[k]:r for r in rows(p)}
def write(n,rs):
 with (OUT/n).open('w') as f:
  for r in rs:f.write(json.dumps(r,sort_keys=True)+'\n')
files=[]
for root in [*ROOTS.values(),BASE]:
 for p in sorted((root/'tables').glob('frontend*.jsonl')):files.append(p)
for n in ['primitive_sites','primitive_evidence_sites','primitives','registrations','gems']:
 p=BASE/'tables'/f'{n}.jsonl'
 if p.exists():files.append(p)
manifest=[]
for p in sorted(set(files)):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 manifest.append({'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()})
freezeid=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
(OUT/'freeze_manifest.json').write_text(json.dumps({'dataset_id':freezeid,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'published_predecessor':'d46b1fdd8c39556f781daeba9f0fa21fb521f517','description':'Unpublished corrected CE/EE v2 datasets frozen before probability sampling; predecessor not this audited dataset','files':manifest},indent=2))
nt=idx(BASE/'tables/frontend_native_tails.jsonl','tail_id'); nh=idx(BASE/'tables/frontend_native_hops.jsonl','hop_id'); gems=idx(BASE/'tables/gems.jsonl','gem_id')
allbundles=[];strata=[];edgemap={};coverage=[]
reviewers=['ruby_analysis','report','provenance_validation','native_analysis']
for profile,root in ROOTS.items():
 t=root/'tables'; entries=idx(t/'frontend_entrypoints.jsonl','entrypoint_id'); ex=idx(t/'frontend_exposure.jsonl','entrypoint_id'); prefs=idx(t/'frontend_ruby_prefixes.jsonl','prefix_id'); hops=idx(t/'frontend_ruby_hops.jsonl','hop_id'); groups=defaultdict(list)
 for p in rows(t/'frontend_paths.jsonl'):
  key=(profile,entries[p['entrypoint_id']]['kind'],p['native_confidence']);groups[key].append(p)
  for hid in prefs[p['ruby_prefix_id']]['hops']:
   h=hops[hid];ek=(profile,'ruby',hid);edgemap[ek]={'profile':profile,'layer':'ruby','hop':h}
  for hid in nt[p['native_tail_id']]['hops']:
   h=nh[hid];ek=('shared','native',hid);edgemap[ek]={'profile':'shared','layer':'native','hop':h}
 for key,pop in sorted(groups.items()):
  pop.sort(key=lambda p:p['path_id']); sample=rng.sample(pop,min(5,len(pop)));stratum='|'.join(key);strata.append({'stratum':stratum,'profile':profile,'N':len(pop),'n':len(sample)})
  for p in sample:
   hs=[hops[i] for i in prefs[p['ruby_prefix_id']]['hops']]; native=[nh[i] for i in nt[p['native_tail_id']]['hops']]
   allbundles.append({'audit_id':f'A{len(allbundles)+1:03}','dataset_id':freezeid,'design':'stratified_SRSWOR','stratum':stratum,'population_size':len(pop),'sample_size':len(sample),'inclusion_probability':len(sample)/len(pop),'profile':profile,'root':str(root),'path':p,'entrypoint':entries[p['entrypoint_id']],'exposure':ex[p['entrypoint_id']],'ruby_hops':hs,'native_tail':nt[p['native_tail_id']],'native_hops':native,'gem':gems.get(p['gem_id'],{}),'length':len(hs)+len(native),'techniques':sorted(set(str(h.get('confidence',h.get('resolution'))) for h in hs+native))})
 covgroups=defaultdict(list)
 for c in rows(t/'frontend_entrypoint_coverage.jsonl'):
  if c.get('eligible_frontend_entrypoint') and not c['complete_paths']:
   covgroups[(c['kind'],'partial' if c['partial_paths'] else 'no_partial')].append(c)
 for key,pop in sorted(covgroups.items()):
  for c in rng.sample(sorted(pop,key=lambda x:x['entrypoint_id']),min(2,len(pop))):coverage.append({'profile':profile,'root':str(root),'stratum':'|'.join(key),'N':len(pop),'n':min(2,len(pop)),'coverage':c,'entrypoint':entries[c['entrypoint_id']],'exposure':ex[c['entrypoint_id']]})
for i,b in enumerate(allbundles):b['reviewer']=reviewers[i%4]
write('path_sample.jsonl',allbundles)
for reviewer in reviewers:write('sample_'+reviewer+'.jsonl',[b for b in allbundles if b['reviewer']==reviewer])
# Eight independently re-reviewed cases selected at random; excluded from estimator.
dup=rng.sample(allbundles,min(8,len(allbundles)))
for b in dup:
 b=dict(b); b['design']='duplicate_agreement_only';b['reviewer']=reviewers[(reviewers.index(b['reviewer'])+1)%4];write('duplicate_'+b['audit_id']+'_'+b['reviewer']+'.jsonl',[b])
eg=defaultdict(list)
for e in edgemap.values():eg[(e['layer'],e['hop'].get('type',e['hop'].get('kind')),e['hop'].get('resolution',e['hop'].get('confidence')))].append(e)
es=[]
for k,pop in sorted(eg.items(),key=lambda x:str(x[0])):
 for e in rng.sample(sorted(pop,key=lambda x:x['hop']['hop_id']),min(3,len(pop))):es.append(dict(e,stratum=str(k),N=len(pop),n=min(3,len(pop))))
write('unique_edge_sample.jsonl',es);write('coverage_sample.jsonl',coverage)
(OUT/'sampling_design.json').write_text(json.dumps({'seed':SEED,'dataset_id':freezeid,'strata':strata,'n_paths':len(allbundles),'n_unique_edge_samples':len(es),'unique_edges_population':len(edgemap),'n_coverage_cases':len(coverage),'n_duplicate_reviews':len(dup),'runtime_feasibility':'not claimed; source connectivity only','selection':'5 uniformly sampled without replacement per profile/frontend-kind/native-confidence stratum; edge sample 3 per edge technique stratum; coverage 2 per profile/kind/partial-status','uncertainty':'Path selection probabilities support weighted finite-population descriptive estimates, not global recall or runtime exploitability. Shared edges and reviewer errors require separate accounting.'},indent=2))
print(json.dumps({'dataset_id':freezeid,'paths':len(allbundles),'edges':len(es),'coverage':len(coverage),'strata':strata}))
