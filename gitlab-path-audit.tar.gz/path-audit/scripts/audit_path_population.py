#!/usr/bin/env python3
import json,collections
from pathlib import Path
B=Path('/workspace/gitlab_c_ext_trace');A=B/'audit/end_to_end_20260930'
res={}
for label,root in [('ce',Path('/workspace/gitlab_c_ext_frontend_v2')),('ee',Path('/workspace/gitlab_c_ext_ee_profile'))]:
 sets={k:set() for k in ['paths','entrypoints','ruby_prefixes','native_tails','registrations','gem_ids','terminal_sites','entry_site_pairs','entry_registration_pairs']};mult=collections.Counter()
 for l in (root/'tables/frontend_paths.jsonl').open():
  p=json.loads(l)
  for key,field in [('paths','path_id'),('entrypoints','entrypoint_id'),('ruby_prefixes','ruby_prefix_id'),('native_tails','native_tail_id'),('registrations','registration_id'),('gem_ids','gem_id'),('terminal_sites','terminal_site_id')]:sets[key].add(p[field])
  sets['entry_site_pairs'].add((p['entrypoint_id'],p['terminal_site_id']));sets['entry_registration_pairs'].add((p['entrypoint_id'],p['registration_id']));mult[p['entrypoint_id']]+=1
 counts=json.loads((root/'reports/frontend_counts_v2.json').read_text());res[label]={'distinct_units':{k:len(v) for k,v in sets.items()},'max_paths_one_entrypoint':max(mult.values()),'top10_entrypoints_fraction_of_paths':sum(v for _,v in mult.most_common(10))/len(sets['paths']),'bounds':counts['bounds'],'counts':counts['counts'],'kind_breakdown':counts['entrypoint_kind_counts'],'native_confidence':counts['native_confidence_counts'],'partial_reasons':counts['partial_reasons']}
(A/'population_structure.json').write_text(json.dumps(res,indent=2));print(json.dumps({k:v['distinct_units'] for k,v in res.items()}))
