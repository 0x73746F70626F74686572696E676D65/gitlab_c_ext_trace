#!/usr/bin/env python3
import json,hashlib,collections,datetime,re
from pathlib import Path
B=Path('/workspace/gitlab_c_ext_trace');A=B/'audit/end_to_end_20260930'
def rows(p):return [json.loads(l) for l in p.open() if l.strip()]
samples={r['audit_id']:r for r in rows(A/'path_sample.jsonl')};errors=[];counts=collections.Counter();sources={};excerpts=[];verdicts=collections.defaultdict(list)
def walk(x):
 if isinstance(x,dict):
  p=x.get('file');line=x.get('line')
  if isinstance(p,str) and isinstance(line,int) and (p.startswith('sources/') or p.startswith('/workspace/')):
   f=Path(p) if p.startswith('/') else B/p
   if not f.is_file():errors.append({'missing_source':p})
   else:
    if p not in sources:
     data=f.read_bytes();sources[p]={'sha256':hashlib.sha256(data).hexdigest(),'lines':data.decode('utf8',errors='replace').split('\n'),'bytes':len(data)}
    src=sources[p]
    if not 1<=line<=len(src['lines']):errors.append({'line_out_of_bounds':p,'line':line})
    counts['source_location_checks']+=1
    if isinstance(x.get('source_context'),str):
     for numbered in x['source_context'].split('\n'):
      m=re.match(r'^(\d+): (.*)$',numbered)
      if m:
       n=int(m.group(1));t=m.group(2)
       if 1<=n<=len(src['lines']) and src['lines'][n-1]==t:counts['numbered_source_context_line_matches']+=1
       else:errors.append({'numbered_source_context_mismatch':p,'line':n})
    for k in ['source_sha256','file_sha256']:
     if x.get(k) and x[k]!=src['sha256']:errors.append({'hash_mismatch':p})
    text=next((x[k] for k in ['source_text','context','source'] if isinstance(x.get(k),str) and x[k]),None)
    if text:
     end=x.get('end_line',line);span='\n'.join(src['lines'][line-1:end])
     if text.strip() in span.strip():counts['exact_excerpt_matches']+=1
     else:excerpts.append({'file':p,'line':line,'field_text':text[:500],'note':'Not exact within declared span; inspect, may be abbreviated or expanded context.'})
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
for who in ['ruby_analysis','report','provenance_validation','native_analysis']:
 p=A/f'review_{who}.jsonl'
 if not p.exists():errors.append({'missing_review':who});continue
 for r in rows(p):
  s=samples[r['audit_id']];assert r['path_id']==s['path']['path_id'];assert r['dataset_id']==s['dataset_id']
  verdicts[r['audit_id']].append({'reviewer':who,'status':r['status'],'primary':who==s['reviewer']})
  hs=r.get('per_hop',r.get('per_hop_verdicts',r.get('hop_reviews',r.get('hops',[]))))
  expected=[h['hop_id'] for h in s['ruby_hops']+s['native_hops']]
  got=[h.get('hop_id') for h in hs]
  if got!=expected:errors.append({'hop_order_or_coverage_mismatch':r['audit_id'],'reviewer':who,'expected_n':len(expected),'actual_n':len(got)})
  counts['reviewed_path_records']+=1;counts['hop_verdicts']+=len(hs);walk(r)
for aid,s in samples.items():
 if len([r for r in verdicts[aid] if r['primary']])!=1:errors.append({'primary_review_cardinality':aid})
for name in ['review_unique_edges.jsonl','review_coverage.jsonl']:
 for r in rows(A/name):walk(r)
dups=[{'audit_id':k,'reviews':v,'agreement':len(set(r['status'] for r in v))==1} for k,v in verdicts.items() if len(v)>1]
(A/'review_agreement.json').write_text(json.dumps({'duplicates':dups,'n':len(dups),'agreements':sum(x['agreement'] for x in dups),'note':'Small duplicate subset; shared reviewer guidance and error-family discussion mean not a blind external accuracy oracle.'},indent=2))
with (A/'review_source_manifest.jsonl').open('w') as f:
 for p,v in sorted(sources.items()):f.write(json.dumps({'file':p,'bytes':v['bytes'],'sha256':v['sha256']})+'\n')
res={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':dict(counts),'errors':errors,'excerpt_exceptions':excerpts,'source_files':len(sources),'semantic_accuracy_not_asserted':True}
(A/'audit_validation.json').write_text(json.dumps(res,indent=2));print(json.dumps({'checks':dict(counts),'errors':errors,'excerpt_exceptions':len(excerpts),'source_files':len(sources)}))
