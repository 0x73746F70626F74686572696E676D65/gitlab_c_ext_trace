"""Read-only census: no lookup edges inferred and no source corpus modified."""
import collections,hashlib,json,pathlib
V=pathlib.Path('/workspace/gitlab_c_ext_v3')
def rows(p):
 with p.open() as f:
  for line in f:yield json.loads(line)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return dict(path=str(p),sha256=h.hexdigest(),bytes=p.stat().st_size)
def main():
 out=[];inputs=[]
 for profile,g in [('ce','/workspace/gitlab_c_ext_ruby_expanded'),('ee','/workspace/gitlab_c_ext_ee_profile')]:
  G=pathlib.Path(g);dp=V/'profiles'/profile/'tables/controller_callback_demands.jsonl';mp=G/'tables/ruby_methods.jsonl';np=G/'tables/ruby_native_paths.jsonl';hp=V/'tables'/f'{profile}_inherited_callback_invocation_unresolved.jsonl'
  inputs.extend(digest(p) for p in [dp,mp,np,hp]);demands={d['callback_demand_id']:d for d in rows(dp)};methods={m['method_id']:m for m in rows(mp)};paths=collections.defaultdict(list)
  for r in rows(np):
   if r.get('primary_bundle_compatible'):paths[r['file']].append(r)
  holes=list(rows(hp))
  for reason in ['intervening_include_lookup_unresolved','preceding_owner_prepend_unresolved']:
   hs=[h for h in holes if h['reason']==reason];ds=[demands[h['callback_demand_id']] for h in hs];candidates={c['method_id']:c for d in ds for c in d['target_candidates']};hits=[];missing=[]
   for mid,c in candidates.items():
    m=methods.get(mid)
    if m is None:missing.append(mid);continue
    for r in paths[c['file']]:
     if m['line']<=r['line']<=m['end_line']:hits.append(dict(method_id=mid,path_id=r['path_id'],file=r['file'],line=r['line']))
   out.append(dict(profile=profile,reason=reason,demands=len(ds),controllers=len({d['controller_owner'] for d in ds}),route_action_pairs=len({(d['controller_owner'],d['action']) for d in ds}),symbols=len({h['symbol'] for h in hs}),callback_declarations=len({h['callback_id'] for h in hs}),candidate_methods=len(candidates),empty_target_demands=sum(not d['target_candidates'] for d in ds),missing_method_ids=missing,existing_native_path_start_matches=len(hits),matches=hits,top_symbols=collections.Counter(h['symbol'] for h in hs).most_common(12)))
 report=dict(scope='Feasibility only; no method absence, dispatch, native absence or callback activation proof',inputs=inputs,counts=out,join_method='Unresolved callback demand ID joins declarations of actual route/controller/action demands; distinct target_candidates.method_id joins ruby_methods. Primary_bundle_compatible ruby_native_paths joined by exact source file and inclusive method line/end_line containment. This is a source-region screen, not a new verified invocation edge; nested definitions could overcount a positive.',limitations=['Existing target_candidates omit module/framework-generated bodies; empty target sets are unresolved, not absent behavior.','Existing native paths are incomplete conditional syntactic candidates. Zero matching starts does not prove absence of downstream native behavior.','Counts across reasons/profiles overlap; do not sum into unique controllers or methods.','No include/prepend ordering, hooks, reopenings, mutation or callback activation has been resolved by this census.'],recommendation='Prioritize a sink-driven screen before implementing mixin expansion. Strict production-scoped leaf-module negative-name certificates cost approximately45–75minutes plus independent review, with real sink gain currently unestablished. Reject hooks/Concern, nested mixins, aliases/dynamic definitions or mutations until modeled; enumerate reopenings and keep activation separate.',priority_reason='A selected HTTP body-prefix proof ranks higher despite one case because its actual request-byte transfer, admission conditions and existing native mechanism can be source-checked end to end. Thousands of callback declaration demands currently have no demonstrated new native continuation; row count is not a request-to-memory coverage gain.',source_examples=[dict(file='sources/gitlab/lib/gitlab/no_cache_headers.rb',assessment='Small explicit module offers potential negative-name certificate, conditional on complete reopening/hook inventory.'),dict(file='sources/gitlab/app/controllers/concerns/floc_opt_out.rb',assessment='Concern included hook registers callback; not a closed leaf.'),dict(file='sources/gitlab/lib/gitlab/gon_helper.rb',assessment='Nested includes; add_gon_variables target discovery requires additional lookup.'),dict(file='sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/ee/app/controllers/ee/application_controller.rb',assessment='prepended hook includes Onboarding::Redirect.'),dict(file='sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/ee/app/controllers/ee/projects/merge_requests_controller.rb',assessment='prepended hook contains includes, callback registrations and method definition; not a leaf.')])
 B=pathlib.Path('/workspace/gitlab_c_ext_trace')
 for e in report['source_examples']:e.update(digest(B/e['file']))
 target=V/'reports/callback_mixin_feasibility.json';target.write_text(json.dumps(report,indent=2)+'\n');print(target)
if __name__=='__main__':main()
