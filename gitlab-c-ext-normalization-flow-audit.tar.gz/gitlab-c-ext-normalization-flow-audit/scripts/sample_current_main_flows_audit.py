import json,random,hashlib
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');A=V/'audit/current_main_flows_20260930';A.mkdir(exist_ok=True)
p=V/'tables/request_flow_index_activity_pub_final.jsonl';digest=hashlib.sha256(p.read_bytes()).hexdigest();assert digest=='4fff6159ef01f9838fe60d15e21ea632c19133b7ea0c0b4a0de3b926c370ca2e'
pool=[json.loads(l) for l in p.open() if json.loads(l)['ledger_category']=='conditional_source_flow'];assert len(pool)==18
rng=random.Random(202609301041);selected=[]
def choose(candidates,stratum):
 r=dict(rng.choice(sorted(candidates,key=lambda x:x['flow_id'])));r['audit_id']=f'MF{len(selected)+1:03}';r['selection_stratum']=stratum;r['prior_personal_review_overlap']='No prior review of this ActivityPub case recalled' if r['frontend_source_case_family']=='activity_pub_releases_inbox' else 'Related flow/source family previously reviewed by this reviewer; fresh selection/reinspection is not reviewer-naive';selected.append(r)
for mechanism in sorted({r['conditional_memory_influence_mechanism'] for r in pool}):
 cand=[r for r in pool if r['conditional_memory_influence_mechanism']==mechanism]
 if mechanism=='json_object_key_content_and_derived_length':cand=[r for r in cand if r['frontend_source_case_family']=='activity_pub_releases_inbox']
 choose(cand,'one_each_mechanism_with_activitypub_novelty_priority')
choose([r for r in pool if r['frontend_source_case_family']=='graphql_package_cursor'],'GraphQL_frontend')
while len(selected)<8:
 used={r['flow_id'] for r in selected};families={r['frontend_source_case_family'] for r in selected}
 cand=[r for r in pool if r['flow_id'] not in used and r['profile']=='ee' and r['frontend_source_case_family'] not in families]
 if not cand:cand=[r for r in pool if r['flow_id'] not in used and r['frontend_source_case_family'] not in families]
 choose(cand,'EE_and_frontend_diversity')
(A/'sample.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in selected))
(A/'selection_freeze.json').write_text(json.dumps({'seed':202609301041,'index_sha256':digest,'published_revision':'9a62fdf','population':18,'sample_sha256':hashlib.sha256((A/'sample.jsonl').read_bytes()).hexdigest(),'design':'Purposeful strata: one per four mechanisms, ActivityPub novelty priority, GraphQL, then EE/new-family diversity. Random within each eligible stratum. Not a probability accuracy estimate; prior personal involvement disclosed, source evidence freshly reviewed without using prior verdicts.'},indent=2)+'\n')
for r in selected:print(r['audit_id'],r['flow_id'])
