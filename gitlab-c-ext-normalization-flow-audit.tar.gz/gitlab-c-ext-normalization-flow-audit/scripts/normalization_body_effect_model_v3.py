#!/usr/bin/env python3
"""Bounded AST-gated Ruby summaries + receiver/key-sensitive abstract effects.
Not a Ruby interpreter or general effect analyzer; unrecognized source is unresolved.
"""
import json,hashlib,pathlib,copy
from deferred_execution import parser
R=pathlib.Path('/workspace/gitlab_c_ext_v3');T=pathlib.Path('/workspace/gitlab_c_ext_trace')
AUTH='sources/gitlab/lib/gitlab/auth/auth_finders.rb'
REQ='sources/wrappers/rails-7.2.3.1/actionpack/lib/action_dispatch/http/request.rb'
RACK='sources/expansion/rack-2.2.23--rack/lib/rack/request.rb'
PARAM='sources/wrappers/rails-7.2.3.1/actionpack/lib/action_dispatch/http/parameters.rb'
TEMPLATES={
 'ensure_action_dispatch_request':'''def ensure_action_dispatch_request(request)
 ActionDispatch::Request.new(request.env.dup)
 end''',
 'current_request':'''def current_request
 @current_request ||= ensure_action_dispatch_request(request)
 end''',
 'body_stream':'''def body_stream
 get_header("rack.input")
 end''',
 'raw_post':'''def raw_post
 unless has_header? "RAW_POST_DATA"
 set_header("RAW_POST_DATA", read_body_stream)
 end
 get_header "RAW_POST_DATA"
 end''',
 'read_body_stream':'''def read_body_stream
 if body_stream
 reset_stream(body_stream) do
 if headers.key?("Transfer-Encoding")
 body_stream.read
 else
 body_stream.read(content_length)
 end
 end
 end
 end''',
 'reset_stream':'''def reset_stream(body_stream)
 if body_stream.respond_to?(:rewind)
 body_stream.rewind
 content = yield
 body_stream.rewind
 content
 else
 yield
 end
 end''',
 'body':'''def body
 if raw_post = get_header("RAW_POST_DATA")
 raw_post = (+raw_post).force_encoding(Encoding::BINARY)
 StringIO.new(raw_post)
 else
 body_stream
 end
 end''',
 'get_header':'''def get_header(name)
 @env[name]
 end''',
 'set_header':'''def set_header(name, v)
 @env[name] = v
 end''',
 'has_header?':'''def has_header?(name)
 @env.key? name
 end''',
 'extract_personal_access_token':'''def extract_personal_access_token
 current_request.params[PRIVATE_TOKEN_PARAM].presence ||
 current_request.env[PRIVATE_TOKEN_HEADER].presence ||
 parsed_oauth_token
 end'''
}
FILES={k:AUTH if k in {'ensure_action_dispatch_request','current_request','extract_personal_access_token'} else RACK if k in {'get_header','set_header','has_header?'} else REQ for k in TEMPLATES}
def walk(n):
 yield n
 for c in n.named_children:yield from walk(c)
def text(n,b):return b[n.start_byte:n.end_byte].decode() if n else ''
def method_node(data,name):
 tree=parser().parse(data)
 if tree.root_node.has_error:return None
 found=[n for n in walk(tree.root_node) if n.type=='method' and text(n.child_by_field_name('name'),data)==name]
 return found[0] if len(found)==1 else None
def shape(n,b):
 # Ordered ALL-child tree including anonymous operators/punctuation/keywords.
 # Discard only comments and parser-omitted whitespace; literal whitespace retained.
 children=[shape(c,b) for c in n.children if c.type!='comment']
 return [n.type,children] if children else [n.type,text(n,b)]
def compile_source(name,data):
 n=method_node(data,name);tmpl=TEMPLATES[name].encode();tn=method_node(tmpl,name)
 if n is None or shape(n,data)!=shape(tn,tmpl):return {'status':'unresolved_source_shape','method':name}
 return {'status':'supported_exact_ast_summary','method':name,'file':FILES[name],'line':n.start_point.row+1,'end_line':n.end_point.row+1,'byte_start':n.start_byte,'byte_end':n.end_byte,'source_sha256':hashlib.sha256(data).hexdigest(),'method_sha256':hashlib.sha256(data[n.start_byte:n.end_byte]).hexdigest(),'ast_shape_sha256':hashlib.sha256(json.dumps(shape(n,data)).encode()).hexdigest(),'ordered_source_calls':[{'method':text(c.child_by_field_name('method'),data),'receiver':text(c.child_by_field_name('receiver'),data),'line':c.start_point.row+1,'expression':text(c,data)} for c in walk(n) if c.type=='call'],'excerpt':text(n,data)}
class State:
 def __init__(self,body=b'{"a":1}',cache=False,compiled=None):
  self.source_verified = bool(compiled) and all(compiled.get(n,{}).get('status')=='supported_exact_ast_summary' for n in TEMPLATES)
  self.objects={'io0':{'kind':'StringIO','bytes':body.decode('latin1'),'pos':0,'known':True}}
  self.envs={'original':{'rack.input':'io0'}};self.unknown_envs=set();self.wrapper=None;self.n=0;self.history=[]
  if cache:
   self.objects['str0']={'kind':'String','bytes':body.decode('latin1'),'known':True};self.envs['original']['RAW_POST_DATA']='str0'
 def duplicate_wrapper(self,compiled,source_env='original'):
  if not compiled or not self.source_verified: return {'status':'unresolved_source_shape'}
  if source_env in self.unknown_envs:return {'status':'unresolved_environment_effect'}
  if self.wrapper is not None:return {'status':'memoized_wrapper','env_id':self.wrapper}
  self.wrapper='auth_copy';self.envs[self.wrapper]=dict(self.envs[source_env]);self.history.append('source_checked_shallow_env_dup_no_read')
  return {'status':'new_wrapper_without_read','env_id':self.wrapper}
 def raw_post(self,env_id,*,compiled=True,read_length='unknown',rewindable=True,fail=None,headers=None):
  if not compiled or not self.source_verified:return {'status':'unresolved_source_shape'}
  if env_id in self.unknown_envs:return {'status':'unresolved_environment_effect'}
  env=self.envs[env_id]
  if 'RAW_POST_DATA' in env:return {'status':'existing_cache_returned_without_read','value_id':env['RAW_POST_DATA']}
  io_id=env.get('rack.input');io=self.objects.get(io_id)
  if io_id is None:
   env['RAW_POST_DATA']=None;return {'status':'nil_body_stream_cached','value_id':None}
  if not io or not io.get('known') or io['kind']!='StringIO':return {'status':'unresolved_receiver_or_escaped_state'}
  if not rewindable:return {'status':'unresolved_nonrewindable_receiver'}
  if read_length is None and not(headers is not None and 'Transfer-Encoding' in headers):return {'status':'unresolved_inconsistent_no_length_branch'}
  if fail=='first_rewind' and rewindable:return {'status':'exception_no_cache','position':io['pos']}
  if rewindable:io['pos']=0
  if headers is not None and 'Transfer-Encoding' in headers:read_length=None
  if read_length is not None and type(read_length) is not int:return {'status':'unresolved_read_length_domain'}
  if type(read_length) is int and read_length<0:return {'status':'exception_invalid_length_no_cache','position':io['pos']}
  if fail=='read':io['pos']=None;return {'status':'exception_no_cache_position_unknown','value_id':None}
  if io['pos'] is None:return {'status':'unresolved_position'}
  if headers is not None and 'Transfer-Encoding' in headers:read_length=None
  start=io['pos'];body=io['bytes']
  if type(start) is not int or start<0:return {'status':'unresolved_position_domain'}
  nil_result = read_length is not None and read_length>0 and start>=len(body)
  if start>=len(body):end=start;result=None if nil_result else ''
  else:
   end=len(body) if read_length is None else min(len(body),start+read_length)
   result=body[start:end];io['pos']=end
  if fail=='final_rewind' and rewindable:
   io['pos']=None
   return {'status':'exception_no_cache_position_unknown','position':None}
  if rewindable:io['pos']=0
  if nil_result:
   env['RAW_POST_DATA']=None
   return {'status':'normal_return_nil_cached_locally','value_id':None,'source_io_id':io_id,'byte_interval':None,'position_after':io['pos']}
  self.n+=1;sid=f'local_str{self.n}';self.objects[sid]={'kind':'String','bytes':result,'known':True};env['RAW_POST_DATA']=sid
  return {'status':'normal_return_cached_locally','value_id':sid,'source_io_id':io_id,'byte_interval':[start,end],'position_after':io['pos']}
 def body_receiver(self,env_id):
  if not self.source_verified:return {'status':'unresolved_source_shape'}
  if env_id in self.unknown_envs:return {'status':'unresolved_environment_effect'}
  value=self.envs[env_id].get('RAW_POST_DATA')
  if value is None or value is False:return {'status':'fallback_shared_stream','io_id':self.envs[env_id].get('rack.input')}
  obj=self.objects.get(value)
  if not obj or obj['kind']!='String' or not obj.get('known'):return {'status':'unresolved_cached_value'}
  self.n+=1;i=f'fresh_io{self.n}';self.objects[i]={'kind':'StringIO','bytes':obj['bytes'],'pos':0,'known':True,'encoding':'ASCII-8BIT','backing_may_alias':value}
  return {'status':'fresh_cached_binary_stringio','io_id':i}
 def unknown_call(self,*ids):
  # Explicit escapes invalidate transitively reachable values, not just a local variable.
  if not ids:ids=tuple(self.envs) # Unknown ambient call can access request/global state.
  for i in ids:
   if i in self.envs:
    self.unknown_envs.add(i)
    for v in self.envs[i].values():
     if v in self.objects:self.mutate_shared_value(v)
   elif i in self.objects:self.mutate_shared_value(i)
 def set_key(self,env,key,value):self.envs[env][key]=value
 def mutate_shared_value(self,value_id):
  pending=[value_id];seen=set()
  while pending:
   i=pending.pop()
   if i in seen or i not in self.objects:continue
   seen.add(i);obj=self.objects[i];obj['known']=False
   if obj.get('kind')=='StringIO':obj['pos']=None
   if obj.get('backing_may_alias') is not None:pending.append(obj['backing_may_alias'])
   pending.extend(k for k,v in self.objects.items() if v.get('backing_may_alias')==i)

def evidence(file,lo,hi,claim):
 p=T/file;b=p.read_bytes();return {'file':file,'line':lo,'end_line':hi,'sha256':hashlib.sha256(b).hexdigest(),'claim':claim,'excerpt':'\n'.join(b.decode().splitlines()[lo-1:hi])}
def main():
 compiled={n:compile_source(n,(T/FILES[n]).read_bytes()) for n in TEMPLATES};assert all(x['status']=='supported_exact_ast_summary' for x in compiled.values())
 syntax=[]
 mutations=[('ensure_action_dispatch_request','dup','deep_dup'),('ensure_action_dispatch_request','request.env.dup','other.env.dup'),('ensure_action_dispatch_request','ActionDispatch::Request.new','Unknown.new'),('raw_post','RAW_POST_DATA','OTHER_CACHE'),('raw_post','read_body_stream','unknown_call'),('reset_stream','content = yield','unknown_call(body_stream)\n content = yield'),('reset_stream','body_stream.rewind\n\n          content','body_stream.read\n\n          content')]
 mutations += [('current_request','||=','&&='),('current_request','||=','+='),('extract_personal_access_token','||','&&'),('ensure_action_dispatch_request','request.env','request&.env'),('body','(+raw_post)','(-raw_post)'),('raw_post','unless','if')]
 for n,a,b in mutations:
  source=(T/FILES[n]).read_bytes();mn=method_node(source,n);snippet=source[mn.start_byte:mn.end_byte];assert a.encode() in snippet;changed=source[:mn.start_byte]+snippet.replace(a.encode(),b.encode(),1)+source[mn.end_byte:]
  result=compile_source(n,changed);assert result['status']=='unresolved_source_shape',(n,a)
  syntax.append({'method':n,'mutation':[a,b],'verdict':result['status'],'pass':True})
 for n in TEMPLATES:
  source=TEMPLATES[n].replace('\n','\n # harmless comment\n').encode();assert compile_source(n,source)['status']=='supported_exact_ast_summary'
  syntax.append({'method':n,'mutation':'whitespace_comment_only','verdict':'supported_exact_ast_summary','pass':True})
 checks=[]
 def check(name,ok):assert ok,name;checks.append({'name':name,'pass':True})
 s=State(compiled=compiled);old=s.objects['io0'].copy();s.duplicate_wrapper(True);check('normalizer_only_no_read_or_cache',s.objects['io0']==old and 'RAW_POST_DATA' not in s.envs['auth_copy']);check('same_io_alias',s.envs['auth_copy']['rack.input']==s.envs['original']['rack.input'])
 result=s.raw_post('auth_copy',read_length=7);check('normal_read_restores_shared_position',result['position_after']==0);check('new_cache_binding_local_only','RAW_POST_DATA' not in s.envs['original']);check('normal_full_interval',result['byte_interval']==[0,7]);check('memoized_wrapper_not_recopied',s.duplicate_wrapper(True)['status']=='memoized_wrapper')
 s=State(cache=True,compiled=compiled);s.duplicate_wrapper(True);r=s.raw_post('auth_copy',read_length=7);check('existing_cache_alias_no_read',r['value_id']=='str0' and s.objects['io0']['pos']==0);s.mutate_shared_value('str0');check('existing_shared_cache_value_mutation_visible_both',s.envs['original']['RAW_POST_DATA']==s.envs['auth_copy']['RAW_POST_DATA'] and not s.objects['str0']['known']);s.set_key('auth_copy','RAW_POST_DATA',None);check('cache_binding_replace_local',s.envs['original']['RAW_POST_DATA']=='str0')
 for fail in ['first_rewind','read','final_rewind']:
  s=State(compiled=compiled);s.duplicate_wrapper(True);r=s.raw_post('auth_copy',read_length=7,fail=fail);check(f'{fail}_no_cache_write','RAW_POST_DATA' not in s.envs['auth_copy']);check(f'{fail}_not_normal',r['status'].startswith('exception'))
 s=State(compiled=compiled);s.duplicate_wrapper(True);s.unknown_call('auth_copy');check('unknown_escape_invalidates_original_shared_io',not s.objects['io0']['known']);check('unknown_escape_not_normal_summary',s.raw_post('auth_copy',read_length=7)['status'].startswith('unresolved_'))
 s=State(compiled=compiled);s.duplicate_wrapper(True);s.set_key('auth_copy','rack.input','unknown_io');check('local_stream_replacement_does_not_replace_original',s.envs['original']['rack.input']=='io0');check('replacement_unknown_receiver',s.raw_post('auth_copy',read_length=7)['status'].startswith('unresolved_'))
 s=State(compiled=compiled);s.objects['io0']['pos']=2;s.duplicate_wrapper(True);r=s.raw_post('auth_copy',read_length=7,rewindable=False);check('nonrewindable_branch_rejected_for_selected_StringIO',r['status']=='unresolved_nonrewindable_receiver')
 s=State(compiled=compiled);s.duplicate_wrapper(True);r=s.raw_post('auth_copy',read_length=3);check('contentlength_prefix_only',r['byte_interval']==[0,3] and r['position_after']==0)
 s=State(compiled=compiled);s.envs['original']['RAW_POST_DATA']=None;s.duplicate_wrapper(True);check('present_nil_cache_does_not_read',s.raw_post('auth_copy',read_length=7)['status']=='existing_cache_returned_without_read' and s.objects['io0']['pos']==0)
 s=State(compiled=compiled);check('unknown_constructor_source_not_applied',s.duplicate_wrapper(False)['status']=='unresolved_source_shape')
 for cache_value in [None,False]:
  s=State(compiled=compiled);s.envs['original']['RAW_POST_DATA']=cache_value;s.duplicate_wrapper(True);r=s.raw_post('auth_copy',read_length=7);b=s.body_receiver('auth_copy');check(f'present_{cache_value}_raw_post_skips_read_but_body_falls_back',r['status']=='existing_cache_returned_without_read' and b['status']=='fallback_shared_stream' and b['io_id']=='io0' and s.objects['io0']['pos']==0)
 s=State(cache=True,compiled=compiled);s.duplicate_wrapper(True);b=s.body_receiver('auth_copy');check('truthy_cache_body_new_binary_stream',b['status']=='fresh_cached_binary_stringio' and s.objects[b['io_id']]['encoding']=='ASCII-8BIT' and b['io_id']!='io0')
 s=State(cache=True,compiled=compiled);s.objects['str0']['bytes']='';s.duplicate_wrapper(True);check('empty_string_cache_is_ruby_truthy',s.body_receiver('auth_copy')['status']=='fresh_cached_binary_stringio')
 for header_value in [None,False,'chunked','identity']:
  s=State(compiled=compiled);s.duplicate_wrapper(True);r=s.raw_post('auth_copy',read_length=3,headers={'Transfer-Encoding':header_value});check(f'Transfer_Encoding_presence_{header_value}_not_truthiness',r['byte_interval']==[0,7])
 s=State(compiled=compiled);s.duplicate_wrapper(True);s.unknown_call();check('unknown_ambient_call_invalidates',s.raw_post('auth_copy',read_length=7)['status'].startswith('unresolved_'))
 s=State(body=b'\xc3\xa9',compiled=compiled);s.duplicate_wrapper(True);check('byte_extent_not_unicode_character_count',s.raw_post('auth_copy',read_length=1)['byte_interval']==[0,1])
 s=State();check('engine_requires_source_compilation',s.duplicate_wrapper(True)['status']=='unresolved_source_shape')
 s=State(compiled=compiled);s.duplicate_wrapper(True);check('negative_read_length_raises_no_cache',s.raw_post('auth_copy',read_length=-1)['status']=='exception_invalid_length_no_cache' and 'RAW_POST_DATA' not in s.envs['auth_copy'])
 for length in ['unknown','7',1.5,False]:
  s=State(compiled=compiled);s.duplicate_wrapper(True);check(f'unsupported_read_length_domain_{length}',s.raw_post('auth_copy',read_length=length)['status']=='unresolved_read_length_domain')
 s=State(compiled=compiled);s.duplicate_wrapper(True);check('default_unknown_length_not_full_read',s.raw_post('auth_copy')['status']=='unresolved_read_length_domain')
 s=State(compiled=compiled);s.duplicate_wrapper(True);check('zero_length_reads_empty',s.raw_post('auth_copy',read_length=0)['byte_interval']==[0,0])
 s=State(compiled=compiled);s.duplicate_wrapper(True);check('oversize_length_clamps',s.raw_post('auth_copy',read_length=100)['byte_interval']==[0,7])
 s=State(cache=True,compiled=compiled);s.duplicate_wrapper(True);fresh=s.body_receiver('auth_copy')['io_id'];s.mutate_shared_value('str0');del s.envs['auth_copy']['RAW_POST_DATA'];s.set_key('auth_copy','rack.input',fresh);check('shared_cache_mutation_invalidates_fresh_io',s.raw_post('auth_copy',read_length=7)['status']=='unresolved_receiver_or_escaped_state')
 s=State(cache=True,compiled=compiled);s.duplicate_wrapper(True);fresh=s.body_receiver('auth_copy')['io_id'];s.unknown_call(fresh);check('fresh_io_escape_invalidates_backing_cache',not s.objects['str0']['known'] and s.body_receiver('original')['status']=='unresolved_cached_value')
 s=State(body=b'',compiled=compiled);s.duplicate_wrapper(True);r=s.raw_post('auth_copy',read_length=3,headers={});check('positive_length_EOF_nil_cache_body_fallback',r['status']=='normal_return_nil_cached_locally' and s.envs['auth_copy']['RAW_POST_DATA'] is None and s.body_receiver('auth_copy')['status']=='fallback_shared_stream')
 s=State(body=b'',compiled=compiled);s.duplicate_wrapper(True);r=s.raw_post('auth_copy',read_length=0,headers={});check('zero_length_EOF_empty_String',r['status']=='normal_return_cached_locally' and s.objects[r['value_id']]['bytes']=='' and s.body_receiver('auth_copy')['status']=='fresh_cached_binary_stringio')
 s=State(body=b'',compiled=compiled);s.duplicate_wrapper(True);r=s.raw_post('auth_copy',headers={'Transfer-Encoding':None});check('no_length_EOF_empty_String',r['status']=='normal_return_cached_locally' and s.objects[r['value_id']]['bytes']=='')
 s=State(compiled=compiled);s.duplicate_wrapper(True);check('nil_length_without_transfer_header_rejected',s.raw_post('auth_copy',read_length=None,headers={})['status']=='unresolved_inconsistent_no_length_branch')
 v2freeze=json.loads((R/'reports/auth_request_normalization_body_effect_freeze_v2.json').read_text())
 for path,h in v2freeze['files'].items():assert hashlib.sha256((R/path).read_bytes()).hexdigest()==h
 old_freeze=json.loads((R/'reports/auth_request_normalization_body_effect_freeze.json').read_text())
 for path,h in old_freeze['files'].items():assert hashlib.sha256((R/path).read_bytes()).hexdigest()==h
 old_model=json.loads((R/'tables/auth_request_normalization_body_effect_model.jsonl').read_text())
 old_methods={x['method']:x for x in old_model['compiled_source_methods']}
 assert set(old_methods)==set(compiled)
 for name,m in compiled.items():assert m['method_sha256']==old_methods[name]['method_sha256']
 # Additional exact implementations supporting method topology/receiver and conditional lazy trigger.
 E=[evidence(AUTH,270,274,'Concrete later token helper dereferences current_request.params; normalizer itself does not do so'),evidence(AUTH,539,545,'One normalization boundary: first current_request memoized wrapper'),evidence(PARAM,51,65,'Uncached params invokes request_parameters; cached params avoids parse entirely'),evidence(REQ,404,416,'Request parameters invoke MIME strategy before normalized cache'),evidence(PARAM,89,100,'Selected nonempty JSON strategy invokes raw_post; strategy may fail after raw bytes cached'),evidence(REQ,62,71,'Rails Request initializer super(env) chain; only local metadata initialized'),evidence(REQ,19,29,'ActionDispatch Request is its own class including Rack::Request::Env, not a Rack::Request subclass'),evidence(RACK,46,53,'Rack Env initializer binds supplied Hash identity'),evidence('sources/wrappers/rails-7.2.3.1/actionpack/lib/action_dispatch/http/filter_parameters.rb',24,31,'Intermediate initializer only delegates and resets local filter metadata'),evidence('sources/wrappers/rails-7.2.3.1/actionpack/lib/action_dispatch/http/url.rb',181,185,'URL initializer delegates and clears metadata'),evidence('sources/runtime/ruby-v3_3_11/object.c',591,600,'Object dup allocates same-class destination and invokes dup setup'),evidence('sources/runtime/ruby-v3_3_11/object.c',543,549,'Dup setup invokes initialize_dup'),evidence('sources/runtime/ruby-v3_3_11/object.c',647,658,'Default initialize_dup invokes initialize_copy'),evidence('sources/runtime/ruby-v3_3_11/hash.c',7190,7190,'Hash initialize_copy registration'),evidence('sources/runtime/ruby-v3_3_11/hash.c',2967,2988,'Hash initialize_copy uses hash_copy'),evidence('sources/runtime/ruby-v3_3_11/hash.c',1530,1560,'Hash entries copied as VALUE references, not deep copies'),evidence('sources/gitlab/lib/api/helpers/packages/conan/api_helpers.rb',254,282,'Conan concrete credential helper overrides generic AuthFinders ownership'),evidence('sources/gitlab/lib/api/helpers.rb',87,106,'Actual current_user auth/scopes/audit roots remain unsummarized'),evidence('sources/gitlab/lib/api/api_guard.rb',56,83,'find_current_user and source selection invokes additional request-aware helpers'),evidence('sources/gitlab/lib/api/helpers/packages/conan/api_helpers.rb',197,199,'Conan selected sink reads original Grape request body, not ActionDispatch cached-body wrapper')]
 E += [evidence(REQ,284,288,'Transfer-Encoding presence gets cached/read raw bytes length; absent branch uses Rack length converted to integer'),evidence(RACK,158,160,'Rack content_length reads CONTENT_LENGTH env key'),evidence('sources/wrappers/rails-7.2.3.1/actionpack/lib/action_dispatch/http/headers.rb',77,80,'Headers key? delegates to env key presence'),evidence('sources/wrappers/rails-7.2.3.1/actionpack/lib/action_dispatch/http/headers.rb',123,132,'HTTP header spelling normalized to env key HTTP_TRANSFER_ENCODING')]
 E += [evidence('sources/gems/stringio-3.2.0/ext/stringio/stringio.c',1657,1730,'Exact StringIO positive-length EOF nil vs zero/no-length empty String and read extent; negative length raises'),evidence('sources/gems/stringio-3.2.0/ext/stringio/stringio.c',874,881,'Selected standard StringIO rewind resets position'),evidence('sources/gems/stringio-3.2.0/ext/stringio/stringio.c',2037,2037,'Selected StringIO has rewind method so nonrewindable branch outside exact receiver'),evidence('sources/gems/stringio-3.2.0/ext/stringio/stringio.c',2055,2055,'Exact read native registration')]
 model={'model_id':'auth_request_shallow_env_body_effect_v3','status':'source_supported_bounded_normalization_effect_pending_independent_review','scope':'Exactly one source-resolved first current_request->ensure_action_dispatch_request boundary; later lazy raw_post behavior is conditional, not eager or universally executed in all authentication branches.','historical_v2':'Preserved unchanged; corrected positive-length EOF nil and absent-transfer nil-length branch domains in v3. Nonrewindable alternative rejected for selected exact StringIO instead of claiming generic IO proof.','historical_v1':'Preserved unchanged; unsafe compiler operator elision, negative length and cached-String alias counterexamples corrected only in v2. V1 must not be used as current compiler.','compiler':'Exact ordered ALL-token tree-sitter AST contract recognition with comments/whitespace ignored; receiver/literal/call/branch/order changes reject, unknown source is unresolved. This is a narrow source-summary compiler, not whole-program inference.','compiled_source_methods':list(compiled.values()),'required_body_constructor_supplement':{'path':'tables/activity_pub_inbox_independent_source_supplement.jsonl','sha256':hashlib.sha256((R/'tables/activity_pub_inbox_independent_source_supplement.jsonl').read_bytes()).hexdigest(),'scope':'Fresh StringIO singleton new/initializer and unary-plus/subsequence semantics only, not ActivityPub route or callback claims.'},'initial_transfer':{'new_env_identity':True,'shallow_values_shared':['rack.input','preexisting RAW_POST_DATA String','preexisting params Hashes and other mutable values'],'body_read':False,'new_cache_write':False,'memoization':'Existing @current_request returns same wrapper and existing copied env; no fresh copy on later calls.'},'conditional_later_transfer':{'trigger':'Actual extract_personal_access_token source calls current_request.params first; ONLY if that branch is invoked and request/params/MIME caches require parsing does Rails params->request_parameters->parse_formatted_parameters->raw_post execute.','cache_absent':'Successful read_body_stream returns before set_header assigns local RAW_POST_DATA. Original env gets no new key through this local write.','cache_present':'has_header? checks key presence, even nil/false. Existing values return without read. body instead tests Ruby truthiness: nil/false fall back to shared stream, empty String creates fresh cached BINARY StringIO. Shared mutable existing values remain aliased until local binding replaced.','normal_selected_rewindable_io':'reset_stream rewind -> yield read -> rewind -> return content. Shared IO position restored0 on normal return; Transfer-Encoding HEADER PRESENCE selects no-length read regardless of value; otherwise content_length can select prefix, not necessarily full body.','exception':'No ensure. Read failure may advance shared IO with unknown position; final rewind failure leaves no new cache. Parser strategy failure happens AFTER raw_post cache write; does not erase cache automatically.','unknown':'Unknown call/escape invalidates reachable mutable identities; key replacement local but unknown value cannot be assumed same receiver. Deepdup/clone/overrides not supported.'},'preconditions':['Plain Hash env and exact retained standard Ruby3.3.11 Hash dup/copy semantics; subclasses/default_proc/overrides outside model.','Actual exact-source ActionDispatch/Rack constructors/accessors and selected StringIO read/rewind semantics; no runtime monkeypatch.','Only normal-return continuation can borrow restored-position summary. Unknown calls or input mutations are not waved away.'],'evidence':E,'coverage':{'reviewed_normalization_boundaries':1,'compiled_method_templates':len(compiled),'all_auth_paths_proven':False,'conan_promoted':False}}
 application={'application_id':'conan_auth_normalization_effect_application_v3','case_id':'conan_recipe_upload_ce_body_read_v1','model_id':model['model_id'],'status':'partial_specific_normalization_hole_closed_conditionally','closed_gap':'A fresh ActionDispatch auth request built by env.dup shares original Grape rack.input; constructing it alone does not consume body. A later source-matched successful raw_post read resets shared rewindable IO, while newly assigned cache is private to copied env.','not_closed':['Whether selected complete auth path invokes params/raw_post or returns cached params; choose and resolve actual namespace strategy and Conan overrides.','All intervening global filters, auth scopes/DPoP/language-server/service/organization/validation calls and unknown request escapes.','Actual dynamic receiver overrides, deployment stream type and exceptional outcomes.'],'promotion':False,'native_terminal_site_id':None,'effect':'Refines one known normalization boundary; does not replace old Conan partial or strengthen conditional-flow ledger.'}
 for name,obj in [('auth_request_normalization_body_effect_model_v3',model),('conan_normalization_effect_application_v3',application)]: (R/'tables'/f'{name}.jsonl').write_text(json.dumps(obj,sort_keys=True)+'\n')
 report={'status':'PASS','syntax_fixture_count':len(syntax),'syntax_fixtures':syntax,'effect_fixture_count':len(checks),'effect_fixtures':checks,'compiled_source_methods':len(compiled),'unchanged_actual_method_source_hashes_from_v1':len(compiled),'v1_frozen_hashes_preserved':True,'v2_frozen_hashes_preserved':True,'source_evidence_excerpts':len(E),'target_execution':False,'conan_flow_promoted':False}
 (R/'reports/auth_request_normalization_body_effect_validation_v3.json').write_text(json.dumps(report,indent=2)+'\n')
 schema={'model_pk':'model_id','application_pk':'application_id','application_model_fk':'model_id -> auth_request_normalization_body_effect_model_v3.model_id','method_evidence':'trace-relative file/full SHA/byte and inclusive line span, ordered source calls; AST shape must match before effects used','effect_objects':'Env mappings hold shared object identity tokens; per-env key binding and shared mutable value state distinguished','normalization_boundaries':1,'limits':'Source compiler is structural summary matcher, not complete effect analysis; fixture abstract states are not actual runtime observations.'}
 (R/'reports/auth_request_normalization_body_effect_schema_v3.json').write_text(json.dumps(schema,indent=2)+'\n')
 paths=['scripts/normalization_body_effect_model_v3.py','tables/auth_request_normalization_body_effect_model_v3.jsonl','tables/conan_normalization_effect_application_v3.jsonl','reports/auth_request_normalization_body_effect_validation_v3.json','reports/auth_request_normalization_body_effect_schema_v3.json']
 (R/'reports/auth_request_normalization_body_effect_freeze_v3.json').write_text(json.dumps({'files':{p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in paths},'previous_frozen_models_unchanged':True,'v2_independent_counterexample_report':{'path':'reports/auth_request_normalization_independent_review_v2.json','sha256':hashlib.sha256((R/'reports/auth_request_normalization_independent_review_v2.json').read_bytes()).hexdigest()},'v1_independent_counterexample_report':{'path':'reports/auth_request_normalization_independent_review_v1.json','sha256':hashlib.sha256((R/'reports/auth_request_normalization_independent_review_v1.json').read_bytes()).hexdigest()},'corrected_root_causes':['All anonymous operator/punctuation/keyword tokens now retained; v1 accepted semantic operator mutations.','Negative read length rejects; noninteger/unknown length unresolved and cannot imply full read. Positive-length EOF returns nil; absent Transfer-Encoding cannot use nil/no-length fact. Nonrewindable selected StringIO branch rejected.','Fresh StringIO preserves may-alias backing String dependency; mutations and escapes invalidate both directions transitively.']},indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items() if not k.endswith('fixtures')}))
if __name__=='__main__':main()
