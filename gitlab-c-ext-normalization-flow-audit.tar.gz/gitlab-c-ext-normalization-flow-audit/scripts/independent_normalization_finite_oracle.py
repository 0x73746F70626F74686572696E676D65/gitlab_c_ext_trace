#!/usr/bin/env python3
"""Finite abstract source oracle for pinned Rails raw_post + standard StringIO.
No Ruby, Rails or extension execution. Oracle derived independently from actual C/Ruby.
"""
import argparse,json,hashlib,importlib.util,itertools,sys
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');B=Path('/workspace/gitlab_c_ext_trace');sys.path.insert(0,str(V/'scripts'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def expected(body,pos,length,te,rewindable,cache):
 # Rack key presence short circuits before stream lookup/rewind/length selection.
 if cache!='absent':return {'kind':'existing','position':pos,'value':cache}
 # Exact standard StringIO cannot lack rewind without an excluded override.
 if not rewindable:return {'kind':'unresolved'}
 # Header key presence overrides content-length supplied facts even for nil/false values.
 effective=None if te else length
 if not te and (effective is None or type(effective) is not int):return {'kind':'unresolved'}
 if effective is not None and effective<0:return {'kind':'exception','position':0,'cache_present':False}
 # reset_stream successful first rewind makes initial position irrelevant.
 # StringIO positive count at EOF returns nil; zero count and noarg return empty String.
 if not body and effective is not None and effective>0:value=None
 else:value=body if effective is None else body[:effective]
 return {'kind':'normal','position':0,'cache_present':True,'bytes':value}
def normalize_result(s,r):
 status=r['status'];env=s.envs['auth_copy']
 if status.startswith('unresolved'):return {'kind':'unresolved'}
 if status=='existing_cache_returned_without_read':return {'kind':'existing','position':s.objects['io0']['pos'],'value_id':r['value_id']}
 if status.startswith('exception'):return {'kind':'exception','position':s.objects['io0']['pos'],'cache_present':'RAW_POST_DATA' in env}
 if 'RAW_POST_DATA' not in env:return {'kind':'unrecognized','status':status}
 value=env['RAW_POST_DATA'];b=None if value is None else s.objects[value]['bytes'].encode('latin1')
 return {'kind':'normal','position':s.objects['io0']['pos'],'cache_present':True,'bytes':b}
def main():
 a=argparse.ArgumentParser();a.add_argument('--version',default='v3');args=a.parse_args();p=V/'scripts'/f'normalization_body_effect_model_{args.version}.py'
 spec=importlib.util.spec_from_file_location('review_target',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);compiled={n:m.compile_source(n,(B/m.FILES[n]).read_bytes()) for n in m.TEMPLATES}
 assert all(x['status']=='supported_exact_ast_summary' for x in compiled.values())
 results=[]
 for body,pos_kind,length_kind,te,rewindable,cache in itertools.product([b'',b'abc'],['start','eof','beyond'],['zero','one','exceeds','negative','nil'],[False,True],[False,True],['absent','nil','false','String']):
  pos={'start':0,'eof':len(body),'beyond':len(body)+2}[pos_kind];length={'zero':0,'one':1,'exceeds':len(body)+2,'negative':-1,'nil':None}[length_kind]
  s=m.State(body=body,compiled=compiled);s.objects['io0']['pos']=pos
  if cache=='String':s.objects['cache_obj']={'kind':'String','bytes':body.decode('latin1'),'known':True};s.envs['original']['RAW_POST_DATA']='cache_obj'
  elif cache!='absent':s.envs['original']['RAW_POST_DATA']=None if cache=='nil' else False
  s.duplicate_wrapper(True);r=s.raw_post('auth_copy',read_length=length,headers={'Transfer-Encoding':None} if te else {},rewindable=rewindable)
  got=normalize_result(s,r);exp=expected(body,pos,length,te,rewindable,cache)
  if exp['kind']=='existing':exp['value_id']={'nil':None,'false':False,'String':'cache_obj'}[cache];exp.pop('value')
  ok=got==exp
  def ser(x):return {k:({'hex':v.hex()} if isinstance(v,bytes) else v) for k,v in x.items()}
  results.append({'body_hex':body.hex(),'initial_position':pos,'position_class':pos_kind,'length':length,'transfer_header_present':te,'rewindable':rewindable,'cache':cache,'expected':ser(exp),'actual':ser(got),'pass':ok})
 out={'status':'PASS' if all(r['pass'] for r in results) else 'FAIL','script_sha256':sha(p),'cases':len(results),'failures':sum(not r['pass'] for r in results),'case_records':results,'oracle_source':['Rack Env has_header? key presence and raw_post cache short circuit','Rails read_body_stream Transfer-Encoding presence vs content_length; reset_stream normal rewind/read/rewind no ensure','StringIO3.2.0 strio_read1657–1730 positive-count EOF nil versus zero/no-length emptyString'],'domain':'Finite hand-selected input bytes/positions/read counts/cache/header/receiver facts; NOT production recall, runtime testing or exhaustive verification. Missing rewind conflicts with exact standard StringIO model and is rejected only on actual read branch. Existing cache bypasses read and preserves position.','target_execution':False}
 outp=V/'reports'/f'normalization_finite_oracle_{args.version}.json';outp.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['status','cases','failures']}));print(sha(outp))
 if out['failures']:print(json.dumps([r for r in results if not r['pass']][:8],indent=2))
if __name__=='__main__':main()
