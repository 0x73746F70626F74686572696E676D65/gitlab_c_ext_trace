#!/usr/bin/env python3
"""Independent clean extraction/inspection audit; never executes bundled analysis/runtime."""
import csv,hashlib,json,subprocess,tarfile,tempfile
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_v3');archive=R/'publication/CURRENT_INPUT_FLOWS.tar.gz'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def jl(p):return [json.loads(l) for l in p.open() if l.strip()]
def main():
 global archive
 receipt=json.loads((R/'reports/publication_mlflow_cgi_flow_receipt.json').read_text());expected=next(x for x in receipt['archives'] if x['name']==archive.name);
 if sha(archive)!=expected['sha256']:
  archive=R/'publication/current-input-flows-history'/('CURRENT_INPUT_FLOWS-'+expected['sha256']+'.tar.gz')
 assert sha(archive)==expected['sha256'] and archive.stat().st_size==expected['bytes']
 stage=Path(tempfile.mkdtemp(prefix='gitlab-flow-inspection-',dir='/tmp'))
 with tarfile.open(archive) as t:
  members=t.getmembers();assert all(x.isfile() and not Path(x.name).is_absolute() and '..' not in Path(x.name).parts and x.name.startswith('CURRENT_INPUT_FLOWS/') for x in members)
 subprocess.run(['tar','-xzf',str(archive),'-C',str(stage)],check=True,capture_output=True)
 root=stage/'CURRENT_INPUT_FLOWS';run=subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=root,text=True,capture_output=True);assert run.returncode==0,run.stdout+run.stderr
 index=jl(root/'tables/request_flow_index_mlflow_final.jsonl');full=jl(root/'current_input_flows.jsonl');assert len(index)==29==len(full);assert len({x['flow_id'] for x in index})==29
 loaded={};byid={};joinchecks=0
 for i,x in enumerate(index):
  rr=x['record_reference'];p=root/rr['path'];assert p.is_file() and sha(p)==rr['file_sha256'];loaded.setdefault(rr['path'],jl(p));f=loaded[rr['path']][rr['line']-1];assert f['flow_id']==rr['flow_id']==x['flow_id'];assert full[i]['current_index']==x and full[i]['authoritative_record']==f
  for k in ['profile','terminal_site_id']:assert f[k]==x[k]
  byid[x['flow_id']]=x;joinchecks+=1
 overview=list(csv.DictReader((root/'OVERVIEW.csv').open()));assert len(overview)==29 and {x['flow_id'] for x in overview}==set(byid)
 arguments=list(csv.DictReader((root/'ARGUMENT_CONTROL.csv').open()));assert all(x['flow_id'] in byid for x in arguments)
 for x in arguments:
  ix=byid[x['flow_id']];assert x['recipe_path']==ix['record_reference']['path'] and int(x['recipe_line'])==ix['record_reference']['line']
  f=loaded[x['recipe_path']][int(x['recipe_line'])-1];claim=json.loads(x['argument_claim']);original=f.get('terminal_arguments');assert (claim in original if isinstance(original,list) else claim==original)
 cases=list(csv.DictReader((root/'SOURCE_CASES.csv').open()));mechs=list(csv.DictReader((root/'MECHANISMS.csv').open()))
 for summaries,key,field in [(cases,'source_case_family','frontend_source_case_family'),(mechs,'mechanism_id','conditional_memory_influence_mechanism')]:
  seen=[]
  for row in summaries:
   ids=row['flow_ids'].split(';');seen+=ids;assert int(row['terminal_flow_records'])==len(ids)
   g=[byid[n] for n in ids];assert all(x['scope_ledger']==row['scope'] and x['ledger_category']==row['record_kind'] for x in g)
   assert int(row['physical_sites'])==len({x['terminal_site_id'] for x in g if x.get('terminal_site_id')})
   if key=='source_case_family':assert all(x.get(field,'unspecified')==row[key] for x in g)
   else:assert all((x.get(field) or x.get('auxiliary_memory_influence_mechanism') or 'unspecified')==row[key] for x in g)
  assert len(seen)==29 and set(seen)==set(byid)
 refs=[]
 def walk(x,origin,trail=()):
  if isinstance(x,dict):
   p=x.get('path',x.get('table'));h=x.get('sha256',x.get('file_sha256'))
   if isinstance(p,str) and p.startswith(('tables/','reports/','schemas/','scripts/')):
    local=root/p;refs.append(dict(origin=origin,trail='.'.join(trail),path=p,present=local.is_file(),sha256=h))
    if local.is_file() and h:assert sha(local)==h,(origin,p)
   for k,v in x.items():walk(v,origin,trail+(k,))
  elif isinstance(x,list):
   for i,v in enumerate(x):walk(v,origin,trail+(str(i),))
 for p in sorted(root.rglob('*')):
  if p.suffix=='.jsonl':
   for x in jl(p):walk(x,str(p.relative_to(root)))
  elif p.suffix=='.json':walk(json.loads(p.read_text()),str(p.relative_to(root)))
 missing=sorted({x['path'] for x in refs if not x['present']});mandatory_missing=[x for x in refs if not x['present'] and ('supplement' in x['trail'] or x['origin']=='tables/request_flow_index_mlflow_final.jsonl')]
 assert not mandatory_missing,mandatory_missing
 primary=[x for x in index if x['ledger_category']=='conditional_source_flow'];counts=dict(main_records=len(primary),main_sites=len({x['terminal_site_id'] for x in primary}),main_mechanisms=len({x['conditional_memory_influence_mechanism'] for x in primary}),main_case_families=len({x['frontend_source_case_family'] for x in primary}),partials=sum(x['ledger_category']=='partial' for x in index),auxiliary=sum(x['ledger_category']=='auxiliary_version_conditioned_flow' for x in index));assert list(counts.values())==[26,13,6,11,2,1]
 report=dict(status='PASS_EXTRACTED_CONTENT_WITH_DOCUMENTATION_FIXES',published_commit=receipt['commit'],archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,clean_extraction_root=str(root),archive_members=len(members),internal_checksum_files=run.stdout.count(': OK'),exact_recipe_files=len(loaded),index_recipe_fullrecord_joins=joinchecks,csv_rows=dict(overview=len(overview),arguments=len(arguments),cases=len(cases),mechanisms=len(mechs)),counts=counts,structured_reference_occurrences=len(refs),missing_structured_paths=missing,missing_mandatory_current_evidence=mandatory_missing,mandatory_evidence_scope='Current index/recipe/supplement references and included structured hashed contracts checked; full source bodies and broad ID tables intentionally external.',documentation_findings=[dict(issue='Filename typo SHA 256 SUMS',fix='Use exact SHA256SUMS filename'),dict(issue='No clean extraction/check instructions',fix='Add tested tar -xzf and sha256sum -c commands, distinguish inspection from saved-environment regeneration')],extraction_commands=['mkdir -p inspection','tar -xzf CURRENT_INPUT_FLOWS.tar.gz -C inspection','cd inspection/CURRENT_INPUT_FLOWS','sha256sum -c SHA256SUMS'],not_established=['runtime execution','complete source or broad graph reproduction from this archive alone','global semantic precision/recall','case-family equals distinct route'],prior_files_modified=False,target_code_executed=False)
 out=R/'reports/final_morning_artifact_usability.json';out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
