#!/usr/bin/env python3
"""Bounded read-only presentation of exact indexed recipes; no reachability inference."""
import argparse,collections,csv,hashlib,json
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_v3')
def compact(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def csvwrite(path,fields,rows):
 with path.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def render(index,output):
 output.mkdir(parents=True,exist_ok=True);rows=[json.loads(l) for l in index.open()];arguments=[];recipes={};cases=collections.defaultdict(list);mechanisms=collections.defaultdict(list)
 for x in rows:
  rr=x['record_reference'];p=R/rr['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==rr['file_sha256'];f=json.loads(p.read_text().splitlines()[rr['line']-1]);assert f['flow_id']==x['flow_id'];recipes[x['flow_id']]=f
  kind=x['ledger_category'];scope=x['scope_ledger'];case=x.get('frontend_source_case_family') or 'unspecified';phase=x.get('frontend_phase_case_id') or 'unspecified';mechanism=x.get('conditional_memory_influence_mechanism') or x.get('auxiliary_memory_influence_mechanism') or 'unspecified'
  cases[(scope,kind,case)].append(x);mechanisms[(scope,kind,mechanism)].append(x)
  args=f.get('terminal_arguments');base=dict(flow_id=x['flow_id'],record_kind=kind,scope=scope,profile=x['profile'],source_case_family=case,phase_case=phase,mechanism=mechanism,terminal_site_id=x.get('terminal_site_id'),recipe_path=rr['path'],recipe_line=rr['line'])
  if isinstance(args,list):
   for arg in args:arguments.append(dict(base,argument_position=arg.get('position',''),influence=compact(arg.get('influence')),argument_claim=compact(arg),position_status='position_explicit_in_recipe' if 'position' in arg else 'position_not_stated'))
  else:arguments.append(dict(base,argument_position='',influence='',argument_claim=compact(args),position_status='unpositioned_recipe_argument_map' if isinstance(args,dict) else 'no_terminal_argument_claim'))
 csvwrite(output/'ARGUMENT_CONTROL.csv',list(arguments[0]),arguments)
 summaries=[]
 for (scope,kind,case),group in sorted(cases.items()):
  summaries.append(dict(scope=scope,record_kind=kind,source_case_family=case,source_case_name=case.replace('_',' '),selected_requests_json=compact([recipes[x['flow_id']].get('selected_request',recipes[x['flow_id']].get('selected_route',recipes[x['flow_id']].get('request_source'))) for x in group]),source_summaries_json=compact([recipes[x['flow_id']].get('source_kind',recipes[x['flow_id']].get('request_source',recipes[x['flow_id']].get('request_input_control'))) for x in group]),terminal_flow_records=len(group),profiles=';'.join(sorted({x['profile'] for x in group})),profile_count=len({x['profile'] for x in group}),profile_phase_pairs=len({(x['profile'],x.get('frontend_phase_case_id')) for x in group}),physical_sites=len({x['terminal_site_id'] for x in group if x.get('terminal_site_id')}),mechanism_ids=';'.join(sorted({x.get('conditional_memory_influence_mechanism') or x.get('auxiliary_memory_influence_mechanism') or 'unspecified' for x in group})),flow_ids=';'.join(x['flow_id'] for x in group),distinct_routes_proven=False))
 csvwrite(output/'SOURCE_CASES.csv',list(summaries[0]),summaries)
 mechanism_rows=[]
 for (scope,kind,mechanism),group in sorted(mechanisms.items()):
  mechanism_rows.append(dict(scope=scope,record_kind=kind,mechanism_id=mechanism,mechanism_name=mechanism.replace('_',' '),terminal_flow_records=len(group),source_case_families=len({x.get('frontend_source_case_family') for x in group}),profiles=';'.join(sorted({x['profile'] for x in group})),physical_sites=len({x['terminal_site_id'] for x in group if x.get('terminal_site_id')}),flow_ids=';'.join(x['flow_id'] for x in group)))
 csvwrite(output/'MECHANISMS.csv',list(mechanism_rows[0]),mechanism_rows)
 report=dict(status='PASS',source_index=str(index),source_index_sha256=hashlib.sha256(index.read_bytes()).hexdigest(),index_rows=len(rows),argument_rows=len(arguments),case_summary_rows=len(summaries),mechanism_summary_rows=len(mechanism_rows),main_conditional_source_case_families=len({x.get('frontend_source_case_family') for x in rows if x['ledger_category']=='conditional_source_flow'}),counts_are_not_distinct_routes=True,qualifications='Case-family groups can span profiles/phases/terminal sites; auxiliary and partial rows remain separate. Missing argument positions are left unstated; exact original argument maps retained. Content/derived count/fixed count claims are copied without stronger normalization.')
 (output/'overview_validation.json').write_text(json.dumps(report,indent=2)+'\n');return report
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--index',required=True);ap.add_argument('--output',required=True);a=ap.parse_args();print(json.dumps(render(R/a.index,Path(a.output))))
