#!/usr/bin/env python3
"""Bounded inspection bundle: current 29 records, exact recipes, selected contracts/reviews."""
import csv,gzip,hashlib,io,json,shutil,tarfile
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_v3');B=Path('/workspace/gitlab_c_ext_trace');D=R/'publication/current-input-flows'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():

 recipe=json.loads((R/'tables/passkey_bcrypt_source_recipe.jsonl').read_text().splitlines()[0])
 witness=recipe['selected_dummy_input']
 assert f'The selected dummy input {witness} has length {len(witness)};' in (D/'INDEX.txt').read_text(), 'narrative witness length differs from frozen recipe'
 latest='tables/request_flow_index_mlflow_final.jsonl';rows=[json.loads(l) for l in (R/latest).open()];assert len(rows)==29
 recipe_paths={x['record_reference']['path'] for x in rows};selected={latest}|recipe_paths
 def refs(x):
  found=set()
  if isinstance(x,dict):
   for v in x.values():found|=refs(v)
  elif isinstance(x,list):
   for v in x:found|=refs(v)
  elif isinstance(x,str) and x.startswith(('tables/','reports/','schemas/','scripts/')) and (R/x).is_file():found.add(x)
  return found
 for x in rows:selected|=refs(x)
 # Exactly one bounded supporting-reference expansion; never recursive graph/tree copying.
 initial=tuple(selected)
 for n in initial:
  assert (R/n).stat().st_size<2_000_000,('support exceeds manual bound',n)
  if n.endswith('.jsonl'):
   for l in (R/n).open():selected|=refs(json.loads(l))
  elif n.endswith('.json'):selected|=refs(json.loads((R/n).read_text()))
 manual=['reports/mlflow_cgi_escape_independent_review.json','reports/mlflow_cgi_escape_native_independent_review.json','tables/mlflow_cgi_escape_independent_source_supplement.jsonl','reports/mlflow_cgi_escape_path_provenance_boundary.txt','tables/cgi_escape_native_contract_v1.jsonl','reports/mlflow_union_root_verification.json','reports/next_distinct_mechanism_prioritization.json','tables/request_memory_flows_cgi_branches.jsonl','tables/cgi_unescape_native_contract_v1.jsonl','tables/cgi_branches_independent_forcing_supplement.jsonl','tables/raw_query_find_prefix_transfer_correction_v2.jsonl','reports/cgi_branches_independent_assembly_review.json','reports/cgi_unescape_native_independent_review.json','reports/query_prefix_v2_independent_review.json','reports/activity_pub_inbox_independent_review.json','reports/stringio_constructor_targeted_prior_flow_check.json','tables/activity_pub_inbox_source_recipe.jsonl','tables/activity_pub_inbox_independent_source_supplement.jsonl','tables/rails_cached_body_transfer_contract.jsonl','reports/passkey_bcrypt_independent_assembly_review.json','reports/bcrypt_v2_independent_native_review.json','reports/actioncontroller_callback_model_independent_review.json','reports/bcrypt_native_feasibility_v2_erratum.json','reports/passkey_bcrypt_flow_methodology.txt','tables/passkey_bcrypt_source_recipe.jsonl','tables/passkey_bcrypt_source_supplement_v2.jsonl','tables/bcrypt_native_feasibility_v2.jsonl','tables/actioncontroller_before_callback_invocation_model_v2.jsonl','reports/flow3_independent_assembly_review.json','reports/flow4_independent_assembly_review.json','reports/flow4_graphql_independent_assembly_review.json','reports/independent_json_sorter_source_review.json','reports/independent_json_capacity_review.json','reports/independent_psych_libyaml_bridge_review.json','reports/ruby_runtime_acquisition.json','reports/ruby_runtime_contract_review_iteration3.json','tables/ruby_runtime_contract_supplement_iteration3.jsonl','reports/rails_request_json_flow_methodology.txt','reports/ci_lint_psych_flow_methodology.txt','reports/request_flow_iteration3_methodology.txt','reports/request_flow_iteration4_methodology.txt','reports/request_flow_methodology.txt','reports/route_initializer_invocation_iteration3.json']
 selected|={n for n in manual if (R/n).exists()}
 for p in (R/'schemas').glob('*flow*.json'):selected.add(str(p.relative_to(R)))
 for p in (R/'reports').glob('request_flow_index_mlflow_final_*.json'):selected.add(str(p.relative_to(R)))
 audit_manifest=json.loads((R/'reports/final_morning_audit_manifest.json').read_text())
 for entry in audit_manifest['files']:
  assert sha(R/entry['path'])==entry['sha256']
  selected.add(entry['path'])
 selected.add('reports/final_morning_audit_manifest.json')
 selected.add('scripts/package_current_input_flows.py');selected.add('scripts/render_current_flow_overview.py')
 # Historical v1 contracts remain external; v2 contracts are authoritative for this addition.
 selected-={'tables/bcrypt_native_feasibility.jsonl','tables/passkey_bcrypt_source_supplement.jsonl','tables/actioncontroller_before_callback_invocation_model.jsonl'}
 assert len(selected)<=120 and sum((R/n).stat().st_size for n in selected)<8_000_000,'bounded manual scope exceeded'
 stage=D/'CURRENT_INPUT_FLOWS';D.mkdir(parents=True,exist_ok=True)
 if stage.exists():shutil.rmtree(stage)
 stage.mkdir()
 for n in sorted(selected):
  dest=stage/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,dest)
 records=[];sources=set()
 def source_refs(x):
  if isinstance(x,dict):
   for k,v in x.items():
    if k in ('file','path','source_file') and isinstance(v,str) and v.startswith('sources/') and (B/v).is_file():sources.add(v)
    source_refs(v)
  elif isinstance(x,list):
   for v in x:source_refs(v)
 for x in rows:
  ref=x['record_reference'];p=R/ref['path'];assert sha(p)==ref['file_sha256'];record=json.loads(p.read_text().splitlines()[ref['line']-1]);assert record['flow_id']==ref['flow_id']==x['flow_id']
  records.append(dict(flow_id=x['flow_id'],current_index=x,authoritative_record=record));source_refs(x);source_refs(record)
 from render_current_flow_overview import render
 overview_report=render(R/latest,stage)
 (stage/'current_input_flows.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in records))
 from render_reviewed_argument_control import render as render_reviewed
 reviewed_argument_report=render_reviewed(stage)
 (stage/'reviewed_argument_validation.json').write_text(json.dumps(reviewed_argument_report,indent=2)+'\n')
 fields=['flow_id','record_kind','scope','profile','source_case_family','phase_case','mechanism','terminal_site_id','recipe_path','recipe_line','gitlab_sha','runtime_verified']
 with (stage/'OVERVIEW.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for x in rows:w.writerow(dict(flow_id=x['flow_id'],record_kind=x['ledger_category'],scope=x['scope_ledger'],profile=x['profile'],source_case_family=x.get('frontend_source_case_family'),phase_case=x.get('frontend_phase_case_id'),mechanism=x.get('conditional_memory_influence_mechanism'),terminal_site_id=x.get('terminal_site_id'),recipe_path=x['record_reference']['path'],recipe_line=x['record_reference']['line'],gitlab_sha=x.get('gitlab_sha'),runtime_verified=False))
 (stage/'selected_source_provenance.json').write_text(json.dumps([dict(file=f,sha256=sha(B/f),bytes=(B/f).stat().st_size,durable_location=str(B/f)) for f in sorted(sources)],indent=2)+'\n')
 if (B/'reports/provenance.json').exists():shutil.copyfile(B/'reports/provenance.json',stage/'original_gitlab_provenance.json')
 (stage/'INDEX.txt').write_text((D/'INDEX.txt').read_text())
 # Document supporting references intentionally not recursively pulled into inspection scope.
 external=set()
 for n in selected:
  if n.endswith('.jsonl'):
   for l in (R/n).open():external|=refs(json.loads(l))-selected
  elif n.endswith('.json'):
   try:external|=refs(json.loads((R/n).read_text()))-selected
   except ValueError:pass
 (stage/'external_support_references.json').write_text(json.dumps([dict(path=n,durable_location=str(R/n),sha256=sha(R/n),bytes=(R/n).stat().st_size) for n in sorted(external)],indent=2)+'\n')
 cat=[dict(path=str(p.relative_to(stage)),bytes=p.stat().st_size,sha256=sha(p),rows=sum(1 for _ in p.open('rb')) if p.suffix=='.jsonl' else None) for p in sorted(stage.rglob('*')) if p.is_file()]
 (stage/'table_catalog.json').write_text(json.dumps(cat,indent=2)+'\n')
 (stage/'validation.json').write_text(json.dumps(dict(status='PASS',index_rows=29,primary_conditional=sum(x['ledger_category']=='conditional_source_flow' for x in rows),primary_partial=sum(x['ledger_category']=='partial' for x in rows),auxiliary=sum(x['ledger_category']=='auxiliary_version_conditioned_flow' for x in rows),authoritative_recipe_files=len(recipe_paths),recipe_bytes=sum((R/n).stat().st_size for n in recipe_paths),selected_source_files=len(sources),selected_support_files=len(selected),external_support_references=len(external),record_hash_id_line_checks_passed=True,scope='Inspection/review bundle, not standalone graph regeneration or runtime verification'),indent=2)+'\n')
 (stage/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(stage)}\n' for p in sorted(stage.rglob('*')) if p.is_file()))
 arc=R/'publication/CURRENT_INPUT_FLOWS.tar.gz'
 if arc.exists():
  history=R/'publication/current-input-flows-history';history.mkdir(exist_ok=True)
  backup=history/('CURRENT_INPUT_FLOWS-'+sha(arc)+'.tar.gz')
  if not backup.exists():shutil.copyfile(arc,backup)
  assert sha(backup)==sha(arc)
 with arc.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0,compresslevel=9) as gz,tarfile.open(fileobj=gz,mode='w') as t:
  for p in sorted(stage.rglob('*')):
   if p.is_file():
    info=tarfile.TarInfo('CURRENT_INPUT_FLOWS/'+str(p.relative_to(stage)));info.size=p.stat().st_size;info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(p.read_bytes()))
 with tarfile.open(arc,'r:gz') as t:got={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers()}
 assert got=={'CURRENT_INPUT_FLOWS/'+str(p.relative_to(stage)):sha(p) for p in stage.rglob('*') if p.is_file()}
 for n in selected:assert sha(stage/n)==sha(R/n),n
 result=dict(status='PASS',archive=str(arc),bytes=arc.stat().st_size,sha256=sha(arc),members=len(got),authoritative_recipe_files=len(recipe_paths))
 (D/'archive_validation.json').write_text(json.dumps(result,indent=2)+'\n');(D/'SHA256SUMS').write_text(f"{result['sha256']}  {arc.name}\n");print(json.dumps(result))
if __name__=='__main__':main()
