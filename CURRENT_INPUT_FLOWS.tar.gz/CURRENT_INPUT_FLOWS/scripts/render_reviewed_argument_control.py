#!/usr/bin/env python3
"""Additive audited argument annotations; preserves original recipes/CSV claims."""
import csv,json,hashlib
from pathlib import Path
def render(root):
 records={x['flow_id']:x for x in map(json.loads,(root/'current_input_flows.jsonl').open())};reviews=list(map(json.loads,(root/'audit/final_morning_argument_audit/record_reviews.jsonl').open()));assert len(reviews)==len(records)==29;out=[]
 for r in reviews:
  f=records[r['flow_id']]['authoritative_record'];assert hashlib.sha256(json.dumps(f,sort_keys=True).encode()).hexdigest()==r['source_record_sha256']
  for arg in r['argument_positions_audited'] or [dict(position=None,control_kind='no_terminal_argument_claim')]:
   out.append(dict(flow_id=r['flow_id'],profile=r['profile'],scope=r['scope'],record_kind=r['ledger_category'],site_id=r['site_id'],mechanism=r['mechanism'],argument_position=arg.get('position'),control_kind=arg.get('control_kind'),meaning=arg.get('meaning'),argument_details_json=json.dumps(arg,sort_keys=True),original_argument_map_shape=r['argument_map_shape'],required_guard=r['required_guard'],qualification=r['qualification'],review_status=r['status'],authorship_overlap=True,runtime_executed=False))
 with (root/'ARGUMENT_CONTROL_REVIEWED.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
 return dict(records=len(reviews),argument_rows=len(out),source_record_hashes_verified=True,original_recipe_bytes_unchanged=True)
