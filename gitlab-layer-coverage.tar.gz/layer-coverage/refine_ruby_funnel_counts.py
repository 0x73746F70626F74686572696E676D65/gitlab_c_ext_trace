import json,pathlib,collections
B=pathlib.Path('/workspace/gitlab_c_ext_trace');A=B/'audit/end_to_end_20260930';p=A/'layer_ruby_funnel.json';d=json.load(open(p))
def rows(p):return (json.loads(l) for l in open(p))
regs=list(rows(B/'tables/c_registrations.jsonl'));sources=list(rows(B/'tables/c_source_gems.jsonl'))
for label,v in d['profiles'].items():
 G=pathlib.Path('/workspace/gitlab_c_ext_ruby_expanded' if label=='ce' else '/workspace/gitlab_c_ext_ee_profile')
 primary={g['gem_id'] for g in rows(B/'tables/gems.jsonl') if g.get('lockfile')=='Gemfile.lock'} if label=='ce' else set(json.load(open(G/'reports/profile_config.json'))['primary_gem_ids'])
 canon={r['canonical_gem_id'] for r in sources if r['gem_id'] in primary};rs={r['registration_id'] for r in regs if r['gem_id'] in canon};cf={r['registration_id'] for r in regs if r['registration_id'] in rs and r.get('c_function_id')}
 bs=[r for r in rows(G/'tables/ruby_native_registrations.jsonl') if r['registration_id'] in rs and r.get('primary_locked')];owned={r['registration_id'] for r in bs if r.get('resolution')=='syntactic_owner_and_name' and r.get('namespace') and r.get('method')}
 v['registrations'].update(ruby_owner_name_bound=len(owned),ruby_owner_name_unbound=len(rs-owned),both_c_function_and_ruby_owner_bound=len(cf&owned),owner_binding_rows_by_resolution=dict(collections.Counter(r['resolution'] for r in bs)))
 v['registrations']['unresolved_owner_includes']='Receiver unknown, alias kind unknown, ambiguous receiver variable or missing literal method name; rows are not all owner-resolved merely because table contains them.'
 if label=='ce':
  c=json.load(open(G/'reports/expanded_parse_coverage.json'));v['parsing']['accepted_scopes_reconciliation']={k:c[k] for k in ['status','accepted_scopes','merged_files']};v['parsing']['accepted_scopes_reconciliation'].update(eligible_file_memberships=sum(x['eligible_files'] for x in c['scopes']),missing_files=len(c['missing_files']),duplicate_files=len(c['duplicate_files']),source_hash_mismatches=len(c['source_hash_mismatches']))
 api=v['traced_identified_gem_api_calls'];api['mapped_to_identified_gem_method_or_registration']=api['denominator'];api['unknown_receiver_calls_not_classifiable_as_gem_api']=v['traced_call_slice']['unresolved_no_candidate'];api['qualification']+=' The latter unknown-receiver count is the slice unresolved count, not an assertion all are gem calls.'
 v['definitions']['owner_bound_numerator']='Unique registration IDs with resolution syntactic_owner_and_name and nonempty namespace/method; ambiguous ownership not counted as bound.'
p.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:{'registrations':v['registrations'],'slice':v['traced_call_slice'],'whole':v['whole_active_call_records'],'gem_api':v['traced_identified_gem_api_calls'],'parsing':v['parsing']} for k,v in d['profiles'].items()},indent=2))
# Supplement: count continuation on every position of retained representative paths,
# not only their root-call index. This still does not enumerate missing paths.
for label,v in d['profiles'].items():
 G=pathlib.Path('/workspace/gitlab_c_ext_ruby_expanded' if label=='ce' else '/workspace/gitlab_c_ext_ee_profile');F=pathlib.Path('/workspace/gitlab_c_ext_frontend_v2') if label=='ce' else G
 primary={g['gem_id'] for g in rows(B/'tables/gems.jsonl') if g.get('lockfile')=='Gemfile.lock'} if label=='ce' else set(json.load(open(G/'reports/profile_config.json'))['primary_gem_ids'])
 gfiles={r['file_id'] for r in rows(G/'tables/ruby_file_gems.jsonl') if r['gem_id'] in primary};gm={r['method_id'] for r in rows(G/'tables/ruby_methods.jsonl') if r['file_id'] in gfiles}
 hs=list(rows(F/'tables/frontend_ruby_hops.jsonl'));apis={h['call_id'] for h in hs if h.get('call_id') and (h.get('target_type')=='registration' or h.get('target_id') in gm)};apis|={r['call_id'] for r in rows(F/'tables/frontend_unmapped_gem_apis.jsonl')}
 continuation={h['call_id'] for h in hs if h.get('target_type')=='registration'}
 for r in rows(G/'tables/ruby_native_paths.jsonl'):
  if r.get('primary_bundle_compatible') is True:continuation.update(r['call_path'])
 api=v['traced_identified_gem_api_calls'];api['with_retained_native_path']=len(apis&continuation);api['without_retained_native_path']=len(apis-continuation);api['qualification']='Native continuation includes every call position in retained primary-compatible representative paths plus direct registration hops; not just root-call index. Pure Ruby APIs legitimately lack native paths. Conditional/candidate graph suffix availability does not prove usable receiver binding or runtime execution. Unknown-receiver calls cannot be exhaustively attributed to gems.'
p.write_text(json.dumps(d,indent=2)+'\n')
print('FINAL_API', {k:v['traced_identified_gem_api_calls'] for k,v in d['profiles'].items()})
