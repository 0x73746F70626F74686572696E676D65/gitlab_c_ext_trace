#!/usr/bin/env python3
"""Read-only census of retained source/parser manifests; no source inference or rebuild."""
import json,pathlib,collections,hashlib,subprocess
R=pathlib.Path('/workspace/gitlab_c_ext_trace');A=R/'audit/end_to_end_20260930';EE=R.parent/'gitlab_c_ext_ee_profile';EXP=R.parent/'gitlab_c_ext_ruby_expanded'
def rows(p):
 if p.exists():
  for l in p.open():
   if l.strip():yield json.loads(l)
def load(p):return json.loads(p.read_text()) if p.exists() else None
def source_manifest(p):
 c=collections.Counter();paths=set();dups=0
 for r in rows(p):
  s=r.get('path',r.get('file'));c['manifest_rows']+=1;c['bytes']+=r.get('bytes',0);c['sha256_present']+=bool(r.get('sha256'));c['kind_'+str(r.get('kind','file'))]+=1
  if s in paths:dups+=1
  paths.add(s)
  group='/'.join(str(s).split('/')[:2]) if not str(s).startswith('/') else 'absolute_profile_source'
  c['scope_'+group]+=1
 return {'manifest':str(p),'counts':dict(c),'unique_manifest_paths':len(paths),'duplicate_path_rows':dups,'semantics':'Manifest census of retained file entries, not expected contents of inaccessible published gem archives; all source identities retain original provenance qualifiers.'}
def ruby(p,prefix=None):
 c=collections.Counter();seen=set();error_files=[];corpora=collections.Counter()
 for r in rows(p):
  f=r['file']
  if prefix and not f.startswith(prefix):continue
  c['rows']+=1;c['bytes']+=r.get('bytes',0);c['error_flagged_files']+=bool(r.get('has_parse_error'));c['no_error_flag_files']+=not bool(r.get('has_parse_error'));corpora[r.get('corpus','unknown')]+=1
  if f in seen:c['duplicate_file_path_rows']+=1
  seen.add(f)
  if r.get('has_parse_error'):error_files.append({'file':f,'file_id':r.get('file_id')})
 return {'manifest':str(p),'path_filter':prefix,'counts':dict(c),'unique_file_paths':len(seen),'corpus_counts':dict(corpora),'error_files':error_files,'semantics':'File appears in AST parser manifest; no-error flag is syntactic parser status, not semantic completeness. Retained recoverable AST output can coexist with parser errors.'}
primary=[r for r in rows(R/'tables/gems.jsonl') if r.get('lockfile')=='Gemfile.lock'];eeprimary=list(rows(EE/'tables/profile_gems.jsonl'));gems={}
for label,rs in [('ce',primary),('ee',eeprimary)]:
 gems[label]={'locked_entries':len(rs),'unique_names':len({r['name'] for r in rs}),'source_available_entries':sum(bool(r.get('source_dir')) for r in rs),'source_unknown_entries':sum(not r.get('source_dir') for r in rs),'retained_root_count':len({r['source_dir'] for r in rs if r.get('source_dir')}),'unknown_gem_expected_file_count':None,'unknown_gem_expected_native_file_count':None,'platform_entries':dict(collections.Counter(r.get('platform') for r in rs)),'raw_native_flag_counts':dict(collections.Counter(str(r.get('native')) for r in rs)),'qualification':'Raw native boolean is broad source-tree C-family presence including test/sibling/vendor code; refined primary classifications are separate. Missing source sizes/file counts are unknown, not zero.'}
cf=list(rows(R/'tables/c_files.jsonl'));nc=collections.Counter()
for r in cf:
 nc['parsed_file_records']+=1;nc['parse_error_file_records']+=r.get('parse_error_count',0)>0;nc['no_parse_error_file_records']+=r.get('parse_error_count',0)==0;nc['error_or_missing_nodes_record_sum']+=r.get('parse_error_count',0);nc['initial_error_or_missing_nodes_record_sum']+=r.get('initial_parse_error_count',0)
reports={'source_layer':'deterministic_observed_census','dataset_id':'97267dd258e01a46620e45d398eee914e53c46e431bae5b4ff5f1354bab1a849','primary_gems':gems,'refined_primary_classification':load(R/'reports/primary_completeness_audit.json'),'retained_source_manifests':{'baseline_and_expanded':source_manifest(R/'tables/source_files.jsonl'),'separate_full_ee':source_manifest(R/'reports/ee_discovery_candidate_source_manifest.jsonl'),'ee_new_gem_versions':source_manifest(EE/'tables/profile_new_source_manifest.jsonl')},'native_parser':{'counts':dict(nc),'unique_textual_paths':len({r['path'] for r in cf}),'physical_deduplicated':{'files':len({str((R/r['path']).resolve()) for r in cf}),'files_with_error_or_missing_nodes':sum(r.get('parse_error_count',0)>0 for r in {str((R/q['path']).resolve()):q for q in cf}.values()),'error_or_missing_node_count':sum(r.get('parse_error_count',0) for r in {str((R/q['path']).resolve()):q for q in cf}.values())},'parse_counter_definition':'analyze_c.py counts nodes whose type is ERROR OR is_missing; physical-deduplicated sums differ from record sums because same sources have repeated gem-bound rows and path aliases','source_reconciliation':load(R/'reports/c_source_reconciliation.json'),'language_records':dict(collections.Counter(r.get('language') for r in cf)),'scope_qualification':'Expected denominator applies selected native suffixes/retained roots only; deferred grpc-tools is explicit; missing gem sources and external system headers are outside observed denominator, unknown globally.'},'ruby_parser':{'ce_expanded_graph_manifest':ruby(EXP/'tables/ruby_files.jsonl'),'ce_gitlab_prefix':ruby(EXP/'tables/ruby_files.jsonl','sources/gitlab/'),'ee_combined_graph_manifest':ruby(EE/'tables/ruby_files.jsonl'),'ee_gitlab_prefix':ruby(EE/'tables/ruby_files.jsonl','sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/'),'ee_selected_input_scope':load(EE/'reports/ruby_production_scope.json')},'independent_source_and_lexical_baseline':load(R/'reports/independent_baselines/coverage_baselines.json'),'bounded_native_mismatch_triage':load(A/'native_baseline_mismatch_summary.json'),'limitations':['No global semantic recall derived from parser-manifest inclusion or lexical overlap.','No exact published gem archive byte-equivalence asserted for qualified repository/tag sources.','Native declaration/build selection and compiled runtime coverage remain unproven.','Ruby graph manifests include reused baseline gem files and may contain sources outside a profile execution scope; path-filtered rows are separately enumerated.','Independent production filter excludes vendor and tests; CE vendored sidekiq parser error remains relevant to gem-wrapper coverage even though outside that filter.']}
for label,root in [('ce_expanded_graph_manifest',EXP),('ee_combined_graph_manifest',EE)]:
 rr=reports['ruby_parser'][label]; rr['parse_issue_rows']=sum(1 for _ in rows(root/'tables/ruby_parse_issues.jsonl'));rr['non_gitlab_prefix_rows']=rr['counts']['rows']-sum(r['file'].startswith(('sources/gitlab/','sources/ee_discovery/')) for r in rows(root/'tables/ruby_files.jsonl'))
cepaths={x['path'].removeprefix('sources/gitlab/') for x in rows(R/'tables/source_files.jsonl') if x['path'].startswith('sources/gitlab/')};eepaths={x['path'] for x in rows(R/'reports/ee_discovery_candidate_source_manifest.jsonl')};recon={}
for label,root,got in [('ce',R/'sources/gitlab',cepaths),('ee',R/'sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2',eepaths)]:
 expected={s.decode() for s in subprocess.check_output(['git','ls-tree','-r','-z','--name-only','HEAD'],cwd=root).split(b'\0') if s};recon[label]={'tracked_expected_files':len(expected),'manifested_files':len(got),'missing_tracked_paths':sorted(expected-got),'extra_manifest_paths':sorted(got-expected),'expected_scope':'Pinned Git commit tracked tree; no canonical upstream latest identity claim.'}
reports['gitlab_tracked_tree_reconciliation']=recon
(A/'layer_source_funnel.json').write_text(json.dumps(reports,indent=2));checkpoint={'primary_gems':{k:{x:v[x] for x in ['locked_entries','source_available_entries','source_unknown_entries']} for k,v in gems.items()},'source_manifests':{k:v['unique_manifest_paths'] for k,v in reports['retained_source_manifests'].items()},'native_parser':dict(nc),'ruby_parser':{k:{'rows':v['counts']['rows'],'error_flagged_files':v['counts']['error_flagged_files'],'unique_paths':v['unique_file_paths'],'corpus':v['corpus_counts']} for k,v in reports['ruby_parser'].items() if isinstance(v,dict) and 'counts' in v},'native_physical':reports['native_parser']['physical_deduplicated']};print(json.dumps(checkpoint))
