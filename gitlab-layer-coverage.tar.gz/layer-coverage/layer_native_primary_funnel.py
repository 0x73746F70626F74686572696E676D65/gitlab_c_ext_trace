import json,pathlib,collections
R=pathlib.Path('/workspace/gitlab_c_ext_trace');T=R/'tables';D=R/'audit/end_to_end_20260930'
def rows(n):
 with (T/(n+'.jsonl')).open()as f:
  for s in f:yield json.loads(s)
primary={x['gem_id']for x in rows('gems')if x.get('primary_bundle')or x.get('lockfile')=='Gemfile.lock'}
canonical={x['canonical_gem_id']for x in rows('c_source_gems')if x['gem_id']in primary}
sites={x['site_id']:x for x in rows('primitive_sites')};mapping={x['primitive_id']:x['site_id']for x in rows('primitive_evidence_sites')};sel={k for k,v in sites.items()if set(v['gem_ids'])&canonical};calls=collections.Counter();syntax=collections.Counter();n=target=0
for x in rows('c_calls'):
 if x['gem_id']in canonical:n+=1;calls[x['resolution']]+=1;syntax[x['syntax']]+=1;target+=bool(x.get('target_function_id'))
regs=[x for x in rows('c_registrations')if x['gem_id']in canonical];reached=set();reachedreg=set()
for x in rows('c_reachability'):
 if x['gem_id']in canonical:reached.add(mapping[x['primitive_id']]);reachedreg.add(x['registration_id'])
out={'scope':'Primary Gemfile.lock source aliases expanded through c_source_gems canonical IDs; excludes auxiliary lock-only gem versions, but includes vendor/test/example files within primary source trees. No primary package-membership purity claim.','primary_locked_gem_ids':len(primary),'canonical_source_gem_ids_with_bindings':len(canonical),'site_count':len(sel),'site_kinds':dict(collections.Counter(sites[k]['site_kind']for k in sel)),'sites_with_registration_graph_path':len(reached),'reached_site_kinds':dict(collections.Counter(sites[k]['site_kind']for k in reached)),'call_records':n,'call_targets_attached':target,'call_resolution_labels':dict(calls),'call_syntax_labels':dict(syntax),'registrations':len(regs),'registrations_with_target':sum(bool(x.get('c_function_id'))for x in regs),'registrations_with_any_primitive_graph_path':len(reachedreg),'caveat':'Call rows are unique call-ID evidence, not physically deduplicated C call expressions. Registration graph connectivity is not feasible runtime reachability.'}
full=json.loads((D/'layer_native_funnel.json').read_text());full['primary_bundle']=out;allreach={mapping[x['primitive_id']]for x in rows('c_reachability')};front={}
for name,root in [('ce',R.parent/'gitlab_c_ext_frontend_v2'),('ee',R.parent/'gitlab_c_ext_ee_profile')]:
 s={x['terminal_site_id']for x in map(json.loads,(root/'tables/frontend_paths.jsonl').open())};front[name]={'distinct_terminal_sites':len(s),'site_kinds':dict(collections.Counter(sites[k]['site_kind']for k in s)),'intersection_with_any_registration_graph_sites':len(s&allreach),'outside_any_registration_graph_sites':len(s-allreach),'primary_ce_source_site_intersection':len(s&sel),'semantic_status':'Frozen complete candidate witnesses, known contradicted in audit; not proven frontend reachability.'}
full['frontend_candidate_sites']=front;(D/'layer_native_funnel.json').write_text(json.dumps(full,indent=2)+'\n');print(json.dumps({'primary_bundle':out,'frontend':front},indent=2))
