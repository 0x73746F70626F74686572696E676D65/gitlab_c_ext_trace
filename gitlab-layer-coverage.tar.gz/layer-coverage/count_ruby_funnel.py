import json,pathlib,collections,time
B=pathlib.Path('/workspace/gitlab_c_ext_trace');A=B/'audit/end_to_end_20260930'
def read(p):
 with open(p) as f:
  for l in f:yield json.loads(l)
regs=list(read(B/'tables/c_registrations.jsonl'));source=list(read(B/'tables/c_source_gems.jsonl'))
result={'dataset_id':'97267dd258e01a46620e45d398eee914e53c46e431bae5b4ff5f1354bab1a849','semantic_qualification':'All mapping numerators below describe frozen graph construction, not semantic audit success. Sample audit disproved some constructed chains. No graph regenerated.','profiles':{}}
for label,G,F in [('ce',pathlib.Path('/workspace/gitlab_c_ext_ruby_expanded'),pathlib.Path('/workspace/gitlab_c_ext_frontend_v2')),('ee',pathlib.Path('/workspace/gitlab_c_ext_ee_profile'),pathlib.Path('/workspace/gitlab_c_ext_ee_profile'))]:
 contract=json.load(open(G/'reports/frontend_input_contract.json'));prefix=contract['gitlab_source_prefixes']
 def prod(f):return any(f.startswith(p) for p in prefix) and not any(x in f for x in ('/spec/','/test/','/tests/','/qa/','/examples/','/fixtures/','/benchmark/','/vendor/'))
 if label=='ce':primary={g['gem_id'] for g in read(B/'tables/gems.jsonl') if g.get('lockfile')=='Gemfile.lock'}
 else:primary=set(json.load(open(G/'reports/profile_config.json'))['primary_gem_ids'])
 canon={s['canonical_gem_id'] for s in source if s['gem_id'] in primary};rids={r['registration_id'] for r in regs if r['gem_id'] in canon}
 bound=list(read(G/'tables/ruby_native_registrations.jsonl'));owned={r['registration_id'] for r in bound if r.get('primary_locked') and r['registration_id'] in rids and r.get('resolution')=='syntactic_owner_and_name' and r.get('namespace') and r.get('method')};cf={r['registration_id'] for r in regs if r['registration_id'] in rids and r.get('c_function_id')}
 methods={r['method_id']:r for r in read(G/'tables/ruby_methods.jsonl')};files={r['file_id']:r for r in read(G/'tables/ruby_files.jsonl')};gemfiles=set();gemids=set()
 for r in read(G/'tables/ruby_file_gems.jsonl'):
  if r['gem_id'] in primary:gemfiles.add(r['file_id']);gemids.add(r['gem_id'])
 activefiles={k for k,v in files.items() if prod(v['file'] if 'file' in v else v['path'])}|gemfiles
 edges=collections.Counter();mapped=set();direct=set();gemapi=set();regused=set()
 for e in read(G/'tables/ruby_dispatch_edges.jsonl'):
  if e.get('primary_bundle_compatible') is not True:continue
  edges[e['target_type']]+=1;mapped.add(e['source_call_id'])
  if e['target_type']=='registration':direct.add(e['source_call_id']);regused.add(e['target_id']);gemapi.add(e['source_call_id'])
  elif methods.get(e['target_id'],{}).get('file_id') in gemfiles:gemapi.add(e['source_call_id'])
 hops=list(read(F/'tables/frontend_ruby_hops.jsonl'));sliceids={h['call_id'] for h in hops if h.get('call_id')};unres=list(read(F/'tables/frontend_unresolved_sites.jsonl'));unresolved={r['call_id'] for r in unres};sliceids|=unresolved
 holeids={r['call_id'] for r in read(F/'tables/frontend_binding_holes.jsonl')};candidate={r['call_id'] for r in unres if r.get('candidate_edge_ids')};candidate|={r['blocked_call_id'] for r in read(F/'tables/frontend_candidate_continuations.jsonl')}
 supported={h['call_id'] for h in hops if h.get('type')=='ruby_dispatch'}-holeids
 candidate=(candidate&sliceids)-supported;unknown=sliceids-supported-candidate
 apis={h['call_id'] for h in hops if h.get('target_type')=='registration' or methods.get(h.get('target_id'),{}).get('file_id') in gemfiles}
 unmappedapi={r['call_id'] for r in read(F/'tables/frontend_unmapped_gem_apis.jsonl')};apis|=unmappedapi
 nativepaths=set()
 for r in read(G/'tables/ruby_native_paths.jsonl'):
  if r.get('primary_bundle_compatible') is True:nativepaths.add(r['gitlab_call_id'])
 bare={r['call_id']:r['classification'] for r in read(G/'tables/ruby_ambiguous_identifier_classification.jsonl')}
 out={'definitions':{'registration_denominator':'Unique C registration IDs in frozen native corpus whose canonical source gem has a primary profile lock entry; excludes unavailable C sources. Ruby owner-name binding is syntactic, not runtime installation.','whole_call_denominator':'All parsed call-like records in production GitLab prefix plus primary-gem-associated files, excluding known local/parameter reads. Gem associated files include test/support files retained by source parser; not loaded-code coverage.','slice_denominator':'Unique call IDs emitted in frozen frontend Ruby hops or frontend unresolved sites. Includes representative suffix/candidate records; bounded explored slice, not every reachable runtime call.','gem_api_denominator':'Unique traced-slice calls with an existing edge to a primary gem Ruby method/native registration or frontend_unmapped_gem_apis row; unidentified receivers cannot be exhaustively labeled gem APIs.','resolved_meaning':'Constructed source-target dispatch accepted by builder; semantic correctness not independently established for population.'},'registrations':{'detected':len(rids),'c_function_resolved':len(cf),'c_function_unresolved':len(rids-cf),'ruby_owner_name_bound':len(owned),'ruby_owner_name_unbound':len(rids-owned),'both_c_function_and_ruby_owner_bound':len(cf&owned),'targeted_by_primary_compatible_dispatch':len(regused&rids)},'traced_call_slice':{'denominator':len(sliceids),'constructed_supported_dispatch':len(supported&sliceids),'candidate_only':len(candidate),'unresolved_no_candidate':len(unknown)},'traced_identified_gem_api_calls':{'denominator':len(apis),'with_retained_native_path':len(apis&nativepaths|apis&direct),'without_retained_native_path':len(apis-(nativepaths|direct)),'unmapped_table_distinct_calls':len(unmappedapi),'qualification':'Pure Ruby APIs legitimately lack native paths; this is not a failure rate. Native suffix path index is keyed by GitLab root calls, so suffix-only wrappers without indexed root retain unknown continuation.'},'graph':{'primary_compatible_edges':dict(edges),'unique_calls_with_dispatch':len(mapped)},'parsing':{'metadata_files':len(files),'metadata_methods':len(methods),'primary_gem_associated_files':len(gemfiles),'primary_gem_ids_with_parsed_files':len(gemids),'primary_lock_entries':len(primary),'active_production_plus_primary_gem_files':len(activefiles)}}
 print(label,'checkpoint',json.dumps(out['registrations']),json.dumps(out['traced_call_slice']),flush=True)
 counts=collections.Counter();namecandidate=set()
 for r in read(G/'tables/ruby_native_unresolved.jsonl'):namecandidate.add(r['call_id'])
 for p in contract['tables']['ruby_calls']:
  for c in read(p):
   if c['file_id'] not in activefiles:continue
   if bare.get(c['call_id']) in ('local_variable_read','parameter_read'):counts['known_noncall_records_excluded']+=1;continue
   cid=c['call_id'];counts['denominator']+=1
   if cid in mapped:counts['constructed_dispatch']+=1
   elif cid in namecandidate:counts['name_only_candidate_no_dispatch']+=1
   else:counts['no_dispatch_or_name_candidate']+=1
   if prod(c['file']):
    counts['production_gitlab_calls']+=1
    if cid in mapped:counts['production_gitlab_calls_with_dispatch']+=1
 out['whole_active_call_records']=dict(counts)
 issuefiles={r['file_id'] for r in read(G/'tables/ruby_parse_issues.jsonl') if r.get('file_id') in activefiles};out['parsing']['active_files_with_recorded_parse_issue']=len(issuefiles)
 out['disconnections']=['Unknown receiver calls cannot be exhaustively attributed to a gem, preventing a complete gem-API denominator.','All graph dispatch is static conditional; semantic sample contradictions are separate from these structural counts.','Primary source-file availability and parsing do not establish source/package byte equivalence or runtime loading.','Missing gem sources, unsupported syntax, dynamic callbacks, framework binding holes and method-depth bounds remain.']
 result['profiles'][label]=out
 (A/'layer_ruby_funnel.json').write_text(json.dumps(result,indent=2)+'\n')
 print(label,'done',dict(counts),flush=True)
