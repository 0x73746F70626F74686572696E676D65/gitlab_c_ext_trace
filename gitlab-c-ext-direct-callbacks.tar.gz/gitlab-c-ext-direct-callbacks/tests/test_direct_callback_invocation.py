import pathlib,sys,unittest,tempfile
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
from link_direct_controller_callbacks import declaration_eligibility,zero_argument_body_possible
from ruby_argument_flow_iteration5 import FlowSource
from ruby_method_lookup import Lookup
class CallbackTests(unittest.TestCase):
 def decl(self,**kw):
  r=dict(api='before_action',block_body=None,option_expressions={},only=None,except_actions=None,filters=['authorize'],declaration_conditions=[]);r.update(kw);return r
 def test_literal_only_matches(self):self.assertIsNone(declaration_eligibility(self.decl(option_expressions={'only':'[:show]'},only=['show']),'show'))
 def test_literal_only_excludes(self):self.assertEqual(declaration_eligibility(self.decl(option_expressions={'only':'[:show]'},only=['show']),'create'),'literal_only_excludes_action')
 def test_except_excludes(self):self.assertEqual(declaration_eligibility(self.decl(option_expressions={'except':':show'},except_actions=['show']),'show'),'literal_except_excludes_action')
 def test_dynamic_selector_unknown(self):self.assertEqual(declaration_eligibility(self.decl(option_expressions={'only':'actions'}),'show'),'dynamic_action_selector')
 def test_false_if_excludes(self):self.assertEqual(declaration_eligibility(self.decl(option_expressions={'if':'false'}),'show'),'literal_predicate_excludes')
 def test_dynamic_if_retained_only_partial(self):self.assertIsNone(declaration_eligibility(self.decl(option_expressions={'if':':allowed?'}),'show'))
 def test_block_filter_outside_model(self):self.assertEqual(declaration_eligibility(self.decl(block_body={'line':1}),'show'),'block_callback_not_symbol_model')
 def test_dynamic_filter_unknown(self):self.assertEqual(declaration_eligibility(self.decl(filters=[None]),'show'),'dynamic_filter')
 def test_around_not_before(self):self.assertEqual(declaration_eligibility(self.decl(api='around_action'),'show'),'unsupported_callback_phase')
 def test_own_target_precedence(self):
  l=Lookup([],[],{'ExampleController'});r=l.decide('ExampleController','authorize','instance',[dict(id='m',owner='ExampleController',method='authorize',kind='instance')])[0];self.assertEqual(r['decision'],'retain_conditional')
 def test_prepended_owner_target_unresolved(self):
  l=Lookup([dict(owner='ExampleController',kind='prepend',target_candidates=['Extension'],inheritance_id='r')],[],{'ExampleController','Extension'});r=l.decide('ExampleController','authorize','instance',[dict(id='m',owner='ExampleController',method='authorize',kind='instance')])[0];self.assertEqual(r['decision'],'unresolved_prepend_order')
 def test_required_callback_argument_rejected(self):
  s=FlowSource('class Demo; def gate(value); end; end');self.assertFalse(zero_argument_body_possible(s,s.methods['gate'][0]))
 def test_required_keyword_rejected(self):
  s=FlowSource('class Demo; def gate(value:); end; end');self.assertFalse(zero_argument_body_possible(s,s.methods['gate'][0]))
 def test_defaults_and_rest_accept_zero_arguments(self):
  s=FlowSource('class Demo; def gate(value=false, **opts); end; end');self.assertTrue(zero_argument_body_possible(s,s.methods['gate'][0]))
if __name__=='__main__':unittest.main()
