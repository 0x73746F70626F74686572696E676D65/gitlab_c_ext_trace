import json,hashlib,random,collections
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');D=V/'audit/direct_callbacks_holdout';seed=202609300927
rng=random.Random(seed);selected=[];inputs={};counts={}
def selector(r):
 o=r['selectors'];return 'only' if o.get('only') is not None else 'except' if o.get('except_actions') is not None else 'all'
def special(r):
 o=r['selectors']['options'];return 'source_conditional' if r['registration_conditions'] else 'unless' if 'unless'in o else 'if' if 'if'in o else 'ordinary'
for p in ['ce','ee']:
 path=V/f'tables/{p}_direct_callback_invocation_edges.jsonl';data=path.read_bytes();inputs[str(path.relative_to(V))]=hashlib.sha256(data).hexdigest();rs=[json.loads(l)for l in data.splitlines()];counts[p]=len(rs)
 rs=[r for r in rs if r['receiver_owner']!='Profiles::PasskeysController'];rng.shuffle(rs);used=set();picked=[]
 requirements=[('prepend',lambda r:r['callback_api']=='prepend_before_action'),('source_conditional',lambda r:special(r)=='source_conditional'),('unless',lambda r:special(r)=='unless'),('if',lambda r:special(r)=='if'),('only',lambda r:selector(r)=='only'),('except',lambda r:selector(r)=='except'),('all',lambda r:selector(r)=='all')]
 for label,pred in requirements:
  candidates=[r for r in rs if pred(r) and r['edge_id']not in used]
  diverse=[r for r in candidates if r['receiver_owner']not in {x['receiver_owner']for x in picked}]
  if candidates:
   r=(diverse or candidates)[0];r={**r,'sampling_stratum':label};picked.append(r);used.add(r['edge_id'])
 for r in rs:
  if len(picked)>=12:break
  if r['edge_id'] in used or r['receiver_owner']in{x['receiver_owner']for x in picked}:continue
  picked.append({**r,'sampling_stratum':'random_diverse_controller'});used.add(r['edge_id'])
 selected+=picked
for i,r in enumerate(selected,1):r['audit_id']=f'DCB{i:03}'
out=D/'sample.jsonl';out.write_text(''.join(json.dumps(r)+'\n'for r in selected))
manifest={'seed':seed,'inputs':inputs,'population_counts':counts,'sample_rows':len(selected),'sample_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'design':'Seeded shuffled selection12/profile with mandatory available prepend,source-conditional,unless,if,only,except,all strata; prefer previously unsampled controller owner, then random diverse-controller fill. Exclude prior manually reviewed Profiles::PasskeysController. Purposeful rare-strata/controller diversity, not equal-probability population sample and no global precision estimate. Frozen before semantic review.','review_target':'Support of stated partial source relation, not callback activation/runtime exposure/native reachability.'}
(D/'selection_freeze.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2));print([(r['audit_id'],r['profile'],r['receiver_owner'],r['action'],r['symbol'],r['sampling_stratum'])for r in selected])
