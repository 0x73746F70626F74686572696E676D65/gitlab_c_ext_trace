import json,hashlib,collections,re
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');B=Path('/workspace/gitlab_c_ext_trace');D=V/'audit/direct_callbacks_holdout';freeze=json.loads((D/'selection_freeze.json').read_text());errors=[];checks=0;cache={};population=[]
def check(ok,reason):
 global checks
 checks+=1
 if not ok:errors.append(reason)
def excerpt(e):
 p=B/e['file'];data=cache.setdefault(str(p),p.read_bytes());ls=data.decode(errors='replace').split('\n')
 check(hashlib.sha256(data).hexdigest()==e['sha256'],{'kind':'source_hash','file':e['file']})
 check('\n'.join(ls[e['line']-1:e['end_line']])==e['excerpt'],{'kind':'excerpt','file':e['file'],'line':e['line']})
for profile in ['ce','ee']:
 rel=f'tables/{profile}_direct_callback_invocation_edges.jsonl';data=(V/rel).read_bytes();check(hashlib.sha256(data).hexdigest()==freeze['inputs'][rel],{'kind':'frozen_table','profile':profile});rows=[json.loads(l)for l in data.splitlines()];population+=rows
 check(len(rows)==freeze['population_counts'][profile],{'kind':'rowcount','profile':profile});check(len({r['edge_id']for r in rows})==len(rows),{'kind':'duplicate_ids','profile':profile})
 refs={}
 for name,key in [('route_scope_bindings','scope_occurrence_id'),('controller_callback_declarations','callback_id'),('controller_callback_demands','callback_demand_id')]:refs[name]={r[key]:r for r in map(json.loads,(V/f'profiles/{profile}/tables/{name}.jsonl').open())}
 for r in rows:
  check(not r['may_seed_complete_path'] and not r['callback_activated_proven'] and not r['runtime_exposure_proven'] and r['new_native_paths']==0,{'kind':'partial_boundary','edge':r['edge_id']})
  check(r['target_method_kind']=='instance',{'kind':'instance_target','edge':r['edge_id']})
  check(r['callback_id']in refs['controller_callback_declarations'],{'kind':'callback_ref','edge':r['edge_id']})
  check(r['callback_demand_id']in refs['controller_callback_demands'],{'kind':'demand_ref','edge':r['edge_id']})
  for q in r['route_scope_occurrence_ids']:check(q in refs['route_scope_bindings'],{'kind':'route_ref','edge':r['edge_id']})
  for e in r['source_evidence']:excerpt(e)
rs=[json.loads(l)for l in (D/'sample.jsonl').read_text().splitlines()];check(hashlib.sha256((D/'sample.jsonl').read_bytes()).hexdigest()==freeze['sample_sha256'],{'kind':'sample_hash'})
notes=[
'prepend_before_action registers two literal symbols for show. Own authenticate_user! instance body exists. skip_before_action same symbol is only decline, so does not contradict selected show; actual prepend order/earlier callback halt remains unproved.',
'Callback inside with_options only show/unless external_storage_request?; nested registration constraint explicitly retained. Selected route is show so inherited only selector agrees; external-storage predicate and block execution unknown. Own zero-argument method and project raw namespace supported.',
'Chaos sleep route under chaos singleton maps ChaosController; callback unless development_or_test? preserved. Own method may render403/500; invocation is conditional, action continuation not implied.',
'Projects commits show route matches own action; callback if non-Atom lambda remains unresolved. Prior around action and sessionless block prevent activation inference. Own validate_path direct instance definition supported.',
'Groups/settings namespace plus applications REST show route resolves nested controller. Literal only list includes show, own set_application instance method. Inherited authorization/lookup admission unresolved.',
'Projects jobs member unschedule route maps JobsController; except index/play/retry/show does not exclude unschedule. Own find_job_as_build has zero arguments; earlier/auth/predicate effects unproved.',
'Import/offline/import resource explicitly overrides singular controller and declares history. Own feature check callback supported. Action history renders404, which does not contradict preceding callback relation or prove action completion.',
'Projects noteable scope/discussions REST show resolves DiscussionsController. All-actions literal callback points to own instance method. Method may render404, and preceding inherited callbacks remain unknown.',
'Users route scope explicitly controller users; get snippets and own public snippets action. All-actions set_legacy_data own instance definition. Skip authenticate_user! affects different callback symbol; actual chain unknown.',
'Nested jobs resource/artifacts singleton resolves Projects::ArtifactsController raw member route, not JobsController. only download/browse/raw admits raw. Own authorization callback supported; its success not assumed.',
'Import manifest resource controller override maps status route. Explicit public status wrapper re-exposes internal inherited method as action; selected own verify_import_enabled callback precedes it conditionally.',
'Projects environments/deployments REST index selects DeploymentsController, not EnvironmentsController. Own environment instance method declared before_action. Prior authorization and memoization/DB success unknown.',
'JWT explicit jwt#auth route and own auth action. prepend registration has two literal symbols; authenticate_project_or_user is own instance method. HTTP Basic block invocation/result is outside edge, no activation or downstream authentication claim.',
'EE RawController with_options source condition preserved; show selector agrees. Body differs from CE rate-limit argument form; independently inspected EE file. Unknown external_storage condition remains, not unconditional registration.',
'EE Chaos cpu_spin member route, own public action, same unless development_or_test? condition. Source-declared partial supported; runtime environment/auth unknown.',
'EE collect_events explicit event_forward/event_forward#forward route; own authenticate_sessionless_user! wrapper super(editor_extension). if editor_extension_request? remains unresolved. Edge stops at wrapper, does not prove ancestor invocation or authentication.',
'Admin namespace topics REST destroy route includes destroy; callback only edit/update/destroy includes it. Own topic instance method, no singleton confusion. Nested avatar controller declaration does not replace parent route owner.',
'Projects pages/domains resource explicitly controller pages_domains; show survives route except index and callback except new/create. Own domain definition, unresolved prior pages/auth guards.',
'EE-only instance_admin route draws admin namespace audit_logs index; EE controller source class matches. Own license-check callback may render404; load/profile/feature conditions unresolved.',
'EE groups analytics/type_of_work/tasks_by_type explicit controller resource and member top_labels. Own prepare_date_range callback; earlier anonymous feature/auth callbacks not proven to allow it. Date validation may halt later.',
'EE groups issues_analytics singular resource maps plural IssuesAnalyticsController correctly; own show action and authorization callback. License/authorization conditions remain unknown; no activation claim.',
'EE project error_tracking collection explicit details route maps controller details, matching only selector. Own set_issue_id instance method. Earlier Sentry authorization and feature callback effects not resolved.',
'EE admin audit_log_reports REST index with csv route constraint maps own class/action. Own license check callback supported, but csv/admission/license prerequisites unproved.',
'EE groups/settings/domain_verification resource member clean_certificate maps singular DomainVerificationController via explicit resource name. Own feature callback is all-actions; nested namespace and public action supported, while license/auth/order unresolved.'
]
reviews=[]
for r,n in zip(rs,notes):
 check(r['edge_id']in {x['edge_id']for x in population},{'kind':'sample_membership','edge':r['edge_id']})
 evidence=list(r['source_evidence']);p=B/evidence[0]['file'];lines=p.read_text().split('\n');end=min(35,len(lines));evidence.append({'file':evidence[0]['file'],'line':1,'end_line':end,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'excerpt':'\n'.join(lines[:end]),'role':'independently_inspected_class_registration_context'})
 for rc in r['route_conditions'][:1]:
  for t in rc['scope_trace']:
   if not t.get('file')or not t.get('line'):continue
   path=B/t['file'];ls=path.read_text().split('\n');end=min(t['line']+5,t['end_line']);evidence.append({'file':t['file'],'line':t['line'],'end_line':end,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'excerpt':'\n'.join(ls[t['line']-1:end]),'role':'independently_inspected_route_scope'})
 reviews.append({'audit_id':r['audit_id'],'edge_id':r['edge_id'],'profile':r['profile'],'status':'supported_stated_partial_edge','activation_status':'unresolved','semantic_review':n,'source_evidence':evidence,'method_kind':'instance','runtime_verified':False,'native_reachability_proven':False,'remaining_constraints':r['unresolved_constraints'],'registration_conditions':r['registration_conditions'],'selectors':r['selectors']})
(D/'reviews.jsonl').write_text(''.join(json.dumps(r)+'\n'for r in reviews))
summary={'status':'PASS'if not errors else'FAIL','checks':checks,'errors':errors,'population_rows':len(population),'population_profiles':dict(collections.Counter(r['profile']for r in population)),'population_edge_ids_unique':len({r['edge_id']for r in population}),'sample_rows':len(rs),'sample_verdicts':dict(collections.Counter(r['status']for r in reviews)),'activation_unresolved':len(rs),'sample_profile_controller_groups':len({(r['profile'],r['receiver_owner'])for r in rs}),'sample_cross_profile_owner_groups':len({r['receiver_owner']for r in rs}),'sample_profile_registration_groups':len({(r['profile'],r['callback_id'])for r in rs}),'sample_owner_symbol_groups':len({(r['receiver_owner'],r['symbol'])for r in rs}),'sample_target_method_ids':len({r['target_method_id']for r in rs}),'sample_registration_forms':dict(collections.Counter(r['callback_api']for r in rs)),'correlation_note':'RawController and ChaosController source families appear in both profiles; all edges reuse one framework callback contract. No independence or population precision estimate. Profile-specific own methods/route contexts reviewed separately.','design':freeze['design'],'new_counterexamples':[],'findings':['All24 support the claimed partial declaration/own-method relation, not activation.','with_options registration constraints and if/unless predicates remain unresolved; passkeys prior manual proof excluded.','Known differing-symbol skips or nonmatching-action skips do not contradict selected edges. Prior anonymous/around callbacks remain explicit blockers to completion.'],'source_files_integrity_checked':len(cache),'no_complete_or_native_path_promotion':True,'graph_mutated':False}
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
