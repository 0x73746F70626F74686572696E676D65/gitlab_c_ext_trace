"""Additive route-bound own-method callback invocation candidates; never complete paths."""
import collections,hashlib,json,pathlib,re
from ruby_argument_flow_iteration5 import FlowSource
from ruby_method_lookup import Lookup
V=pathlib.Path(__file__).resolve().parents[1];B=pathlib.Path('/workspace/gitlab_c_ext_trace')
MODEL=V/'tables/actioncontroller_before_callback_invocation_model_v2.jsonl'
def rows(p):
 with open(p) as f:
  for l in f:yield json.loads(l)
def uid(*args):return hashlib.sha256('\0'.join(map(str,args)).encode()).hexdigest()[:24]
def declaration_eligibility(c,action):
 if c['api'] not in ('before_action','append_before_action','prepend_before_action'):return 'unsupported_callback_phase'
 if c.get('block_body'):return 'block_callback_not_symbol_model'
 opts=c['option_expressions']
 if 'only' in opts and c['only'] is None or 'except' in opts and c['except_actions'] is None:return 'dynamic_action_selector'
 if 'only' in opts and action not in c['only']:return 'literal_only_excludes_action'
 if 'except' in opts and action in c['except_actions']:return 'literal_except_excludes_action'
 if opts.get('if')=='false' or opts.get('unless')=='true':return 'literal_predicate_excludes'
 if any(x is None for x in c['filters']):return 'dynamic_filter'
 return None
def zero_argument_body_possible(src,node):
 params=src.field(node,'parameters')
 for p in params.named_children if params else []:
  if p.type in ('identifier','destructured_parameter'):return False
  if p.type=='keyword_parameter' and src.field(p,'value') is None:return False
 return True
class Sources:
 def __init__(self):self.cache={}
 def get(self,file):
  if file not in self.cache:self.cache[file]=FlowSource((B/file).read_bytes(),file)
  return self.cache[file]
 def evidence(self,file,start,end):
  s=self.get(file);return dict(file=file,line=start,end_line=end,sha256=hashlib.sha256(s.data).hexdigest(),excerpt='\n'.join(s.data.decode().splitlines()[start-1:end]))
 def node(self,m):
  s=self.get(m['file']);ns=[n for n in s.methods.get(m['method'],[]) if n.start_point.row+1==m['line']];return (s,ns[0]) if len(ns)==1 else (s,None)
 def literal_symbols(self,c):
  s=self.get(c['file']);pending=[s.tree.root_node];found=[]
  while pending:
   n=pending.pop()
   if n.type=='call' and n.start_point.row+1==c['line'] and s.text(s.field(n,'method'))==c['api']:found.append(n)
   pending.extend(n.named_children)
  if len(found)!=1:return False
  args=s.field(found[0],'arguments');filters=[n for n in args.named_children if n.type!='pair'] if args else []
  return bool(filters) and all(n.type=='simple_symbol' for n in filters)
def main():
 model=next(rows(MODEL));assert model['model_id'].endswith('_v2');modelref=dict(model_id=model['model_id'],path=str(MODEL.relative_to(V)),sha256=hashlib.sha256(MODEL.read_bytes()).hexdigest());sources=Sources();reports={}
 for profile,G,prefix in [('ce',pathlib.Path('/workspace/gitlab_c_ext_ruby_expanded'),'sources/gitlab/'),('ee',pathlib.Path('/workspace/gitlab_c_ext_ee_profile'),'sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/')]:
  P=V/'profiles'/profile/'tables';decl={r['callback_id']:r for r in rows(P/'controller_callback_declarations.jsonl')};routes={r['scope_occurrence_id']:r for r in rows(P/'route_scope_bindings.jsonl')};methods={r['method_id']:r for r in rows(G/'tables/ruby_methods.jsonl') if (r['file'].startswith(prefix) or r['file'].startswith('sources/wrappers/rails-7.2.3.1/')) and not re.search(r'/(spec|test|qa|fixtures)/',r['file'])};universe={m['namespace'] for m in methods.values()};defs=collections.defaultdict(list)
  for m in methods.values():defs[(m['namespace'],m['method'],m['kind'])].append(m)
  rels=[r for r in rows(G/'tables/ruby_inheritance.jsonl') if (r['file'].startswith(prefix) or r['file'].startswith('sources/wrappers/rails-7.2.3.1/')) and not re.search(r'/(spec|test|qa|fixtures)/',r['file'])];byowner=collections.defaultdict(list)
  for r in rels:byowner[r['owner']].append(r)
  lookup=Lookup(rels,[],universe)
  def ancestry(owner):
   evidence=[];seen=set();cur=owner
   while cur not in seen:
    if cur=='ActionController::Base':return True,evidence
    seen.add(cur);rs=[r for r in byowner[cur] if r['kind']=='superclass'];parents={t for r in rs for t in r['target_candidates'] if t in universe}
    if len(parents)!=1:return False,evidence
    target=next(iter(parents));evidence.extend(r for r in rs if target in r['target_candidates']);cur=target
   return False,evidence
  edges=[];holes=[];counts=collections.Counter();demands=list(rows(P/'controller_callback_demands.jsonl'))
  for demand in demands:
   c=decl[demand['callback_id']];reason=declaration_eligibility(c,demand['action'])
   if not reason and c['owner']!=demand['controller_owner']:reason='inherited_registration_outside_direct_subset'
   selected_routes=[routes[x] for x in demand['route_scope_occurrence_ids'] if x in routes and routes[x].get('method_ids') and any(mid in methods for mid in routes[x]['method_ids'])]
   if not reason and not selected_routes:reason='no_source_bound_route_action_method'
   if not reason and not sources.literal_symbols(c):reason='filter_not_exact_literal_symbol'
   known_rails,inheritance=ancestry(demand['controller_owner'])
   if not reason and not known_rails:reason='framework_base_ancestry_unresolved_or_not_ActionController_Base'
   if reason:
    counts[reason]+=1;holes.append(dict(unresolved_id='cbhole_'+uid(profile,demand['callback_demand_id'],reason),profile=profile,callback_demand_id=demand['callback_demand_id'],callback_id=c['callback_id'],reason=reason,route_scope_occurrence_ids=demand['route_scope_occurrence_ids']));continue
   for symbol in c['filters']:
    ms=defs.get((demand['controller_owner'],symbol,'instance'),[]);reason=None
    if len(ms)!=1:reason='own_method_absent_or_nonunique'
    else:
     m=ms[0];src,node=sources.node(m)
     if node is None or node.has_error or src.method_context[node.start_byte][2]:reason='method_AST_missing_conditional_or_parse_error'
     elif not zero_argument_body_possible(src,node):reason='callback_method_requires_arguments'
     else:
      decision=lookup.decide(demand['controller_owner'],symbol,'instance',[dict(id=m['method_id'],owner=m['namespace'],method=symbol,kind='instance')])[0]
      if decision['decision']!='retain_conditional':reason=decision['decision']
    if reason:
     counts[reason]+=1;holes.append(dict(unresolved_id='cbhole_'+uid(profile,demand['callback_demand_id'],symbol,reason),profile=profile,callback_demand_id=demand['callback_demand_id'],callback_id=c['callback_id'],symbol=symbol,reason=reason,route_scope_occurrence_ids=demand['route_scope_occurrence_ids']));continue
    unresolved=['effective_callback_chain_order_and_duplicate_registration_not_resolved','prior_callback_or_around_wrapper_halt_exception_predicates_not_resolved','framework_process_action_inclusion_compilation_and_terminator_conditions_required','no_runtime_or_dynamic_method_rebinding_proof']
    if c['declaration_conditions']:unresolved.append('conditional_callback_registration')
    if any(k in c['option_expressions'] for k in ('if','unless')):unresolved.append('if_unless_predicate_or_selector_normalization_requires_runtime_conditions')
    if demand['skip_candidate_ids']:unresolved.append('overlapping_skip_registration_activation_unresolved')
    unknown_opts=set(c['option_expressions'])-{'only','except','if','unless','prepend'}
    if unknown_opts:unresolved.append('other_callback_options:'+','.join(sorted(unknown_opts)))
    # All skip declarations are retained separately; dynamic ones may evade name intersection.
    if any(s['api']=='skip_before_action' and (s['owner']==c['owner'] or s['owner'] in {r['owner'] for r in inheritance}) and any(f is None for f in s['filters']) for s in decl.values()):unresolved.append('dynamic_skip_filter_may_match')
    edges.append(dict(edge_id='cbown_'+uid(profile,demand['callback_demand_id'],m['method_id']),profile=profile,edge_type='conditional_framework_before_callback_invocation',status='partial_source_registered_callback_invocation_candidate',callback_demand_id=demand['callback_demand_id'],callback_id=c['callback_id'],callback_api=c['api'],receiver_owner=c['owner'],action=demand['action'],symbol=symbol,target_method_id=m['method_id'],target_method_kind='instance',target_resolution='unique_unconditional_own_definition_precedes_ordinary_ancestors_under_normal_lookup',lookup_decision=decision,framework_model=modelref,framework_ancestry_ids=[r['inheritance_id'] for r in inheritance],route_scope_occurrence_ids=[r['scope_occurrence_id'] for r in selected_routes],action_method_ids=sorted({i for r in selected_routes for i in r['method_ids'] if i in methods}),selectors=dict(only=c['only'],except_actions=c['except_actions'],options=c['option_expressions']),skip_candidate_ids=demand['skip_candidate_ids'],registration_conditions=c['declaration_conditions'],route_conditions=[dict(scope_occurrence_id=r['scope_occurrence_id'],conditions=r['conditions'],scope_trace=r['scope_trace']) for r in selected_routes],unresolved_constraints=unresolved,source_evidence=[sources.evidence(c['file'],c['line'],c['end_line']),sources.evidence(m['file'],m['line'],m['end_line'])]+[sources.evidence(r['file'],r['line'],r['end_line']) for r in selected_routes],may_seed_complete_path=False,runtime_exposure_proven=False,callback_activated_proven=False,continuation_to_action='not_implied',new_native_paths=0))
  for stem,rs in [('direct_callback_invocation_edges',edges),('direct_callback_invocation_unresolved',holes)]:
   with (V/'tables'/f'{profile}_{stem}.jsonl').open('w') as f:
    for r in rs:f.write(json.dumps(r)+'\n')
  reports[profile]=dict(input_route_bindings=len(routes),input_callback_declarations=len(decl),input_callback_demands=len(demands),additive_partial_edges=len(edges),unique_callback_declarations=len({e['callback_id'] for e in edges}),unique_target_methods=len({e['target_method_id'] for e in edges}),route_action_pairs=len({(e['receiver_owner'],e['action']) for e in edges}),omitted_or_unresolved_rows=len(holes),reasons=dict(counts),new_complete_callback_paths=0,new_native_paths=0)
 report=dict(status='additive_bounded_direct_own_method_subset',framework_model=modelref,profiles=reports,scope='Literal-symbol before callbacks on actual source-bound routes. Every edge remains partial; inherited registrations and unresolved/prepended targets are not promoted. Source framework invocation is conditional, not automatic activation.',baseline_mutated=False,input_references={str(p.relative_to(V)):hashlib.sha256(p.read_bytes()).hexdigest() for profile in ('ce','ee') for p in [(V/'profiles'/profile/'tables'/name) for name in ('route_scope_bindings.jsonl','controller_callback_declarations.jsonl','controller_callback_demands.jsonl')]},analyzer_support_references={name:hashlib.sha256((V/'scripts'/name).read_bytes()).hexdigest() for name in ('ruby_argument_flow_iteration5.py','ruby_method_lookup.py')})
 (V/'reports/direct_callback_invocation_coverage.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
