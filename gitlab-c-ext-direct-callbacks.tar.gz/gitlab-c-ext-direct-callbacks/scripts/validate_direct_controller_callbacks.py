import collections,hashlib,json,pathlib
from link_direct_controller_callbacks import declaration_eligibility,Sources,zero_argument_body_possible
V=pathlib.Path(__file__).resolve().parents[1];B=pathlib.Path('/workspace/gitlab_c_ext_trace');checks=0;sources=Sources();counts={}
def rows(p):
 with open(p) as f:
  for l in f:yield json.loads(l)
def check(v):
 global checks
 checks+=1;assert v
modelp=V/'tables/actioncontroller_before_callback_invocation_model_v2.jsonl';modelhash=hashlib.sha256(modelp.read_bytes()).hexdigest()
for profile,G in [('ce',pathlib.Path('/workspace/gitlab_c_ext_ruby_expanded')),('ee',pathlib.Path('/workspace/gitlab_c_ext_ee_profile'))]:
 P=V/'profiles'/profile/'tables';routes={r['scope_occurrence_id']:r for r in rows(P/'route_scope_bindings.jsonl')};cs={r['callback_id']:r for r in rows(P/'controller_callback_declarations.jsonl')};ds={r['callback_demand_id']:r for r in rows(P/'controller_callback_demands.jsonl')};edges=list(rows(V/'tables'/f'{profile}_direct_callback_invocation_edges.jsonl'));need={e['target_method_id'] for e in edges};methods={r['method_id']:r for r in rows(G/'tables/ruby_methods.jsonl') if r['method_id'] in need}
 check(len(edges)==len({e['edge_id'] for e in edges}))
 for e in edges:
  check(e['callback_id'] in cs and e['callback_demand_id'] in ds and e['target_method_id'] in methods);c=cs[e['callback_id']];m=methods[e['target_method_id']]
  check(e['receiver_owner']==c['owner']==m['namespace']);check(e['symbol'] in c['filters'] and e['symbol']==m['method']);check(m['kind']=='instance');check(declaration_eligibility(c,e['action']) is None);check(sources.literal_symbols(c))
  src,n=sources.node(m);check(n is not None and not n.has_error and not src.method_context[n.start_byte][2]);check(zero_argument_body_possible(src,n));check(e['lookup_decision']['decision']=='retain_conditional');check(e['framework_model']['sha256']==modelhash)
  check(not e['may_seed_complete_path'] and not e['runtime_exposure_proven'] and not e['callback_activated_proven'] and e['new_native_paths']==0);check(bool(e['unresolved_constraints']))
  for rid in e['route_scope_occurrence_ids']:
   r=routes[rid];check(r['owner']==e['receiver_owner'] and r['method']==e['action'] and bool(r['method_ids']))
  for ev in e['source_evidence']:
   src=sources.get(ev['file']);check(hashlib.sha256(src.data).hexdigest()==ev['sha256']);check('\n'.join(src.data.decode().splitlines()[ev['line']-1:ev['end_line']])==ev['excerpt'])
  if e['skip_candidate_ids']:check('overlapping_skip_registration_activation_unresolved' in e['unresolved_constraints'])
  if profile=='ee':check(all(not ev['file'].startswith('sources/gitlab/') for ev in e['source_evidence']))
 holes=list(rows(V/'tables'/f'{profile}_direct_callback_invocation_unresolved.jsonl'));check(len(holes)==len({r['unresolved_id'] for r in holes}));check(all(r['callback_demand_id'] in ds for r in holes));counts[profile]=dict(edges=len(edges),unresolved_rows=len(holes))
report=dict(status='pass',checks=checks,errors=0,profiles=counts,scope='PK/FK, source agreement, direct method/arity/selector constraints and no-promotion flags; independent semantic sample separate');(V/'reports/direct_callback_invocation_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
