#!/usr/bin/env python3
"""Independent source-evidence integrity checks; semantic judgments from manual review."""
import json,hashlib
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3'); B=Path('/workspace/gitlab_c_ext_trace')
errors=[]; checks=0; cache={}
def walk(x):
 global checks
 if isinstance(x,list):
  for v in x:walk(v)
 elif isinstance(x,dict):
  if x.get('file') and x.get('line') and 'excerpt' in x:
   p=B/x['file'];data=cache.setdefault(str(p),p.read_bytes()); lines=data.decode(errors='replace').split('\n')
   checks+=1
   if '\n'.join(lines[x['line']-1:x.get('end_line',x['line'])])!=x['excerpt']:errors.append({'file':str(p),'line':x['line'],'error':'excerpt'})
   sha=x.get('source_sha256',x.get('sha256'))
   if sha:
    checks+=1
    if hashlib.sha256(data).hexdigest()!=sha:errors.append({'file':str(p),'error':'sha256'})
  for v in x.values():walk(v)
rel='tables/actioncontroller_before_callback_invocation_model_v2.jsonl';sha='29e25b2ad6af99bec82a9cf538a0b8120c282e1651d070cf0fd5ceb74b4ab393';data=(V/rel).read_bytes();checks+=1
if hashlib.sha256(data).hexdigest()!=sha:errors.append({'error':'frozen_hash'})
r=json.loads(data);walk(r)
# Narrow evidence-completeness mutations, NOT a Ruby semantic parser or application reachability test.
anchors=['result_lambda.call; controller.performed?', 'invoke_sequence.call', 'user_callback.call target, value', 'target.send(@method_name, &block)', '!halted && user_conditions.all?', '@method_name = method']
joined='\n'.join(e['excerpt'] for e in r['source_evidence'])
def evidence_complete(text):return all(a in text for a in anchors)
cases=[('complete_retained_spans',joined,True),('lambda_definition_only','result_lambda = -> { user_callback.call target, value }',False)]
for a in anchors:cases.append(('missing_forcing_or_identity_'+a,joined.replace(a,''),False))
reg=[]
for label,src,wanted in cases:
 actual=evidence_complete(src);checks+=1;reg.append({'case':label,'expected':wanted,'actual':actual})
 if actual!=wanted:errors.append({'error':'evidence_mutation','case':label})
report={'status':'PASS'if not errors else'FAIL','checks':checks,'errors':errors,'source_files_checked':len(cache),'frozen_input':{rel:sha},'evidence_mutation_checks':reg,'regression_scope':'Eight narrow static evidence-presence regressions; not target execution, not Ruby semantic parsing, not precision tests for arbitrary source. Manual source inspection supplies semantic judgment.','independent_judgment':'Supported pinned-framework conditional invocation contract. Source-known symbol template preserves method identity; compile installs Before object into sequence. run_callbacks directly invokes before sequence and, in around case, explicitly forces invoke_sequence at141. Before gates halted/conditions, passes result_lambda to concrete ActionController terminator, which invokes it then tests performed?. user_callback dispatches symbol on same target. Conditions, effective registration/order/skips, around wrappers, receiver overrides and runtime admission must be resolved separately per application. Stored Proc or declaration alone never sufficient.','erratum':'Original v1 run_callbacks excerpt ended134 before actual invoke_sequence.call141. V2 adds forcing plus method identity and sequence application spans. Original retained. This was a citation completeness defect, not source contradiction.','automatic_application':False,'all_callbacks_reachable':False,'runtime_verified':False}
(V/'reports/actioncontroller_callback_model_independent_review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
