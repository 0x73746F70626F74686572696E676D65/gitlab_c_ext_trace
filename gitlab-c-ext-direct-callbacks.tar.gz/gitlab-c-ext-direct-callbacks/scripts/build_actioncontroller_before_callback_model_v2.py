#!/usr/bin/env python3
import json,hashlib
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');B=Path('/workspace/gitlab_c_ext_trace');old=V/'tables/actioncontroller_before_callback_invocation_model.jsonl';x=json.loads(old.read_text());f='sources/wrappers/rails-7.2.3.1/activesupport/lib/active_support/callbacks.rb';p=B/f
for a,z,c in [(132,144,'Around-sequence Proc is actually invoked by invoke_sequence.call, not merely constructed.'),(338,342,'MethodCall initializer stores exact callback symbol in @method_name.'),(188,193,'Compiled Before object applies itself into before sequence.')]:
 x['source_evidence'].append(dict(file=f,line=a,end_line=z,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),excerpt='\n'.join(p.read_text().splitlines()[a-1:z]),claim=c))
x['model_id']='rails7231_actioncontroller_symbol_before_action_invocation_v2';x['supersedes_model_sha256']=hashlib.sha256(old.read_bytes()).hexdigest();out=V/'tables/actioncontroller_before_callback_invocation_model_v2.jsonl';out.write_text(json.dumps(x,sort_keys=True)+'\n');print(hashlib.sha256(out.read_bytes()).hexdigest())
