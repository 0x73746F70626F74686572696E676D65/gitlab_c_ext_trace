#!/usr/bin/env python3
"""Independent source-evidence integrity checks; semantic judgments from manual review."""
import json,hashlib
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3'); B=Path('/workspace/gitlab_c_ext_trace')
errors=[]; checks=0; cache={}
def walk(x):
 global checks
 if isinstance(x,list):
  for v in x:walk(v)
 elif isinstance(x,dict):
  if x.get('file') and x.get('line') and 'excerpt' in x:
   p=B/x['file'];data=cache.setdefault(str(p),p.read_bytes()); lines=data.decode(errors='replace').split('\n')
   checks+=1
   if '\n'.join(lines[x['line']-1:x.get('end_line',x['line'])])!=x['excerpt']:errors.append({'file':str(p),'line':x['line'],'error':'excerpt'})
   sha=x.get('source_sha256',x.get('sha256'))
   if sha:
    checks+=1
    if hashlib.sha256(data).hexdigest()!=sha:errors.append({'file':str(p),'error':'sha256'})
  for v in x.values():walk(v)
spec={'tables/passkey_bcrypt_source_recipe.jsonl':'32d925969b3aa19bd7243c37b1fb1981a41fcf704e26d3f53e8bcdfd7d9fb62d','tables/passkey_bcrypt_request_flow.jsonl':'18baa8c1269619dbfc2290c697e1737f5f32a8d50799ae13ee8bed86a75c6b61','tables/passkey_bcrypt_source_supplement_v2.jsonl':'e8dd19f6e6ec7c208de70230bb042066ae0868ec94c98e369cf540e7d306588c','tables/bcrypt_native_feasibility_v2.jsonl':'66743ff6f8c5ab2e311c12742b6b8dde9bdeec1e9316a1c739ec0e49d9ef63a8'}
for rel,sha in spec.items():
 data=(V/rel).read_bytes();checks+=1
 if hashlib.sha256(data).hexdigest()!=sha:errors.append({'file':rel,'error':'frozen_hash'})
 walk([json.loads(l)for l in data.splitlines()])
report={'status':'PASS'if not errors else'FAIL','checks':checks,'errors':errors,'source_files_checked':len(cache),'frozen_inputs':spec,'independent_judgments':{
 'route_and_invocation':'Existing CE POST /-/profile/passkeys create route. validate_current_password is conditional before_action, not action body. Concrete Rails process_action terminator invokes result_lambda, which invokes registered symbol callback on controller; this missing original span is now explicit supplement. Earlier inherited/CSRF/passkey/admission conditions retained.',
 'receiver_and_transfer':'Existing authenticated current_user ordinary User is a premise; no Warden strategy inference. permit current_password/action and ordinary String accessor conversion preserve selected scalar. No arbitrary params coercion or frozen-state proof. User override checks blank/denylist/automatic/password-auth then super; actual included EncryptedUserPassword selected, not shortcut to Devise DatabaseAuthenticatable.',
 'gates':'Concern29 tests ApplicationSetting::DEFAULT_MINIMUM_PASSWORD_LENGTH literal8 (implementation.rb37), not live configured setting. Stored $2a$ strategy selects BCrypt comparison; PBKDF2 alternative excluded. FIPS is not this comparison selector. Entering comparison does not require submitted password equals stored secret; sink precedes secure_compare outcome/migration.',
 'devise_and_salt':'Selected blank/nil pepper branch is explicit runtime assumption; present pepper changes effective bytes. Valid stored BCrypt hash required for BCrypt::Password.new; split_hash produces salt from first29 stored bytes, not request salt. hash_secret validates secret/salt then ordinary to_s and72byte truncation guard.',
 'native_effect':'Dummy9byte ASCII selected key bypasses truncation. Corrected v2 actual predicate/constant anchors reviewed. bc_crypt rb_str_new_frozen(key) occurs before later NUL validation and crypto. Copy requires unfrozen plus embedded/embeddable state; params alone does not prove state, and≤72 is not generic embedding proof. Matching Ruby3.3.11 str_new0 copies effective key length; frozen/shared alternatives retained.',
 'evidence_corrections':'Original native v1 incorrect predicate span and missing constant corrected by immutable v2+erratum. Original frontend route enclosing-scope, String conversion and callback-terminator support supplied additively in supplementv2. All original bytes preserved, no hidden rewrite.',
 'limits':'Conditional source recipe, no actual credentials/runtime verification, no exact heap bytes/arbitrary address/vulnerability inference. Existing route reused; one new BCrypt gem constructor terminal supported through separate runtime source contract, not added runtime inventory site.'},'runtime_verified':False,'status_scope':'source_supported_conditional_request_argument_recipe','frontend_runtime_admission_proven':False,'mutability_embeddability_proven_from_request':False}
(V/'reports/passkey_bcrypt_independent_assembly_review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
