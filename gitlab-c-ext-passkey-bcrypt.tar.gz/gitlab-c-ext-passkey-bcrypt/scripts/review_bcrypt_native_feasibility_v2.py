#!/usr/bin/env python3
"""Correct evidence spans additively, with required semantic source anchors."""
import hashlib,json
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_trace'); V=Path('/workspace/gitlab_c_ext_v3')
old=V/'tables/bcrypt_native_feasibility.jsonl'; original=old.read_bytes(); row=json.loads(original)
old_id=row['model_id'];row['model_id']='bcrypt3122_mutable_embeddable_key_copy_feasibility_v2'
row['supersedes']={'model_id':old_id,'sha256':hashlib.sha256(original).hexdigest(),'reason':'Wrong semantic evidence range for valid_salt?/valid_secret?; missing constant definition anchor. Evidence defect, not demonstrated flow contradiction.'}
e=row['source_evidence'];e[0]['line']=54;e[0]['end_line']=78;e[1]['line']=98;e[1]['end_line']=105
p='sources/gems/bcrypt-3.1.22/lib/bcrypt/engine.rb'
e.append(dict(file=p,line=17,end_line=19,claim='Literal maximum secret bytesize is72.'))
anchors=[['def self.hash_secret(secret, salt, _ = nil)','if valid_secret?(secret)','if valid_salt?(salt)','secret = secret.to_s','secret.byteslice(0, MAX_SECRET_BYTESIZE)','__bc_crypt(secret, salt)'],['def self.valid_salt?(salt)','!!(salt =~','def self.valid_secret?(secret)','secret.respond_to?(:to_s)'],['static VALUE bc_crypt','if(NIL_P(key) || NIL_P(setting))','key     = rb_str_new_frozen(key)','StringValueCStr(key)'],['void Init_bcrypt_ext()','"__bc_crypt", bc_crypt, 2'],['rb_str_new_frozen(VALUE orig)','if (OBJ_FROZEN(orig)) return orig'],['str_new_frozen(VALUE klass, VALUE orig)','str_new_frozen_buffer(klass, orig, TRUE)'],['long len = RSTRING_LEN(orig)','STR_EMBED_P(orig) || STR_EMBEDDABLE_P(len, termlen)','str_new0(klass, RSTRING_PTR(orig), len, termlen)'],['STR_SHARED','heap_str_make_shared(klass, orig)'],['str_new0(VALUE klass, const char *ptr, long len, int termlen)','memcpy(RSTRING_PTR(str), ptr, len)'],['rb_string_value_cstr','string contains null byte'],['__crypt_ra','CRYPT_OUTPUT_SIZE'],['tmp[0] |= (unsigned char)*ptr','ptr++'],['MAX_SECRET_BYTESIZE = 72']]
checks=0
for entry,required in zip(e,anchors,strict=True):
 d=(R/entry['file']).read_bytes();excerpt='\n'.join(d.decode().split('\n')[entry['line']-1:entry['end_line']])
 for anchor in required:
  assert anchor in excerpt,(entry['file'],entry['line'],anchor)
  checks+=1
 entry.update(sha256=hashlib.sha256(d).hexdigest(),excerpt=excerpt,required_anchors=required)
row['semantic_anchor_validation']={'checks':checks,'errors':0,'limits':'Checks assert required source tokens inside selected spans, not independent semantic proof.'}
out=V/'tables/bcrypt_native_feasibility_v2.jsonl';out.write_text(json.dumps(row,sort_keys=True)+'\n')
report={'status':'corrected_evidence_only_independent_review_pending','model_id':row['model_id'],'supersedes':row['supersedes'],'checks':checks,'errors':0,'original_bytes_unchanged':old.read_bytes()==original,'corrected_model_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_evidence_records':len(e),'publication_rule':'Use v2 certificate; preserve v1 as superseded evidence with this erratum. No frontend promotion until independent review.'}
(V/'reports/bcrypt_native_feasibility_v2_erratum.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
