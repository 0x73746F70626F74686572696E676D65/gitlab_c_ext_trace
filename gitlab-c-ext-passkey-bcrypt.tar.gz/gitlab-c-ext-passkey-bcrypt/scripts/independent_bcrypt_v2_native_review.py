#!/usr/bin/env python3
"""Independent source-evidence integrity checks; semantic judgments from manual review."""
import json,hashlib
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3'); B=Path('/workspace/gitlab_c_ext_trace')
errors=[]; checks=0; cache={}
def walk(x):
 global checks
 if isinstance(x,list):
  for v in x:walk(v)
 elif isinstance(x,dict):
  if x.get('file') and x.get('line') and 'excerpt' in x:
   p=B/x['file'];data=cache.setdefault(str(p),p.read_bytes()); lines=data.decode(errors='replace').split('\n')
   checks+=1
   if '\n'.join(lines[x['line']-1:x.get('end_line',x['line'])])!=x['excerpt']:errors.append({'file':str(p),'line':x['line'],'error':'excerpt'})
   sha=x.get('source_sha256',x.get('sha256'))
   if sha:
    checks+=1
    if hashlib.sha256(data).hexdigest()!=sha:errors.append({'file':str(p),'error':'sha256'})
  for v in x.values():walk(v)
spec={'tables/bcrypt_native_feasibility_v2.jsonl':'66743ff6f8c5ab2e311c12742b6b8dde9bdeec1e9316a1c739ec0e49d9ef63a8','tables/bcrypt_native_feasibility.jsonl':'136518b7c424cbb731f01bb2942ad4af79344ad164a44019da130e362cf05d42'}
for rel,sha in spec.items():
 data=(V/rel).read_bytes();checks+=1
 if hashlib.sha256(data).hexdigest()!=sha:errors.append({'file':rel,'error':'frozen_hash'})
 if '_v2.'in rel:walk([json.loads(l)for l in data.splitlines()])
report={'status':'PASS'if not errors else'FAIL','checks':checks,'errors':errors,'source_files_checked':len(cache),'frozen_inputs':spec,'independent_judgments':{
 'erratum':'Actual engine.rb98-105 defines valid_salt? regex and valid_secret? respond_to?(:to_s); engine.rb17 defines72byte constant. Earlier106-116 evidence defect is retained as superseded, not treated as proof. Corrected predicates are wrapper admission, not proof arbitrary salt succeeds downstream crypt.',
 'wrapper':'Selected ordinary String to_s and byte truncation if bytesize>72 produce effective native key. Engine does not itself transcode. MRI branch invokes registered __bc_crypt arity2. No universal original-object identity; frontend pepper/other transformations outside native certificate.',
 'ordering':'bc_crypt rejects nil then calls rb_str_new_frozen(key) before freezing setting and StringValueCStr NUL checks. Selected constructor can occur before later hashing failure; successful full crypto additionally requires valid key/salt/noNUL. Copy effect is assessed at this earlier selected terminal only.',
 'core_branch':'rb_str_new_frozen returns already-frozen original without copy. Unfrozen embedded OR embeddable input enters str_new_frozen_buffer str_new0 with source pointer/RSTRING_LEN; nonnull ordinary String causes memcpy len. Large nonembeddable shared/backing-store branches remain alternatives; no universal constructor-copy equivalence.',
 'memory_effect':'Selected short nonempty mutable ASCII effective key under matching Ruby3.3.11 layout supports byte copy. Length≤72 from wrapper is not itself proof all layouts embed it. Length is effective key byte count, not exact heap size or arbitrary destination. No new core inventory site IDs.',
 'frontend_gap':'Native certificate alone establishes no request→key path, stored-password validity, loaded Devise/FIPS lookup, pepper or request mutability. Must remain conditional until independent frontend assembly; no runtime/build execution.'},'runtime_verified':False,'frontend_promoted':False}
(V/'reports/bcrypt_v2_independent_native_review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
