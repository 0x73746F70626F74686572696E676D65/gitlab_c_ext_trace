import sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from native_preprocessor_iteration5 import *
class Tests(unittest.TestCase):
 def run_source(self,s,extras=None):
  with tempfile.TemporaryDirectory()as d:
   p=Path(d)/'a.c';p.write_text(s)
   for n,b in(extras or{}).items():(Path(d)/n).write_text(b)
   pp=Interpreter(d,{'ruby.h':{'HAVE_RUBY_ENCODING_H':dict(defined=True,value=1)}});pp.scan(p)
   return [pp.at(p,i+1)['active']for i,line in enumerate(s.split('\n'))if 'SINK' in line]
 def test_defined_else(self):self.assertEqual(self.run_source('#define X 1\n#ifdef X\nSINK\n#else\nSINK\n#endif'),[True,False])
 def test_undefined(self):self.assertEqual(self.run_source('#undef X\n#ifndef X\nSINK\n#endif'),[True])
 def test_unknown_ifdef(self):self.assertEqual(self.run_source('#ifdef X\nSINK\n#else\nSINK\n#endif'),[None,None])
 def test_redefine_value(self):self.assertEqual(self.run_source('#define X 1\n#undef X\n#define X 0\n#if X\nSINK\n#endif'),[False])
 def test_unknown_conditional_define(self):self.assertEqual(self.run_source('#if PLATFORM\n#define X 1\n#endif\n#ifdef X\nSINK\n#endif'),[None])
 def test_unknown_include_kills(self):self.assertEqual(self.run_source('#define X 1\n#include <missing.h>\n#ifdef X\nSINK\n#endif'),[None])
 def test_conditional_include_kills(self):self.assertEqual(self.run_source('#define X 1\n#if PLATFORM\n#include "b.h"\n#endif\n#ifdef X\nSINK\n#endif',{'b.h':'#define Y 1'}),[None])
 def test_local_include(self):self.assertEqual(self.run_source('#include "b.h"\n#ifdef X\nSINK\n#endif',{'b.h':'#define X 1'}),[True])
 def test_false_include_no_effect(self):self.assertEqual(self.run_source('#define X 1\n#if 0\n#include <missing.h>\n#endif\n#ifdef X\nSINK\n#endif'),[True])
 def test_elif(self):self.assertEqual(self.run_source('#if 0\nSINK\n#elif 1\nSINK\n#else\nSINK\n#endif'),[False,True,False])
 def test_unsupported_arithmetic(self):self.assertEqual(self.run_source('#define X 1\n#if X+1\nSINK\n#endif'),[None])
 def test_compound(self):self.assertEqual(self.run_source('#define X 1\n#undef Y\n#if defined(X) && !defined(Y)\nSINK\n#endif'),[True])
 def test_header_contract(self):self.assertEqual(self.run_source('#include <ruby.h>\n#ifdef HAVE_RUBY_ENCODING_H\nSINK\n#else\nSINK\n#endif'),[True,False])
 def test_contract_undef(self):self.assertEqual(self.run_source('#include <ruby.h>\n#undef HAVE_RUBY_ENCODING_H\n#include <ruby.h>\n#ifdef HAVE_RUBY_ENCODING_H\nSINK\n#endif'),[False])
 def test_contract_unknown_include(self):self.assertEqual(self.run_source('#include <ruby.h>\n#include <missing.h>\n#include <ruby.h>\n#ifdef HAVE_RUBY_ENCODING_H\nSINK\n#endif'),[None])
 def test_comments(self):self.assertEqual(self.run_source('/*\n#define X 1\n*/\n#ifdef X\nSINK\n#endif'),[None])
 def test_comment_token_in_string(self):self.assertEqual(self.run_source('const char *x="/*";\n#define X 1\n#ifdef X\nSINK\n#endif'),[True])
 def test_include_guard(self):self.assertEqual(self.run_source('#ifndef A_H\n#define A_H\n#define X 1\n#ifdef X\nSINK\n#endif\n#endif'),[True])
 def test_pragma_pop_unknown(self):self.assertEqual(self.run_source('#define X 1\n#pragma push_macro("X")\n#undef X\n#pragma pop_macro("X")\n#ifdef X\nSINK\n#endif'),[None])
 def test_inline_pragma_unknown(self):self.assertEqual(self.run_source('#undef X\n_Pragma("pop_macro\\\"X\\\"")\n#ifdef X\nSINK\n#endif'),[None])
 def test_elifdef(self):self.assertEqual(self.run_source('#define X 1\n#if 0\nSINK\n#elifdef X\nSINK\n#endif'),[False,True])
 def test_translation_unit_local_undef_before_header(self):self.assertEqual(self.run_source('#include <ruby.h>\n#undef HAVE_RUBY_ENCODING_H\n#include "b.h"\n#ifdef HAVE_RUBY_ENCODING_H\nSINK\n#endif',{'b.h':'#include <ruby.h>'}),[False])
 def test_comment_separates_tokens(self):self.assertEqual(self.run_source('#define X 0/**/0\n#if X\nSINK\n#endif'),[None])
 def test_escaped_newline_comment_unknown(self):self.assertEqual(self.run_source('// comment '+chr(92)+'\n#define X 1\n#ifdef X\nSINK\n#endif'),[None])
 def test_quoted_local_header_precedes_contract(self):self.assertEqual(self.run_source('#include "ruby.h"\n#ifdef HAVE_RUBY_ENCODING_H\nSINK\n#endif',{'ruby.h':'#undef HAVE_RUBY_ENCODING_H'}),[False])
if __name__=='__main__':unittest.main()
