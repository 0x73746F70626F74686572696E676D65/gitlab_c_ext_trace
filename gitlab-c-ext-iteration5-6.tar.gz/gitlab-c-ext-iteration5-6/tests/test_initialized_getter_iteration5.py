import hashlib,pathlib,sys,tempfile,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
from initialized_getter_iteration5 import InitializedGetter
from ruby_argument_flow_iteration5 import FlowSource,truth
class GetterTests(unittest.TestCase):
 def setup_contract(self,**kw):
  td=tempfile.TemporaryDirectory();self.addCleanup(td.cleanup);root=pathlib.Path(td.name);(root/'clock.rb').write_text('def setting; local || default; end')
  c=dict(contract_id='fixture_clock',status='source_checked_conditional_contract',owner='Clock',method='setting',getter_method_id='fixture',initialized_profile_applicable=True,required_conditions=['successful_application_initialization','getter_definition_unchanged','no_later_global_default_replacement','ordinary_Ruby_truthiness'],evidence=[dict(file='clock.rb',sha256=hashlib.sha256((root/'clock.rb').read_bytes()).hexdigest())]);c.update(kw);m=InitializedGetter(c,root);return m,root
 def metadata(self,**kw):
  d=dict(method_id='fixture',namespace='Clock',method='setting',kind='singleton');d.update(kw);return d
 def test_truthy_only_no_invented_type(self):
  c,_=self.setup_contract();self.assertTrue(c.validate());v=c.apply(self.metadata());self.assertEqual(v['kind'],'unknown');self.assertIs(truth(v),True)
 def test_unvalidated_rejected(self):self.assertIsNone(self.setup_contract()[0].apply(self.metadata()))
 def test_changed_source_rejected(self):
  c,r=self.setup_contract();(r/'clock.rb').write_text('def setting; nil; end');self.assertFalse(c.validate());self.assertIsNone(c.apply(self.metadata()))
 def test_unknown_initialization_rejected(self):
  c,_=self.setup_contract(initialized_profile_applicable=False);c.validate();self.assertIsNone(c.apply(self.metadata()))
 def test_mutable_default_without_condition_rejected(self):
  c,_=self.setup_contract(required_conditions=['successful_application_initialization','getter_definition_unchanged','ordinary_Ruby_truthiness']);self.assertFalse(c.validate())
 def test_wrong_owner_rejected(self):
  c,_=self.setup_contract();c.validate();self.assertIsNone(c.apply(self.metadata(namespace='OtherClock')))
 def test_override_method_rejected(self):
  c,_=self.setup_contract();c.validate();self.assertIsNone(c.apply(self.metadata(method_id='override')))
 def test_wrong_method_kind_rejected(self):
  c,_=self.setup_contract();c.validate();self.assertIsNone(c.apply(self.metadata(kind='instance')))
 def branch(self,truthiness):
  src=FlowSource('class Calendar; def self.now; Clock.setting ? good() : fallback(); end; end');src.summary_resolver=lambda s,n,e,d:dict(kind='unknown',conditional_truthiness=True) if s.text(s.field(n,'method'))=='setting' and truthiness else None
  def walk(n):
   yield n
   for x in n.named_children:yield from walk(x)
  m=src.methods['now'][0];call=next(n for n in walk(m) if n.type=='call' and src.text(src.field(n,'method'))=='fallback');return src.env_at(m,call,{})
 def test_general_ternary_false_arm_excluded(self):self.assertTrue(self.branch(True)['unreachable'])
 def test_unknown_getter_ternary_remains_possible(self):self.assertFalse(self.branch(False)['unreachable'])
 def test_no_completed_initialization_condition_rejected(self):
  c,_=self.setup_contract(required_conditions=['getter_definition_unchanged','no_later_global_default_replacement','ordinary_Ruby_truthiness']);self.assertFalse(c.validate())
 def test_true_ternary_arm_retained(self):
  s=FlowSource('class Demo; def self.run; true ? sink() : other(); end; end')
  def walk(n):
   yield n
   for x in n.named_children:yield from walk(x)
  m=s.methods['run'][0];c=next(n for n in walk(m) if n.type=='call' and s.text(s.field(n,'method'))=='sink');self.assertFalse(s.env_at(m,c,{})['unreachable'])
if __name__=='__main__':unittest.main()
