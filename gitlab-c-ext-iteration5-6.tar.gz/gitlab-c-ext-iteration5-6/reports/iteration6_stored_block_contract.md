# Source-backed deferred BatchLoader registration

This additive overlay resolves qualified inline `BatchLoader.for(...).batch { ... }` and `BatchLoader::GraphQL.for(...).batch { ... }` receivers against the retained, profile-locked batch-loader 2.0.5 implementation. The contract inspects factory construction, GraphQL proxy initialization/delegation, explicit `&batch_block` storage, executor-proxy metadata registration, and the separate eventual `@batch_block.call` site. It does not classify arbitrary methods named `batch`.

`iteration6_stored_block_regions.jsonl` follows the existing deferred-region contract and can be supplied to `deferred_execution.classify_call`. Registration does not establish body execution. A frozen path entering a region needs an explicit forcing/invocation and capture-identity model. No invocation evidence is manufactured from a nearby or same-named call. Unsupported local aliases, receiver overrides and transitive effects beyond the reviewed helper chain remain unresolved.

The selected 151-path census supplies the source-file scope, not a completeness denominator for all callbacks. AST call IDs and enclosing-method identities match existing formulas. Nested named methods retain separate ownership. The resulting C035 and C118 decisions are **partial_requires_stored_callback_invocation**: the supplied frozen witnesses omit necessary forcing/capture evidence. This does not prove these callbacks never execute or that a stronger path cannot be established.

The separately reviewed CE GraphQL request recipe has a different path identity, explicit lazy forcing, decoder and first-uncached-wrapper constraints. It remains unchanged. Its evidence is not borrowed into either frozen witness, and no EE strong request flow is promoted.

Reproduce with `python scripts/test_batchloader_deferred_iteration6.py` and `python scripts/batchloader_deferred_iteration6.py`. All analysis is static; Ruby and extensions are never executed. Source association and ordinary method dispatch remain explicit conditions.
