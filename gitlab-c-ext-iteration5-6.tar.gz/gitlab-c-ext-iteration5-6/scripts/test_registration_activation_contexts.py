import unittest,tempfile,pathlib
import extract_registration_activation_iteration5 as m
class ContextCases(unittest.TestCase):
 def get(self,src,line):
  with tempfile.TemporaryDirectory() as t:
   old=m.B;m.B=pathlib.Path(t);(m.B/'x.c').write_text(src)
   try:return m.contexts('x.c',{line},'c')[line]
   finally:m.B=old
 def test_else_polarity(self):
  e=self.get('void x(){\nif (argc>1) { a(); } else {\ninstall();\n}\n}',3);self.assertEqual(e['lexical_guards'][0]['branch'],'alternative_false')
 def test_true_polarity(self):
  e=self.get('void x(){\nif (enabled) {\ninstall();\n}\n}',3);self.assertEqual(e['lexical_guards'][0]['branch'],'consequence_true')
 def test_preprocessor_guard(self):
  e=self.get('void x(){\n#ifdef ENABLE\ninstall();\n#endif\n}',3);self.assertEqual(e['lexical_guards'][0]['kind'],'preproc_ifdef')
 def test_no_guard_does_not_prove(self):
  e=self.get('void x(){\ninstall();\n}',2);self.assertEqual(e['lexical_guards'],[]);self.assertIn('not_proven',e['control_flow'])
if __name__=='__main__':unittest.main()
