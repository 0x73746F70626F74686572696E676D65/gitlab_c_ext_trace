#!/usr/bin/env python3
"""Development reuse of completed census; not a new independent holdout."""
import json,hashlib,collections
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');D=V/'audit/candidate_census_iteration3';I=V/'iterations/iteration5'
def rows(p):return [json.loads(l)for l in p.open()]
freeze=json.loads((I/'freeze_manifest.json').read_text());errors=[]
for item in freeze.get('inputs',[])+freeze.get('outputs',[]):
 p=Path(item['path']);b=p.read_bytes()
 if hashlib.sha256(b).hexdigest()!=item['sha256']:errors.append(dict(kind='frozen_hash',path=str(p)))
review=rows(D/'census_results.jsonl');dim={r['path_id']:r for r in rows(D/'census_path_dimensions.jsonl')};dec={r.get('baseline_path_id',r.get('path_id')):r for r in rows(I/'path_decisions.jsonl')};out=[]
for r in review:
 d=dec[r['path_id']];s=d['status'];assess='withheld_unresolved'if'partial'in s else'candidate_still_conditional'if'candidate'in s else'correct_conditional_exclusion'if r['status']=='contradicted'else'potential_false_exclusion'
 out.append(dict(audit_id=r['audit_id'],path_id=r['path_id'],profile=r['profile'],census_verdict=r['status'],primary_census_bucket=dim[r['path_id']]['bucket'],iteration3_status='candidate_not_disproved',iteration5_status=s,assessment=assess,contradictions=d.get('contradictions',[]),unresolved_conditions=d.get('unresolved_conditions',[]),source_review_reused=True,fresh_holdout=False,runtime_verified=False))
(D/'iteration5_development_comparison.jsonl').write_text(''.join(json.dumps(x)+'\n'for x in out))
report=dict(scope='Reused151-record iteration3 census used for development comparison after its error families informed iteration5. Not fresh holdout, not independent out-of-sample accuracy.',iteration_id=freeze.get('iteration_id'),paths=len(out),cross_tab=dict(collections.Counter(r['census_verdict']+' -> '+r['iteration5_status']for r in out)),primary_bucket_cross_tab=dict(collections.Counter(r['primary_census_bucket']+' -> '+r['iteration5_status']for r in out)),known_contradictions=[dict(audit_id=r['audit_id'],path_id=r['path_id'],new_status=r['iteration5_status'],reasons=r['contradictions'])for r in out if r['census_verdict']=='contradicted'],potential_false_exclusions=[r for r in out if r['assessment']=='potential_false_exclusion'],remaining_unresolved_candidates=[r for r in out if r['census_verdict']=='unresolved' and r['iteration5_status']=='candidate_not_disproved'],profile_transition_counts={p:dict(collections.Counter(r['iteration5_status']for r in out if r['profile']==p))for p in ['ce','ee']},remaining_candidate_physical_sites=len({dim[r['path_id']]['physical_site_id']for r in out if r['iteration5_status']=='candidate_not_disproved'}),remaining_candidate_entrypoints=len({dim[r['path_id']]['entrypoint_id']for r in out if r['iteration5_status']=='candidate_not_disproved'}),conditions='Header exclusions require matching Ruby3.3.11 headers/canonical guards; Time.zone exclusions require completed boot, unchanged getter and no later global default replacement. Remaining candidates remain qualified, not verified.',freeze_errors=errors)
(D/'iteration5_development_summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
