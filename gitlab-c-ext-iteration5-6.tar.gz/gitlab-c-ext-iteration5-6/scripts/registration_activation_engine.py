"""Bounded source-graph activation witnesses; no build/runtime activation claim."""
from collections import defaultdict,deque

def witnesses(edges, seeds, per_node=4, max_depth=16):
 """Shortest source paths by seed, bounded per node; cycles do not create walks."""
 adj=defaultdict(list)
 for e in edges:adj[e['from']].append(e)
 for es in adj.values():es.sort(key=lambda x:x['id'])
 seen=defaultdict(dict);q=deque();truncated=set();depth_stops=set()
 for key,node in sorted(seeds.items()):
  if len(seen[node])>=per_node:truncated.add(node);continue
  seen[node][key]=[];q.append((node,key))
 while q:
  node,key=q.popleft();path=seen[node][key]
  if len(path)>=max_depth:
   if adj[node]:depth_stops.add(node)
   continue
  for e in adj[node]:
   target=e['to']
   if key in seen[target]:continue
   if len(seen[target])>=per_node:truncated.add(target);continue
   seen[target][key]=path+[e['id']];q.append((target,key))
 return dict(seen),{'per_node_seed_cap':per_node,'max_direct_call_depth':max_depth,'seed_cap_nodes':sorted(truncated),'depth_stop_nodes':sorted(depth_stops),'cycles':'one shortest witness per admitted seed/node, no infinite walks; alternate paths not enumerated'}

def classify(container, init, exposed):
 if not container:return 'unresolved_registration_container'
 if init.get(container):return 'Init_named_root_candidate_reachable'
 if exposed.get(container):return 'Ruby_exposed_activation_candidate_only'
 return 'unresolved_no_bounded_activation_witness'
