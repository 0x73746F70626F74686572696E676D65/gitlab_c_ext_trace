#!/usr/bin/env python3
import json
from batchloader_deferred_iteration6 import summary_method,regions,V
from deferred_execution import classify_call
checks=[]
for label,src,expected in [
 ('generic_stored_parameter','def register(&callback); @later = callback; self; end','stored_block_with_no_direct_invocation'),
 ('direct_callback_call','def register(&callback); @later=callback; callback.call; end','direct_invocation'),
 ('stored_callback_called','def register(&callback); @later=callback; @later.call; end','direct_invocation'),
 ('yield_with_parameter','def register(&callback); @later=callback; yield; end','direct_invocation'),
 ('forwarding_unknown','def register(&callback); other(&callback); end','unresolved_forwarding')]:
 r=summary_method(src.encode(),'register');assert r['classification']==expected,(label,r);checks.append(dict(case=label,passed=True))
c=dict(contract_id='synthetic_source_reviewed_contract',receiver_bindings=[dict(factory='BatchLoader.for',returned_owner='BatchLoader'),dict(factory='BatchLoader::GraphQL.for',returned_owner='BatchLoader::GraphQL')])
for label,src,count in [
 ('known_factory','def test; BatchLoader.for(1).batch { sink() }; end',1),
 ('known_proxy','def test; ::BatchLoader::GraphQL.for(1).batch { sink() }; end',1),
 ('unknown_receiver','def test; other.batch { sink() }; end',0),
 ('same_method_wrong_class','def test; Other.for(1).batch { sink() }; end',0),
 ('ordinary_immediate_block','def test; [1].each { sink() }; end',0),
 ('local_alias_unknown','def test; b=BatchLoader.for(1); b.batch { sink() }; end',0),
 ('shadow_constant','BatchLoader=Other; BatchLoader.for(1).batch { sink() }',0),
 ('nested_named_method','def test; BatchLoader.for(1).batch { def inner; sink(); end }; end',1)]:
 regs,calls,notes=regions('fixture/'+label+'.rb',src.encode(),c);assert len(regs)==count,(label,regs)
 seen=0
 for call in calls.values():
  if call['line'] and src[call['byte_offset']:].startswith('sink'):
   seen+=1
   ann=classify_call(call,regs)
   if count and label!='nested_named_method':assert ann and ann['classification']=='requires_invocation'
   else:assert ann is None
 assert seen==1,(label,seen)
 checks.append(dict(case=label,passed=True))
(V/'reports/iteration6_stored_block_fixture_validation.json').write_text(json.dumps(dict(cases=checks,passed=len(checks),ruby_executed=False),indent=2)+'\n');print('passed',len(checks))
