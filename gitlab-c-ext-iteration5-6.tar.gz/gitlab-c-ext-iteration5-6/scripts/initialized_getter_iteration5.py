"""Checked conditional framework-summary contract, independent of call path IDs.
Only supplies truthiness, never an invented concrete return class/value.
"""
import hashlib,json,pathlib
class InitializedGetter:
 def __init__(self,contract,root):self.contract=contract;self.root=pathlib.Path(root);self.used=[];self.errors=[];self.validated=False
 def validate(self):
  c=self.contract
  if c.get('status')!='source_checked_conditional_contract':self.errors.append('contract_not_checked')
  required={'successful_application_initialization','getter_definition_unchanged','no_later_global_default_replacement','ordinary_Ruby_truthiness'}
  if not required.issubset(set(c.get('required_conditions',[]))):self.errors.append('missing_state_conditions')
  for e in c.get('evidence',[]):
   p=self.root/e['file']
   if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=e['sha256']:self.errors.append('source_changed:'+e['file'])
  if not c.get('evidence'):self.errors.append('no_source_evidence')
  self.validated=not self.errors;return self.validated
 def apply(self,metadata):
  c=self.contract
  if not self.validated or self.errors or metadata.get('method_id')!=c.get('getter_method_id') or metadata.get('namespace')!=c.get('owner') or metadata.get('method')!=c.get('method') or metadata.get('kind')!='singleton':return None
  if not c.get('initialized_profile_applicable'):return None
  ev=dict(contract_id=c['contract_id'],getter_method_id=c['getter_method_id'],conditions=c['required_conditions'],source_evidence=c['evidence'],rule='local_state_OR_truthy_initialized_default')
  self.used.append(ev)
  return dict(kind='unknown',conditional_truthiness=True,initialized_getter_contract=ev)
