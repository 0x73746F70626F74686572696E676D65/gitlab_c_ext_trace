#!/usr/bin/env python3
"""Independent static contract regressions and source checks; never target execution."""
import json,hashlib,tempfile,sys
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');B=Path('/workspace/gitlab_c_ext_trace');sys.path.insert(0,str(V/'scripts'))
from native_preprocessor_iteration5 import Interpreter
from initialized_getter_iteration5 import InitializedGetter
errors=[];results=[];checks=0
fixtures=[('local_undef','#include <ruby.h>\n#undef HAVE_RUBY_ENCODING_H\n#ifdef HAVE_RUBY_ENCODING_H\nSINK\n#endif',False,{}),('unknown_include','#include <ruby.h>\n#include <unknown.h>\n#ifdef HAVE_RUBY_ENCODING_H\nSINK\n#endif',None,{}),('unknown_conditional_include','#include <ruby.h>\n#if PLATFORM\n#include <unknown.h>\n#endif\n#ifdef HAVE_RUBY_ENCODING_H\nSINK\n#endif',None,{}),('unknown_conditional_undef','#include <ruby.h>\n#if PLATFORM\n#undef HAVE_RUBY_ENCODING_H\n#endif\n#ifdef HAVE_RUBY_ENCODING_H\nSINK\n#endif',None,{}),('false_conditional_undef','#include <ruby.h>\n#if 0\n#undef HAVE_RUBY_ENCODING_H\n#endif\n#ifdef HAVE_RUBY_ENCODING_H\nSINK\n#endif',True,{}),('local_header_undef','#include <ruby.h>\n#include "local.h"\n#ifdef HAVE_RUBY_ENCODING_H\nSINK\n#endif',False,{'local.h':'#undef HAVE_RUBY_ENCODING_H\n'}),('quoted_contract_shadow','#include "ruby.h"\n#ifdef HAVE_RUBY_ENCODING_H\nSINK\n#endif',False,{'ruby.h':'#undef HAVE_RUBY_ENCODING_H\n'}),('unknown_pragma','#include <ruby.h>\n#pragma pop_macro("HAVE_RUBY_ENCODING_H")\n#ifdef HAVE_RUBY_ENCODING_H\nSINK\n#endif',None,{}),('macro_include','#include <ruby.h>\n#include HEADER\n#ifdef HAVE_RUBY_ENCODING_H\nSINK\n#endif',None,{})]
for name,src,want,extras in fixtures:
 with tempfile.TemporaryDirectory()as d:
  p=Path(d)/'fixture.c';p.write_text(src)
  for f,t in extras.items():(Path(d)/f).write_text(t)
  pp=Interpreter(d,{'ruby.h':{'HAVE_RUBY_ENCODING_H':dict(defined=True,value=1)}});pp.scan(p);line=next(i+1 for i,s in enumerate(src.split('\n'))if s=='SINK');actual=pp.at(p,line)['active'];checks+=1;results.append(dict(name=name,expected=want,actual=actual,pass_test=actual is want))
  if actual is not want:errors.append(dict(kind='independent_fixture',name=name,expected=want,actual=actual))
contracts=[]
for profile in ['ce','ee']:
 c=json.loads((V/'reports'/f'{profile}_initialized_getter_contract_iteration5.json').read_text());model=InitializedGetter(c,B);checks+=1
 if not model.validate():errors.append(dict(kind='getter_hash_contract',profile=profile,errors=model.errors))
 for e in c['evidence']:
  actual=(B/e['file']).read_text().split('\n')[e['line']-1];checks+=1
  if actual!=e['excerpt']:errors.append(dict(kind='getter_source_excerpt',profile=profile,file=e['file'],line=e['line']))
 meta=dict(method_id=c['getter_method_id'],namespace='Time',method='zone',kind='singleton');checks+=1
 if model.apply(meta) is None:errors.append(dict(kind='exact_getter_missing',profile=profile))
 for field,val in [('method_id','different'),('namespace','DifferentTime'),('method','zone_default'),('kind','instance')]:
  checks+=1
  if model.apply({**meta,field:val}) is not None:errors.append(dict(kind='unsafe_getter_matching',profile=profile,field=field))
 contracts.append(dict(profile=profile,status='supported_under_explicit_source_state_contract',global_write_closure_proven=False,conclusion='Completed ordinary initialization and unchanged truthy default make getter local_state OR default truthy. Nil/false local restoration is harmless; changed getter precedence or later global default replacement invalidates applicability.',inventory_limit='Lexical source writer inventory is not closure over dynamic/reflection/external writes. Required absence is an explicit contract assumption, not inferred from candidate scan counts.'))
report=dict(status='PASS'if not errors else'GAP_FOUND',checks=checks,errors=errors,native_fixtures=results,ruby_getter_contracts=contracts,native_semantic_review='Actual charlock common.h includes canonical ruby.h, which defines capability; selected fallback arms excluded only for matching Ruby3.3.11 header contract and canonical nonexternallypredefined guards. Observed caller translation unit must corroborate header condition. Unknown header/pragma and explicit local writes fail closed subject to recorded regression results.',memory_effect_review='LONG2NUM(sf) immediate Fixnum bound is separate terminal effect annotation; it must not remove path connectivity or imply another allocation is absent.',graph_mutation=False,target_execution=False)
(V/'reports/independent_iteration5_contract_review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
