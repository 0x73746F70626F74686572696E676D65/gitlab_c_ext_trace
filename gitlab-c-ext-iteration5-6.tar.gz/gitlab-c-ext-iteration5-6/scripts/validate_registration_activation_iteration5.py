#!/usr/bin/env python3
import collections,hashlib,json,pathlib
V=pathlib.Path('/workspace/gitlab_c_ext_v3');B=pathlib.Path('/workspace/gitlab_c_ext_trace')
def rows(p):return [json.loads(l) for l in p.open() if l.strip()]
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while buf:=f.read(1024*1024):h.update(buf)
 return h.hexdigest()
regs=rows(V/'tables/registration_activation_iteration5.jsonl');byreg={r['registration_id']:r for r in regs};hops=rows(V/'tables/registration_activation_hops_iteration5.jsonl');byhop={h['id']:h for h in hops};old=list(rows(B/'tables/c_registrations.jsonl'));original={r['registration_id']:r for r in old};assert set(original)==set(byreg);assert len(byreg)==len(regs);assert len(byhop)==len(hops)
cache={};evidence_checks=0;witnesses=0

def evcheck(ev):
 global evidence_checks
 p=B/ev['file']
 if str(p) not in cache:cache[str(p)]=(digest(p),p.read_text(errors='replace').splitlines())
 hash,lines=cache[str(p)];assert hash==ev['source_sha256'];line=ev['line'];end=ev.get('end_line',line)
 if 'excerpt' in ev:assert '\n'.join(lines[line-1:end])==ev['excerpt'],(p,line)
 evidence_checks+=1
for r in regs:
 assert not r['actual_activation_proven'];evcheck(r['registration_evidence']);assert r['registration_container_function_id']==original[r['registration_id']]['function_id']
 for kind,startkey in [('Init_named_root_witnesses','root_function_id'),('Ruby_exposed_activation_witnesses','activation_registration_id')]:
  for w in r[kind]:
   cur=w[startkey] if kind.startswith('Init') else original[w[startkey]]['c_function_id']
   if kind.startswith('Init'):evcheck(w['root_definition'])
   else:assert byreg[w[startkey]]['Init_named_root_witnesses']
   for eid in w['call_ids']:
    edge=byhop[eid];assert edge['from']==cur;cur=edge['to']
   assert cur==r['registration_container_function_id'];witnesses+=1
for h in hops:evcheck(h['source_evidence'])
models=rows(V/'tables/oj_registration_activation_review_iteration5.jsonl');
for m in models:
 for e in m['evidence']+m['alternate_standard_JSON_binding']['evidence']:evcheck(e)
 assert m['target_registration_id'] in byreg
for r in rows(V/'tables/registration_activation_census_effects_iteration5.jsonl'):
 assert r['activation_reference']['sha256']==digest(V/r['activation_reference']['path']);assert not r['frozen_decision_modified']
files=list((V/'tables').glob('registration_activation*iteration5.jsonl'))+[V/'tables/oj_registration_activation_review_iteration5.jsonl',V/'tables/oj_activation_search_sources_iteration5.jsonl']
report={'status':'pass_integrity_and_source_evidence_checks_not_semantic_runtime_validation','registrations':len(regs),'witnesses_checked':witnesses,'distinct_hops':len(hops),'source_evidence_checks':evidence_checks,'source_files_checked':len(cache),'registration_points_without_parsed_call_context':sum(not r['registration_evidence'].get('lexical_call_context_found') for r in regs),'registration_context_parse_limitations':sum(bool(r['registration_evidence'].get('parse_limitation')) for r in regs),'registry_entry_primary_bundle_counts':dict(collections.Counter(str(r['inventory_gem_entry_primary_bundle']) for r in regs)),'input_tables':[{'path':str(B/'tables'/p),'sha256':digest(B/'tables'/p)} for p in ['c_registrations.jsonl','c_functions.jsonl','c_calls.jsonl','c_files.jsonl','gems.jsonl']],'outputs':[{'path':str(p.relative_to(V)),'sha256':digest(p),'bytes':p.stat().st_size} for p in files],'synthetic_regressions':'12 source-graph/context tests; not production precision/recall evidence','no_frozen_baseline_changes':True}
(V/'reports/registration_activation_validation_iteration5.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
