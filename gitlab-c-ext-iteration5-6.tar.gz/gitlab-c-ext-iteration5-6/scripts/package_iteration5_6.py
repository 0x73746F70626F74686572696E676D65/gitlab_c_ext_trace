#!/usr/bin/env python3
"""Package frozen iteration5/6 contracts and overlays; no publication or source-tree copies."""
import gzip,hashlib,io,json,shutil,tarfile
from pathlib import Path
from package_v3_publication import digest,verify_manifest
R=Path('/workspace/gitlab_c_ext_v3');D=R/'publication/iteration5-6'
def main():
 required=['iterations/iteration5/freeze_manifest.json','iterations/iteration6/freeze_manifest.json','reports/ruby_arguments_iteration5_manifest.json','reports/native_preprocessor_freeze_iteration5.json','reports/iteration6_stored_block_freeze.json','reports/registration_activation_validation_iteration5.json','reports/independent_iteration6_stored_block_review.json','reports/iteration6_overlay_integrity.json','audit/candidate_census_iteration3/iteration6_development_summary.json']
 for n in required:assert (R/n).exists(),('pending final artifact',n)
 checks=[dict(manifest=n,verified_files=verify_manifest(R/n)) for n in required[:6]]
 priors=[R/'publication/gitlab-c-ext-v3.tar.gz',R/'publication/gitlab-c-ext-iteration3.tar.gz',R/'publication/gitlab-c-ext-census-and-flows.tar.gz'];ph={str(p):digest(p) for p in priors}
 stage=D/'gitlab-c-ext-iteration5-6';D.mkdir(parents=True,exist_ok=True)
 if stage.exists():shutil.rmtree(stage)
 stage.mkdir();selected=set()
 patterns=['iterations/iteration5/*','iterations/iteration6/*','audit/candidate_census_iteration3/*iteration5*','audit/candidate_census_iteration3/*iteration6*','reports/*iteration5*.json','reports/*iteration6*.json','reports/*iteration5*.txt','reports/*iteration6*.txt','reports/*iteration6*.md','tables/*iteration5*.jsonl','tables/*iteration6*.jsonl','fixtures/*iteration5*','fixtures/*iteration6*','schemas/*iteration5*','schemas/*iteration6*','scripts/*iteration5*.py','scripts/*iteration6*.py','scripts/package_iteration5_6.py','scripts/package_v3_publication.py','scripts/combine_iteration_overlay.py','scripts/validate_overlay.py','scripts/summarize_audited_overlay.py','scripts/registration_activation_engine.py','scripts/test_registration_activation*.py','tests/*iteration5*.py','tests/*iteration6*.py','reports/publication_census_receipt.json','BACKLOG.json']
 for pat in patterns:
  for p in R.glob(pat):
   if p.is_file() and p.suffix not in ('.log','.pyc') and 'iteration7' not in str(p):selected.add(p)
 # Full root5 and root6 overlays retain every baseline path; bulk Ruby trace ledgers
 # are separately frozen local inputs with explicit hashes, while their changed-path
 # outcomes, facts, bindings and source contracts remain included.
 omit={f'{profile}_ruby_path_decisions_iteration5.jsonl' for profile in ('ce','ee')}
 omitted=[p for p in selected if p.name in omit];selected-=set(omitted)
 for p in sorted(selected):
  dst=stage/p.relative_to(R);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
 (stage/'omitted_local_artifacts.json').write_text(json.dumps([dict(path=str(p.relative_to(R)),durable_location=str(p),sha256=digest(p),bytes=p.stat().st_size,rows=sum(1 for _ in p.open('rb')),reason='full root5/root6 per-path ledgers included; redundant raw Ruby per-path trace remains local with its freeze manifest') for p in omitted],indent=2)+'\n')
 (stage/'prerequisites.json').write_text(json.dumps(dict(prior_archives=ph,source_root='/workspace/gitlab_c_ext_trace',analysis_root=str(R),prior_census_revision='5c88395340596b216070e4dcd52395a12ce9d27473b6bc60bf8719306865cdd2',standalone=False),indent=2)+'\n')
 (stage/'INDEX.txt').write_text((D/'INDEX.txt').read_text())
 catalog=[dict(path=str(p.relative_to(stage)),bytes=p.stat().st_size,sha256=digest(p),rows=sum(1 for _ in p.open('rb')) if p.suffix=='.jsonl' else None) for p in sorted(stage.rglob('*')) if p.is_file()]
 paths={x['path'] for x in catalog}
 for iteration in ('iteration5','iteration6'):
  path=stage/'iterations'/iteration/'path_decisions.jsonl'
  assert path.exists()
  records=[json.loads(l) for l in path.open()]
  assert len(records)==38499,(iteration,len(records))
  assert len({(r['profile'],r['baseline_path_id']) for r in records})==38499
 assert not any('iteration7' in p for p in paths)
 (stage/'table_catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
 (stage/'package_validation.json').write_text(json.dumps(dict(status='PASS',freeze_checks=checks,full_path_rows_per_iteration=38499,files=len(catalog),bytes=sum(x['bytes'] for x in catalog),scope='Frozen-file agreement, complete root5/root6 path membership, archive content checks; no runtime claim'),indent=2)+'\n')
 (stage/'SHA256SUMS').write_text(''.join(f'{digest(p)}  {p.relative_to(stage)}\n' for p in sorted(stage.rglob('*')) if p.is_file()))
 arc=R/'publication/gitlab-c-ext-iteration5-6.tar.gz'
 with arc.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0,compresslevel=9) as gz,tarfile.open(fileobj=gz,mode='w') as t:
  for p in sorted(stage.rglob('*')):
   if p.is_file():
    info=tarfile.TarInfo('gitlab-c-ext-iteration5-6/'+str(p.relative_to(stage)));info.size=p.stat().st_size;info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(p.read_bytes()))
 expected={'gitlab-c-ext-iteration5-6/'+str(p.relative_to(stage)):digest(p) for p in stage.rglob('*') if p.is_file()}
 with tarfile.open(arc,'r:gz') as t:actual={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers()}
 assert actual==expected
 assert all(digest(Path(p))==h for p,h in ph.items())
 result=dict(status='PASS',archive=str(arc),bytes=arc.stat().st_size,sha256=digest(arc),members=len(actual),prior_archives_preserved=True)
 (D/'archive_validation.json').write_text(json.dumps(result,indent=2)+'\n');(D/'SHA256SUMS').write_text(f"{result['sha256']}  {arc.name}\n");print(json.dumps(result))
if __name__=='__main__':main()
