#!/usr/bin/env python3
import sys,json,hashlib
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');R=Path('/workspace/gitlab_c_ext_trace');sys.path.insert(0,str(V/'scripts'))
from batchloader_deferred_iteration6 import summary_method,regions
from deferred_execution import classify_call
errors=[];checks=0;results=[];freeze=json.loads((V/'reports/iteration6_stored_block_freeze.json').read_text())
for x in freeze['outputs']+freeze['preserved_inputs']:
 b=(V/x['path']).read_bytes();checks+=1
 if hashlib.sha256(b).hexdigest()!=x['sha256']:errors.append(dict(kind='frozen_hash',path=x['path']))
contract=json.loads((V/'tables/iteration6_stored_block_contracts.jsonl').open().readline())
for e in contract['evidence']:
 b=(R/e['file']).read_bytes();ls=b.decode().split('\n');checks+=2
 if hashlib.sha256(b).hexdigest()!=e['source_sha256']:errors.append(dict(kind='source_hash',file=e['file']))
 if '\n'.join(ls[e['line']-1:e['end_line']])!=e['excerpt']:errors.append(dict(kind='excerpt',file=e['file'],line=e['line']))
for name,src,want in [('explicit_graphql','def r; ::BatchLoader::GraphQL.for(1).batch { parse_me() }; end',True),('different_factory','def r; Other.for(1).batch { parse_me() }; end',False),('local_alias','def r; b=BatchLoader.for(1); b.batch { parse_me() }; end',False),('ordinary_each','def r; [1].each { parse_me() }; end',False),('nested_def','def r; BatchLoader.for(1).batch { def inner; parse_me(); end }; end',False),('outside_block','def r; BatchLoader.for(1).batch { 1 }; parse_me(); end',False),('known_shadow','BatchLoader=Other; def r; BatchLoader.for(1).batch { parse_me() }; end',False)]:
 data=src.encode();regs,calls,notes=regions('independent/'+name+'.rb',data,contract);target=next(c for c in calls.values()if data[c['byte_offset']:].startswith(b'parse_me'));actual=classify_call(target,regs) is not None;checks+=1;results.append(dict(name=name,expected_partial_boundary=want,actual_partial_boundary=actual))
 if actual!=want:errors.append(dict(kind='fixture',name=name))
for name,src,want in [('stored','def register(&callback); @saved=callback; self; end','stored_block_with_no_direct_invocation'),('direct_invocation','def register(&callback); @saved=callback; @saved.call; end','direct_invocation'),('unresolved_forward','def register(&callback); send_elsewhere(&callback); end','unresolved_forwarding')]:
 actual=summary_method(src.encode(),'register')['classification'];checks+=1;results.append(dict(name=name,expected=want,actual=actual))
 if actual!=want:errors.append(dict(kind='summary_fixture',name=name))
decisions=[json.loads(l)for l in (V/'tables/iteration6_stored_block_path_decisions.jsonl').open()];checks+=1
if {d['audit_id']for d in decisions}!={'C035','C118'}or any(d['status']!='partial_requires_stored_callback_invocation'for d in decisions):errors.append(dict(kind='decision_scope'))
report=dict(status='PASS'if not errors else'FAIL',checks=checks,errors=errors,fixtures=results,affected_audit_ids=[d['audit_id']for d in decisions],source_semantic_verdict='Supported bounded withholding: pinned BatchLoader factory/GraphQL proxy forwards explicit block to batch, which stores @batch_block. Reviewed ExecutorProxy only registers metadata/item. Separate __ensure_batched invokes @batch_block.call when uncached. Lexical resolve→decode_cursor transition inside captured body omits this forcing/capture event in C035/C118.',scope='Selected151 census source-file scope, not all callbacks or arbitrary methods named batch. Qualified factories and retained normal dispatch only; local aliases and unknown overrides remain unresolved.',not_contradiction='Callbacks may execute under stronger evidence. These two supplied witnesses are partial, not impossible paths.',stronger_recipe='Independent CE manual GraphQL recipe retains explicit interpreter/dataloader sync and first-uncached-wrapper/capture identity conditions. Its frozen bytes verified unchanged; no proof borrowed into C035 or EE C118.',limitations=['Generic local method summary reports unknown transitive callee effects; actual contract additionally source-reviews its helper chain.','Constant/factory mapping remains conditional on no unmodeled runtime override/shadowing; lexical scans are not global dynamic closure.','No runtime execution, authorization feasibility, general callback coverage or input-control proof.'],frozen_input_manifest_sha256=hashlib.sha256((V/'reports/iteration6_stored_block_freeze.json').read_bytes()).hexdigest())
(V/'reports/independent_iteration6_stored_block_review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
