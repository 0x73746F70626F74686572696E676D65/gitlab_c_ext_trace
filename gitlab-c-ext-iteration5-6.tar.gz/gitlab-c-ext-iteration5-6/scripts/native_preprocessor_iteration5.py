"""Bounded source-only preprocessing facts. Does not invoke a compiler.
Unknown includes invalidate environment; only explicit header contracts preserve
facts. No compiled-configuration claim. Tri-state conditions fail closed.
"""
import re,hashlib
from pathlib import Path
UNKNOWN=None

def both(a,b):
 if a is False or b is False:return False
 return True if a is True and b is True else None

def negate(a):return None if a is None else not a

def condition(expression,env):
 tokens=re.findall(r'defined|0[xX][0-9a-fA-F]+|\d+|[A-Za-z_]\w*|&&|\|\||[!()]|\S',expression);i=0
 def atom():
  nonlocal i
  if i>=len(tokens):raise ValueError()
  t=tokens[i];i+=1
  if t=='!':return negate(atom())
  if t=='(':
   v=orr()
   if i>=len(tokens)or tokens[i]!=')':raise ValueError()
   i+=1;return v
  if t=='defined':
   par=i<len(tokens)and tokens[i]=='('
   if par:i+=1
   if i>=len(tokens)or not re.fullmatch(r'[A-Za-z_]\w*',tokens[i]):raise ValueError()
   name=tokens[i];i+=1
   if par:
    if i>=len(tokens)or tokens[i]!=')':raise ValueError()
    i+=1
   return env.get(name,{}).get('defined')
  if re.fullmatch(r'0[xX][0-9a-fA-F]+|\d+',t):return bool(int(t,0)if t!='0'else 0)
  if re.fullmatch(r'[A-Za-z_]\w*',t):
   v=env.get(t,{})
   if v.get('defined')is False:return False
   return None if v.get('value')is None else bool(v['value'])
  raise ValueError()
 def andd():
  nonlocal i
  v=atom()
  while i<len(tokens)and tokens[i]=='&&':i+=1;v=both(v,atom())
  return v
 def orr():
  nonlocal i
  v=andd()
  while i<len(tokens)and tokens[i]=='||':
   i+=1;q=andd();v=True if v is True or q is True else False if v is False and q is False else None
  return v
 try:
  ans=orr();return ans if i==len(tokens)else None
 except (ValueError,RecursionError):return None

class Interpreter:
 def __init__(self,root,contracts=None,ruby_root=None):
  self.root=Path(root);self.contracts=contracts or{};self.ruby_root=Path(ruby_root)if ruby_root else None;self.contract_seen=set();self.events=[];self.issues=[];self.active_files=set();self.states={};self.evidence=[]
 def event(self,p,line,rule,**kw):
  x=dict(file=str(p),line=line,rule=rule,**kw);self.events.append(x);return x
 def kill(self,env,p,line,why):
  for name in list(env):env[name]={'defined':None,'value':None}
  self.event(p,line,'invalidate_macro_facts',reason=why)
 def include(self,target,quoted,parent,env,line,active):
  if active is False:return
  if active is None:self.kill(env,parent,line,'conditional_include_unknown');return
  local=parent.parent/target if quoted else None
  if local and local.is_file():self.scan(local,env);return
  if target in self.contracts:
   if target in self.contract_seen:
    self.event(parent,line,'certified_header_already_included',include=target);return
   self.contract_seen.add(target)
   for n,v in self.contracts[target].items():env[n]=dict(v)
   self.event(parent,line,'certified_header_exports',include=target,macros=sorted(self.contracts[target]));return
  # Named retained Ruby header contracts preserve exported capability flags;
  # all other unknown macro names remain unknown. The bounded contract excludes
  # external header injection/undef and is independently checked against sources.
  ruby=self.ruby_root/'include'/target if self.ruby_root else None
  if target.startswith('ruby/')and ruby and ruby.is_file():
   for n in list(env):
    if n not in {k for c in self.contracts.values() for k in c}:env[n]={'defined':None,'value':None}
   self.event(parent,line,'retained_ruby_header_capability_preservation',include=target,source=str(ruby));return
  self.kill(env,parent,line,'unresolved_include:'+target)
 def scan(self,p,env=None,depth=0):
  p=Path(p).resolve();env={}if env is None else env
  if p in self.active_files:self.kill(env,p,1,'include_cycle');return env
  self.active_files.add(p);raw=p.read_text(errors='replace');self.evidence.append(dict(file=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
  # Preserve LF coordinates while removing block comments. Directives hidden
  # in quoted strings are not matched because # must lead a logical line.
  pattern=r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|/\*.*?\*/|//[^\n]*'
  text=re.sub(pattern,lambda m:(' '+ '\n'*m[0].count('\n')) if m[0].startswith(('/*','//')) else m[0],raw,flags=re.S)
  splice_comment_unsupported=bool(re.search(r'//[^\n]*\\\n',raw))
  lines=text.split('\n');guard=re.search(r'^\s*#\s*ifndef\s+(\w+)\s*\n\s*#\s*define\s+\1\b',text)
  if guard and guard[1]not in env:
   env[guard[1]]={'defined':False,'value':None};self.event(p,1,'canonical_header_guard_not_externally_predefined',macro=guard[1])
  stack=[];active=True;i=0;line_states={}
  while i<len(lines):
   line=i+1;s=lines[i];i+=1
   while s.rstrip().endswith('\\')and i<len(lines):s=s.rstrip()[:-1]+lines[i];i+=1
   s=re.sub(r'//.*','',s);m=re.match(r'^\s*#\s*(\w+)\b(.*)',s)
   line_states[line]={'active':active,'guards':[dict(x)for x in stack]}
   if not m:
    if active is not False and re.search(r'\b(?:_Pragma|__pragma)\s*\(',s):self.kill(env,p,line,'inline_pragma_unknown_macro_effect')
    continue
   op,arg=m[1],m[2].strip()
   if op in('ifdef','ifndef','if'):
    expr='defined('+arg+')'if op=='ifdef'else'!defined('+arg+')'if op=='ifndef'else arg
    q=condition(expr,env);stack.append(dict(parent_active=active,taken=q,condition=expr,opening_condition=expr,opening_line=line,truth=q,file=str(p),line=line,arm='if'));active=both(active,q)
   elif op in('elif','elifdef','elifndef','else'):
    if op=='elifdef':arg='defined('+arg+')'
    if op=='elifndef':arg='!defined('+arg+')'
    if not stack:self.issues.append(dict(file=str(p),line=line,reason='unmatched_conditional'));active=None;continue
    top=stack[-1];q=True if op=='else'else condition(arg,env);eligible=negate(top['taken']);arm=both(eligible,q)
    top.update(arm=op,condition=arg if op!='else'else'else',truth=arm,line=line)
    top['taken']=True if top['taken']is True or q is True else False if top['taken']is False and q is False else None
    active=both(top['parent_active'],arm)
   elif op=='endif':
    if stack:active=stack.pop()['parent_active']
    else:self.issues.append(dict(file=str(p),line=line,reason='unmatched_endif'));active=None
   elif op in('define','undef')and active is not False:
    mm=re.match(r'(\w+)(.*)',arg)
    if not mm:continue
    n,rest=mm[1],mm[2].strip();v=None
    if op=='define'and re.fullmatch(r'(?:0[xX][0-9a-fA-F]+|\d+)[uUlL]*',rest):
     try:v=int(re.sub('[uUlL]+$','',rest),0)
     except ValueError:pass
    env[n]=dict(defined=(op=='define')if active is True else None,value=v if active is True and op=='define'else None)
    self.event(p,line,op,macro=n,active=active,value=v)
   elif op in('include','include_next')and active is not False:
    inc=re.fullmatch(r'([<"])([^>"]+)[>"]',arg)
    if op=='include_next'or not inc:self.kill(env,p,line,'unsupported_include_operand')
    else:self.include(inc[2],inc[1]=='"',p,env,line,active)
   elif op=='pragma'and active is not False and arg!='once':self.kill(env,p,line,'pragma_unknown_macro_effect')
   elif op=='error'and active is True:self.issues.append(dict(file=str(p),line=line,reason='active_error_directive'))
  if stack:self.issues.append(dict(file=str(p),reason='unclosed_conditional'));line_states={k:{**v,'active':None}for k,v in line_states.items()}
  if splice_comment_unsupported:
   self.issues.append(dict(file=str(p),reason='escaped_newline_line_comment_unsupported'))
   self.kill(env,p,1,'escaped_newline_line_comment_unsupported')
   line_states={k:{**v,'active':None}for k,v in line_states.items()}
  self.states[str(p)]=line_states;self.active_files.remove(p);return env
 def at(self,p,line):
  p=str(Path(p).resolve());states=self.states.get(p,{})
  if not states:return{'active':None,'guards':[]}
  k=max((k for k in states if k<=line),default=None)
  return states[k]if k else{'active':None,'guards':[]}
