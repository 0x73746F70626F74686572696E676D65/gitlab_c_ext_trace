import datetime,hashlib,json,pathlib
V=pathlib.Path(__file__).resolve().parents[1];preservation={}
for name in ('lookup_iteration1_manifest.json','super_iteration2_manifest.json','ruby_arguments_iteration3_manifest.json','ruby_arguments_iteration4_manifest.json'):
 m=json.load(open(V/'reports'/name));bad=[p for p,x in m['files'].items() if hashlib.sha256((V/p).read_bytes()).hexdigest()!=x['sha256']];preservation[name]={'hash_mismatches':bad};assert not bad
validation=json.load(open(V/'reports/ruby_arguments_iteration5_validation.json'));assert validation['status']=='pass'
paths=[]
for folder in ('scripts','tests','tables','reports'):
 paths.extend(p for p in (V/folder).glob('*iteration5*') if p.is_file() and p.suffix not in ('.log','.pyc') and p.name!='ruby_arguments_iteration5_manifest.json' and ('ruby_argument' in p.name or 'ruby_path_decisions' in p.name or 'fixed_json' in p.name or 'initialized_getter' in p.name or 'zone_write_inventory' in p.name))
m={'iteration':5,'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'feature':'Conditional initialized getter truthiness and general ternary guards','tests_passed':58,'validation':validation,'delta':json.load(open(V/'reports/ruby_argument_delta_iteration5.json')),'preserved_prior_manifests':preservation,'development_input':'Parent-disclosed census3 source error family; no path-ID rules; source contract and independent fixtures','files':{str(p.relative_to(V)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(set(paths))}}
p=V/'reports/ruby_arguments_iteration5_manifest.json';p.write_text(json.dumps(m,indent=2)+'\n');print(str(p),hashlib.sha256(p.read_bytes()).hexdigest(),len(m['files']))
