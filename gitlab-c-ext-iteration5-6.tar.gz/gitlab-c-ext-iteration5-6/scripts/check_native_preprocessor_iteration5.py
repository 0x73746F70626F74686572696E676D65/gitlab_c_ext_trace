import json,hashlib,re,collections,datetime
from pathlib import Path
from native_preprocessor_iteration5 import Interpreter
R=Path('/workspace/gitlab_c_ext_trace');V=Path('/workspace/gitlab_c_ext_v3');RR=R/'sources/runtime/ruby-v3_3_11'
def rows(p):
 with p.open()as f:
  for s in f:yield json.loads(s)
def write(n,xs):
 with(V/'tables'/f'{n}_iteration5.jsonl').open('w')as f:
  for x in xs:f.write(json.dumps(x,sort_keys=True)+'\n')
def key(*ss):return hashlib.sha256('\0'.join(map(str,ss)).encode()).hexdigest()[:24]
def evidence(p,a,z):
 b=p.read_bytes();return dict(file=str(p.relative_to(R)),line=a,end_line=z,sha256=hashlib.sha256(b).hexdigest(),excerpt='\n'.join(b.decode(errors='replace').split('\n')[a-1:z]))
header=RR/'include/ruby.h';export={};defs=[]
for n,line in enumerate(header.read_text().split('\n'),1):
 m=re.match(r'#define\s+(HAVE_RUBY_\w+)\s+1\s*$',line)
 if m:export[m[1]]=dict(defined=True,value=1);defs.append(evidence(header,n,n))
conflicts=[];scanned=0
for p in RR.rglob('*'):
 if not p.is_file()or p.suffix not in('.h','.c','.in'):continue
 scanned+=1
 for n,line in enumerate(p.read_text(errors='replace').split('\n'),1):
  m=re.match(r'\s*#\s*(define|undef)\s+(HAVE_RUBY_\w+)\b',line)
  if m and m[2]in export and p!=header:conflicts.append(evidence(p,n,n));export.pop(m[2],None)
contract=dict(model_id='ruby3311_header_capabilities_v1',runtime_commit='1f2d15125a2dc701e1822ed2900eb17899500ec7',exports=export,evidence=defs,conflicts=conflicts,scanned_runtime_source_files=scanned,assumptions=['Extension compiled against these matching Ruby3.3.11 headers.','Canonical header guards are not externally predefined before first include.','No externally injected redefinition/undef of Ruby capability flags, including generated/system-header injection; explicit local writes are interpreted.','Retained Ruby subheaders preserve these exports (no retained redefine/undef found).'],runtime_deployment_proven=False)
write('native_header_contracts',[contract])
paths=[]
for profile,root in [('ce',Path('/workspace/gitlab_c_ext_frontend_v2')),('ee',Path('/workspace/gitlab_c_ext_ee_profile'))]:
 paths += [dict(x,profile=profile)for x in rows(root/'tables/frontend_paths.jsonl')]
needed={x['native_tail_id']for x in paths};tails={x['tail_id']:x for x in rows(R/'tables/frontend_native_tails.jsonl')if x['tail_id']in needed};hid={h for t in tails.values()for h in t['hops']};hops={x['hop_id']:x for x in rows(R/'tables/frontend_native_hops.jsonl')if x['hop_id']in hid}
cache={};assess=[];events=[];sourcehashes={}
for h in hops.values():
 f=h['file'];line=h['line']
 if f not in cache:
  pp=Interpreter(R,{'ruby.h':export},RR);pp.scan(R/f);cache[f]=pp
  events += [dict(e,source_scan_file=f)for e in pp.events]
  for e in pp.evidence:sourcehashes[e['file']]=e['sha256']
 pp=cache[f];a=pp.at(R/f,line);assess.append(dict(assessment_id=key(h['hop_id'],'preprocessor5'),hop_id=h['hop_id'],file=f,line=line,status='contradicted'if a['active']is False else'unknown_preprocessor_condition'if a['active']is None else'source_branch_not_excluded',active=a['active'],guards=a['guards'],source_scan_file=f,contract_id=contract['model_id'],evidence=evidence(R/f,line,line),semantics='Source-profile preprocessor condition only; no compiled or runtime proof.'))
byhop={x['hop_id']:x for x in assess};decisions=[]
for p in paths:
 a=[byhop[h]for h in tails[p['native_tail_id']]['hops']];false=[x['assessment_id']for x in a if x['active']is False];unknown=[x['assessment_id']for x in a if x['active']is None]
 tu_evidence=[]
 # A header exclusion must also hold when scanned through an observed caller's
 # retained translation unit. Never certify a header solely in isolation.
 for assessment in list(false):
  candidate=next(x for x in a if x['assessment_id']==assessment)
  if Path(candidate['file']).suffix not in('.h','.hpp','.hh','.inc'):continue
  proofs=[]
  for hop_id in tails[p['native_tail_id']]['hops']:
   source=hops[hop_id].get('file')
   if source in cache and source!=candidate['file']:
    q=cache[source].at(R/candidate['file'],candidate['line'])
    if q['active']is False:proofs.append(dict(source_scan_file=source,header=candidate['file'],line=candidate['line'],active=False))
  if proofs:tu_evidence.extend(proofs)
  else:false.remove(assessment);unknown.append(assessment)
 decisions.append(dict(profile=p['profile'],path_id=p['path_id'],native_tail_id=p['native_tail_id'],status='contradicted'if false else'unresolved'if unknown else'source_branch_not_excluded',contradictions=false,unknown_conditions=unknown,header_translation_unit_evidence=tu_evidence,contract_id=contract['model_id'],runtime_verified=False))
write('native_preprocessor_hops',assess);write('native_preprocessor_decisions',decisions);write('native_preprocessor_events',events)
write('native_preprocessor_sources',[dict(file=f,sha256=s)for f,s in sorted(sourcehashes.items())])
# Separate memory-effect certificate: do not turn immediate Integer conversion
# into an unreachable native call site.
effects=[]
for s in rows(R/'tables/primitive_sites.jsonl'):
 if s['canonical_source_path'].endswith('/date-3.5.1/ext/date/date_core.c')and s['line']==8228 and s['operation']=='LONG2NUM':
  effects.append(dict(site_id=s['site_id'],operation='LONG2NUM(sf)',status='no_new_allocation_under_bounded_nanosecond_contract',callsite_reachability_unchanged=True,bounds=dict(sf_min=0,sf_max=999999999,minimum_fixnum_max_32bit_long=1073741823),assumptions=['Normal successful POSIX clock_gettime/gettimeofday fractional field ranges.','Matching Ruby3.3.11 core integer representation and C long width at least32 bits.'],evidence=[evidence(R/s['canonical_source_path'],8213,8218),evidence(R/s['canonical_source_path'],8226,8230),evidence(RR/'include/ruby/internal/arithmetic/long.h',307,314),evidence(RR/'include/ruby/internal/arithmetic/long.h',110,120),evidence(RR/'include/ruby/internal/arithmetic/fixnum.h',43,55)],semantic_limit='Numeric conversion expression executes; immediate Fixnum encoding does not allocate a new Integer object. This is not path exclusion.'))
write('terminal_memory_effects',effects)
report=dict(paths=len(paths),native_hops=len(hops),source_scan_roots=len(cache),source_files=len(sourcehashes),path_statuses=[dict(profile=p,status=s,paths=n)for(p,s),n in collections.Counter((x['profile'],x['status'])for x in decisions).items()],contradicting_source_loci=[dict(file=f,line=l,hops=n)for(f,l),n in collections.Counter((x['file'],x['line'])for x in assess if x['active']is False).items()],memory_effect_annotations=len(effects),assumptions=contract['assumptions'],issues=[x for pp in cache.values()for x in pp.issues],no_graph_mutation=True,no_compiler_or_target_execution=True)
(V/'reports/native_preprocessor_coverage_iteration5.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in('issues','assumptions')}))
