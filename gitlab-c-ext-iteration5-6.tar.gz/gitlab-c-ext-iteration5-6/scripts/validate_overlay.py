#!/usr/bin/env python3
"""Check overlay identity/references/freeze; these are NOT semantic accuracy checks."""
import argparse,collections,hashlib,json,pathlib
V=pathlib.Path(__file__).resolve().parents[1]
ROOTS={'ce':pathlib.Path('/workspace/gitlab_c_ext_frontend_v2'),'ee':pathlib.Path('/workspace/gitlab_c_ext_ee_profile')}
def rows(p):
 with pathlib.Path(p).open() as f:
  for s in f:
   if s.strip():yield json.loads(s)
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('iteration');a=ap.parse_args();o=V/'iterations'/a.iteration;m=json.loads((o/'freeze_manifest.json').read_text());errors=[];checks=0
 def check(ok,msg):
  nonlocal checks
  checks+=1
  if not ok:errors.append(msg)
 for r in m['inputs']+m['outputs']:
  p=pathlib.Path(r['path']);check(p.is_file() and p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],'freeze:'+str(p))
 baseline={}
 for profile,root in ROOTS.items():
  for r in rows(root/'tables/frontend_paths.jsonl'):baseline[(profile,r['path_id'])]=r
 seen=set();counts=collections.defaultdict(collections.Counter)
 for r in rows(o/'path_decisions.jsonl'):
  k=(r['profile'],r['baseline_path_id']);check(k not in seen,'duplicate:'+str(k));seen.add(k);check(k in baseline,'missing_baseline:'+str(k))
  if k not in baseline:continue
  b=baseline[k]
  for field in ['entrypoint_id','ruby_prefix_id','native_tail_id']:check(r[field]==b[field],'changed_join:'+str(k)+':'+field)
  check(r['baseline_terminal_site_id']==b['terminal_site_id'],'changed_site:'+str(k))
  expected='rejected_static_contradiction' if r['contradictions'] else 'partial_unresolved_conditions' if r['unresolved_conditions'] else 'candidate_not_disproved'
  check(r['status']==expected,'status:'+str(k));check(r['terminal_site_id']==(b['terminal_site_id'] if expected=='candidate_not_disproved' else None),'terminal:'+str(k));check(r['runtime_verified'] is False and r['source_to_sink_argument_flow_established'] is False,'overclaimed:'+str(k));counts[r['profile']][r['status']]+=1
 check(set(baseline)==seen,'baseline_coverage')
 report={'iteration':a.iteration,'iteration_id':m['iteration_id'],'checks':checks,'errors':errors,'status':'PASS' if not errors else 'FAIL','rows':len(seen),'counts':dict(counts),'interpretation':'Identity, reference and reproducibility integrity only; no semantic accuracy or runtime proof.'}
 p=V/'reports'/f'{a.iteration}_overlay_integrity.json';p.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));raise SystemExit(bool(errors))
if __name__=='__main__':main()
