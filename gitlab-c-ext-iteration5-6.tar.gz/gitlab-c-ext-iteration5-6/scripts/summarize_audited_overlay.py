#!/usr/bin/env python3
"""Summarize the reviewed surviving witness slice, not unbounded paths or runtime accuracy."""
import argparse,collections,hashlib,json,pathlib
V=pathlib.Path(__file__).resolve().parents[1]
def rows(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
a=argparse.ArgumentParser();a.add_argument('iteration');args=a.parse_args()
p=V/'iterations'/args.iteration/'path_decisions.jsonl';dims=V/'audit/candidate_census_iteration3/census_path_dimensions.jsonl'
ds={r['path_id']:r for r in rows(dims)};candidates=[r for r in rows(p) if r['status']=='candidate_not_disproved'];missing=[r['baseline_path_id'] for r in candidates if r['baseline_path_id'] not in ds]
assert not missing, missing
rs=[ds[r['baseline_path_id']]for r in candidates]
def counts(group):
 groups=collections.defaultdict(list)
 for r in rs:groups[r[group]].append(r)
 return {k:{'path_records':len(v),'distinct_profile_entrypoints':len({(r['profile'],r['entrypoint_id'])for r in v}),'distinct_physical_sites':len({r['physical_site_id']for r in v})}for k,v in sorted(groups.items())}
report={'iteration':args.iteration,'path_records':len(rs),'profile_entrypoints':len({(r['profile'],r['entrypoint_id'])for r in rs}),'physical_sites':len({r['physical_site_id']for r in rs}),'by_profile':counts('profile'),'by_frontend':counts('frontend'),'by_gem':counts('gem'),'by_primitive_kind':counts('primitive_kind'),'by_review_bucket':counts('bucket'),'interpretation':'All survivors belong to the frozen151-witness census. This is development reuse, not fresh holdout precision. Candidate does not prove feasible request execution or client influence. Sets overlap; multiple paths can share a terminal site. Seven LONG2NUM records share one site that is nonallocating under reviewed valid-nanosecond conditions. Conditional source and unreviewed external ICU buckets stay separate.','inputs':[{'path':str(x),'sha256':hashlib.sha256(x.read_bytes()).hexdigest()}for x in [p,dims]]}
(V/'reports'/f'{args.iteration}_audited_breakdowns.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['iteration','path_records','profile_entrypoints','physical_sites','by_review_bucket']},indent=2))
