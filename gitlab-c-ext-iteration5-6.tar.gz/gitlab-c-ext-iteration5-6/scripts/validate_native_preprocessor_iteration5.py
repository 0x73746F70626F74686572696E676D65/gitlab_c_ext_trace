import json,hashlib,collections
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');R=Path('/workspace/gitlab_c_ext_trace');checks=collections.Counter();errors=[]
def rows(n):return [json.loads(s)for s in(V/'tables'/f'{n}_iteration5.jsonl').read_text().splitlines()]
def ck(ok,kind,detail):
 checks[kind]+=1
 if not ok:errors.append(dict(kind=kind,detail=detail))
hops=rows('native_preprocessor_hops');hmap={x['assessment_id']:x for x in hops};decisions=rows('native_preprocessor_decisions');ck(len(hmap)==len(hops),'unique_hop_assessment',len(hops))
for x in hops:
 ev=x['evidence'];b=(R/ev['file']).read_bytes();ls=b.decode(errors='replace').split('\n')
 ck(hashlib.sha256(b).hexdigest()==ev['sha256'],'source_hash',x['assessment_id']);ck(ls[ev['line']-1]==ev['excerpt'],'source_line',x['assessment_id'])
 ck(x['status']==('contradicted'if x['active']is False else'unknown_preprocessor_condition'if x['active']is None else'source_branch_not_excluded'),'hop_status',x['assessment_id'])
for x in decisions:
 for id in x['contradictions']:
  ck(id in hmap and hmap[id]['active']is False,'false_guard_join',id)
  if Path(hmap[id]['file']).suffix in('.h','.hpp','.hh','.inc'):ck(bool(x.get('header_translation_unit_evidence')),'caller_include_support',id)
 for id in x['unknown_conditions']:ck(id in hmap and hmap[id]['active']in(None,False),'unknown_guard_join',id)
 ck(x['status']==('contradicted'if x['contradictions']else'unresolved'if x['unknown_conditions']else'source_branch_not_excluded'),'decision_status',x['path_id'])
for x in rows('native_preprocessor_sources'):ck(hashlib.sha256(Path(x['file']).read_bytes()).hexdigest()==x['sha256'],'retained_include_hash',x['file'])
contract=rows('native_header_contracts')[0];ck(not contract['conflicts'],'header_export_conflicts',contract['conflicts']);ck(contract['exports'].get('HAVE_RUBY_ENCODING_H')=={'defined':True,'value':1},'required_export',contract['exports'])
# Independent bounded source nesting review of newly excluded loci, not general
# semantic validation of every unknown preprocessor branch.
false=[x for x in hops if x['active']is False]
for x in false:
 ck(x['file'].endswith('charlock_holmes/common.h')and x['line']in(19,37),'reviewed_exclusion_locus',x['assessment_id'])
 ck(any(g.get('opening_condition')=='defined(HAVE_RUBY_ENCODING_H)'and g['arm']=='else'for g in x['guards']),'source_guard_evidence',x['assessment_id'])
A=V/'audit/candidate_census_iteration3';census=[json.loads(s)for s in(A/'path_sample.jsonl').read_text().splitlines()];excluded={(x['profile'],x['path_id'])for x in decisions if x['status']=='contradicted'}
inter=[dict(audit_id=x['audit_id'],profile=x['profile'],path_id=x['path']['path_id'])for x in census if(x['profile'],x['path']['path_id'])in excluded]
effects=rows('terminal_memory_effects');ck(len(effects)==1,'memory_effect_site_count',len(effects));ck(all(x['callsite_reachability_unchanged']for x in effects),'effect_not_exclusion',effects[0]['site_id']if effects else None)
r=dict(status='pass'if not errors else'status_failed',checks=sum(checks.values()),check_counts=dict(checks),errors=errors,census_candidate_exclusions=inter,semantics='Integrity plus explicitly reviewed new source loci. Not runtime/build verification or independent full-preprocessor correctness proof.')
(V/'reports/native_preprocessor_validation_iteration5.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
