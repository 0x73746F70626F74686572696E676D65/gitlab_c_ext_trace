#!/usr/bin/env python3
"""Source-backed stored-block overlay for selected prefixes; not a callback engine."""
from pathlib import Path
import hashlib,json,collections
from deferred_execution import parser,uid,classify_call,R,V
B='sources/expansion/batch-loader-2.0.5--exAspArk/lib/'
def walk(n):
 yield n
 for c in n.named_children:yield from walk(c)
def text(data,n):return data[n.start_byte:n.end_byte].decode() if n else ''
def field(n,k):return n.child_by_field_name(k)
def summary_method(data,name):
 """Generic local block-store summary. Does not infer hidden callees execute or defer."""
 tree=parser().parse(data)
 for m in walk(tree.root_node):
  if m.type not in {'method','singleton_method'} or text(data,field(m,'name'))!=name:continue
  params=field(m,'parameters');bp=next((x for x in (params.named_children if params else []) if x.type=='block_parameter'),None)
  blockname=text(data,field(bp,'name')) if bp else None
  if not blockname:return dict(classification='no_explicit_block_parameter',direct_yield=any(x.type=='yield' for x in walk(m)))
  stores=[text(data,field(x,'left')) for x in walk(m) if x.type=='assignment' and field(x,'left').type=='instance_variable' and text(data,field(x,'right'))==blockname]
  invoked=any(x.type=='yield' or (x.type=='call' and text(data,field(x,'receiver')) in [blockname]+stores and text(data,field(x,'method')) in {'call','[]','yield'}) for x in walk(m))
  return dict(classification='stored_block_with_no_direct_invocation' if stores and not invoked else 'direct_invocation' if invoked else 'unresolved_forwarding',block_parameter=blockname,stored_instance_variables=stores,line=m.start_point.row+1,end_line=m.end_point.row+1,unknown_transitive_callee_effects=True)
 return dict(classification='method_missing')
def ev(file,a,b,claim):
 d=(R/file).read_bytes();return dict(file=file,line=a,end_line=b,source_sha256=hashlib.sha256(d).hexdigest(),claim=claim,excerpt='\n'.join(d.decode().split('\n')[a-1:b]))
def contract():
 summary=summary_method((R/B/'batch_loader.rb').read_bytes(),'batch');assert summary['classification']=='stored_block_with_no_direct_invocation' and summary['stored_instance_variables']==['@batch_block']
 e=[ev(B+'batch_loader.rb',17,23,'BatchLoader.for returns newly constructed BatchLoader with item.'),ev(B+'batch_loader.rb',26,37,'batch stores captured &batch_block in @batch_block and returns self; registration not an invocation.'),ev(B+'batch_loader.rb',137,142,'Executor proxy created with same block; next source contract checks constructor uses metadata and stores it.'),ev(B+'batch_loader/executor_proxy.rb',8,21,'Proxy constructor stores block/source_location, executor; add only enqueues item, no callback invocation.'),ev(B+'batch_loader/executor.rb',7,9,'Executor ensures current object without invoking captured callback.'),ev(B+'batch_loader/executor.rb',22,25,'Executor initializes empty item/value hashes.'),ev(B+'batch_loader.rb',86,97,'Actual deferred invocation occurs later via __ensure_batched @batch_block.call and is skipped for cached item.'),ev(B+'batch_loader/graphql.rb',55,71,'GraphQL.for constructs wrapper; initialize sets @batch_loader via BatchLoader.for; batch delegates **kwargs and &block then returns wrapper; sync separate.'),ev('sources/gitlab/config/initializers/batch_loader.rb',7,10,'CE prepend changes replace_methods default then super; registration remains storage.'),ev('sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/config/initializers/batch_loader.rb',7,10,'EE prepend same registration delegation; not proof of EE runtime forcing.')]
 return dict(contract_id='batchloader_205_stored_block_registration_v1',gem='batch-loader',version='2.0.5',source_root=str(R/B),classification='source_reviewed_stored_callback_registration',method_summary=summary,receiver_bindings=[dict(factory='BatchLoader.for',returned_owner='BatchLoader',method='batch'),dict(factory='BatchLoader::GraphQL.for',returned_owner='BatchLoader::GraphQL',method='batch',delegates_to='BatchLoader#batch via @batch_loader initialized by BatchLoader.for')],evidence=e,conditions=['Exact batch-loader2.0.5 source mapping for profile; factory and constructors use retained methods, no local constant shadowing or runtime overrides.','Source-inspected delegation/proxy registration helpers selected; no unseen prepend redirects block invocation.'],not_claimed=['No generic method-name-only batch rule.','No callback execution at registration; no never-invoked claim.','No cache, lazy forcing, argument capture, auth or reachability proof imported from another witness.'])
def regions(file,data,c,receiver_bindings=None):
 tree=parser().parse(data);result=[];notes=[];calls={}
 if tree.root_node.has_error:return [],{},[dict(file=file,reason='parse_error')]
 # Qualified inline factories only. Local aliases and other methods named batch remain unknown.
 bindings=receiver_bindings or {x['factory']:x for x in c['receiver_bindings']}
 shadow=any(n.type=='assignment' and text(data,field(n,'left')).lstrip(':') in {'BatchLoader','BatchLoader::GraphQL'} for n in walk(tree.root_node))
 shadow=shadow or any(n.type in {'class','module'} and text(data,field(n,'name')).split('::')[-1]=='BatchLoader' for n in walk(tree.root_node))
 for n in walk(tree.root_node):
  if n.type!='call':continue
  callid=uid(file,n.start_byte,n.end_byte,'call');mid='';p=n.parent
  while p:
   if p.type in {'method','singleton_method'}:mid=uid(file,p.start_byte,'method');break
   p=p.parent
  calls[callid]=dict(call_id=callid,file=file,line=n.start_point.row+1,byte_offset=n.start_byte,enclosing_method_id=mid)
  block=field(n,'block');recv=field(n,'receiver')
  if text(data,field(n,'method'))!='batch' or not block:continue
  if not recv or recv.type!='call' or text(data,field(recv,'method'))!='for':notes.append(dict(file=file,line=n.start_point.row+1,reason='batch_receiver_not_resolved_factory'));continue
  owner=text(data,field(recv,'receiver')).lstrip(':');factory=owner+'.for'
  if shadow or factory not in bindings:notes.append(dict(file=file,line=n.start_point.row+1,reason='unknown_or_shadowed_receiver_factory'));continue
  body=field(block,'body') or block
  result.append(dict(region_id='stored_defer_'+uid(file,n.start_byte,n.end_byte,c['contract_id']),file=file,file_id=uid(file),source_sha256=hashlib.sha256(data).hexdigest(),line=n.start_point.row+1,end_line=n.end_point.row+1,byte_start=n.start_byte,byte_end=n.end_byte,body_byte_start=body.start_byte,body_byte_end=body.end_byte,enclosing_method_id=mid,kind='source_proven_stored_block_registration',constructor_syntax=factory+'.batch',creation_call_id=callid,invocation_state='requires_invocation',invocation_evidence=None,required_event='source_backed_stored_callback_invocation_with_capture_identity',parse_has_error=False,contract_id=c['contract_id'],factory_binding=bindings[factory],binding_confidence='source_resolved_qualified_inline_factory_conditional_on_no_dynamic_override',qualification='Actual factory/delegation/store implementation reviewed for pinned version. A call in this body requires explicit forcing/invocation, not registration alone.'))
 return result,calls,notes

def main():
 sample=V/'audit/candidate_census_iteration3/path_sample.jsonl';paths=list(map(json.loads,sample.open()));files=sorted({h['file'] for p in paths for h in p['ruby_hops'] if h.get('file')});c=contract();allregs=[];allcalls={};notes=[]
 # Exact primary/profile lock source association. No same-name-only dispatch.
 ce=[r for r in map(json.loads,(R/'tables/gems.jsonl').open()) if r.get('name')=='batch-loader' and r.get('lockfile')=='Gemfile.lock'];ee=[r for r in map(json.loads,Path('/workspace/gitlab_c_ext_ee_profile/tables/profile_gems.jsonl').open()) if r.get('name')=='batch-loader']
 for profile,gemrows in [('ce',ce),('ee',ee)]:
  assert len(gemrows)==1 and gemrows[0]['version']=='2.0.5' and Path(gemrows[0]['source_dir']).resolve()==(R/B).parent.resolve(),(profile,gemrows)
 c['profile_gem_bindings']={profile:{k:xs[0].get(k) for k in ['gem_id','name','version','source_dir','lockfile','provenance']} for profile,xs in [('ce',ce),('ee',ee)]}
 for file in files:
  data=(R/file).read_bytes()
  if b'BatchLoader' not in data:continue
  regs,cs,ns=regions(file,data,c);allregs+=regs;allcalls.update(cs);notes+=ns
 byfile=collections.defaultdict(list)
 for reg in allregs:byfile[reg['file']].append(reg)
 decisions=[]
 for p in paths:
  hits=[]
  for h in p['ruby_hops']:
   call=allcalls.get(h.get('call_id'))
   if call:
    annotation=classify_call(call,byfile[call['file']])
    if annotation:hits.append(dict(hop_id=h['hop_id'],call_id=h['call_id'],file=call['file'],line=call['line'],annotation=annotation))
  if hits:decisions.append(dict(audit_id=p['audit_id'],profile=p['profile'],baseline_path_id=p['decision']['baseline_path_id'],ruby_prefix_id=p['decision']['ruby_prefix_id'],status='partial_requires_stored_callback_invocation',reason='frozen_witness_missing_source_backed_batch_callback_forcing_and_capture_identity',affected_hops=hits,contract_id=c['contract_id'],source_to_sink_flow_proven=False,runtime_verified=False,frozen_witness_mutated=False,strong_ce_recipe_disposition='Separate additive iteration4_graphql path identity retains its explicit forcing/capture conditions; not imported into this frozen witness.',ee_strong_flow_promoted=False))
 for name,rs in [('iteration6_stored_block_contracts',[c]),('iteration6_stored_block_regions',allregs),('iteration6_stored_block_path_decisions',decisions),('iteration6_stored_block_unresolved',notes)]:
  (V/f'tables/{name}.jsonl').write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in rs))
 report=dict(selected_frozen_paths=len(paths),selected_prefix_source_files=len(files),source_backed_regions=len(allregs),affected_frozen_paths=len(decisions),affected_by_profile=dict(collections.Counter(x['profile'] for x in decisions)),affected_audit_ids=[x['audit_id'] for x in decisions],unresolved_receiver_candidates=len(notes),actual_gem_version='2.0.5',methodname_only_matching=False,no_frozen_mutation=True,positive_recipe_unchanged=True)
 (V/'reports/iteration6_stored_block_coverage.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
