import unittest
from registration_activation_engine import witnesses,classify
class Cases(unittest.TestCase):
 def edge(self,a,b,id=None,**kw):return dict(id=id or a+b,**{'from':a,'to':b},**kw)
 def test_nested_init(self):
  w,_=witnesses([self.edge('I','helper'),self.edge('helper','reg')],{'Init_x':'I'});self.assertEqual(w['reg']['Init_x'],['Ihelper','helperreg'])
 def test_registration_pointer_is_not_call(self):
  w,_=witnesses([] ,{'Init_x':'I'});self.assertNotIn('ruby_api_implementation',w)
 def test_ruby_exposed_activation(self):
  i,_=witnesses([] ,{'Init_x':'I'});x,_=witnesses([self.edge('ruby_api','installer')],{'reg_activate':'ruby_api'});self.assertEqual(classify('installer',i,x),'Ruby_exposed_activation_candidate_only')
 def test_conditional_edge_not_proved(self):
  e=self.edge('I','reg',guard='if(enabled)');w,_=witnesses([e],{'Init_x':'I'});self.assertEqual(w['reg']['Init_x'],[e['id']]);self.assertEqual(e['guard'],'if(enabled)')
 def test_cycle_is_finite(self):
  w,_=witnesses([self.edge('I','a'),self.edge('a','I')],{'Init_x':'I'});self.assertEqual(w['I']['Init_x'],[])
 def test_missing_is_unknown(self):self.assertEqual(classify('x',{},{}),'unresolved_no_bounded_activation_witness')
 def test_depth_reported(self):
  w,b=witnesses([self.edge('I','a'),self.edge('a','b')],{'Init_x':'I'},max_depth=1);self.assertNotIn('b',w);self.assertEqual(b['depth_stop_nodes'],['a'])
 def test_seed_cap_reported(self):
  w,b=witnesses([self.edge('a','r'),self.edge('b','r')],{'A':'a','B':'b'},per_node=1);self.assertEqual(len(w['r']),1);self.assertIn('r',b['seed_cap_nodes'])
if __name__=='__main__':unittest.main()
