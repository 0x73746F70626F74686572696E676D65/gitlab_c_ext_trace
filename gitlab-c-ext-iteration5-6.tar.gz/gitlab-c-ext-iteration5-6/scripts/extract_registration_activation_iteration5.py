#!/usr/bin/env python3
import collections,hashlib,json,pathlib,re,time
from registration_activation_engine import witnesses,classify
import sys
sys.path.insert(0,"/workspace/gitlab_c_ext_trace/.python")
from tree_sitter import Parser,Language
import tree_sitter_c,tree_sitter_cpp
B=pathlib.Path('/workspace/gitlab_c_ext_trace');V=pathlib.Path('/workspace/gitlab_c_ext_v3')
def rows(name):
 with (B/'tables'/name).open() as f:
  for l in f:
   if l.strip():yield json.loads(l)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def out(name,data):(V/'tables'/name).write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in data))
def contexts(file,points,lang):
 p=B/file;b=p.read_bytes();ls=b.decode(errors='replace').splitlines();base={'file':file,'source_sha256':hashlib.sha256(b).hexdigest()};result={}
 for line in points:result[line]=dict(base,line=line,excerpt=ls[line-1] if line<=len(ls) else '',lexical_guards=[],lexical_call_context_found=False,control_flow='not_proven; predecessor failures/returns, compile selection and runtime values remain conditions')
 if len(b)>5_000_000:
  for r in result.values():r['parse_limitation']='source file exceeds5MB contextual parse bound'
  return result
 parser=Parser(Language(tree_sitter_cpp.language() if lang=='cpp' else tree_sitter_c.language()));tree=parser.parse(b);stack=[tree.root_node];count=0
 # Point-local ancestry: record ancestors of calls covering exact requested start line.
 while stack:
  n=stack.pop();count+=1
  if count>2_000_000:
   for r in result.values():r['parse_limitation']='node traversal cap2million'
   break
  line=n.start_point.row+1
  if n.type=='call_expression' and line in result:
   r=result[line];r['lexical_call_context_found']=True;anc=n.parent;guards=[]
   while anc is not None and anc.type!='function_definition':
    if anc.type in {'if_statement','conditional_expression','for_statement','while_statement','do_statement','switch_statement','case_statement','preproc_if','preproc_ifdef','preproc_else','preproc_elif'}:
     cond=anc.child_by_field_name('condition');consequence=anc.child_by_field_name('consequence');alternative=anc.child_by_field_name('alternative');branch=('consequence_true' if consequence and consequence.start_byte<=n.start_byte<consequence.end_byte else 'alternative_false' if alternative and alternative.start_byte<=n.start_byte<alternative.end_byte else 'unknown_or_loop_or_preprocessor');guards.append({'kind':anc.type,'line':anc.start_point.row+1,'condition':b[cond.start_byte:cond.end_byte].decode(errors='replace') if cond else b[anc.start_byte:min(anc.end_byte,anc.start_byte+160)].decode(errors='replace'),'branch':branch,'feasibility':'not evaluated'})
    anc=anc.parent
   if guards:r['lexical_guards']+=guards
   r['source_parse_has_errors']=tree.root_node.has_error
  stack.extend(n.named_children)
 return result

def main():
 regs=list(rows('c_registrations.jsonl'));gemmeta={g['gem_id']:g for g in rows('gems.jsonl')};gems={r['gem_id'] for r in regs};files={f['file_id']:f for f in rows('c_files.jsonl')};func={}
 for f in rows('c_functions.jsonl'):
  if f['gem_id'] in gems:func[f['function_id']]={k:f.get(k) for k in ['function_id','gem_id','file_id','name','line','end_line','is_init','parse_has_errors','kind']}
 edges=[];excluded=collections.Counter();unresolved=[]
 for c in rows('c_calls.jsonl'):
  if c.get('function_id') not in func:continue
  if c.get('syntax')!='ast_call' or c.get('target_function_id') not in func:
   excluded[c.get('resolution','unknown')]+=1
   # Retain callback/indirect evidence only for initializer functions, compactly.
   if func[c['function_id']]['is_init'] and (c.get('arguments') or c.get('syntax')!='ast_call'):
    unresolved.append({k:c.get(k) for k in ['call_id','function_id','file_id','line','callee','syntax','resolution','arguments']})
   continue
  target=func[c['target_function_id']]
  if target['gem_id']!=c['gem_id']:excluded['cross_gem_target']+=1;continue
  edges.append({'id':c['call_id'],'from':c['function_id'],'to':c['target_function_id'],'file_id':c['file_id'],'line':c['line'],'callee':c['callee'],'resolution':c['resolution'],'parse_region_has_errors':c.get('parse_region_has_errors',False)})
 print('graph',len(func),len(edges),flush=True)
 seeds={f['function_id']:f['function_id'] for f in func.values() if f['is_init']};iw,ib=witnesses(edges,seeds)
 drivers={r['registration_id']:r['c_function_id'] for r in regs if r.get('c_function_id') in func and iw.get(r.get('function_id'))}
 rw,rb=witnesses(edges,drivers);edgeby={e['id']:e for e in edges};used=set();output=[]
 for r in regs:
  container=r.get('function_id');ins=iw.get(container,{});acts=rw.get(container,{}) if not ins else {}
  for path in list(ins.values())+list(acts.values()):used.update(path)
  output.append({'registration_id':r['registration_id'],'gem_id':r['gem_id'],'inventory_gem_name':gemmeta.get(r['gem_id'],{}).get('name'),'inventory_gem_version':gemmeta.get(r['gem_id'],{}).get('version'),'inventory_gem_entry_primary_bundle':gemmeta.get(r['gem_id'],{}).get('primary_bundle'),'inventory_source_role':files[r['file_id']].get('corpus_role'),'status':classify(container,iw,rw),'registration_container_function_id':container,'registration_container':func.get(container),'registration_file':files[r['file_id']]['path'],'registration_line':r['line'],'registration_api':r['registration_api'],'ruby_name':r.get('ruby_name'),'implementation_function_id':r.get('c_function_id'),'Init_named_root_witnesses':[{'root_function_id':s,'root_name':func[s]['name'],'root_definition':dict(func[s],file=files[func[s]['file_id']]['path'],source_sha256=files[func[s]['file_id']]['sha256']),'call_ids':p} for s,p in ins.items()],'Ruby_exposed_activation_witnesses':[{'activation_registration_id':s,'call_ids':p,'scope':'driver registration has an Init-named-root source witness; actual Ruby invocation not established'} for s,p in acts.items()],'actual_activation_proven':False,'conditions':['Named Init function must be actual loaded extension initializer; helper/test Init names are candidate roots only.','Required definitions compiled and loaded; source graph linkage/name resolution and guards permit calls.','Predecessor operations return normally; runtime registration receiver is the intended class/module.','Registration not subsequently replaced/removed; Ruby-exposed driver requires independent call-site activation evidence.'],'absence_interpretation':'No bounded witness is unknown, never evidence registration cannot activate; callbacks/macros/generated/foreign dispatch may be missing.'})
 used_edges=[edgeby[e] for e in sorted(used)];points=collections.defaultdict(set)
 for e in used_edges:points[e['file_id']].add(e['line'])
 for r in regs:points[r['file_id']].add(r['line'])
 context={}
 for fid,lines in points.items():
  f=files[fid];context.update({(fid,line):ev for line,ev in contexts(f['path'],lines,f['language']).items()})
 for e in used_edges:e['source_evidence']=context[e['file_id'],e['line']];e['target_definition']={**func[e['to']],'file':files[func[e['to']]['file_id']]['path']}
 byreg={r['registration_id']:r for r in regs}
 for r in output:
  old=byreg[r['registration_id']];r['registration_evidence']=context[old['file_id'],old['line']]
 out('registration_activation_iteration5.jsonl',output);out('registration_activation_hops_iteration5.jsonl',used_edges);out('registration_activation_initializer_holes_iteration5.jsonl',unresolved)
 report={'corpus_scope':'All registrations in retained native inventory, including auxiliary/fixture entries; per-row primary_bundle and role identify original gem-entry membership, not complete primary dependency denominator.','registration_rows':len(output),'gems':len(gems),'functions_considered':len(func),'direct_candidate_edges':len(edges),'Init_named_candidate_roots':len(seeds),'Init_reachable_Ruby_activation_driver_registrations':len(drivers),'statuses':dict(collections.Counter(r['status'] for r in output)),'excluded_call_counts':dict(excluded),'Init_witness_bounds':ib,'Ruby_driver_witness_bounds':rb,'used_witness_hops':len(used_edges),'initializer_holes':len(unresolved),'actual_runtime_activation_proven':0,'source_tables':'existing retained c_functions/c_calls/c_registrations/c_files; no new native build or execution','limitations':['Syntactic graph reachability only, including possible cross-translation-unit name links explicitly retained as such.','Conditional ancestor extraction is lexical, not C branch feasibility proof; preprocessor alternatives and function-level guards may remain unknown.','Source absent/gems with no inventoried registrations are outside this table.','Root/helper Init distinction, Ruby loading/activation call sites, overwrite ordering and callbacks require independent analysis.']}
 (V/'reports/registration_activation_iteration5.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if 'bounds' not in k}),flush=True)
if __name__=='__main__':main()
