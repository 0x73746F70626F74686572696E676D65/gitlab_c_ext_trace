import collections,hashlib,json,pathlib,re
from ruby_argument_flow_iteration5 import FlowSource
V=pathlib.Path(__file__).resolve().parents[1];B=pathlib.Path('/workspace/gitlab_c_ext_trace');RAILS='sources/wrappers/rails-7.2.3.1'
def rows(p):
 with open(p) as f:
  for l in f:yield json.loads(l)
def walk(n):
 yield n
 for x in n.named_children:yield from walk(x)
def evidence(file,pattern,meaning):
 data=(B/file).read_bytes();lines=data.decode().splitlines();hits=[i+1 for i,l in enumerate(lines) if pattern in l];assert len(hits)==1,(file,pattern,hits)
 return dict(file=file,line=hits[0],sha256=hashlib.sha256(data).hexdigest(),excerpt=lines[hits[0]-1],meaning=meaning)
for profile,root,prefix in [('ce',pathlib.Path('/workspace/gitlab_c_ext_ruby_expanded'),'sources/gitlab/'),('ee',pathlib.Path('/workspace/gitlab_c_ext_ee_profile'),'sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/')]:
 primary={g['gem_id'] for g in rows(B/'tables/gems.jsonl') if g.get('lockfile')=='Gemfile.lock'} if profile=='ce' else set(json.load(open(root/'reports/profile_config.json'))['primary_gem_ids'])
 gfiles={r['file_id'] for r in rows(root/'tables/ruby_file_gems.jsonl') if r['gem_id'] in primary}
 def eligible(r):return not any(t in r['file'] for t in ('/spec/','/test/','/tests/','/fixtures/','/qa/','/examples/','/benchmark/','/vendor/')) and not(profile=='ee' and r['file'].startswith('sources/gitlab/')) and (r['file'].startswith(prefix) or r['file_id'] in gfiles)
 methods=[r for r in rows(root/'tables/ruby_methods.jsonl') if eligible(r)];getters=[r for r in methods if (r['namespace'],r['method'],r['kind'])==('Time','zone','singleton')];assert len(getters)==1,getters
 getter=getters[0];src=FlowSource((B/getter['file']).read_bytes(),getter['file']);mn=[n for n in src.methods['zone'] if n.start_point.row+1==getter['line']];assert len(mn)==1
 body=src.field(mn[0],'body');body=[x for x in body.named_children if x.type!='comment'];assert len(body)==1 and body[0].type=='binary' and src.text(src.field(body[0],'operator'))=='||'
 assert src.text(src.field(body[0],'left'))=='::ActiveSupport::IsolatedExecutionState[:time_zone]' and src.text(src.field(body[0],'right'))=='zone_default'
 ev=[evidence(getter['file'],'::ActiveSupport::IsolatedExecutionState[:time_zone] || zone_default','getter returns local state or process default'),evidence(getter['file'],'::ActiveSupport::IsolatedExecutionState[:time_zone] = find_zone!(time_zone)','setter replaces local state only'),evidence(getter['file'],'::Time.zone = old_zone','ensure restores through local setter'),evidence(getter['file'],'return time_zone unless time_zone','nil/false zone setter is allowed but getter falls back'),evidence(RAILS+'/railties/lib/rails/application/configuration.rb','@time_zone                               = "UTC"','initial configuration supplies ordinary nonempty zone'),evidence(RAILS+'/activesupport/lib/active_support/railtie.rb','Time.zone_default = Time.find_zone!(app.config.time_zone)','Rails initialization sets process default'),evidence(prefix+'config/initializers/time_zone.rb','Time.zone = Gitlab.config.gitlab.time_zone || Time.zone','application override preserves existing zone when absent'),evidence(prefix+'config/initializers/time_zone.rb','Time.zone_default = Time.zone','application copies effective zone into global default'),evidence(prefix+'config/initializers/time_zone.rb','Rails.application.config.time_zone = Time.zone.name','normal completed initialization dereferences zone')]
 writes=[];scanned=0;candidate_files=0;parse_errors=[]
 for f in rows(root/'tables/ruby_files.jsonl'):
  if not eligible(f):continue
  scanned+=1;data=(B/f['file']).read_bytes()
  if not any(x in data for x in (b'zone_default',b'Time.zone',b'Time::zone',b'[:time_zone]')):continue
  candidate_files+=1;s=FlowSource(data,f['file'])
  if s.tree.root_node.has_error:parse_errors.append(f['file'])
  for n in walk(s.tree.root_node):
   lhs=s.field(n,'left');tx=s.text(lhs);name=s.text(s.field(n,'method'));args=s.text(s.field(n,'arguments'))
   kind=None
   if n.type in ('assignment','operator_assignment'):
    if re.search(r'(?:Time\.zone_default|@zone_default)',tx):kind='global_default_assignment_candidate'
    elif re.search(r'Time\.zone\b|\[:time_zone\]',tx):kind='local_zone_assignment_candidate'
   elif n.type=='call' and name in ('instance_variable_set','remove_instance_variable','attr_writer','attr_accessor','send','public_send','__send__') and 'zone_default' in args:kind='reflective_or_accessor_default_candidate'
   if kind:writes.append(dict(write_id=hashlib.sha256((profile+'\0'+f['file']+'\0'+str(n.start_byte)).encode()).hexdigest()[:24],profile=profile,file=f['file'],line=n.start_point.row+1,byte_offset=n.start_byte,kind=kind,context=s.text(n),source_sha256=hashlib.sha256(data).hexdigest(),resolution='source_syntax_candidate_not_runtime_execution'))
 contract=dict(contract_id='initialized_time_zone_'+profile+'_iteration5',profile=profile,status='source_checked_conditional_contract',owner='Time',method='zone',getter_method_id=getter['method_id'],getter_file=getter['file'],getter_line=getter['line'],initialized_profile_applicable=True,required_conditions=['successful_application_initialization','getter_definition_unchanged','no_later_global_default_replacement','ordinary_Ruby_truthiness'],conditions_detail=['Rails/GitLab initializers completed in documented ordinary order with successful timezone lookup','Process default remains the non-false TimeZone value established at initialization','No later global setter/reflection replacement, altered getter precedence, or monkeypatched Nil/False name behavior','Request-local nil/false clearing and Time.use_zone restoration are safe because getter uses logical OR with unchanged truthy default'],evidence=ev,write_inventory_rows=len(writes),source_files_scanned=scanned,candidate_files_parsed=candidate_files,parse_error_files=parse_errors,scope='Initialized frontend witness population only; not standalone Rails library behavior or runtime proof',global_write_closure='conditional: dynamic/reflection/external writes cannot be excluded; known syntax candidates retained')
 (V/'reports'/f'{profile}_initialized_getter_contract_iteration5.json').write_text(json.dumps(contract,indent=2)+'\n')
 with (V/'tables'/f'{profile}_zone_write_inventory_iteration5.jsonl').open('w') as out:
  for r in writes:out.write(json.dumps(r)+'\n')
 print(profile,scanned,candidate_files,len(writes),len(parse_errors),flush=True)
