"""Refresh metadata/context after source-only model fix without rescanning2GB call table."""
import collections,json
import extract_registration_activation_iteration5 as m
regs=[json.loads(l) for l in (m.V/'tables/registration_activation_iteration5.jsonl').open()];hops=[json.loads(l) for l in (m.V/'tables/registration_activation_hops_iteration5.jsonl').open()];files={f['path']:f for f in m.rows('c_files.jsonl')};gem={g['gem_id']:g for g in m.rows('gems.jsonl')};pts=collections.defaultdict(set)
for r in regs:pts[r['registration_file']].add(r['registration_line'])
for h in hops:pts[h['source_evidence']['file']].add(h['line'])
ctx={}
for file,lines in pts.items():ctx.update({(file,line):v for line,v in m.contexts(file,lines,files[file]['language']).items()})
for r in regs:
 g=gem.get(r['gem_id'],{});r.update(inventory_gem_name=g.get('name'),inventory_gem_version=g.get('version'),inventory_gem_entry_primary_bundle=g.get('primary_bundle'),inventory_source_role=files[r['registration_file']].get('corpus_role'));r['registration_evidence']=ctx[r['registration_file'],r['registration_line']]
for h in hops:h['source_evidence']=ctx[h['source_evidence']['file'],h['line']]
m.out('registration_activation_iteration5.jsonl',regs);m.out('registration_activation_hops_iteration5.jsonl',hops)
p=m.V/'reports/registration_activation_iteration5.json';r=json.loads(p.read_text());r['corpus_scope']='All registrations in retained native inventory, including auxiliary/fixture entries; per-row primary_bundle and role identify original gem-entry membership, not complete primary dependency denominator.';p.write_text(json.dumps(r,indent=2)+'\n');print('refreshed',len(regs),len(hops))
