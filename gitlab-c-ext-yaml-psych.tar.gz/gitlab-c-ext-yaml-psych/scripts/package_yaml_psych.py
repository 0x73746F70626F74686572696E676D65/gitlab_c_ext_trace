#!/usr/bin/env python3
"""Small frozen YAML/Psych primary-partial and auxiliary-model companion; gated on additive review/union."""
import gzip,hashlib,io,json,shutil,tarfile
from pathlib import Path
from package_v3_publication import digest,verify_manifest
R=Path('/workspace/gitlab_c_ext_v3');D=R/'publication/yaml-psych'
def main():
 config=json.loads((D/'package_inputs.json').read_text())
 for name in config['required_reviews']:
  p=R/name;assert p.exists(),('pending review',name);assert json.loads(p.read_text())['status']=='PASS',name
 checks=[dict(manifest=n,verified_files=verify_manifest(R/n)) for n in config['freeze_manifests']]
 acquisition=json.loads((R/'reports/auxiliary_libyaml_acquisition.json').read_text())
 manifest=R/'tables/auxiliary_libyaml_source_manifest.jsonl'
 assert digest(manifest)==acquisition['source_manifest_sha256']
 source_rows=[json.loads(l) for l in manifest.open()]
 assert len(source_rows)==acquisition['files']==62
 for row in source_rows:assert digest(Path('/workspace/gitlab_c_ext_trace')/row['file'])==row['sha256']
 checks.append(dict(manifest='tables/auxiliary_libyaml_source_manifest.jsonl',verified_files=len(source_rows),role='auxiliary_source_identity_only_not_locked_runtime'))
 bridge=json.loads((R/'reports/psych_libyaml_auxiliary_bridge.json').read_text())
 assert digest(R/'tables/psych_libyaml_auxiliary_bridge.jsonl')==bridge['model_sha256']
 assert digest(R/'tables/psych_native_feasibility.jsonl')==bridge['parent_partial_unchanged_sha256']
 for n in config['required_files']:assert (R/n).exists(),('pending artifact',n)
 priors={str(p):digest(p) for p in [R/'publication'/n for n in ['gitlab-c-ext-v3.tar.gz','gitlab-c-ext-iteration3.tar.gz','gitlab-c-ext-census-and-flows.tar.gz','gitlab-c-ext-iteration5-6.tar.gz','gitlab-c-ext-json-request-flow.tar.gz']]}
 stage=D/'gitlab-c-ext-yaml-psych'
 if stage.exists():shutil.rmtree(stage)
 stage.mkdir();files=set(config['required_files'])|set(config['required_reviews'])|set(config['freeze_manifests'])|{'scripts/package_yaml_psych.py','scripts/package_v3_publication.py'}
 for n in sorted(files):
  p=R/n;dest=stage/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 (stage/'package_inputs.json').write_text(json.dumps(config,indent=2)+'\n');(stage/'INDEX.txt').write_text((D/'INDEX.txt').read_text())
 (stage/'prerequisites.json').write_text(json.dumps(dict(prior_archives=priors,source_root='/workspace/gitlab_c_ext_trace',analysis_root=str(R),runtime_verified=False),indent=2)+'\n')
 catalog=[dict(path=str(p.relative_to(stage)),bytes=p.stat().st_size,sha256=digest(p),rows=sum(1 for _ in p.open('rb')) if p.suffix=='.jsonl' else None) for p in sorted(stage.rglob('*')) if p.is_file()]
 (stage/'table_catalog.json').write_text(json.dumps(catalog,indent=2)+'\n');(stage/'package_validation.json').write_text(json.dumps(dict(status='PASS',freeze_checks=checks,files=len(catalog),bytes=sum(x['bytes'] for x in catalog),scope='Required independent review status, frozen source hashes and archive identity; no runtime feasibility proof'),indent=2)+'\n')
 (stage/'SHA256SUMS').write_text(''.join(f'{digest(p)}  {p.relative_to(stage)}\n' for p in sorted(stage.rglob('*')) if p.is_file()))
 arc=R/'publication/gitlab-c-ext-yaml-psych.tar.gz'
 with arc.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0,compresslevel=9) as gz,tarfile.open(fileobj=gz,mode='w') as t:
  for p in sorted(stage.rglob('*')):
   if p.is_file():
    info=tarfile.TarInfo('gitlab-c-ext-yaml-psych/'+str(p.relative_to(stage)));info.size=p.stat().st_size;info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(p.read_bytes()))
 with tarfile.open(arc,'r:gz') as t:actual={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers()}
 assert actual=={'gitlab-c-ext-yaml-psych/'+str(p.relative_to(stage)):digest(p) for p in stage.rglob('*') if p.is_file()}
 assert all(digest(Path(p))==h for p,h in priors.items())
 for row in catalog:
  if row['path'] in files:assert digest(R/row['path'])==row['sha256'],('source changed during packing',row['path'])
 result=dict(status='PASS',archive=str(arc),bytes=arc.stat().st_size,sha256=digest(arc),members=len(actual),prior_archives_preserved=True)
 (D/'archive_validation.json').write_text(json.dumps(result,indent=2)+'\n');(D/'SHA256SUMS').write_text(f"{result['sha256']}  {arc.name}\n");print(json.dumps(result))
if __name__=='__main__':main()
