#!/usr/bin/env python3
"""Independent source-evidence integrity checks; semantic judgments from manual review."""
import json,hashlib
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3'); B=Path('/workspace/gitlab_c_ext_trace')
errors=[]; checks=0; cache={}
def walk(x):
 global checks
 if isinstance(x,list):
  for v in x:walk(v)
 elif isinstance(x,dict):
  if x.get('file') and x.get('line') and 'excerpt' in x:
   p=B/x['file'];data=cache.setdefault(str(p),p.read_bytes()); lines=data.decode(errors='replace').split('\n')
   checks+=1
   if '\n'.join(lines[x['line']-1:x.get('end_line',x['line'])])!=x['excerpt']:errors.append({'file':str(p),'line':x['line'],'error':'excerpt'})
   sha=x.get('source_sha256',x.get('sha256'))
   if sha:
    checks+=1
    if hashlib.sha256(data).hexdigest()!=sha:errors.append({'file':str(p),'error':'sha256'})
  for v in x.values():walk(v)
spec={'tables/ci_lint_psych_source_recipe.jsonl':'78334ff742457edd7667506eb156f31c7a50aea02b968ee1ef7dc01d8bd2f4bb','tables/ci_lint_psych_primary_partial.jsonl':'8a2ff72f001804db25fc0e263cfbfb238e08bf79f51682d5e781ab0de6f37556','tables/ci_lint_psych_auxiliary_flow.jsonl':'3e881c8538376be67640e773ce478411792b939cce0f4c482a28ea2320afff0e','tables/psych_libyaml_auxiliary_bridge.jsonl':'5e080716831a15bdd9d24906de7d773cbf6cfec4465a280e8e7c9b7fc59718fe','tables/psych_native_feasibility.jsonl':'178a7a00f455e406ace7d301e91f3b5f797cb0a70d7fe0b9e83ad46ff601a15a'}
for rel,sha in spec.items():
 data=(V/rel).read_bytes();checks+=1
 if hashlib.sha256(data).hexdigest()!=sha:errors.append({'file':rel,'error':'frozen_input_hash'})
 walk([json.loads(l)for l in data.splitlines()])
report={'status':'PASS'if not errors else'FAIL','checks':checks,'errors':errors,'source_files_checked':len(cache),'frozen_inputs':spec,'independent_judgments':{
 'request_prefix':'Explicit POST /api/v4/projects/:id/ci/lint content String and dry_run false. Project permission/create_pipeline, outer API authentication/scopes, rate limit, normal repository/context/logger operations remain prerequisites. Not GET repository config and not anonymous feasibility.',
 'invocation':'Logger.instrument yields immediately on both normal branches; FeatureFlags.with_actor yields. Fresh StrongMemoize documents wrapper captures original method and bind_call on same receiver when cache absent. These are actual invocation contracts, not method-name or stored-block inference.',
 'transfer_and_guards':'YamlProcessor nonblank→Ci::Config→first load_uninterpolated_yaml→MultiDocYaml splits then maps Yaml.new. Selected job/script document has no separator/BOM and survives ordinary split/delete_prefix byte-equivalently, not pointer-identically. bytesize preparse guard applies; later maxdepth/Hash/CI-schema validation cannot block already selected native parse. Constructor/setup success explicit.',
 'psych':'Normal YAML=Psych alias, safe_load parses before restricted visitors. parse uses block branch of parse_stream, builds DocumentStream/Parser, calls parse(yaml,filename) with explicit nil. Therefore default path expression not evaluated; no filename file read. _native_parse gets handler, ordinary UTF8 String, nil; no IO read override. Earlier event callbacks must continue normally.',
 'auxiliary':'Independently reviewed libyaml0.2.5 callback/reader/scanner/token/event bridge transfers selected abc scalar3 to Psych rb_str_new. New source is auxiliary exact commit2c891fc7a770e8ba2fec34fc6b545c672beb37e6, not evidence of linked/deployed libyaml. Original primary model and new primary recipe remain unresolved at external dataflow frontier.',
 'counting':'One request case with overlapping primary partial and auxiliary continuation; no new primary complete flow or primary physical-site count. Scalar count3 not exact heap allocation, no arbitrary pointer/size or vulnerability conclusion.'},'primary_status':'partial_external_native_dataflow','auxiliary_status':'source_supported_conditional_auxiliary_external_library','runtime_verified':False,'primary_coverage_added':False}
(V/'reports/ci_lint_psych_independent_assembly_review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
