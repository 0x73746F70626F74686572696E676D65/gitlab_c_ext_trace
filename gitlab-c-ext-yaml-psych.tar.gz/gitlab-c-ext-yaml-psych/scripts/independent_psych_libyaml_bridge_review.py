#!/usr/bin/env python3
"""Independent source-evidence integrity checks; semantic judgments from manual review."""
import json,hashlib
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3'); B=Path('/workspace/gitlab_c_ext_trace')
errors=[]; checks=0; cache={}
def walk(x):
 global checks
 if isinstance(x,list):
  for v in x:walk(v)
 elif isinstance(x,dict):
  if x.get('file') and x.get('line') and 'excerpt' in x:
   p=B/x['file'];data=cache.setdefault(str(p),p.read_bytes()); lines=data.decode(errors='replace').split('\n')
   checks+=1
   if '\n'.join(lines[x['line']-1:x.get('end_line',x['line'])])!=x['excerpt']:errors.append({'file':str(p),'line':x['line'],'error':'excerpt'})
   sha=x.get('source_sha256',x.get('sha256'))
   if sha:
    checks+=1
    if hashlib.sha256(data).hexdigest()!=sha:errors.append({'file':str(p),'error':'sha256'})
  for v in x.values():walk(v)
spec={'tables/psych_libyaml_auxiliary_bridge.jsonl':'5e080716831a15bdd9d24906de7d773cbf6cfec4465a280e8e7c9b7fc59718fe','tables/psych_native_feasibility.jsonl':'178a7a00f455e406ace7d301e91f3b5f797cb0a70d7fe0b9e83ad46ff601a15a'}
for rel,sha in spec.items():
 data=(V/rel).read_bytes();checks+=1
 if hashlib.sha256(data).hexdigest()!=sha:errors.append({'file':rel,'error':'frozen_hash'})
 walk([json.loads(l)for l in data.splitlines()])
report={'status':'PASS'if not errors else'FAIL','checks':checks,'errors':errors,'source_files_checked':len(cache),'frozen_inputs':spec,'judgments':{
 'native_branch':'Ordinary UTF8 String without read override selects Psych transcode_string and yaml_parser_set_input_string. UTF8 returns source unchanged. io_reader memcpy is not on this path. RSTRING_PTR/LEN set external input span; no claim input remains original pre-split Ruby object.',
 'callback':'libyaml api.c296 installs yaml_string_read_handler and read_handler_data=parser. Reader calls callback with that data and free raw-buffer span. Callback caps memcpy count to remaining input and advances current; data is parser, not Ruby object.',
 'scalar_bytes':'UTF8 ASCII width1 preserves allowed bytes into separate reader buffer. Plain abc selects scan_plain_scalar READ/COPY three times. Under nested mapping indent2, scan indent3; final newline enters separate leading_break, next column0 is below indent and exits before folding. Token scalar length therefore3, no newline. SCALAR_EVENT_INIT transfers same scanner buffer/length, and Psych rb_str_new receives value and long3 before scalar handler/transcoding.',
 'constraints':'Normal successful parser allocation/progress and preceding handlers required. No generalized escapes/multiline/encoding claim. Size3 is scalar bytes, not heap allocation extent. External libyaml0.2.5 ABI/source equivalence is a named assumption, not established by Psych lock/deployment.'},'runtime_verified':False,'primary_partial_unchanged':True,'auxiliary_only':True,'scope':'Native bridge independently reviewed; request prefix/assembly reviewed separately. No baseline site additions or primary complete-flow promotion.'}
(V/'reports/independent_psych_libyaml_bridge_review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
