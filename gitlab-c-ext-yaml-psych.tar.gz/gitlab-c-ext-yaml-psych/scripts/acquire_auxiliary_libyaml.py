#!/usr/bin/env python3
"""Auxiliary official libyaml source model only; never a locked/deployed version claim."""
from pathlib import Path
import subprocess,datetime,json,hashlib,os
V=Path('/workspace/gitlab_c_ext_v3');D=Path('/workspace/gitlab_c_ext_trace/sources/external_models/libyaml-0.2.5');URL='https://github.com/yaml/libyaml.git';TAG='0.2.5'
r=dict(url=URL,tag=TAG,role='auxiliary_explicit_source_model',locked_dependency_version_proven=False,deployed_library_version_proven=False,primary_gem_coverage_changed=False,retrieval_started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),attempts=[])
def run(args,timeout=30):
 p=subprocess.run(args,capture_output=True,timeout=timeout);r['attempts'].append(dict(args=args,exit_code=p.returncode,stderr=p.stderr.decode('utf8','replace')[-1500:]));p.check_returncode();return p.stdout
try:
 remote=run(['git','ls-remote',URL,'refs/tags/'+TAG,'refs/tags/'+TAG+'^{}']).decode();r['remote_ref_evidence']=remote
 D.parent.mkdir(parents=True,exist_ok=True)
 if not (D/'.git').exists():run(['git','clone','--depth','1','--single-branch','--branch',TAG,'--config','core.autocrlf=false',URL,str(D)],60)
 commit=run(['git','-C',str(D),'rev-parse','HEAD']).decode().strip();tree=run(['git','-C',str(D),'rev-parse','HEAD^{tree}']).decode().strip();tagobj=run(['git','-C',str(D),'rev-parse','refs/tags/'+TAG]).decode().strip()
 assert commit in [x.split()[0] for x in remote.splitlines()]
 manifest=[];nonblobs=[]
 for e in run(['git','-C',str(D),'ls-tree','-rz','HEAD']).split(b'\0'):
  if not e:continue
  meta,name=e.split(b'\t',1);mode,kind,blob=meta.decode().split();file=os.fsdecode(name);p=D/file
  if kind!='blob':nonblobs.append(dict(file=file,kind=kind,git_object=blob));continue
  data=os.fsencode(os.readlink(p)) if mode=='120000' else p.read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert actual==blob,(file,actual,blob)
  manifest.append(dict(file=str(p.relative_to(Path('/workspace/gitlab_c_ext_trace'))),relative_path=file,mode=mode,git_blob=blob,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),source_role='auxiliary_libyaml_0.2.5_model_not_locked_runtime'))
 out=V/'tables/auxiliary_libyaml_source_manifest.jsonl';out.write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in manifest))
 r.update(status='acquired_full_tracked_tree',source_dir=str(D),tag_object=tagobj,commit=commit,tree=tree,files=len(manifest),tracked_bytes=sum(x['bytes'] for x in manifest),nonblob_entries=nonblobs,all_tracked_blob_hashes_verified=True,source_manifest_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),limitations=['Official tag association established; signature verification not performed.','No Ruby/Psych/libyaml build or execution.','Actual selected system/vendored libyaml version and linking remain unresolved; this auxiliary tree alone cannot establish unconditional end-to-end reachability.'])
except Exception as e:r.update(status='failed',error=repr(e))
finally:
 r['retrieval_completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(V/'reports/auxiliary_libyaml_acquisition.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='attempts'}))
