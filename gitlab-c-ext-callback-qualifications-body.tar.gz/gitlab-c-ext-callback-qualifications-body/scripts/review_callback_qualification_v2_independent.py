"""Static regression and unchanged-population check; no Ruby execution."""
import json,hashlib,sys
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');B=Path('/workspace/gitlab_c_ext_trace');sys.path.insert(0,str(V/'scripts'))
from qualify_callback_activation import replay as old
from qualify_callback_activation_v2 import replay as new

def rows(p):return [json.loads(x) for x in p.read_text().splitlines()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def event(id,api='before_action',**opts):return dict(event_id=id,kind='declaration',declaration=dict(callback_id=id,api=api,filters=['check'],declaration_conditions=[],option_expressions=opts,only=['edit'] if 'only' in opts else None,except_actions=['show'] if 'except' in opts else None))
cases=[]
for selector in ['only','except']:
 for predicate in ['if','unless']:
  events=[event('original'),event('skip','skip_before_action',**{selector:':edit' if selector=='only' else ':show',predicate:':flag?'})]
  a=old(events,'show')['eligible'];b=new(events,'show')['eligible'];assert a is True and b is None
  cases.append(dict(selector=selector,predicate=predicate,action='show',old_eligible=a,new_eligible=b,result='PASS_fail_closed_before_selector_shortcut'))
  assert new(events+[event('replacement')],'show')['eligible'] is True
  cases.append(dict(selector=selector,predicate=predicate,result='PASS_later_unconditional_registration_restores_bounded_state'))
changes=[];count=0;conditional=[]
for p in ['ce','ee']:
 ev={e['event_id']:e for e in rows(V/'tables'/f'{p}_callback_activation_events.jsonl')}
 for e in ev.values():
  c=e.get('declaration',{})
  if c.get('api')=='skip_before_action' and any(k in c.get('option_expressions',{}) for k in ['if','unless']):conditional.append(e['event_id'])
 for q in rows(V/'tables'/f'{p}_callback_activation_qualifications.jsonl'):
  count+=1
  if q['order_failure']:continue
  events=[ev[i] for i in q['ordered_event_ids']]
  if old(events,q['action'])!=new(events,q['action']):changes.append(q['qualification_id'])
assert count==3092 and not changes and not conditional
table_deltas=[]
for profile in ['ce','ee']:
 baseline=rows(V/'tables'/f'{profile}_callback_activation_qualifications.jsonl'); revised=rows(V/'tables'/f'{profile}_callback_activation_qualifications_v2.jsonl')
 assert len(baseline)==len(revised)
 for a,b in zip(baseline,revised):
  a.pop('framework_model_id');b.pop('framework_model_id')
  if a!=b:table_deltas.append(a['qualification_id'])
 assert (V/'tables'/f'{profile}_callback_activation_events.jsonl').read_bytes()==(V/'tables'/f'{profile}_callback_activation_events_v2.jsonl').read_bytes()
assert not table_deltas
source=[]
for file,start,end in [('sources/wrappers/rails-7.2.3.1/actionpack/lib/abstract_controller/callbacks.rb',93,105),('sources/wrappers/rails-7.2.3.1/activesupport/lib/active_support/callbacks.rb',257,267),('sources/wrappers/rails-7.2.3.1/activesupport/lib/active_support/callbacks.rb',787,811)]:
 p=B/file;source.append(dict(file=file,line=start,end_line=end,sha256=sha(p),excerpt='\n'.join(p.read_text().split('\n')[start-1:end])))
frozen=rows(V/'audit/callback_qualification_holdout/reviews.jsonl');assert len(frozen)==12
report=dict(status='PASS',scope='Independent static conservative replay correction; original12 judgments and frozen v1 outputs unchanged',script_sha256=sha(V/'scripts/qualify_callback_activation_v2.py'),source_evidence=source,source_rule='Controller only/except become if/unless entries; skip merge inverts each predicate into the original callback conditions. Unknown skip predicates must be withheld before ordinary registration-selector shortcuts. V2 intentionally returns unknown even when a previous blocker might be retained, which is conservative.',regressions=cases,population_rows=count,current_conditional_skip_events=conditional,current_row_replay_changes=changes,current_row_impact=0,table_deltas_excluding_versioned_framework_model_id=table_deltas,runtime_execution=False,activation_proven=False,original_audit_freeze_sha256=sha(V/'audit/callback_qualification_holdout/review_freeze.json'))
(V/'reports/callback_qualification_v2_independent_review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['source_evidence','regressions']}))
