import hashlib,json,pathlib,sys
from qualify_callback_activation import replay,V,B,rows
checks=0;errors=[];cache={}
def check(ok,msg):
 global checks
 checks+=1
 if not ok:errors.append(msg)
def evidence(e):
 if e['file'] not in cache:
  data=(B/e['file']).read_bytes();cache[e['file']]=(hashlib.sha256(data).hexdigest(),data.decode().splitlines())
 h,ls=cache[e['file']];check(h==e['sha256'],'source hash');check('\n'.join(ls[e['line']-1:e['end_line']])==e['excerpt'],'source excerpt')
for p in ['ce','ee']:
 inputs={r['edge_id']:r for scope in ['direct','inherited'] for r in rows(V/'tables'/f'{p}_{scope}_callback_invocation_edges.jsonl')}
 ev={r['event_id']:r for r in rows(V/'tables'/f'{p}_callback_activation_events.jsonl')}
 for e in ev.values():evidence(e['source_evidence'])
 quals=list(rows(V/'tables'/f'{p}_callback_activation_qualifications.jsonl'));check(len({r['qualification_id'] for r in quals})==len(quals),'unique ids');check({r['edge_id'] for r in quals}==set(inputs),'complete inputs')
 for q in quals:
  check(q['source_relation_preserved'] and not q['callback_activated_proven'] and q['new_native_paths']==0,'no promotion')
  for h in q['hierarchy_evidence']:evidence(h['source_evidence'])
  check(all(i in ev for i in q['ordered_event_ids']+q['blocking_event_ids']),'event FK')
  if not q['order_failure']:
   st=replay([ev[i] for i in q['ordered_event_ids']],q['action']);check(st['registration']==q['effective_registration_id'],'registration replay');check(st['blockers']==q['blocking_event_ids'],'blocker replay');check((st['eligible'] is False)==(q['activation_status']=='conditionally_blocked_for_action'),'status replay')
  check(inputs[q['edge_id']]['callback_id']==q['source_callback_id'],'source callback FK')
for r in rows(V/'tables/callback_activation_qualification_model.jsonl'):
 for e in r['source_evidence']:evidence(e)
r=dict(checks=checks,errors=errors,source_files=len(cache),status='pass' if not errors else 'fail');(V/'reports/callback_activation_qualification_validation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));sys.exit(bool(errors))
