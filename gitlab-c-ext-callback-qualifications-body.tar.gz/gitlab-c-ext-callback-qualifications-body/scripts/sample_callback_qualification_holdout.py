import json,random,hashlib
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3'); A=V/'audit/callback_qualification_holdout';A.mkdir(exist_ok=True)
def rows(p):return [json.loads(x) for x in p.read_text().splitlines()]
old={r['edge_id'] for n in ['direct_callbacks_holdout','inherited_callbacks_holdout'] for r in rows(V/'audit'/n/'sample.jsonl')}
rng=random.Random(202609301117); selected=[]; used=set()
for p in ['ce','ee']:
 pool=rows(V/'tables'/f'{p}_callback_activation_qualifications.jsonl')
 for stratum in ['blocked','superseded','unknown','unknown','not_blocked','not_blocked']:
  cand=[r for r in pool if r['edge_id'] not in old|{x['edge_id'] for x in selected} and (r['activation_status']=='conditionally_blocked_for_action' if stratum=='blocked' else r['declaration_relation_status']=='superseded_by_later_same_symbol_registration' if stratum=='superseded' else r['activation_status']=='unknown_activation' if stratum=='unknown' else r['activation_status']=='not_blocked_by_modeled_operations')]
  novel=[r for r in cand if r['receiver_owner'] not in used];cand=novel or cand
  r=dict(rng.choice(sorted(cand,key=lambda r:r['edge_id'])));r['audit_id']=f'CQ{len(selected)+1:03}';r['sampling_stratum']=stratum;selected.append(r);used.add(r['receiver_owner'])
(A/'sample.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in selected))
meta={'seed':202609301117,'design':'Purposeful rare-stratum sampling, 6/profile: blocked, superseded, two unknown, two not-blocked. Random choice within eligible stratum, preference unused receiver. Excludes prior48 audited edges. Not probability population precision estimate.','prior_edges_excluded':len(old),'sample_sha256':hashlib.sha256((A/'sample.jsonl').read_bytes()).hexdigest(),'input_freeze_sha256':hashlib.sha256((V/'reports/callback_activation_qualification_freeze.json').read_bytes()).hexdigest()}
(A/'selection_freeze.json').write_text(json.dumps(meta,indent=2)+'\n')
for r in selected:print(r['audit_id'],r['profile'],r['receiver_owner'],r['action'],r['symbol'],r['activation_status'],r['declaration_relation_status'])
