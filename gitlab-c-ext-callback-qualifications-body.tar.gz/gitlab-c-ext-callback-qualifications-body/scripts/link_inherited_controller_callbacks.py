"""Bounded superclass-registered before callback links; normalized additive evidence."""
import collections,hashlib,json,pathlib,re
from link_direct_controller_callbacks import Sources,declaration_eligibility,zero_argument_body_possible,uid,rows,V,B,MODEL

def resolve_target(chain,symbol,definitions,relations,check_method):
 path=[]
 for owner in chain:
  rs=relations.get(owner,[])
  if any(r['kind']=='prepend' for r in rs):return None,'preceding_owner_prepend_unresolved',path
  ms=definitions.get((owner,symbol,'instance'),[])
  if len(ms)>1:return None,'nearest_class_multiple_definitions',path
  if ms:
   reason=check_method(ms[0])
   return (None,reason,path) if reason else (ms[0],None,path)
  if any(r['kind']=='include' for r in rs):return None,'intervening_include_lookup_unresolved',path
  path.append(owner)
 return None,'instance_method_not_found_in_plain_class_chain',path

def superclass_step(relations,universe,check):
 rs=[r for r in relations if r['kind']=='superclass'];parents={t for r in rs for t in r['target_candidates'] if t in universe}
 if len(parents)!=1:return None,rs,'ambiguous_or_missing_superclass'
 if not all(check(r) for r in rs):return None,rs,'conditional_or_unparsed_superclass_declaration'
 return next(iter(parents)),rs,None

def superclass_source_unconditional(src,line):
 pending=[src.tree.root_node];found=[]
 while pending:
  n=pending.pop()
  if n.type=='class' and n.start_point.row+1==line and src.field(n,'superclass') is not None:found.append(n)
  pending.extend(n.named_children)
 okay=len(found)==1 and not found[0].has_error
 if okay:
  parent=found[0].parent
  while parent:
   if parent.type in ('if','unless','if_modifier','unless_modifier','case','when','block','do_block','method','singleton_method','lambda','while','until','for','rescue','ensure','conditional'):return False
   parent=parent.parent
 return okay

def main():
 sources=Sources();model=next(rows(MODEL));assert model['model_id'].endswith('_v2');modelref=dict(model_id=model['model_id'],path=str(MODEL.relative_to(V)),sha256=hashlib.sha256(MODEL.read_bytes()).hexdigest());reports={};inputs={}
 for profile,G,prefix in [('ce',pathlib.Path('/workspace/gitlab_c_ext_ruby_expanded'),'sources/gitlab/'),('ee',pathlib.Path('/workspace/gitlab_c_ext_ee_profile'),'sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/')]:
  P=V/'profiles'/profile/'tables';decl={r['callback_id']:r for r in rows(P/'controller_callback_declarations.jsonl')};routes={r['scope_occurrence_id']:r for r in rows(P/'route_scope_bindings.jsonl')};methods={r['method_id']:r for r in rows(G/'tables/ruby_methods.jsonl') if (r['file'].startswith(prefix) or r['file'].startswith('sources/wrappers/rails-7.2.3.1/')) and not re.search(r'/(spec|test|qa|fixtures)/',r['file'])};universe={m['namespace'] for m in methods.values()};defs=collections.defaultdict(list)
  for m in methods.values():defs[(m['namespace'],m['method'],m['kind'])].append(m)
  rels=[r for r in rows(G/'tables/ruby_inheritance.jsonl') if (r['file'].startswith(prefix) or r['file'].startswith('sources/wrappers/rails-7.2.3.1/')) and not re.search(r'/(spec|test|qa|fixtures)/',r['file'])];byowner=collections.defaultdict(list)
  for r in rels:byowner[r['owner']].append(r)
  proof={};chains={};methodcheck={};targetcache={};literalcache={};evs={}
  def evidence(file,line,end):
   key=uid(file,line,end)
   if key not in evs:evs[key]=dict(evidence_id=key,**sources.evidence(file,line,end))
   return key
  def unconditional_superclass(r):
   rid=r['inheritance_id']
   if rid in proof:return proof[rid]
   okay=superclass_source_unconditional(sources.get(r['file']),r['line']);proof[rid]=okay;return okay
  def chain_for(owner):
   if owner in chains:return chains[owner]
   chain=[];rsout=[];seen=set();cur=owner;reason=None
   while cur not in seen:
    chain.append(cur)
    if cur=='ActionController::Base':break
    seen.add(cur);parent,rs,reason=superclass_step(byowner[cur],universe,unconditional_superclass)
    if reason:break
    rsout.extend(rs);cur=parent
   else:reason='superclass_cycle'
   if not reason and chain[-1]!='ActionController::Base':reason='framework_base_not_reached'
   chains[owner]=(chain,rsout,reason);return chains[owner]
  def check_method(m):
   if m['method_id'] not in methodcheck:
    s,n=sources.node(m);reason=None
    if n is None or n.has_error or s.method_context[n.start_byte][2]:reason='nearest_definition_conditional_or_unparsed'
    elif not zero_argument_body_possible(s,n):reason='callback_method_requires_arguments'
    if n is not None and not reason:
     parent=n.parent
     while parent:
      if parent.type in ('for','rescue','ensure','conditional'):reason='nearest_definition_conditional_or_unparsed';break
      parent=parent.parent
    methodcheck[m['method_id']]=reason
   return methodcheck[m['method_id']]
  edges=[];holes=[];counts=collections.Counter();candidate_count=0
  for d in rows(P/'controller_callback_demands.jsonl'):
   c=decl[d['callback_id']]
   if c['owner']==d['controller_owner'] or c['api'] not in ('before_action','append_before_action','prepend_before_action'):continue
   candidate_count+=1;reason=declaration_eligibility(c,d['action']);selected_routes=[routes[x] for x in d['route_scope_occurrence_ids'] if x in routes and any(mid in methods for mid in routes[x].get('method_ids',[]))]
   if not reason and not selected_routes:reason='no_source_bound_route_action_method'
   if c['callback_id'] not in literalcache:literalcache[c['callback_id']]=sources.literal_symbols(c)
   if not reason and not literalcache[c['callback_id']]:reason='filter_not_exact_literal_symbol'
   chain,inheritance,chain_reason=chain_for(d['controller_owner'])
   if not reason and chain_reason:reason=chain_reason
   if not reason and c['owner'] not in chain[1:]:reason='registration_not_on_verified_superclass_chain'
   if reason:
    counts[reason]+=1;holes.append(dict(unresolved_id='cbinhhole_'+uid(profile,d['callback_demand_id'],reason),profile=profile,callback_demand_id=d['callback_demand_id'],callback_id=c['callback_id'],reason=reason));continue
   for symbol in c['filters']:
    key=(d['controller_owner'],symbol)
    if key not in targetcache:targetcache[key]=resolve_target(chain,symbol,defs,byowner,check_method)
    m,reason,preceding=targetcache[key]
    if reason:
     counts[reason]+=1;holes.append(dict(unresolved_id='cbinhhole_'+uid(profile,d['callback_demand_id'],symbol,reason),profile=profile,callback_demand_id=d['callback_demand_id'],callback_id=c['callback_id'],symbol=symbol,reason=reason,lookup_classes_before_blocker=preceding));continue
    conditions=['effective_inherited_callback_registration_duplicate_skip_order_unknown','predicates_route_and_registration_conditions_unresolved','earlier_callback_or_around_wrapper_halt_exception_unknown','framework_process_action_compilation_terminator_contract_required','ordinary_constant_and_method_lookup_without_dynamic_rebinding_required']
    if d['skip_candidate_ids']:conditions.append('matching_skip_may_remove_or_condition_callback')
    if c['declaration_conditions']:conditions.append('conditional_registration_or_concern_activation')
    if any(k in c['option_expressions'] for k in ('if','unless')):conditions.append('if_unless_predicates_not_evaluated')
    # Includes/prepends after selected own class method cannot override it; effective callback chain still unresolved.
    eid='cbinh_'+uid(profile,d['callback_demand_id'],m['method_id'])
    edge=dict(edge_id=eid,profile=profile,status='partial_inherited_callback_invocation_candidate',edge_type='conditional_framework_before_callback_invocation',callback_demand_id=d['callback_demand_id'],callback_id=c['callback_id'],registration_owner=c['owner'],receiver_owner=d['controller_owner'],action=d['action'],symbol=symbol,target_method_id=m['method_id'],target_owner=m['namespace'],target_method_kind='instance',target_resolution='nearest_unique_unconditional_class_definition_before_unresolved_mixins',class_chain=chain,lookup_preceding_classes=preceding,framework_ancestry_ids=[r['inheritance_id'] for r in inheritance],framework_model=modelref,route_scope_occurrence_ids=[r['scope_occurrence_id'] for r in selected_routes],action_method_ids=sorted({x for r in selected_routes for x in r['method_ids'] if x in methods}),selectors=dict(only=c['only'],except_actions=c['except_actions'],options=c['option_expressions']),skip_candidate_ids=d['skip_candidate_ids'],registration_conditions=c['declaration_conditions'],route_condition_references=[r['scope_occurrence_id'] for r in selected_routes if r['conditions'] or r['scope_trace']],unresolved_constraints=conditions,source_evidence_ids=[evidence(c['file'],c['line'],c['end_line']),evidence(m['file'],m['line'],m['end_line'])]+[evidence(r['file'],r['line'],r['line']) for r in inheritance]+[evidence(r['file'],r['line'],r['end_line']) for r in selected_routes],may_seed_complete_path=False,callback_activated_proven=False,runtime_exposure_proven=False,new_native_paths=0,continuation_to_action='not_implied')
    edges.append(edge)
  for stem,rs in [('inherited_callback_invocation_edges',edges),('inherited_callback_invocation_unresolved',holes),('inherited_callback_invocation_evidence',list(evs.values()))]:
   with (V/'tables'/f'{profile}_{stem}.jsonl').open('w') as f:
    for r in rs:f.write(json.dumps(r)+'\n')
  reports[profile]=dict(input_inherited_before_demands=candidate_count,additive_partial_edges=len(edges),unique_registrations=len({e['callback_id'] for e in edges}),unique_target_methods=len({e['target_method_id'] for e in edges}),receiver_controllers=len({e['receiver_owner'] for e in edges}),route_action_pairs=len({(e['receiver_owner'],e['action']) for e in edges}),subclass_override_edges=sum(e['target_owner']!=e['registration_owner'] and chain_for(e['receiver_owner'])[0].index(e['target_owner'])<chain_for(e['receiver_owner'])[0].index(e['registration_owner']) for e in edges),unresolved_rows=len(holes),unresolved_reasons=dict(counts),normalized_evidence_rows=len(evs),new_complete_paths=0,new_native_paths=0)
  for name in ('route_scope_bindings.jsonl','controller_callback_declarations.jsonl','controller_callback_demands.jsonl'):inputs[str((P/name).relative_to(V))]=hashlib.sha256((P/name).read_bytes()).hexdigest()
 report=dict(status='bounded_inherited_superclass_callback_extension',profiles=reports,framework_model=modelref,input_references=inputs,scope='Existing inherited before-action demands only; nearest class target before any unresolved include/prepend; every edge remains partial and adds no native paths.',frozen_direct_outputs_mutated=False)
 (V/'reports/inherited_callback_invocation_coverage.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
