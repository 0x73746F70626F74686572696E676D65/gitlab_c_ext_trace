"""Conservative Ruby method-precedence decisions, with explicit assumptions."""
from collections import defaultdict

class Lookup:
    def __init__(self, inheritance, definitions, universe):
        self.relations = defaultdict(list)
        self.definitions = defaultdict(list)
        self.universe = set(universe)
        for row in inheritance:
            known = [x for x in row['target_candidates'] if x in self.universe]
            entry = dict(row, resolved_targets=known)
            self.relations[row['owner']].append(entry)
        for definition in definitions:
            self.definitions[(definition['owner'], definition['method'], definition['kind'])].append(definition)

    def normal_ancestors(self, owner, kind):
        found, pending, uncertainty = {}, [(owner, [])], []
        while pending:
            current, evidence = pending.pop()
            current_relations = self.relations.get(current, [])
            parents = {t for r in current_relations if r['kind'] == 'superclass' for t in r['resolved_targets']}
            for rel in current_relations:
                if rel['kind'] == 'superclass' and len(parents) > 1:
                    uncertainty.append(rel['inheritance_id'])
                    continue
                if rel['kind'] not in ('superclass', 'include'):
                    continue
                if kind == 'singleton' and rel['kind'] != 'superclass':
                    continue
                if len(rel['resolved_targets']) != 1 or not rel.get('unconditional', False):
                    uncertainty.append(rel['inheritance_id'])
                    continue
                target = rel['resolved_targets'][0]
                if target == owner or target in found:
                    continue
                route = evidence + [rel['inheritance_id']]
                found[target] = route
                pending.append((target, route))
        return found, uncertainty

    def decide(self, receiver, method, kind, targets):
        """Targets are owner/kind/id rows; decisions never manufacture edges."""
        result = []
        defs = [d for d in self.definitions.get((receiver, method, kind), [])
                if d.get('unconditional')]
        ancestors, uncertainty = self.normal_ancestors(receiver, kind)
        # Prepend can override the owner's method. Preserve that ambiguity, but an
        # ordinary ancestor remains shadowed whenever the owner's method exists.
        prepends = [r['inheritance_id'] for r in self.relations.get(receiver, [])
                    if r['kind'] == 'prepend' and kind == 'instance']
        prepend_owners, pending = set(), []
        if kind == 'instance':
            pending = [t for r in self.relations.get(receiver, []) if r['kind'] == 'prepend' for t in r['resolved_targets']]
        while pending:
            owner = pending.pop()
            if owner in prepend_owners:
                continue
            prepend_owners.add(owner)
            pending.extend(t for r in self.relations.get(owner, []) for t in r['resolved_targets'])
        for target in targets:
            decision = dict(target, decision='retain_conditional', reason='No proven dominance relation')
            if target['kind'] == kind and target['owner'] in ancestors and target['owner'] not in prepend_owners and defs:
                decision.update(decision='shadowed', reason='Unconditional owner method precedes ordinary ancestors',
                    dominating_definition_ids=[d['id'] for d in defs],
                    inheritance_path=ancestors[target['owner']],
                    conditions=['owner source loaded', 'ordinary Ruby method lookup',
                                'no later remove_method/undef_method or reflective rebinding'])
            elif target['owner'] == receiver and prepends:
                decision.update(decision='unresolved_prepend_order',
                                reason='Prepended modules may precede owner; ordering/activation not established',
                                inheritance_ids=prepends)
            elif target['owner'] == receiver:
                decision.update(reason='Direct owner method retained; ordinary ancestors cannot override it')
            elif uncertainty:
                decision.update(decision='unresolved_inheritance',
                                reason='Ambiguous/conditional ancestry cannot establish shadowing',
                                inheritance_ids=uncertainty)
            result.append(decision)
        return result

    def resolve_superclass_super(self, defining_owner, method, kind):
        """Resolve only a plain, unambiguous superclass continuation of super."""
        current, seen, evidence = defining_owner, set(), []
        while current not in seen:
            seen.add(current)
            rels = self.relations.get(current, [])
            if kind == 'instance' and any(r['kind'] in ('include', 'prepend') for r in rels):
                return dict(status='unresolved', reason='Mixin order or defining-module position needed', targets=[])
            parents = [r for r in rels if r['kind'] == 'superclass']
            targets = {t for r in parents for t in r['resolved_targets']}
            if len(targets) != 1 or any(not r.get('unconditional') or len(r['resolved_targets']) != 1 for r in parents):
                return dict(status='unresolved', reason='Superclass absent, conditional, or ambiguous', targets=[])
            current = next(iter(targets))
            evidence.extend(r['inheritance_id'] for r in parents)
            defs = self.definitions.get((current, method, kind), [])
            if defs:
                if any(not d.get('unconditional') for d in defs):
                    return dict(status='unresolved', reason='Conditional definition may fall through', targets=[])
                if kind == 'instance' and any(r['kind'] == 'prepend' for r in self.relations.get(current, [])):
                    return dict(status='unresolved', reason='Parent prepended module can precede its own method', targets=[])
                return dict(status='conditional_superclass_target', targets=[d['id'] for d in defs],
                            inheritance_path=evidence,
                            conditions=['defining owner is actual receiver ancestor', 'ordinary source-loaded Ruby lookup'])
        return dict(status='unresolved', reason='Superclass cycle', targets=[])
