#!/usr/bin/env python3
"""Additive source-backed IO-state contract, not a Ruby execution or whole-program analyzer."""
import json,hashlib,pathlib,datetime
R=pathlib.Path('/workspace/gitlab_c_ext_v3'); T=pathlib.Path('/workspace/gitlab_c_ext_trace')
G='sources/expansion/grape-2.4.0--ruby-grape/lib/grape/'
K='sources/expansion/rack-2.2.23--rack/lib/rack/'
# Resolve retained exact-version root, never fall back to a different version.
ks=list((T/'sources/expansion').glob('rack-2.2.23*/lib/rack'))
assert len(ks)==1
K=str(ks[0].relative_to(T))+'/'
S='sources/gems/stringio-3.2.0/ext/stringio/stringio.c'
P='sources/gems/puma-8.0.2/lib/puma/'
A='sources/gitlab/lib/api/'
def ev(file,lo,hi,claim,needle):
 p=T/file; b=p.read_bytes(); lines=b.decode().splitlines(); excerpt='\n'.join(lines[lo-1:hi]); assert needle in excerpt,(file,lo,needle)
 return dict(file=file,line=lo,end_line=hi,sha256=hashlib.sha256(b).hexdigest(),claim=claim,excerpt=excerpt)
evidence=[
 ev(G+'middleware/formatter.rb',10,13,'Formatter before negotiates type then reads body','read_body_input'),
 ev(G+'middleware/formatter.rb',65,77,'Input read is outside begin/ensure; parser work is inside ensure-protected second rewind','input.try(:rewind)'),
 ev(G+'middleware/formatter.rb',79,105,'Parser may consume String before endpoint; Hash cached against same rack.input','RACK_REQUEST_FORM_INPUT'),
 ev(G+'middleware/formatter.rb',114,120,'Only selected HTTP methods/nonform/nonmultipart and positive length or chunked enter body read','content_length.to_i.positive?'),
 ev(G+'middleware/base.rb',22,28,'Formatter before completes before downstream endpoint call','@app.call(@env)'),
 ev(G+'middleware/base.rb',49,51,'Formatter creates Rack request on shared env','Rack::Request.new(env)'),
 ev(G+'endpoint.rb',354,395,'Explicit middleware stack places formatter around endpoint run','builder.run'),
 ev(G+'middleware/stack.rb',86,94,'Stack builds ordered middleware declarations into Rack builder','middlewares.each'),
 ev(K+'builder.rb',231,237,'Rack wraps reversed use list around terminal app','@use.reverse.inject'),
 ev(G+'endpoint.rb',249,268,'Endpoint request constructed on same env; callbacks and validation precede execute','Grape::Request.new(env'),
 ev(G+'endpoint.rb',286,288,'Endpoint execute explicitly invokes endpoint block','@block&.call(self)'),
 ev(G+'request.rb',1,5,'Grape request inherits Rack request','class Request < Rack::Request'),
 ev(K+'request.rb',150,150,'body accessor returns rack.input from env','get_header(RACK_INPUT)'),
 ev(K+'request.rb',440,470,'Cached parsed Hash avoids IO read for same input; JSON content is not form/multipart branch','RACK_REQUEST_FORM_INPUT'),
 ev(G+'parser.rb',8,14,'Parser registry/custom override selection','registry[format]'),
 ev(G+'parser/json.rb',4,10,'Default JSON parser consumes String via Grape::Json.load before endpoint','::Grape::Json.load'),
 ev(G+'json.rb',3,9,'Grape JSON backend depends on loaded MultiJson, not fixed backend here','defined?(::MultiJson)'),
 ev(S,335,374,'StringIO constructor single-string case stores String and encoding, position zero','ptr->enc = rb_enc_get(string)'),
 ev(S,137,155,'StringIO substring clamps byte length and uses rb_str_subseq; no storage-identity guarantee','strio_substr'),
 ev(S,874,881,'StringIO rewind resets byte position and line number','ptr->pos = 0'),
 ev(S,1657,1730,'No-length read returns remaining bytes with get_enc encoding then advances position','ptr->pos += RSTRING_LEN(str)'),
 ev(S,2037,2037,'Exact rewind native registration','"rewind", strio_rewind'),
 ev(S,2055,2055,'Exact read native registration','"read", strio_read'),
 ev(P+'client.rb',482,504,'One retained concrete server branch builds StringIO over exactly completed request body','@body = StringIO.new parser_body'),
 ev(P+'client_env.rb',94,98,'Puma env obtains chosen body object','@env[RACK_INPUT] = @body || EmptyBody'),
 ev(A+'api.rb',65,70,'API v4 path scope','version \'v4\''),
 ev(A+'api.rb',219,225,'JSON format and formatter; formatter is not parser registration','formatter :json, Gitlab::Json::GrapeFormatter'),
 ev(A+'api.rb',281,281,'Project Conan class mount','mount ::API::Conan::V1::ProjectPackages'),
 ev('sources/gitlab/config/routes/api.rb',9,9,'Rails API mount','mount ::API::API'),
 ev(A+'conan/v1/project_packages.rb',7,19,'Project scope and endpoint concern inclusion','include ::API::Concerns::Packages::Conan::V1Endpoints'),
 ev(A+'concerns/packages/conan/v1_endpoints.rb',15,18,'V1 concern composes shared endpoints','include SharedEndpoints'),
 ev(A+'concerns/packages/conan/shared_endpoints.rb',34,51,'Helpers, non-GET authentication, FIPS and packages guards','authenticate_non_get!'),
 ev(A+'concerns/packages/conan/v1_endpoints.rb',43,58,'Route parameter validation and after-validation username/channel gate','check_username_channel'),
 ev(A+'concerns/packages/conan/v1_endpoints.rb',276,286,'Upload metadata plus explicit read-package authorization precede helper','present recipe_upload_urls'),
 ev(A+'helpers/packages/conan/api_helpers.rb',49,53,'file_names evaluated before select/URL generation','file_names.select'),
 ev(A+'helpers/packages/conan/api_helpers.rb',197,208,'Selected request IO result passed to safe_parse before keys; exceptions can abort later work','safe_parse(request.body.read)'),
 ev(A+'helpers.rb',393,399,'Non-GET guard requires actual current_user','authenticate! unless'),
 ev(A+'helpers/packages_manager_clients_helpers.rb',4,8,'Package manager helper includes package auth helper','include ::API::Helpers::PackagesHelpers'),
 ev(A+'helpers/packages_helpers.rb',11,25,'Package feature and actual read-package authorization','authorize!(:read_package'),
 ev(A+'helpers/packages/conan/api_helpers.rb',10,23,'Username/channel validation before endpoint','validate_username_and_channel'),
 ev('sources/gitlab/gems/gitlab-utils/lib/gitlab/json.rb',66,74,'safe_parse validates String before parsing','validate!(string, parse_limits)'),
]
# Static abstract transfer rules: events represent source-proven operations. These are NOT execution traces.
def transfer(events, *, source_resolved=True, initial_pos=None, encoding='ASCII-8BIT'):
 pos=initial_pos; intact=True; same=True; alive=True; result='not_reached'; history=[]
 if not source_resolved:return {'result':'unresolved_receiver','history':[]}
 for event in events:
  if not alive: break
  if event=='rewind_ok':pos=0
  elif event=='read_all_ok':pos='end'
  elif event in ('read_failure','rewind_failure','parser_rejects','guard_rejects'):alive=False
  elif event=='unknown_read':pos=None
  elif event in ('unknown_escape','mutate_bytes'):intact=False;pos=None
  elif event=='replace_stream':same=False;pos=None
  elif event in ('parser_accepts','cached_params','guard_accepts'):pass
  elif event=='endpoint_read':
   result='complete_original_byte_interval' if same and intact and pos==0 else 'empty_at_eof' if same and intact and pos=='end' else 'unresolved_byte_interval'
   pos='end'
  else:raise ValueError(event)
  history.append({'event':event,'position_after':pos,'bytes_unchanged':intact,'same_stream':same,'continues':alive})
 return {'result':result,'output_encoding':encoding if result=='complete_original_byte_interval' else None,'history':history}
fixtures=[
 ('normal', ['rewind_ok','read_all_ok','parser_accepts','rewind_ok','cached_params','endpoint_read'],'complete_original_byte_interval',{}),
 ('prior_eof_restored',['rewind_ok','read_all_ok','rewind_ok','endpoint_read'],'complete_original_byte_interval',{'initial_pos':'end'}),
 ('no_final_rewind',['rewind_ok','read_all_ok','endpoint_read'],'empty_at_eof',{}),
 ('read_failure_outside_ensure',['rewind_ok','read_failure','rewind_ok','endpoint_read'],'not_reached',{}),
 ('first_rewind_failure',['rewind_failure','read_all_ok','endpoint_read'],'not_reached',{}),
 ('final_rewind_failure',['rewind_ok','read_all_ok','rewind_failure','endpoint_read'],'not_reached',{}),
 ('parser_rejects_endpoint_unreachable',['rewind_ok','read_all_ok','rewind_ok','parser_rejects','endpoint_read'],'not_reached',{}),
 ('unknown_intervening_reader',['rewind_ok','unknown_read','endpoint_read'],'unresolved_byte_interval',{}),
 ('reader_then_known_rewind',['rewind_ok','unknown_read','rewind_ok','endpoint_read'],'complete_original_byte_interval',{}),
 ('escape_then_rewind_not_healed',['rewind_ok','unknown_escape','rewind_ok','endpoint_read'],'unresolved_byte_interval',{}),
 ('replacement_then_rewind_not_healed',['replace_stream','rewind_ok','endpoint_read'],'unresolved_byte_interval',{}),
 ('guard_failure',['rewind_ok','guard_rejects','endpoint_read'],'not_reached',{}),
 ('utf8_preserved',['rewind_ok','endpoint_read'],'complete_original_byte_interval',{'encoding':'UTF-8'}),
 ('unknown_receiver_no_methodname_proof',['rewind_ok','endpoint_read'],'unresolved_receiver',{'source_resolved':False}),
]
results=[]
for name,events,expect,opts in fixtures:
 actual=transfer(events,**opts);assert actual['result']==expect,(name,actual)
 results.append({'fixture':name,'events':events,'preconditions':opts,'expected':expect,'actual':actual,'pass':True})
model={'model_id':'rack_grape_rewind_read_v1','status':'source_supported_conditional_transfer_not_execution','versions':{'grape':'2.4.0','rack':'2.2.23','stringio':'3.2.0','puma_example':'8.0.2'},'scope':'Selected exact-source standard StringIO receiver; formatter qualifying nonempty application/json POST and successful no-length reads/rewinds; not generic IO duck typing.','preconditions':['Same unmodified rack.input object and underlying String remains readable throughout selected interval.','Exact retained receiver methods, no subclass/singleton overrides or runtime monkeypatch.','Formatter method/content/length predicate true; content negotiation and parser return successfully.','Both explicit rewinds and read succeed; preceding external middleware and later callbacks neither replace/mutate nor consume stream after final rewind (or are individually modeled restoring position).'],'order':['Outer/custom middleware and versioner admission','Formatter.before: negotiate; first rewind; read all','read_rack_input: backend parse and optional cached params','ensure final rewind (only protects parser block, not preceding input.read)','Endpoint.run: before filters, before-validation, validators, after-validation','Endpoint execute; request.body.read returns remaining bytes'], 'invariants':{'normal_return':'position zero at formatter exit; subsequent no-length read returns full original byte interval when intervening effects satisfy preconditions','encoding':'StringIO no-length read uses stored get_enc, not automatically BINARY. Restrict selected bytes to ASCII and output encoding to UTF-8 or ASCII-8BIT before borrowing reviewed Oj conversion contract.','identity':'Content/length interval only; returned String object and storage identity are not asserted.','earlier_parse':'Formatter may already parse JSON before endpoint/auth. No earliest-native-parse assertion.','bound':'safe_parse bound is checked after formatter and endpoint read allocations; not a bound on server buffering or earlier parser work.'},'limitations':['Abstract fixtures verify transfer-rule safety, not target Ruby execution, complete callback closure or server deployment.','Tempfile, arbitrary IO, chunked reconstruction, multipart/form data and runtime parser overrides outside selected model.'],'evidence':evidence}
case={'case_id':'conan_recipe_upload_ce_body_read_v1','profile':'ce','status':'partial_missing_intervening_body_effect_closure','candidate_id':'surface_ce_conan_recipe_upload','route':'POST /api/v4/projects/:id/packages/conan/v1/conans/:package_name/:package_version/:package_username/:package_channel/upload_urls','model_id':model['model_id'],'request_selection':{'body_example_ascii':'{"conanfile.py":1}','content_type':'application/json','method':'POST','content_length':'positive exact byte length','query':'No conflicting project/package path parameters or format override','stream':'Selected nonchunked completed-body Puma StringIO branch is retained-source evidence, not proof of deployed server path'},'actual_argument':'Gitlab::Json.safe_parse(request.body.read) at ApiHelpers#file_names line198; value then .keys; select and upload URLs happen later','guards':['Global API before/before-validation filters and all earlier middleware admit request.','FIPS disabled; package registry enabled; authenticate_non_get! resolves valid current_user.','Project and route parameters resolve and satisfy declared types/regex; check_username_channel passes.','Job-token/basic-token authentication and upload_conan_package authorization metadata must admit selected principal.','Actual endpoint authorize_read_package!(project) passes separately; upload metadata does not substitute it.','Formatter negotiation and dynamically selected JSON parser succeed.','Selected String and ASCII key satisfy safe_parse validator bounds and reviewed Oj key contract if IO closure established.'],'supported':['Mount/concern/helper and endpoint source chain established with exact excerpts.','Formatter normal-return restoration and selected concrete StringIO byte-interval transfer source-supported.','Rack params cache for same input prevents second form parse in selected formatter-Hash case.'],'unresolved':['Full transitive body side effects of global/authentication/organization/validation helpers between formatter rewind and endpoint read not closed.','Actual deployed rack.input representation, dynamic middleware/parser replacements, monkeypatches and runtime source match not proven.'],'native_terminal_site_id':None,'native_influence_claim':None,'reusable_native_contract_if_gaps_closed':{'table':'tables/ruby_runtime_contracts_iteration3.jsonl','target_site_candidate_only':'site_02ee522b09c10c1f06305d45','status':'not_promoted_or_counted','semantics':'ASCII JSON key content and derived key length; borrowed only after independent whole-chain assembly review'},'evidence_refs':[{'file':e['file'],'line':e['line'],'sha256':e['sha256']} for e in evidence], 'counting':'No new conditional request-memory flow, native mechanism or site; feasibility partial only.'}
for name,row in [('rack_grape_body_transfer_contract',model),('conan_recipe_upload_feasibility',case)]:
 (R/'tables'/f'{name}.jsonl').write_text(json.dumps(row,sort_keys=True)+'\n')
report={'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':'Source excerpts/asserted tokens validated; hashes recorded; Python abstract-transfer fixtures only','source_files':len({x['file'] for x in evidence}),'source_excerpts':len(evidence),'fixtures_passed':len(results),'fixtures':results,'case_status':case['status'],'native_promotion':False,'source_evidence_table':'tables/rack_grape_body_transfer_contract.jsonl'}
(R/'reports/rack_grape_body_transfer_validation.json').write_text(json.dumps(report,indent=2)+'\n')
schema={'contract_pk':'model_id','case_pk':'case_id','case_model_fk':'model_id -> rack_grape_body_transfer_contract.model_id','evidence':'file relative to trace root; 1-based inclusive line/end_line and full-file SHA256; case refs join file,line,sha256','status':'Source-supported model is conditional transfer only; case remains partial with null terminal and no native influence claim','fixtures':'Static abstract-state safety regressions; not executable source tests'}
(R/'reports/rack_grape_body_transfer_schema.json').write_text(json.dumps(schema,indent=2)+'\n')
paths=['scripts/build_rack_grape_body_transfer.py','tables/rack_grape_body_transfer_contract.jsonl','tables/conan_recipe_upload_feasibility.jsonl','reports/rack_grape_body_transfer_validation.json','reports/rack_grape_body_transfer_schema.json']
(R/'reports/rack_grape_body_transfer_freeze.json').write_text(json.dumps({'files':{p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in paths},'immutable_inputs':'No prior frozen tables or recipes mutated','case_status':case['status']},indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['source_files','source_excerpts','fixtures_passed','case_status','native_promotion']}))
if __name__=='__main__': pass
