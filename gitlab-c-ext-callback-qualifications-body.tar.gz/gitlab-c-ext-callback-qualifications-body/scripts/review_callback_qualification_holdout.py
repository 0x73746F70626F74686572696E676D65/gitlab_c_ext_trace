"""Additive independent source review; does not regenerate qualification tables."""
import json,hashlib,collections,sys
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');B=Path('/workspace/gitlab_c_ext_trace');A=V/'audit/callback_qualification_holdout'
def rows(p):return [json.loads(x) for x in p.read_text().splitlines()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=0;errors=[];files={}
def evidence(e):
 global checks
 p=B/e['file'];raw=p.read_bytes();files[str(p)]=sha(p); lines=raw.decode().split('\n');actual='\n'.join(lines[e['line']-1:e['end_line']]);checks+=2
 if sha(p)!=e['sha256'] or actual!=e['excerpt']:errors.append({'source':e['file'],'line':e['line']})
notes=[
'Ancestor unconditional registration is replaced by Admin::Users only: impersonate at line9; unban cannot pass that selector. Earlier includes do not undo later literal replacement under stated initialization assumptions.',
'Drafts line10 same-symbol registration replaces line9 even on update. Its explicit lambda requires action_name == publish, so ordinary update gives false. Overlay conservatively leaves arbitrary predicates unknown; this is an additional source-local blocker opportunity, not a false activation claim.',
'ApplicationController line50 retains html_request? predicate; no truth assignment for this destroy request is justified.',
'ApplicationController line54 retains devise_controller? predicate; source relation alone does not establish its value for the selected request.',
'ApplicationController line63 registers auth_user without selector after earlier includes. Help#show has no modeled same-symbol exclusion; admission, body effects and earlier callback halting remain unknown.',
'Projects::MergeRequests line24 literal only list expressly includes codequality_reports. Later other-symbol and Proc filters do not duplicate this Symbol; no modeled blocker means neither execution nor successful authorization.',
'Groups ancestor line13 registers group; Sso line7 skips, then line22 re-registers only saml. Final replacement excludes unlink; latest registration rather than earlier skip is decisive.',
'Trials line9 prepend exact authenticate_user! replaces inherited line44 after earlier unknown include/prepend effects. No selector excludes create; effective registration changed, invocation remains unknown.',
'Chaos line4 unless development_or_test? is a live predicate; selecting quit does not determine environment.',
'Dashboard line10 only show matches, but if current_user remains a separate condition. Only is normalized by prepending an ActionFilter to existing if conditions, not erasing that predicate.',
'PolicyStore line14 unqualified registration follows ancestor/include events. Its target may reject a request; absence of a registration selector blocker does not prove it runs or succeeds.',
'PipelineSchedules line6 except index/new/create does not exclude play; later other-symbol registrations do not replace schedule. No activation or ordering completion is inferred.'
]
sample=rows(A/'sample.jsonl'); reviews=[]; quals={};events={};edges={};conditional_skips=[]
for profile in ['ce','ee']:
 q=rows(V/'tables'/f'{profile}_callback_activation_qualifications.jsonl');quals.update({r['edge_id']:r for r in q})
 ev=rows(V/'tables'/f'{profile}_callback_activation_events.jsonl');events.update({e['event_id']:e for e in ev})
 for scope in ['direct','inherited']:
  edges.update({e['edge_id']:e for e in rows(V/'tables'/f'{profile}_{scope}_callback_invocation_edges.jsonl')})
 for e in ev:
  evidence(e['source_evidence']);c=e.get('declaration',{});opts=c.get('option_expressions',{})
  if c.get('api')=='skip_before_action' and ('if' in opts or 'unless' in opts):conditional_skips.append(e['event_id'])
 for r in q:
  checks+=5
  if r['edge_id'] not in edges or r['callback_activated_proven'] or r['new_native_paths']!=0 or not r['source_relation_preserved'] or any(i not in events for i in r['ordered_event_ids']+r['blocking_event_ids']):errors.append({'qualification':r['qualification_id']})
  for h in r['hierarchy_evidence']:evidence(h['source_evidence'])
for r,note in zip(sample,notes):
 e=edges[r['edge_id']];ev=[events[i] for i in r['ordered_event_ids']];source= [x['source_evidence'] for x in ev if x['kind']=='declaration']
 if e.get('source_evidence'):source+=e['source_evidence']
 else:
  idx={x['evidence_id']:x for x in rows(V/'tables'/f"{r['profile']}_inherited_callback_invocation_evidence.jsonl")};source += [idx[i] for i in e['source_evidence_ids']]
 for s in source:evidence(s)
 reviews.append(dict(audit_id=r['audit_id'],qualification_id=r['qualification_id'],edge_id=r['edge_id'],profile=r['profile'],receiver_owner=r['receiver_owner'],action=r['action'],symbol=r['symbol'],verdict='supported_bounded_qualification',note=note,reviewed_activation_status=r['activation_status'],reviewed_declaration_status=r['declaration_relation_status'],source_evidence=source,ordered_event_ids=r['ordered_event_ids'],runtime_activation='not_proven',assumptions=r['conditions']))
dev=[]
for old in rows(V/'audit/inherited_callbacks_holdout/sample.jsonl'):
 if old['audit_id'] not in ['ICB002','ICB005','ICB014']:continue
 q=quals[old['edge_id']];ev=[events[i] for i in q['ordered_event_ids'] if events[i]['kind']=='declaration']
 assert q['activation_status']=='conditionally_blocked_for_action'
 dev.append(dict(previous_audit_id=old['audit_id'],edge_id=old['edge_id'],qualification_id=q['qualification_id'],verdict='expected_development_case_blocked',source_evidence=[e['source_evidence'] for e in ev],reason='Invites prepend only show replaces inherited registration; decline additionally has literal skip only decline. Accept is excluded by replacement selector. Development reuse, not fresh holdout.'))
for m in rows(V/'tables/callback_activation_qualification_model.jsonl'):
 for e in m['source_evidence']:evidence(e)
sys.path.insert(0,str(V/'scripts'));from qualify_callback_activation import replay
reg={'event_id':'register','kind':'declaration','declaration':{'callback_id':'register','api':'before_action','filters':['check'],'option_expressions':{},'declaration_conditions':[]}}
skip={'event_id':'skip','kind':'declaration','declaration':{'callback_id':'skip','api':'skip_before_action','filters':['check'],'option_expressions':{'only':':edit','if':':flag?'},'only':['edit'],'declaration_conditions':[]}}
actual=replay([reg,skip],'show')['eligible']
counterexample={'case':'skip only edit plus if flag? on show','producer_eligible':actual,'source_semantics':'Normalization appends ActionFilter(edit) to if; skip merge appends both skip if predicates to callback unless. When flag? is true callback is excluded even on show. Producer returns eligible true after only mismatch without considering predicate. Conservative result should be unknown.','source_locations':['sources/wrappers/rails-7.2.3.1/actionpack/lib/abstract_controller/callbacks.rb:93','sources/wrappers/rails-7.2.3.1/activesupport/lib/active_support/callbacks.rb:257','sources/wrappers/rails-7.2.3.1/activesupport/lib/active_support/callbacks.rb:803'],'current_conditional_skip_event_ids':conditional_skips,'current_rows_affected':0,'runtime_execution':False}
assert actual is True and not conditional_skips
for name,data in [('reviews.jsonl',reviews),('development_rechecks.jsonl',dev)]: (A/name).write_text(''.join(json.dumps(r)+'\n' for r in data))
(A/'counterexample.json').write_text(json.dumps(counterexample,indent=2)+'\n')
summary={'status':'PASS_CURRENT_ROWS_WITH_OUT_OF_CORPUS_MODEL_GAP','fresh_reviewed':12,'fresh_verdicts':{'supported_bounded_qualification':12,'contradicted':0,'unresolved_review':0},'runtime_activation_proven':0,'development_rechecks':3,'population_rows':len(quals),'checks':checks,'errors':errors,'source_files':len(files),'profile_counts':dict(collections.Counter(r['profile'] for r in sample)),'sample_status_counts':dict(collections.Counter(r['activation_status'] for r in sample)),'sample_relation_counts':dict(collections.Counter(r['declaration_relation_status'] for r in sample)),'unique_receiver_families':len({r['receiver_owner'] for r in sample}),'unique_profile_symbol_families':len({(r['profile'],r['symbol']) for r in sample}),'generalization':'Nonuniform rare-stratum sample; no global precision estimate. Same Rails duplicate/skip mechanism shared across reviews. Not-blocked never means activated.','additional_source_local_blocker':'CQ002 update conflicts later lambda action_name == publish; conservative unknown remains safe.','model_gap':counterexample,'source_manifest':files}
(A/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
paths=[A/n for n in ['sample.jsonl','selection_freeze.json','reviews.jsonl','development_rechecks.jsonl','counterexample.json','summary.json']]+[Path(__file__),V/'scripts/sample_callback_qualification_holdout.py']
(A/'review_freeze.json').write_text(json.dumps({'files':{str(p.relative_to(V)):sha(p) for p in paths},'frozen_input_manifest_sha256':sha(V/'reports/callback_activation_qualification_freeze.json')},indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['source_manifest','model_gap']},indent=2))
