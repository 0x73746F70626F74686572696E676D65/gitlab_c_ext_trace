"""Additive conditional activation qualification; frozen relation edges remain intact."""
import collections,hashlib,json,pathlib,re
from link_direct_controller_callbacks import Sources,rows,V,B,uid
from link_inherited_controller_callbacks import superclass_step,superclass_source_unconditional
REG={'before_action','append_before_action','prepend_before_action'}
def in_scope(file,prefix):
 return (file.startswith(prefix) or file.startswith('sources/wrappers/rails-7.2.3.1/')) and not re.search(r'/(spec|test|qa|fixtures)/',file)
def selector(c,action):
 opts=c.get('option_expressions',{})
 if 'only' in opts:
  if c.get('only') is None:return None
  if action not in c['only']:return False
 if 'except' in opts:
  if c.get('except_actions') is None:return None
  if action in c['except_actions']:return False
 if 'if' in opts or 'unless' in opts:return None
 return True

def replay(events,action):
 state=dict(registration=None,eligible=None,blockers=[],trace=[])
 for e in events:
  state['trace'].append(e['event_id'])
  if e['kind']=='unknown':state.update(registration=None,eligible=None,blockers=[]);continue
  c=e['declaration']
  if c.get('declaration_conditions') or any(f is None for f in c['filters']):state.update(registration=None,eligible=None,blockers=[]);continue
  if c['api'] in REG:
   okay=selector(c,action);state.update(registration=c['callback_id'],eligible=okay,blockers=[e['event_id']] if okay is False else [])
  elif c['api']=='skip_before_action':
   # Rails skip predicate inversion differs from registration conjunction.
   # Fail closed BEFORE only/except shortcuts for every conditional skip.
   if any(k in c.get('option_expressions',{}) for k in ('if','unless')):
    state.update(eligible=None,blockers=[]);continue
   match=selector(c,action)
   if match is True:state.update(eligible=False,blockers=[e['event_id']])
   elif match is None and state['eligible'] is not False:state.update(eligible=None,blockers=[])
 return state

def main():
 sources=Sources();reports={};model_source='sources/wrappers/rails-7.2.3.1/activesupport/lib/active_support/callbacks.rb';model_data=(B/model_source).read_bytes();model_evidence=[sources.evidence(model_source,257,267),sources.evidence(model_source,273,280),sources.evidence(model_source,645,663),sources.evidence(model_source,787,811),sources.evidence('sources/wrappers/rails-7.2.3.1/actionpack/lib/abstract_controller/callbacks.rb',93,106)];model=dict(model_id='rails7231_literal_symbol_skip_duplicate_qualification_v2',source_evidence=model_evidence,scope='Exact-symbol before kind; append/prepend both remove_duplicates; skips merge inverted predicates or remove callback. Conditional source initialization order only.')
 (V/'tables/callback_activation_qualification_model_v2.jsonl').write_text(json.dumps(model)+'\n')
 for profile,G,prefix in [('ce',pathlib.Path('/workspace/gitlab_c_ext_ruby_expanded'),'sources/gitlab/'),('ee',pathlib.Path('/workspace/gitlab_c_ext_ee_profile'),'sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/')]:
  declarations=list(rows(V/'profiles'/profile/'tables/controller_callback_declarations.jsonl'));byowner=collections.defaultdict(list)
  for c in declarations:byowner[c['owner']].append(c)
  rels=collections.defaultdict(list)
  for r in rows(G/'tables/ruby_inheritance.jsonl'):
   if in_scope(r['file'],prefix):rels[r['owner']].append(r)
  universe={m['namespace'] for m in rows(G/'tables/ruby_methods.jsonl') if in_scope(m['file'],prefix)};chaincache={};eventcache={};facts=[];events_out={};checksources=set()
  def chain(owner):
   if owner in chaincache:return chaincache[owner]
   out=[];cur=owner;seen=set();reason=None
   while cur not in seen:
    out.append(cur)
    if cur=='ActionController::Base':break
    seen.add(cur);parent,rs,reason=superclass_step(rels[cur],universe,lambda r:superclass_source_unconditional(sources.get(r['file']),r['line']))
    if reason:break
    cur=parent
   else:reason='cycle'
   chaincache[owner]=(out,reason);return out,reason
  def events_for(owner,symbol):
   key=(owner,symbol)
   if key in eventcache:return eventcache[key]
   cc,reason=chain(owner);events=[]
   if reason:eventcache[key]=(events,reason);return events,reason
   for ancestor in reversed(cc):
    local=[]
    for c in byowner[ancestor]:
     if c['api'] not in REG|{'skip_before_action'}:continue
     if symbol not in c['filters'] and not any(f is None for f in c['filters']):continue
     local.append(dict(event_id='cbevent_'+uid(profile,c['callback_id']),kind='declaration',declaration=c,owner=ancestor,file=c['file'],line=c['line'],end_line=c['end_line']))
    for r in rels[ancestor]:
     if r['kind'] in ('include','prepend'):local.append(dict(event_id='cbevent_'+uid(profile,r['inheritance_id']),kind='unknown',reason='mixin_callback_mutation_unknown',inheritance_id=r['inheritance_id'],owner=ancestor,file=r['file'],line=r['line'],end_line=r['line']))
    files={e['file'] for e in local}
    # Explicit custom callback operations in those source bodies are holes.
    for file in files:
     src=sources.get(file);pending=[src.tree.root_node]
     while pending:
      n=pending.pop()
      if n.type in ('method','singleton_method','lambda'):continue
      if n.type=='call' and src.text(src.field(n,'method')) in ('set_callback','skip_callback','reset_callbacks','define_callbacks'):
       local.append(dict(event_id='cbevent_'+uid(profile,file,n.start_byte),kind='unknown',reason='custom_callback_API_mutation_unresolved',owner=ancestor,file=file,line=n.start_point.row+1,end_line=n.end_point.row+1))
      pending.extend(n.named_children)
    if len(files)>1:reason='owner_reopening_or_mixin_source_file_order_unresolved';break
    local.sort(key=lambda e:(e['line'],e['end_line'],e['event_id']))
    if any(a['line']==b['line'] and a['event_id']!=b['event_id'] for a,b in zip(local,local[1:])):reason='same_line_event_order_unresolved';break
    events.extend(local)
   eventcache[key]=(events,reason);return events,reason
  for scope in ('direct','inherited'):
   for e in rows(V/'tables'/f'{profile}_{scope}_callback_invocation_edges.jsonl'):
    ev,reason=events_for(e['receiver_owner'],e['symbol']);st=replay(ev,e['action']) if not reason else dict(registration=None,eligible=None,blockers=[],trace=[])
    for event in ev:
     if event['event_id'] not in events_out:
      event=dict(event);event['source_evidence']=sources.evidence(event['file'],event['line'],event['end_line']);events_out[event['event_id']]=event
    hierarchy=[]
    for ancestor in chain(e['receiver_owner'])[0]:
     for relation in rels[ancestor]:
      if relation['kind']=='superclass':hierarchy.append(dict(inheritance_id=relation['inheritance_id'],owner=ancestor,target_candidates=relation['target_candidates'],source_evidence=sources.evidence(relation['file'],relation['line'],relation['line'])))
    declaration='unknown' if st['registration'] is None else 'latest_known_registration' if st['registration']==e['callback_id'] else 'superseded_by_later_same_symbol_registration'
    status='conditionally_blocked_for_action' if st['eligible'] is False else 'unknown_activation' if st['eligible'] is None else 'not_blocked_by_modeled_operations'
    facts.append(dict(qualification_id='cbqual_'+uid(profile,e['edge_id']),profile=profile,edge_id=e['edge_id'],edge_scope=scope,receiver_owner=e['receiver_owner'],action=e['action'],symbol=e['symbol'],source_callback_id=e['callback_id'],activation_status=status,declaration_relation_status=declaration,effective_registration_id=st['registration'],blocking_event_ids=st['blockers'],ordered_event_ids=st['trace'],order_failure=reason,hierarchy_evidence=hierarchy,framework_model_id=model['model_id'],conditions=['Normal source class initialization: superclass completed before subclass, one known file per owner, lexical class-body event order','No later reload, reflective callback mutation or hidden callback mutation by unmodeled class-body DSL/initializers','Exact Rails7.2.3.1 symbol before-callback duplicate/skip semantics and ordinary route/action-name matching'],remaining_unknown=['Runtime admission, callback predicates/order/earlier halting and effective module activation not established','Not-blocked means only no blocker in this bounded replay; never activated/proven'],source_relation_preserved=True,callback_activated_proven=False,new_native_paths=0))
  with (V/'tables'/f'{profile}_callback_activation_qualifications_v2.jsonl').open('w') as f:
   for r in facts:f.write(json.dumps(r)+'\n')
  with (V/'tables'/f'{profile}_callback_activation_events_v2.jsonl').open('w') as f:
   for r in events_out.values():f.write(json.dumps(r)+'\n')
  reports[profile]=dict(edges_qualified=len(facts),activation_statuses=dict(collections.Counter(r['activation_status'] for r in facts)),declaration_statuses=dict(collections.Counter(r['declaration_relation_status'] for r in facts)),order_failures=dict(collections.Counter(r['order_failure'] for r in facts if r['order_failure'])),events=len(events_out))
 report=dict(scope='Additive conditional source-order activation qualification, preserving all direct/inherited relation IDs',profiles=reports,model_id=model['model_id'],new_native_paths=0,frozen_relations_mutated=False)
 (V/'reports/callback_activation_qualification_coverage_v2.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
