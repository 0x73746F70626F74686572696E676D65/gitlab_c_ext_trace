#!/usr/bin/env python3
"""Callback qualifications and Rack Grape body transfer companion; gated on additive review/union."""
import gzip,hashlib,io,json,shutil,tarfile
from pathlib import Path
from package_v3_publication import digest
def verify_manifest(path):
 r=json.loads(path.read_text());items=r.get("files",{})
 entries=[dict(path=n,sha256=v if isinstance(v,str) else v["sha256"]) for n,v in items.items()] if isinstance(items,dict) else items
 entries+=r.get("immutable_inputs",[]) if isinstance(r.get("immutable_inputs"),list) else []
 for row in entries:assert digest(R/row["path"])==row["sha256"],row["path"]
 return len(entries)
R=Path('/workspace/gitlab_c_ext_v3');D=R/'publication/callback-qualifications-body'
def main():
 config=json.loads((D/'package_inputs.json').read_text())
 for name in config['required_reviews']:
  p=R/name;assert p.exists(),('pending review',name);assert json.loads(p.read_text())['status']==('PASS_CURRENT_ROWS_WITH_OUT_OF_CORPUS_MODEL_GAP' if name=='audit/callback_qualification_holdout/summary.json' else 'PASS'),name
 checks=[dict(manifest=n,verified_files=verify_manifest(R/n)) for n in config['freeze_manifests']]
 for n in config['required_files']:assert (R/n).exists(),('pending artifact',n)
 priors={str(p):digest(p) for p in [R/'publication'/n for n in ['gitlab-c-ext-v3.tar.gz','gitlab-c-ext-iteration3.tar.gz','gitlab-c-ext-census-and-flows.tar.gz','gitlab-c-ext-iteration5-6.tar.gz','gitlab-c-ext-json-request-flow.tar.gz','gitlab-c-ext-yaml-psych.tar.gz','gitlab-c-ext-json-validation.tar.gz','gitlab-c-ext-passkey-bcrypt.tar.gz','gitlab-c-ext-direct-callbacks.tar.gz','gitlab-c-ext-inherited-callbacks-memory.tar.gz','CURRENT_INPUT_FLOWS.tar.gz']]}
 stage=D/'gitlab-c-ext-callback-qualifications-body'
 if stage.exists():shutil.rmtree(stage)
 stage.mkdir();files=set(config['required_files'])|set(config['required_reviews'])|set(config['freeze_manifests'])|{'scripts/package_callback_qualifications_body.py','scripts/package_v3_publication.py'}
 for n in sorted(files):
  p=R/n;dest=stage/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 sources={}
 def walk(x):
  if isinstance(x,dict):
   n=x.get('file');h=x.get('sha256',x.get('source_sha256'))
   if isinstance(n,str) and n.startswith('sources/') and h:
    old=sources.setdefault(n,h);assert old==h
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 for n in files:
  if n.endswith('.jsonl'):
   for line in (R/n).open():walk(json.loads(line))
  elif n.endswith('.json'):walk(json.loads((R/n).read_text()))
 review_sources=json.loads((R/'audit/callback_qualification_holdout/summary.json').read_text())['source_manifest']
 for absolute,h in review_sources.items():
  n=str(Path(absolute).relative_to('/workspace/gitlab_c_ext_trace'));old=sources.setdefault(n,h);assert old==h
 manifest=[]
 for n,h in sorted(sources.items()):
  p=Path('/workspace/gitlab_c_ext_trace')/n;assert digest(p)==h
  manifest.append(dict(file=n,sha256=h,bytes=p.stat().st_size,durable_location=str(p)))
 (stage/'selected_source_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 (stage/'package_inputs.json').write_text(json.dumps(config,indent=2)+'\n');(stage/'INDEX.txt').write_text((D/'INDEX.txt').read_text())
 (stage/'prerequisites.json').write_text(json.dumps(dict(prior_archives=priors,source_root='/workspace/gitlab_c_ext_trace',analysis_root=str(R),runtime_verified=False),indent=2)+'\n')
 catalog=[dict(path=str(p.relative_to(stage)),bytes=p.stat().st_size,sha256=digest(p),rows=sum(1 for _ in p.open('rb')) if p.suffix=='.jsonl' else None) for p in sorted(stage.rglob('*')) if p.is_file()]
 (stage/'table_catalog.json').write_text(json.dumps(catalog,indent=2)+'\n');(stage/'package_validation.json').write_text(json.dumps(dict(status='PASS',freeze_checks=checks,files=len(catalog),bytes=sum(x['bytes'] for x in catalog),scope='Required independent review status, frozen source hashes and archive identity; no runtime feasibility proof'),indent=2)+'\n')
 (stage/'SHA256SUMS').write_text(''.join(f'{digest(p)}  {p.relative_to(stage)}\n' for p in sorted(stage.rglob('*')) if p.is_file()))
 arc=R/'publication/gitlab-c-ext-callback-qualifications-body.tar.gz'
 with arc.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0,compresslevel=9) as gz,tarfile.open(fileobj=gz,mode='w') as t:
  for p in sorted(stage.rglob('*')):
   if p.is_file():
    info=tarfile.TarInfo('gitlab-c-ext-callback-qualifications-body/'+str(p.relative_to(stage)));info.size=p.stat().st_size;info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(p.read_bytes()))
 with tarfile.open(arc,'r:gz') as t:actual={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers()}
 assert actual=={'gitlab-c-ext-callback-qualifications-body/'+str(p.relative_to(stage)):digest(p) for p in stage.rglob('*') if p.is_file()}
 assert all(digest(Path(p))==h for p,h in priors.items())
 for row in catalog:
  if row['path'] in files:assert digest(R/row['path'])==row['sha256'],('source changed during packing',row['path'])
 result=dict(status='PASS',archive=str(arc),bytes=arc.stat().st_size,sha256=digest(arc),members=len(actual),prior_archives_preserved=True)
 (D/'archive_validation.json').write_text(json.dumps(result,indent=2)+'\n');(D/'SHA256SUMS').write_text(f"{result['sha256']}  {arc.name}\n");print(json.dumps(result))
if __name__=='__main__':main()
