import pathlib,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
from qualify_callback_activation_v2 import replay,in_scope
class QualificationTests(unittest.TestCase):
 def test_test_reopenings_excluded(self):
  self.assertFalse(in_scope('sources/wrappers/rails-7.2.3.1/actionpack/test/abstract_unit.rb','sources/gitlab/'))
  self.assertTrue(in_scope('sources/wrappers/rails-7.2.3.1/actionpack/lib/action_controller/base.rb','sources/gitlab/'))
  self.assertFalse(in_scope('sources/gitlab/spec/controllers/a.rb','sources/gitlab/'))
 def e(self,id,api='before_action',only=None,exc=None,pred=None):
  opts={}
  if only is not None:opts['only']=str(only)
  if exc is not None:opts['except']=str(exc)
  if pred is not None:opts['if']=pred
  return dict(event_id=id,kind='declaration',declaration=dict(callback_id=id,api=api,only=only,except_actions=exc,filters=['check'],option_expressions=opts,declaration_conditions=[]))
 def test_duplicate_replaces_even_outside_new_only(self):
  r=replay([self.e('parent'),self.e('child','prepend_before_action',only=['show'])],'accept');self.assertEqual(r['registration'],'child');self.assertIs(r['eligible'],False)
 def test_replacement_samebody_matching_action_not_blocked(self):self.assertIs(replay([self.e('old'),self.e('new',only=['show'])],'show')['eligible'],True)
 def test_unconditional_skip_blocks(self):self.assertIs(replay([self.e('a'),self.e('b','skip_before_action')],'show')['eligible'],False)
 def test_skip_only_other_action_keeps(self):self.assertIs(replay([self.e('a'),self.e('b','skip_before_action',only=['edit'])],'show')['eligible'],True)
 def test_skip_except_other_action_blocks(self):self.assertIs(replay([self.e('a'),self.e('b','skip_before_action',exc=['edit'])],'show')['eligible'],False)
 def test_skip_except_current_action_keeps(self):self.assertIs(replay([self.e('a'),self.e('b','skip_before_action',exc=['show'])],'show')['eligible'],True)
 def test_later_registration_restores_after_skip(self):self.assertIs(replay([self.e('a'),self.e('b','skip_before_action'),self.e('c')],'show')['eligible'],True)
 def test_conditional_skip_unknown(self):self.assertIsNone(replay([self.e('a'),self.e('b','skip_before_action',pred='allowed?')],'show')['eligible'])
 def test_unknown_then_registration_resets(self):self.assertIs(replay([dict(event_id='x',kind='unknown'),self.e('a')],'show')['eligible'],True)
 def test_later_unknown_erases_blocker(self):self.assertIsNone(replay([self.e('a',only=['edit']),dict(event_id='x',kind='unknown')],'show')['eligible'])
 def test_matching_skip_after_unknown_blocks_conditionally(self):self.assertIs(replay([dict(event_id='x',kind='unknown'),self.e('a','skip_before_action',only=['show'])],'show')['eligible'],False)
 def test_dynamic_selector_unknown(self):
  e=self.e('a');e['declaration']['option_expressions']['only']='runtime_actions';self.assertIsNone(replay([e],'show')['eligible'])
 def test_conditional_registration_unknown(self):
  e=self.e('a');e['declaration']['declaration_conditions']=[{'expression':'if feature'}];self.assertIsNone(replay([e],'show')['eligible'])
 def test_skip_only_exclusion_with_if_is_unknown(self):
  self.assertIsNone(replay([self.e('a'),self.e('s','skip_before_action',only=['edit'],pred='allowed?')],'show')['eligible'])
 def test_skip_except_exclusion_with_unless_is_unknown(self):
  e=self.e('s','skip_before_action',exc=['show']);e['declaration']['option_expressions']['unless']='blocked?'
  self.assertIsNone(replay([self.e('a'),e],'show')['eligible'])
 def test_conditional_skip_does_not_preserve_prior_false(self):
  self.assertIsNone(replay([self.e('a',only=['edit']),self.e('s','skip_before_action',pred='allowed?')],'show')['eligible'])
 def test_append_and_prepend_both_replace(self):
  for api in ('append_before_action','prepend_before_action'):
   r=replay([self.e('a'),self.e('b',api,exc=['show'])],'show');self.assertEqual(r['registration'],'b');self.assertIs(r['eligible'],False)
if __name__=='__main__':unittest.main()
