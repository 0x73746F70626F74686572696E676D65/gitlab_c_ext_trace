import importlib.util,unittest
from pathlib import Path
p=Path(__file__).parents[1]/'scripts/memory_semantics_overlay_v1.py'
s=importlib.util.spec_from_file_location('overlay',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class ClassifierTests(unittest.TestCase):
 def test_exact_apis(self):
  for api in m.APIS:self.assertEqual(m.classify(api,'call_token'),api)
 def test_unrelated_and_suffix(self):
  for x in ['my_rb_str_new','rb_str_new_cstr','rb_str_buf_new_cstr','LONG2NUM_extra','rb_str_new_frozen_wrapper','str_new','LONG2FIX']:self.assertIsNone(m.classify(x,'call_token'))
 def test_qualification_not_guessed(self):
  for x in ['::rb_str_new','std::rb_str_new','p->rb_str_new','m.rb_str_new']:self.assertIsNone(m.classify(x,'call_token'))
 def test_aliases_not_guessed(self):
  for x in ['RB_LONG2NUM','rb_long2num_inline','ULONG2NUM']:self.assertIsNone(m.classify(x,'call_token'))
 def test_noncall_not_classified(self):
  for k in ['automatic_array_declarator','macro_alias','lexical','new_delete']:self.assertIsNone(m.classify('rb_str_new',k))
 def test_no_runtime_branch_evaluation(self):
  self.assertEqual(m.classify('LONG2NUM','call_token'),'LONG2NUM') # site matcher has no value/range input
 def test_frozen_no_copy_alternative(self):
  b=m.definitions()['rb_str_new_frozen']['branches'];self.assertEqual(b[0]['input_copy'],'none');self.assertIn('or existing',b[2]['object_effect'])
 def test_embedded_guard_is_or(self):
  self.assertIn(' || ',m.definitions()['rb_str_new_frozen']['branches'][1]['guard'])
 def test_null_input_and_negative_length(self):
  b=m.definitions()['rb_str_new']['branches'];self.assertIn('ptr!=NULL',b[0]['input_copy']);self.assertEqual(b[2]['guard'],'len<0');self.assertIn('positive copy only len>0',b[1]['input_copy'])
 def test_capacity_not_input_copy(self):
  a=m.definitions()['rb_str_buf_new'];self.assertIn('nonnegative',a['arguments']['capa']);self.assertTrue(all('no source buffer argument' in b['input_copy'] for b in a['branches']))
 def test_long_immediate_branch(self):
  b=m.definitions()['LONG2NUM']['branches'];self.assertEqual(b[0]['guard'],'RB_FIXABLE(v)');self.assertIn('no fresh object',b[0]['separate_buffer']);self.assertIn('Bignum',b[1]['object_effect'])
if __name__=='__main__':unittest.main()
