import pathlib,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
from link_inherited_controller_callbacks import resolve_target,superclass_step,superclass_source_unconditional
from ruby_argument_flow_iteration5 import FlowSource
class InheritedTests(unittest.TestCase):
 def run_lookup(self,defs=None,rels=None,check=lambda m:None):return resolve_target(['Child','Parent','Base'],'gate',defs or {},rels or {},check)
 def method(self,owner,kind='instance'):return dict(method_id=owner+'gate',namespace=owner,method='gate',kind=kind)
 def test_nearest_override_wins(self):
  m,r,p=self.run_lookup({('Child','gate','instance'):[self.method('Child')],('Parent','gate','instance'):[self.method('Parent')]});self.assertEqual(m['namespace'],'Child');self.assertEqual(p,[])
 def test_ancestor_target_with_plain_chain(self):
  m,r,p=self.run_lookup({('Parent','gate','instance'):[self.method('Parent')]});self.assertEqual(m['namespace'],'Parent');self.assertEqual(p,['Child'])
 def test_singleton_does_not_shadow_instance(self):
  m,r,p=self.run_lookup({('Child','gate','singleton'):[self.method('Child','singleton')],('Parent','gate','instance'):[self.method('Parent')]});self.assertEqual(m['namespace'],'Parent')
 def test_nearest_conditional_definition_blocks_fallback(self):
  m,r,p=self.run_lookup({('Child','gate','instance'):[self.method('Child')],('Parent','gate','instance'):[self.method('Parent')]},check=lambda m:'conditional' if m['namespace']=='Child' else None);self.assertIsNone(m);self.assertEqual(r,'conditional')
 def test_multiple_own_defs_block(self):
  m,r,p=self.run_lookup({('Child','gate','instance'):[self.method('Child'),self.method('Child')]});self.assertIsNone(m);self.assertEqual(r,'nearest_class_multiple_definitions')
 def test_prepend_before_own_blocks(self):
  m,r,p=self.run_lookup({('Child','gate','instance'):[self.method('Child')]},{'Child':[{'kind':'prepend'}]});self.assertIsNone(m)
 def test_include_before_parent_blocks(self):
  m,r,p=self.run_lookup({('Parent','gate','instance'):[self.method('Parent')]},{'Child':[{'kind':'include'}]});self.assertIsNone(m)
 def test_own_method_precedes_own_include(self):
  m,r,p=self.run_lookup({('Child','gate','instance'):[self.method('Child')]},{'Child':[{'kind':'include'}]});self.assertEqual(m['namespace'],'Child')
 def test_subclass_method_precedes_parent_prepend(self):
  m,r,p=self.run_lookup({('Child','gate','instance'):[self.method('Child')]},{'Parent':[{'kind':'prepend'}]});self.assertEqual(m['namespace'],'Child')
 def test_parent_prepend_blocks_parent_target(self):
  m,r,p=self.run_lookup({('Parent','gate','instance'):[self.method('Parent')]},{'Parent':[{'kind':'prepend'}]});self.assertIsNone(m)
 def test_missing_target_unknown(self):self.assertEqual(self.run_lookup()[1],'instance_method_not_found_in_plain_class_chain')
 def test_ambiguous_superclass_unresolved(self):
  rs=[dict(kind='superclass',target_candidates=['A','B'])];self.assertEqual(superclass_step(rs,{'A','B'},lambda r:True)[2],'ambiguous_or_missing_superclass')
 def test_conditional_superclass_unresolved(self):
  rs=[dict(kind='superclass',target_candidates=['A'])];self.assertEqual(superclass_step(rs,{'A'},lambda r:False)[2],'conditional_or_unparsed_superclass_declaration')
 def test_conditional_class_source_rejected(self):
  s=FlowSource('if enabled\n class Child < Parent\n end\nend');self.assertFalse(superclass_source_unconditional(s,2))
 def test_unconditional_namespaced_class_supported(self):
  s=FlowSource('module Space\n class Child < Parent\n end\nend');self.assertTrue(superclass_source_unconditional(s,2))
if __name__=='__main__':unittest.main()
