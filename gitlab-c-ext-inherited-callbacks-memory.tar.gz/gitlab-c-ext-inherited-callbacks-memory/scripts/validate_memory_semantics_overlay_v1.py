#!/usr/bin/env python3
import hashlib,json,importlib.util,unittest
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_trace');V=Path('/workspace/gitlab_c_ext_v3')
def read(p):return [json.loads(x) for x in p.open()]
sites={x['site_id']:x for x in read(R/'tables/primitive_sites.jsonl')};contracts={x['contract_id']:x for x in read(V/'tables/memory_semantics_contracts_v1.jsonl')};rows=read(V/'tables/physical_site_memory_semantics_v1.jsonl');checks=0;seen=set()
for row in rows:
 assert row['site_id'] in sites and row['contract_id'] in contracts;checks+=2
 assert row['semantics_id'] not in seen;seen.add(row['semantics_id']);checks+=1
 site=sites[row['site_id']];c=contracts[row['contract_id']]
 assert row['operation']==site['operation']==c['api'];checks+=1
 assert site['site_kind']=='call_token';checks+=1
 for a,b in [('file','canonical_source_path'),('line','line'),('source_sha256','source_sha256'),('gem_ids','gem_ids')]:assert row[a]==site[b];checks+=1
 assert row['realized_branch']=='unknown_no_argument_facts' and row['allocation_event_count'] is None and row['copy_event_count'] is None;checks+=1
expected={x['site_id'] for x in sites.values() if x['operation'] in {c['api'] for c in contracts.values()} and x['site_kind']=='call_token'}
assert expected=={x['site_id'] for x in rows};checks+=1
for c in contracts.values():
 for e in c['source_evidence']:
  d=(R/e['file']).read_bytes();assert hashlib.sha256(d).hexdigest()==e['source_sha256'];checks+=1
  excerpt='\n'.join(d.decode().split('\n')[e['line']-1:e['end_line']]);assert excerpt==e['excerpt'];checks+=1
  for a in e['required_anchors']:assert a in excerpt;checks+=1
suite=unittest.defaultTestLoader.discover(str(V/'tests'),pattern='test_memory_semantics_overlay_v1.py');result=unittest.TextTestRunner(verbosity=1).run(suite);assert result.wasSuccessful()
report={'checks':checks,'errors':0,'tests':result.testsRun,'unique_sites':len(expected),'runtime_execution':False,'target_extensions_executed':False,'meaning':'Integrity, complete exact-match census and contract fixture checks; independent source review remains separate.'}
(V/'reports/memory_semantics_overlay_validation_v1.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
