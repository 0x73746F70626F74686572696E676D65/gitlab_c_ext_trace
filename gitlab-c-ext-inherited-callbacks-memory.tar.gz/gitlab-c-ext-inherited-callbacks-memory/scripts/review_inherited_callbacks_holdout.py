import json,pathlib,hashlib,collections
V=pathlib.Path('/workspace/gitlab_c_ext_v3');B=pathlib.Path('/workspace/gitlab_c_ext_trace');D=V/'audit/inherited_callbacks_holdout';f=json.loads((D/'selection_freeze.json').read_text());errors=[];checks=0;allrows=[];files={}
def check(ok,why):
 global checks
 checks+=1
 if not ok:errors.append(why)
def ev(file,a,z):
 p=B/file;data=p.read_bytes();files[file]=hashlib.sha256(data).hexdigest();return dict(file=file,line=a,end_line=z,sha256=files[file],excerpt='\n'.join(data.decode().split('\n')[a-1:z]))
for p in ['ce','ee']:
 rel=f'tables/{p}_inherited_callback_invocation_edges.jsonl';d=(V/rel).read_bytes();check(hashlib.sha256(d).hexdigest()==f['inputs'][rel],'population hash '+p);rs=[json.loads(l)for l in d.splitlines()];allrows+=rs
 es={r['evidence_id']:r for r in map(json.loads,(V/f'tables/{p}_inherited_callback_invocation_evidence.jsonl').open())};routes={r['scope_occurrence_id']for r in map(json.loads,(V/f'profiles/{p}/tables/route_scope_bindings.jsonl').open())}
 for e in es.values():
  actual=ev(e['file'],e['line'],e['end_line']);check(actual['sha256']==e['sha256'],'source hash');check(actual['excerpt']==e['excerpt'],'source excerpt')
 for r in rs:
  check(not r['may_seed_complete_path']and not r['callback_activated_proven']and not r['runtime_exposure_proven']and r['new_native_paths']==0,'partial flags '+r['edge_id'])
  check(r['target_method_kind']=='instance','instance target');check(r['registration_owner']in r['class_chain'][1:],'ancestor registration');check(r['target_owner']in r['class_chain'],'target owner')
  for x in r['source_evidence_ids']:check(x in es,'evidence ref')
  for x in r['route_scope_occurrence_ids']:check(x in routes,'route ref')
check(len({r['edge_id']for r in allrows})==len(allrows),'duplicate edge IDs')
rs=[json.loads(l)for l in (D/'sample.jsonl').open()];check(hashlib.sha256((D/'sample.jsonl').read_bytes()).hexdigest()==f['sample_sha256'],'sample hash')
notes=[
'Drafts own merge_request overrides registration-owner MergeRequests::ApplicationController method. Nested projects/merge_requests/drafts index route and private own definition supported; dynamic prepend helper remains ordinary-lookup condition.',
'Invites own authenticate_user! overrides parent definition, but subclass same-symbol prepend only:show replaces inherited symbol; explicit skip only:decline also excludes selected decline. Declaration/lookup relation exists; active callback is source-blocked under ordinary compiled chain.',
'ExternalRedirect has no intervening definition/include before ApplicationController target. if should_enforce_terms? remains unproved; target private instance method can redirect but edge does not imply action continuation.',
'ProtectedBranches own load_protected_ref overrides inherited registration from ProtectedRefs. only show/update/destroy admits routed show. Dynamic prepend helpers/runtime lookup remain conditions.',
'Invites accept matches original parent except route_not_found, but child prepend authenticate_user! only:show replaces same-symbol inherited callback. accept is excluded by effective literal selector under normal registration order; this is not an activated callback.',
'Runners edit routes to descendant; no intervening literal include/definition before Projects::ApplicationController set_project_markdown_flags. Source prepend_mod helper effects remain deployment/lookup conditions; no active callback claim.',
'Projects/Ml Models inherits Projects::ApplicationController directly; no preceding definitions/mixins. Namespace ml/model destroy route supported. Step-up helper body may branch/raise; only selected callback entry relation reviewed.',
'Help index explicit route; no own default_headers or include before ApplicationController. Other skip declarations concern authentication/2FA, not this symbol. Framework/dynamic prepend conditions retained.',
'Groups/settings/packages_and_registries show route, direct group ancestor and private group-markdown method supported. No overriding method in descendant. Included modules on defining class do not override its own method; dynamic effects remain conditions.',
'Projects saved_views show path alias work_items/views does not change controller owner. Private repository method selected in Projects::ApplicationController; descendant no intervening include/definition.',
'AbuseReports add_category member route and inherited LDAP callback registration. No descendant LDAP override; body depends on user/lease/external access and can redirect. Entry relation only.',
'UserSettings GpgKeys destroy route and lexical ApplicationController inheritance. No descendant LDAP override/include. Private LDAP target supported; user/auth/LDAP state unresolved.',
'JWT own auth_user overrides parent callback target. Subclass also prepends same symbol; duplicate ordering matters and remains unresolved here. Wrapper strong_memoize body/internals not counted as complete continuation.',
'EE Invites same literal only:show replacement plus decline skip as CE. Partial declaration/lookup supported, but ordinary callback activation on decline source-blocked.',
'Gitea subclass inherits Github provider_auth registration but its own method is selected, not Github implementation. only status/realtime_changes/create admits status route. Session/provider checks may redirect, not activation proof.',
'EE HandRaiseLeads own private authenticate_user! overrides ApplicationController. Explicit subscription module/create route. Parent except route_not_found admits create; no pepper/password relation or downstream authentication proof.',
'EE GoogleCloud deployments cloud_storage route; plain direct BaseController ancestry and ancestor admin_project_google_cloud! own definition. Feature/auth conditions unresolved; no mixin before defining owner.',
'EE GoogleCloud databases create route; ancestor google_oauth2_enabled! own method. Google config/error callbacks affect runtime; nothing asserts credentials/config present.',
'EE Organization policy_store route namespace and explicit Organizations::ApplicationController superclass. Ancestor own organization definition precedes its OrganizationHelper include; no descendant override.',
'EE Dashboard Orbit show REST/catchall both select same owner. Ancestor redirect_org_scoped_to_global private method, not descendant override. Runtime prepend/load behavior and organization-scoped route condition remain unresolved.',
'EE Groups VirtualRegistries Maven registries_and_upstreams index inherits VirtualRegistries::BaseController ensure_feature!. Own defining class wins over its included helper; license/service callback may halt, no action continuation.',
'Admin Organizations Dashboard inherits intermediate Admin::Organizations::ApplicationController, whose private set_current_organization overrides original ApplicationController callback target. Intermediate own method selected before Admin includes; dynamic prepend remains conditional.',
'EE Projects/Aws Configuration index inherits Aws BaseController feature_flag_enabled!. Ancestor method public zero-argument and literal registration supported; actual feature state unknown.',
'EE GoogleCloud Configuration index shares ancestor authorization callback with deployments sample; separate route source checked. Same implementation means correlated observations, not independent accuracy evidence.'
]
reviews=[]
for r,n in zip(rs,notes):
 evidence=list(r['source_evidence']);blocked=r['audit_id']in ('ICB002','ICB005','ICB014')
 if blocked:
  pre='sources/gitlab/'if r['profile']=='ce'else'sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/'
  evidence+=[ev(pre+'app/controllers/invites_controller.rb',3,11),ev('sources/wrappers/rails-7.2.3.1/activesupport/lib/active_support/callbacks.rb',269,280),ev('sources/wrappers/rails-7.2.3.1/activesupport/lib/active_support/callbacks.rb',645,663)]
 reviews.append(dict(audit_id=r['audit_id'],edge_id=r['edge_id'],profile=r['profile'],relation_status='supported_stated_partial_declaration_and_lookup',activation_status='contradicted_under_ordinary_literal_callback_chain'if blocked else'unresolved',source_judgment=n,source_evidence=evidence,registration_owner=r['registration_owner'],target_owner=r['target_owner'],receiver_owner=r['receiver_owner'],runtime_verified=False,remaining_constraints=r['unresolved_constraints']))
(D/'reviews.jsonl').write_text(''.join(json.dumps(r)+'\n'for r in reviews));reg=json.loads((D/'regression_results.json').read_text())
s={'status':'PASS'if not errors else'FAIL','checks':checks,'errors':errors,'population_rows':len(allrows),'population_profiles':dict(collections.Counter(r['profile']for r in allrows)),'sample_rows':len(rs),'relation_verdicts':dict(collections.Counter(r['relation_status']for r in reviews)),'activation_verdicts':dict(collections.Counter(r['activation_status']for r in reviews)),'activation_proven':0,'blocked_audit_ids':['ICB002','ICB005','ICB014'],'sample_profile_receiver_groups':len({(r['profile'],r['receiver_owner'])for r in rs}),'sample_logical_receiver_groups':len({r['receiver_owner']for r in rs}),'sample_profile_target_methods':len({(r['profile'],r['target_method_id'])for r in rs}),'sample_registration_ids':len({r['callback_id']for r in rs}),'source_files_integrity_checked':len(files),'regression_expectations':{'total':16,'executed_static_fixtures':12,'manual_source_output_controls':4,'status':reg['status']},'findings':['Invites source literal duplicate registration and skip provide stronger activation exclusions for3 sampled partials; frozen edge status does not claim activation so source relation is not contradicted.','Nearest class-defined targets and subclass overrides supported in remaining source sample; dynamic helper/include/prepend/load/runtime assumptions not closed.'],'next_general_rule_candidate':'Source-order literal symbol duplicate replacement and action-matching skip normalization, with framework duplicate semantics; no sample-ID-specific fix.','design':f['design'],'correlation':'Shared ApplicationController/Projects::ApplicationController and GoogleCloud definitions appear across many paths; sample counts are not independent trials. CE/EE Invites share source family.','population_precision_estimate':None,'graph_mutated':False}
(D/'summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
