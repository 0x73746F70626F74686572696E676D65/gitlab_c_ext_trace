#!/usr/bin/env python3
"""Inherited callback and conditional memory semantics companion; gated on additive review/union."""
import gzip,hashlib,io,json,shutil,tarfile
from pathlib import Path
from package_v3_publication import digest,verify_manifest
R=Path('/workspace/gitlab_c_ext_v3');D=R/'publication/inherited-callbacks-memory'
def main():
 config=json.loads((D/'package_inputs.json').read_text())
 for name in config['required_reviews']:
  p=R/name;assert p.exists(),('pending review',name);assert json.loads(p.read_text())['status']=='PASS',name
 review_root=R/'audit/inherited_callbacks_holdout'
 review_freeze=json.loads((review_root/'review_freeze.json').read_text())
 for n,v in review_freeze.items():
  if n=='scripts':
   for script,h in v.items():assert digest(R/'scripts'/script)==h
  else:assert digest(review_root/n)==(v['sha256'] if isinstance(v,dict) else v)
 for n,h in json.loads((R/'reports/inherited_callback_invocation_freeze.json').read_text())['support_references'].items():assert digest(R/n)==h
 native_review=json.loads((R/'reports/memory_semantics_independent_review_v1.json').read_text())
 assert digest(R/'reports/memory_semantics_overlay_freeze_v1.json')==native_review['freeze_manifest_sha256']
 checks=[dict(manifest=n,verified_files=verify_manifest(R/n)) for n in config['freeze_manifests']]
 for n in config['required_files']:assert (R/n).exists(),('pending artifact',n)
 priors={str(p):digest(p) for p in [R/'publication'/n for n in ['gitlab-c-ext-v3.tar.gz','gitlab-c-ext-iteration3.tar.gz','gitlab-c-ext-census-and-flows.tar.gz','gitlab-c-ext-iteration5-6.tar.gz','gitlab-c-ext-json-request-flow.tar.gz','gitlab-c-ext-yaml-psych.tar.gz','gitlab-c-ext-json-validation.tar.gz','gitlab-c-ext-passkey-bcrypt.tar.gz','gitlab-c-ext-direct-callbacks.tar.gz','CURRENT_INPUT_FLOWS.tar.gz']]}
 stage=D/'gitlab-c-ext-inherited-callbacks-memory'
 if stage.exists():shutil.rmtree(stage)
 stage.mkdir();files=set(config['required_files'])|set(config['required_reviews'])|set(config['freeze_manifests'])|{'scripts/package_inherited_callbacks_memory.py','scripts/package_v3_publication.py'}
 for n in sorted(files):
  p=R/n;dest=stage/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 sources={}
 def source_refs(x):
  if isinstance(x,dict):
   if isinstance(x.get('file'),str) and x['file'].startswith('sources/') and x.get('sha256'):
    previous=sources.setdefault(x['file'],x['sha256']);assert previous==x['sha256']
   for v in x.values():source_refs(v)
  elif isinstance(x,list):
   for v in x:source_refs(v)
 for n in files:
  if n.endswith('.jsonl'):
   for line in (R/n).open():source_refs(json.loads(line))
 for n,h in native_review['source_manifest'].items():
  previous=sources.setdefault(n,h);assert previous==h
 source_rows=[]
 for n,h in sorted(sources.items()):
  p=Path('/workspace/gitlab_c_ext_trace')/n;assert digest(p)==h
  source_rows.append(dict(file=n,sha256=h,bytes=p.stat().st_size,durable_location=str(p)))
 (stage/'selected_source_manifest.json').write_text(json.dumps(source_rows,indent=2)+'\n')
 (stage/'package_inputs.json').write_text(json.dumps(config,indent=2)+'\n');(stage/'INDEX.txt').write_text((D/'INDEX.txt').read_text())
 (stage/'prerequisites.json').write_text(json.dumps(dict(prior_archives=priors,source_root='/workspace/gitlab_c_ext_trace',analysis_root=str(R),runtime_verified=False),indent=2)+'\n')
 catalog=[dict(path=str(p.relative_to(stage)),bytes=p.stat().st_size,sha256=digest(p),rows=sum(1 for _ in p.open('rb')) if p.suffix=='.jsonl' else None) for p in sorted(stage.rglob('*')) if p.is_file()]
 (stage/'table_catalog.json').write_text(json.dumps(catalog,indent=2)+'\n');(stage/'package_validation.json').write_text(json.dumps(dict(status='PASS',freeze_checks=checks,files=len(catalog),bytes=sum(x['bytes'] for x in catalog),scope='Required independent review status, frozen source hashes and archive identity; no runtime feasibility proof'),indent=2)+'\n')
 (stage/'SHA256SUMS').write_text(''.join(f'{digest(p)}  {p.relative_to(stage)}\n' for p in sorted(stage.rglob('*')) if p.is_file()))
 arc=R/'publication/gitlab-c-ext-inherited-callbacks-memory.tar.gz'
 with arc.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0,compresslevel=9) as gz,tarfile.open(fileobj=gz,mode='w') as t:
  for p in sorted(stage.rglob('*')):
   if p.is_file():
    info=tarfile.TarInfo('gitlab-c-ext-inherited-callbacks-memory/'+str(p.relative_to(stage)));info.size=p.stat().st_size;info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(p.read_bytes()))
 with tarfile.open(arc,'r:gz') as t:actual={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers()}
 assert actual=={'gitlab-c-ext-inherited-callbacks-memory/'+str(p.relative_to(stage)):digest(p) for p in stage.rglob('*') if p.is_file()}
 assert all(digest(Path(p))==h for p,h in priors.items())
 for row in catalog:
  if row['path'] in files:assert digest(R/row['path'])==row['sha256'],('source changed during packing',row['path'])
 result=dict(status='PASS',archive=str(arc),bytes=arc.stat().st_size,sha256=digest(arc),members=len(actual),prior_archives_preserved=True)
 (D/'archive_validation.json').write_text(json.dumps(result,indent=2)+'\n');(D/'SHA256SUMS').write_text(f"{result['sha256']}  {arc.name}\n");print(json.dumps(result))
if __name__=='__main__':main()
