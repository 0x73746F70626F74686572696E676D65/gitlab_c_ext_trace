#!/usr/bin/env python3
"""Independent frozen-overlay joins and source evidence; manual semantic judgments explicit."""
import json,hashlib,re,collections
from pathlib import Path
B=Path('/workspace/gitlab_c_ext_trace');V=Path('/workspace/gitlab_c_ext_v3');errors=[];checks=0;opened={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(cond,msg):
 global checks
 checks+=1
 if not cond:errors.append(msg)
def source(f):
 p=B/f;opened[f]=sha(p);return p.read_text().splitlines()
freeze=V/'reports/memory_semantics_overlay_freeze_v1.json';fr=json.loads(freeze.read_text())
for r in fr['files']:check(sha(V/r['path'])==r['sha256'],'frozen_hash:'+r['path'])
contracts=[json.loads(l) for l in (V/'tables/memory_semantics_contracts_v1.jsonl').open()];ids={r['contract_id']:r for r in contracts}
for c in contracts:
 for e in c['source_evidence']:
  ls=source(e['file']);check(opened[e['file']]==e['source_sha256'],'source_hash:'+e['file']);check('\n'.join(ls[e['line']-1:e['end_line']]).rstrip('\n')==e['excerpt'].rstrip('\n'),'excerpt:'+e['file']+':'+str(e['line']))
rows=[json.loads(l) for l in (V/'tables/physical_site_memory_semantics_v1.jsonl').open()];want={r['site_id'] for r in rows};baseline={}
for l in (B/'tables/primitive_sites.jsonl').open():
 s=json.loads(l)
 if s['site_id'] in want:baseline[s['site_id']]=s
check(len(want)==len(rows),'duplicate_site');check(len({r['semantics_id'] for r in rows})==len(rows),'duplicate_semantics_id')
for r in rows:
 s=baseline[r['site_id']];ls=source(r['file']);check(r['operation']==s['operation'] and s['site_kind']=='call_token','site_operation:'+r['site_id']);check(r['line']==s['line'] and r['file']==s['canonical_source_path'],'site_location:'+r['site_id']);check(opened[r['file']]==r['source_sha256'],'site_source_hash:'+r['site_id']);check(re.search(r'\b'+re.escape(r['operation'])+r'\s*\(',ls[r['line']-1]) is not None,'site_line_call:'+r['site_id']);check(r['contract_id'] in ids and ids[r['contract_id']]['api']==r['operation'],'contract_join:'+r['site_id']);check(r['realized_branch']=='unknown_no_argument_facts' and r['target_resolution']=='unresolved_by_this_overlay' and r['allocation_event_count'] is None and r['copy_event_count'] is None,'unsupported_outcome:'+r['site_id'])
# Independent supporting helper excerpts complete allocation/sharing details beyond original narrow API spans.
specs=[('string.c',231,234,'Embeddability depends on GC allocatable-size predicate, not fixed23byte assumption.'),('string.c',835,854,'Embedded and heap String allocation helpers allocate GC objects via NEWOBJ_OF; heap helper is not itself backing-buffer malloc.'),('string.c',1423,1439,'heap_str_make_shared creates wrapper and shares original pointer, changing ownership flags rather than copying content.'),('string.c',1489,1492,'Helper copies encoding and freezes result; no additional content copy implied.'),('bignum.c',3030,3047,'Bignum GC object allocation; digit array embedded or ALLOC_N by size predicate, not unconditional backing buffer.'),('bignum.c',134,136,'bignew macro binds rb_cInteger to bignew_1 allocation helper.'),('include/ruby/internal/arithmetic/fixnum.h',39,52,'Signed FIXABLE combines upper/lower platform-defined bounds.')]
e=[]
for f,a,z,c in specs:
 f='sources/runtime/ruby-v3_3_11/'+f;ls=source(f);e.append(dict(file=f,line=a,end_line=z,source_sha256=opened[f],excerpt='\n'.join(ls[a-1:z]),claim=c))
judgments=[dict(api='rb_str_new',status='supported_conditional_API_semantics',reason='Actual str_new0 rejects negative len, selects embedded versus external buffer allocation, and only copies when ptr nonnull. Zero count is not positive-byte copy. Terminal caller inputs remain unknown.'),dict(api='rb_str_buf_new',status='supported_conditional_API_semantics',reason='Nonnegative valid capacity selects embedded GC storage versus GC object plus ALLOC_N(capa+1). No source buffer; adjacent63minimum macro unused. Capacity not total heap consumption.'),dict(api='rb_str_new_frozen',status='supported_conditional_API_semantics',reason='Frozen input returns itself; mutable embedded OR embeddable copies; nonembeddable shared input may reuse root or allocate sharing wrapper. Helper late embeddable branch repeats rejected predicate for copy_encoding TRUE, so not treated as additional guaranteed copy outcome.'),dict(api='LONG2NUM',status='supported_conditional_API_semantics',reason='Macro resolves rb_long2num_inline; FIXABLE tagged immediate versus signed normalization and Bignum allocation. Platform/digit layout controls storage. No numeric values or allocation counts inferred.')]
report=dict(status='PASS' if not errors else 'FAIL',freeze_manifest_sha256=sha(freeze),checks=checks,errors=errors,contract_semantic_judgments=judgments,physical_site_rows=len(rows),by_operation=dict(collections.Counter(r['operation'] for r in rows)),opened_source_files=len(opened),source_manifest=opened,supplemental_source_evidence=e,review_method='Manual independent full source pre-read of API definitions and helper branches before frozen model arrived; then compared contract claims and independently checked every frozen site join/hash/call line. Not agreement with graph flags.',limitations=['971 exact operation call tokens include retained source roles/versions beyond primary gems; not971runtime-reachable sites.','Target identity explicitly unresolved by overlay; local shadows/interposition must be excluded separately before applying contract.','No taint, input value, feasible route, realized branch, allocation/copy count or exact heap bytes derived.','Successful-operation outcome descriptions are conditional on valid API domain, matching runtime and normal allocation; exceptional allocator instrumentation effects outside model.','Original11fixtures mostly matcher exclusions and assertions about handwritten branch definitions: regression integrity only, not independent semantic precision or production recall.','Supplemental helper evidence strengthens source support without changing frozen tables.'],frozen_files_modified=False)
p=V/'reports/memory_semantics_independent_review_v1.json';p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],checks=checks,errors=errors,sites=len(rows),source_files=len(opened),report_sha256=sha(p))))
