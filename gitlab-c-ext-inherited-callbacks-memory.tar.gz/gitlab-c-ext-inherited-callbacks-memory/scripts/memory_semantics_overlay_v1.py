#!/usr/bin/env python3
"""Exact-name, source-conditioned API semantics; no execution or taint inference."""
import argparse,hashlib,json
from collections import Counter
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_trace');V=Path('/workspace/gitlab_c_ext_v3')
APIS=('rb_str_new_frozen','rb_str_buf_new','rb_str_new','LONG2NUM')
def classify(operation,site_kind):
 return operation if site_kind=='call_token' and operation in APIS else None

def definitions():
 return {
 'rb_str_new_frozen':dict(arguments={'orig':'Ruby String object'},branches=[
  dict(guard='OBJ_FROZEN(orig)',object_effect='returns_existing_object',input_copy='none',separate_buffer='none'),
  dict(guard='!OBJ_FROZEN(orig) && (STR_EMBED_P(orig) || STR_EMBEDDABLE_P(len,termlen))',object_effect='new_String_object',input_copy='copies len bytes through str_new0; positive copy only len>0',separate_buffer='embedded storage in GC object'),
  dict(guard='!OBJ_FROZEN(orig) && !(STR_EMBED_P(orig) || STR_EMBEDDABLE_P(len,termlen))',object_effect='new sharing wrapper or existing shared root depending further guards',input_copy='not guaranteed; source backing storage may be shared',separate_buffer='no guaranteed new backing buffer')],global_note='Do not equate freeze constructor invocation with byte copy or new allocation. Source identity/storage may be shared.'),
 'rb_str_buf_new':dict(arguments={'capa':'nonnegative requested capacity excluding terminator; invalid-domain behavior not modeled'},branches=[
  dict(guard='STR_EMBEDDABLE_P(capa,1)',object_effect='new_String_object',input_copy='none: no source buffer argument',separate_buffer='embedded storage in GC object sized header+capa+1 then GC slot sizing'),
  dict(guard='!STR_EMBEDDABLE_P(capa,1)',object_effect='new_String_object',input_copy='none: no source buffer argument',separate_buffer='ALLOC_N(char,capa+1) plus String object')],global_note='Capacity argument is not actual heap consumption. STR_BUF_MIN_SIZE63 is not used in retained rb_str_buf_new implementation.'),
 'rb_str_new':dict(arguments={'ptr':'source buffer pointer, may be NULL','len':'byte length'},branches=[
  dict(guard='len>=0 && STR_EMBEDDABLE_P(len,1)',object_effect='new_String_object',input_copy='if ptr!=NULL memcpy(ptr,len); positive copy only len>0',separate_buffer='embedded storage in GC object'),
  dict(guard='len>=0 && !STR_EMBEDDABLE_P(len,1)',object_effect='new_String_object',input_copy='if ptr!=NULL memcpy(ptr,len); positive copy only len>0',separate_buffer='rb_xmalloc_mul_add_mul(sizeof(char),len,sizeof(char),1) plus String object'),
  dict(guard='len<0',object_effect='raises before normal String allocation',input_copy='none on this exceptional branch',separate_buffer='none for result String; exception effects not modeled')],global_note='NULL source creates storage without copying caller bytes. Requested len is not allocator overhead/slot consumption.'),
 'LONG2NUM':dict(arguments={'v':'signed C long value'},branches=[
  dict(guard='RB_FIXABLE(v)',object_effect='immediate tagged Fixnum',input_copy='none',separate_buffer='none: no fresh object or backing buffer from this conversion'),
  dict(guard='!RB_FIXABLE(v)',object_effect='rb_int2big→rb_uint2big constructs Bignum object',input_copy='no caller buffer argument',separate_buffer='Bignum digit storage implementation dependent; not inferred')],global_note='Per-value Fixnum bounds and build word size matter. Call count does not imply allocation; no concrete argument range inferred here.')}

SPECS={
'rb_str_new_frozen':[('string.c',1330,1335,['if (OBJ_FROZEN(orig)) return orig;']),('string.c',1417,1421,['str_new_frozen_buffer(klass, orig, TRUE)']),('string.c',867,899,['memcpy(RSTRING_PTR(str), ptr, len)']),('string.c',1441,1489,['STR_EMBED_P(orig) || STR_EMBEDDABLE_P(len, termlen)','return shared;','heap_str_make_shared(klass, orig)'])],
'rb_str_buf_new':[('string.c',1508,1525,['STR_EMBEDDABLE_P(capa, 1)','str_alloc_embed(rb_cString, capa + 1)','ALLOC_N(char, (size_t)capa + 1)']),('string.c',195,210,['rb_gc_obj_slot_size(str)','offsetof(struct RString, as.embed.ary) + capa']),('gc.c',2772,2793,['CEILDIV(size, BASE_SLOT_SIZE)'])],
'rb_str_new':[('string.c',900,910,['str_new0(klass, ptr, len, 1)','str_new(rb_cString, ptr, len)']),('string.c',867,899,['if (len < 0)','STR_EMBEDDABLE_P(len, termlen)','if (ptr)','memcpy(RSTRING_PTR(str), ptr, len)'])],
'LONG2NUM':[('include/ruby/internal/arithmetic/long.h',46,57,['#define LONG2NUM','#define RB_LONG2NUM']),('include/ruby/internal/arithmetic/long.h',307,314,['if (RB_FIXABLE(v))','return RB_LONG2FIX(v)','return rb_int2big(v)']),('include/ruby/internal/arithmetic/fixnum.h',47,52,['#define RB_FIXABLE']),('include/ruby/internal/arithmetic/long.h',110,128,['RB_INT2FIX(long i)','(j << 1) + RUBY_FIXNUM_FLAG','return n']),('bignum.c',3193,3200,['rb_uint2big','bignew(']),('bignum.c',3215,3233,['rb_int2big','rb_uint2big(u)'])]}

def emit(root=R,out=V):
 contracts=[];checks=0
 for api,model in definitions().items():
  evidence=[]
  for relative,a,b,anchors in SPECS[api]:
   file='sources/runtime/ruby-v3_3_11/'+relative;raw=(root/file).read_bytes();excerpt='\n'.join(raw.decode().split('\n')[a-1:b])
   for anchor in anchors:
    assert anchor in excerpt,(api,file,a,anchor);checks+=1
   evidence.append(dict(file=file,line=a,end_line=b,source_sha256=hashlib.sha256(raw).hexdigest(),excerpt=excerpt,required_anchors=anchors))
  contracts.append(dict(contract_id='ruby3311_memory_'+api+'_v1',api=api,scope='conditional_source_API_semantics',runtime_source_commit='1f2d15125a2dc701e1822ed2900eb17899500ec7',applicability=['C operation actually resolves to corresponding retained Ruby API; lexical name alone does not prove target; no shadow/redefinition/interposition.','Matching Ruby3.3.11 implementation/headers and normal valid API inputs unless exceptional branch explicitly specified.','No actual deployed runtime/build/argument values established by overlay.'],source_evidence=evidence,**model))
 t=out/'tables';p=out/'reports';t.mkdir(exist_ok=True,parents=True);p.mkdir(exist_ok=True,parents=True)
 (t/'memory_semantics_contracts_v1.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in contracts))
 counts=Counter();total=0;seen=set()
 with (t/'physical_site_memory_semantics_v1.jsonl').open('w') as f:
  for line in (root/'tables/primitive_sites.jsonl').open():
   site=json.loads(line);total+=1;api=classify(site['operation'],site['site_kind'])
   if not api:continue
   assert site['site_id'] not in seen;seen.add(site['site_id']);counts[api]+=1
   cid='ruby3311_memory_'+api+'_v1';key=hashlib.sha256((site['site_id']+'|'+cid).encode()).hexdigest()[:24]
   row=dict(semantics_id='memsem_'+key,site_id=site['site_id'],contract_id=cid,operation=api,file=site['canonical_source_path'],line=site['line'],source_sha256=site['source_sha256'],gem_ids=site['gem_ids'],match_basis='exact_operation_token_and_call_token_kind',target_resolution='unresolved_by_this_overlay',realized_branch='unknown_no_argument_facts',allocation_event_count=None,copy_event_count=None,site_count_unit='one physical discovery call token; not execution, allocation, copied bytes or heap usage',status='conditional_source_model_only')
   f.write(json.dumps(row,sort_keys=True)+'\n')
 report=dict(status='additive_conditional_semantics_overlay',physical_site_input_rows=total,matched_physical_call_sites=sum(counts.values()),matched_by_exact_API=dict(counts),source_anchor_checks=checks,source_anchor_errors=0,semantic_contracts=4,realized_argument_branches=0,guaranteed_runtime_allocations_inferred=0,limits=['No discovery IDs or classifications overwritten.','Physical-site operation counts are not dynamic calls or allocations.','Four exact names only; aliases, qualified spellings, wrappers, local overrides and other APIs are deliberately outside matching scope.','All sources/roles/lock variants from physical-site census; not primary-only, runtime feasibility or source-data influence.','No existing request-flow or frozen decisions changed.'],input_sha256=hashlib.sha256((root/'tables/primitive_sites.jsonl').read_bytes()).hexdigest())
 (p/'memory_semantics_overlay_v1.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--root',type=Path,default=R);a.add_argument('--out',type=Path,default=V);n=a.parse_args();emit(n.root,n.out)
