import sys,json,pathlib
V=pathlib.Path('/workspace/gitlab_c_ext_v3');sys.path.insert(0,str(V/'scripts'))
from link_inherited_controller_callbacks import resolve_target,superclass_step,superclass_source_unconditional
from link_direct_controller_callbacks import declaration_eligibility
from ruby_argument_flow_iteration5 import FlowSource
out=[]
def m(owner,kind='instance'):return dict(namespace=owner,method='gate',kind=kind)
def test(name,condition):out.append(dict(case_id=name,status='PASS'if condition else'FAIL',evaluation='independent_static_analyzer_fixture'))
def lookup(defs,rels={},check=lambda m:None):return resolve_target(['Child','Parent','Base'],'gate',defs,rels,check)
p={('Parent','gate','instance'):[m('Parent')]};c={**p,('Child','gate','instance'):[m('Child')]}
test('unique_superclass_target',lookup(p)[0]['namespace']=='Parent')
test('subclass_override',lookup(c)[0]['namespace']=='Child')
test('singleton_only',lookup({('Parent','gate','singleton'):[m('Parent','singleton')]})[0]is None)
test('private_instance',lookup({('Parent','gate','instance'):[{**m('Parent'),'visibility':'private'}]})[0]['namespace']=='Parent')
test('conditional_override',lookup(c,check=lambda m:'conditional'if m['namespace']=='Child'else None)[0]is None)
test('known_prepend',lookup(c,{'Child':[{'kind':'prepend'}]})[0]is None)
test('intervening_include',lookup(p,{'Child':[{'kind':'include'}]})[0]is None)
test('ambiguous_superclass',superclass_step([{'kind':'superclass','target_candidates':['A','B']}],{'A','B'},lambda r:True)[0]is None)
def decl(**kw):return dict(api='before_action',block_body=None,filters=['gate'],only=kw.get('only'),except_actions=kw.get('except'),option_expressions={k:str(v)for k,v in kw.items()})
test('literal_only_excludes',declaration_eligibility(decl(only=['index']),'show')=='literal_only_excludes_action')
test('literal_except_excludes',declaration_eligibility(decl(**{'except':['show']}),'show')=='literal_except_excludes_action')
test('predicate_unknown',declaration_eligibility(decl(**{'if':':enabled?'}),'show')is None)
test('namespaced_superclass',superclass_step([{'kind':'superclass','target_candidates':['Space::Base','Base']}],{'Space::Base','Base'},lambda r:True)[0]is None)
for name,reason in [('skip_same_symbol','Frozen ICB002/014 retain skip references and partial flags; ordinary source activation contradicted, no complete claim.'),('duplicate_registration','Frozen ICB005 carries duplicate/order unresolved; source callback duplicate removal blocks accept after only:show replacement.'),('unknown_block_invocation','Implementation retains declaration_conditions as conditional_registration_or_concern_activation; no activation flag true.'),('no_route_method','Main selected_routes requires source-bound action method; otherwise no_source_bound_route_action_method hole, before edge construction.')]:out.append(dict(case_id=name,status='PASS_WITH_SCOPE_QUALIFICATION',evaluation='manual_source_and_output_control_review_not_executable_fixture',reason=reason))
r={'status':'PASS'if all(x['status']!='FAIL'for x in out)else'FAIL','expectations':16,'executed_static_analyzer_fixtures':12,'manual_control_reviews':4,'target_runtime_executed':False,'results':out};(V/'audit/inherited_callbacks_holdout/regression_results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
