import json,pathlib,hashlib,random,collections
V=pathlib.Path('/workspace/gitlab_c_ext_v3');D=V/'audit/inherited_callbacks_holdout';rng=random.Random(202609301001);out=[];inputs={}
for p in ['ce','ee']:
 f=V/f'tables/{p}_inherited_callback_invocation_edges.jsonl';inputs[str(f.relative_to(V))]=hashlib.sha256(f.read_bytes()).hexdigest();rs=[json.loads(l)for l in f.open()];ev={r['evidence_id']:r for r in map(json.loads,(V/f'tables/{p}_inherited_callback_invocation_evidence.jsonl').open())};rng.shuffle(rs);picked=[];used=set()
 tests=[('override',lambda r:r['class_chain'].index(r['target_owner'])<r['class_chain'].index(r['registration_owner'])),('skip',lambda r:bool(r['skip_candidate_ids'])),('guard',lambda r:any(k in r['selectors']['options']for k in ('if','unless'))),('only',lambda r:r['selectors']['only']is not None),('except',lambda r:r['selectors']['except_actions']is not None),('ancestor_target',lambda r:r['target_owner']!=r['receiver_owner'])]
 for name,test in tests:
  cs=[r for r in rs if test(r) and r['edge_id']not in used and r['receiver_owner']!='Profiles::PasskeysController'];div=[r for r in cs if r['receiver_owner']not in {x['receiver_owner']for x in picked}]
  if cs:r=(div or cs)[0];picked.append({**r,'sampling_stratum':name});used.add(r['edge_id'])
 for r in rs:
  if len(picked)>=12:break
  if r['edge_id']in used or r['receiver_owner']=='Profiles::PasskeysController' or r['receiver_owner']in{x['receiver_owner']for x in picked}:continue
  picked.append({**r,'sampling_stratum':'random_diverse_receiver'});used.add(r['edge_id'])
 if len(picked)<12:
  for r in rs:
   if len(picked)>=12:break
   if r['edge_id']not in used and r['receiver_owner']!='Profiles::PasskeysController':picked.append({**r,'sampling_stratum':'random_fill'});used.add(r['edge_id'])
 for r in picked:r['source_evidence']=[ev[x]for x in r['source_evidence_ids']]
 out+=picked
for i,r in enumerate(out,1):r['audit_id']=f'ICB{i:03}'
f=D/'sample.jsonl';f.write_text(''.join(json.dumps(r)+'\n'for r in out));m={'seed':202609301001,'inputs':inputs,'sample_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'rows':len(out),'design':'12/profile seeded shuffled rare-strata override/skip/guard/only/except/ancestor target then receiver-diverse fill. Excludes prior passkey manual case; inherited edge IDs disjoint direct audit. Nonuniform purposive stratification; no population precision inference. Frozen before semantic source review.'};(D/'selection_freeze.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m));print([(r['audit_id'],r['profile'],r['receiver_owner'],r['action'],r['symbol'],r['registration_owner'],r['target_owner'],r['sampling_stratum'])for r in out])
