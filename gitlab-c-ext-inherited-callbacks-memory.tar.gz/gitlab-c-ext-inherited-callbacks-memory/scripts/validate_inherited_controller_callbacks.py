import collections,hashlib,json,pathlib
from link_inherited_controller_callbacks import resolve_target,superclass_source_unconditional
from link_direct_controller_callbacks import Sources,declaration_eligibility,zero_argument_body_possible,rows,V,B,MODEL
checks=0;sources=Sources();counts={}
def check(x):
 global checks
 checks+=1;assert x
for profile,G,prefix in [('ce',pathlib.Path('/workspace/gitlab_c_ext_ruby_expanded'),'sources/gitlab/'),('ee',pathlib.Path('/workspace/gitlab_c_ext_ee_profile'),'sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/')]:
 P=V/'profiles'/profile/'tables';ds={r['callback_demand_id']:r for r in rows(P/'controller_callback_demands.jsonl')};cs={r['callback_id']:r for r in rows(P/'controller_callback_declarations.jsonl')};routes={r['scope_occurrence_id']:r for r in rows(P/'route_scope_bindings.jsonl')};edges=list(rows(V/'tables'/f'{profile}_inherited_callback_invocation_edges.jsonl'));evrows=list(rows(V/'tables'/f'{profile}_inherited_callback_invocation_evidence.jsonl'));evs={r['evidence_id']:r for r in evrows};check(len(evs)==len(evrows));check(len(edges)==len({e['edge_id'] for e in edges}));owners={o for e in edges for o in e['class_chain']};defs=collections.defaultdict(list);methods={}
 for m in rows(G/'tables/ruby_methods.jsonl'):
  if m['namespace'] in owners and (m['file'].startswith(prefix) or m['file'].startswith('sources/wrappers/rails-7.2.3.1/')) and not any(x in m['file'] for x in ('/spec/','/test/','/qa/','/fixtures/')):defs[(m['namespace'],m['method'],m['kind'])].append(m);methods[m['method_id']]=m
 byowner=collections.defaultdict(list);rels={}
 for r in rows(G/'tables/ruby_inheritance.jsonl'):
  if r['owner'] in owners and (r['file'].startswith(prefix) or r['file'].startswith('sources/wrappers/rails-7.2.3.1/')) and not any(x in r['file'] for x in ('/spec/','/test/','/qa/','/fixtures/')):byowner[r['owner']].append(r);rels[r['inheritance_id']]=r
 def methodcheck(m):
  s,n=sources.node(m)
  return 'unparsed_conditional' if n is None or n.has_error or s.method_context[n.start_byte][2] else 'arity' if not zero_argument_body_possible(s,n) else None
 for ev in evrows:
  src=sources.get(ev['file']);check(hashlib.sha256(src.data).hexdigest()==ev['sha256']);check('\n'.join(src.data.decode().splitlines()[ev['line']-1:ev['end_line']])==ev['excerpt'])
  if profile=='ee':check(not ev['file'].startswith('sources/gitlab/'))
 for e in edges:
  check(e['callback_id'] in cs and e['callback_demand_id'] in ds and e['target_method_id'] in methods);c=cs[e['callback_id']];m=methods[e['target_method_id']];check(e['registration_owner']==c['owner'] and c['owner'] in e['class_chain'][1:]);check(e['receiver_owner']==e['class_chain'][0] and e['class_chain'][-1]=='ActionController::Base');check(e['registration_owner']!=e['receiver_owner']);check(m['namespace']==e['target_owner'] and m['method']==e['symbol'] and m['kind']=='instance');check(declaration_eligibility(c,e['action']) is None and sources.literal_symbols(c));selected,reason,preceding=resolve_target(e['class_chain'],e['symbol'],defs,byowner,methodcheck);check(reason is None and selected['method_id']==e['target_method_id']);check(preceding==e['lookup_preceding_classes']);check(not e['may_seed_complete_path'] and not e['runtime_exposure_proven'] and not e['callback_activated_proven'] and e['new_native_paths']==0);check(bool(e['unresolved_constraints']));check(all(i in evs for i in e['source_evidence_ids']));check(e['framework_model']['sha256']==hashlib.sha256(MODEL.read_bytes()).hexdigest())
  for rid in e['route_scope_occurrence_ids']:
   r=routes[rid];check(r['owner']==e['receiver_owner'] and r['method']==e['action'] and bool(r['method_ids']))
  for rid in e['framework_ancestry_ids']:
   r=rels[rid];check(r['kind']=='superclass' and superclass_source_unconditional(sources.get(r['file']),r['line']))
  if e['skip_candidate_ids']:check('matching_skip_may_remove_or_condition_callback' in e['unresolved_constraints'])
 holes=list(rows(V/'tables'/f'{profile}_inherited_callback_invocation_unresolved.jsonl'));check(len(holes)==len({r['unresolved_id'] for r in holes}));check(all(r['callback_demand_id'] in ds for r in holes));counts[profile]=dict(edges=len(edges),holes=len(holes),normalized_evidence=len(evs))
# Direct frozen bundle must remain exact.
m=json.load(open(V/'reports/direct_callback_invocation_freeze.json'))
for p,x in m['files'].items():check(hashlib.sha256((V/p).read_bytes()).hexdigest()==x['sha256'])
report=dict(status='pass',checks=checks,errors=0,profiles=counts,direct_frozen_manifest_unchanged=True,scope='Source/PK/FK/lookup/arity/partial flags; independent fresh semantic sample separate');(V/'reports/inherited_callback_invocation_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
