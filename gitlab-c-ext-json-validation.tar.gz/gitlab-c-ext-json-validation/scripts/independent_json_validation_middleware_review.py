#!/usr/bin/env python3
"""Independent source-evidence integrity checks; semantic judgments from manual review."""
import json,hashlib
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3'); B=Path('/workspace/gitlab_c_ext_trace')
errors=[]; checks=0; cache={}
def walk(x):
 global checks
 if isinstance(x,list):
  for v in x:walk(v)
 elif isinstance(x,dict):
  if x.get('file') and x.get('line') and ('excerpt' in x or 'source_text' in x):
   p=B/x['file'];data=cache.setdefault(str(p),p.read_bytes()); lines=data.decode(errors='replace').split('\n')
   checks+=1
   if '\n'.join(lines[x['line']-1:x.get('end_line',x['line'])])!=x.get('excerpt',x.get('source_text')):errors.append({'file':str(p),'line':x['line'],'error':'excerpt'})
   sha=x.get('source_sha256',x.get('sha256'))
   if sha:
    checks+=1
    if hashlib.sha256(data).hexdigest()!=sha:errors.append({'file':str(p),'error':'sha256'})
  for v in x.values():walk(v)
freeze=V/'reports/json_validation_middleware_flow_freeze.json';expected='5c0e001fb75a31baad5bb008092960737fcd00a6432a6b8b908be56c4faf81c9';checks+=1
if hashlib.sha256(freeze.read_bytes()).hexdigest()!=expected:errors.append({'error':'freeze_manifest_hash'})
spec=json.loads(freeze.read_text())['files']
for rel,m in spec.items():
 checks+=1
 if hashlib.sha256((V/rel).read_bytes()).hexdigest()!=m['sha256']:errors.append({'file':rel,'error':'frozen_hash'})
rows=[json.loads(l)for l in (V/'tables/request_memory_flows_json_validation.jsonl').read_text().splitlines()];walk(rows)
judgments={
 'entrypoint':'Both retained CE/EE application.rb524 explicitly insert JsonValidation after ShowExceptions with no custom options. Actual installed runtime stack/outer admission is still conditional. Selected POST /-/collect_events route pattern is first in ordinary ROUTE_CONFIGS and overrides max_json_size_bytes with10MiB after relative-root normalization/method filtering.',
 'guards':'global mode != disabled, JSON MIME recognized, selected route mode != disabled. Selected path is neither internal API nor Duo; their verification/GET stripping not invoked. Absent gzip content encoding excludes CompressedJson transformation. No arbitrary/all-routes/authentication-bypass conclusion.',
 'value_transfer':'Rack Request#body returns rack.input. validate_json_request! reads body before rewinding; the returned String is passed unchanged to StreamValidator.new(limits).validate!. Normal Class.new allocator/initialize model and source initialize preserve options. Oj.sc_parse receives handler and body directly; safe_parse and its20MiB bound are not part of this prefix.',
 'bounds':'StreamValidator check_body_size! returns unless configured limit.to_i>0. Generic0 disables that size check, not zero-byte cap. Selected10MiB override applies to String bytesize before Oj but after potentially larger IO read/allocation. Overlimit logging may forward downstream but does not resume this native parse. Small selected object admitted; depth/numeric/encoding guards retained.',
 'native':'Object bypasses primitive/numeric/simple-string skip. First object-start callback must return normally; implemented hash_key method activates native key constructor. Reused frozen Oj String branch and UTF8/ASCII-BINARY encoding model supports key bytes and derived key span, not original pointer identity or arbitrary count. No new native mechanism/site asserted.',
 'scope':'Two profile-specific middleware prefixes on existing collect_events route; same Oj key terminal and mechanism already reviewed for controller paths. No gzip partial upgrade, no extra external route family, no all-route closure, no observed runtime activation.'}
report={'status':'PASS'if not errors else'FAIL','checks':checks,'errors':errors,'source_files_checked':len(cache),'freeze_manifest_sha256':expected,'recipe_sha256':spec['tables/request_memory_flows_json_validation.jsonl']['sha256'],'profiles':[r['profile']for r in rows],'flows':len(rows),'distinct_physical_sites':len({r['terminal_site_id']for r in rows}),'new_physical_sites':0,'runtime_verified':False,'independent_judgments':judgments}
(V/'reports/json_validation_middleware_independent_review.json').write_text(json.dumps(report,indent=2)+'\n')
(V/'tables/json_validation_middleware_independent_review.jsonl').write_text(''.join(json.dumps({'flow_id':r['flow_id'],'profile':r['profile'],'status':'source_supported_conditional_middleware_prefix','terminal_site_id':r['terminal_site_id'],'runtime_verified':False,'judgments':judgments})+'\n'for r in rows))
print(json.dumps(report,indent=2))
