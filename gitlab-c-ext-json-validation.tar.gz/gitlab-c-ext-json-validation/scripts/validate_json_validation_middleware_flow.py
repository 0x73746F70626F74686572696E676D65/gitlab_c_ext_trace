import hashlib,json,pathlib
V=pathlib.Path(__file__).resolve().parents[1];B=pathlib.Path('/workspace/gitlab_c_ext_trace');rows=list(map(json.loads,open(V/'tables/request_memory_flows_json_validation.jsonl')));checks=0
assert len(rows)==2 and len({r['flow_id'] for r in rows})==2
hashes={}
def visit(x):
 global checks
 if isinstance(x,dict):
  if 'file' in x and 'source_sha256' in x:
   p=x['file'];data=(B/p).read_bytes();h=hashes.setdefault(p,hashlib.sha256(data).hexdigest());assert h==x['source_sha256'];checks+=1
   lines=data.decode().splitlines()
   if 'excerpt' in x:assert '\n'.join(lines[x['line']-1:x['end_line']])==x['excerpt'];checks+=1
   if 'source_text' in x:assert lines[x['line']-1]==x['source_text'];checks+=1
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
for r in rows:
 visit(r);body=r['selected_request']['illustrative_body'];obj=json.loads(body);assert body.isascii() and isinstance(obj,dict) and all(k and k.isascii() and '\\' not in k for k in obj);assert len(body.encode())<=r['bounds']['selected_route_max_body_bytes'];assert r['bounds']['selected_route_max_body_bytes']==10485760;assert not r['gzip_partial_promoted'] and not r['all_routes_claim'];checks+=4
report=dict(status='pass',checks=checks,errors=0,unique_source_files=len(hashes),semantic_scope='Source/hash agreement, selected literal shape and scope assertions; not runtime proof or independent source review')
(V/'reports/json_validation_middleware_flow_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
