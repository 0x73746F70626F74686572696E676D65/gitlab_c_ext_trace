#!/usr/bin/env python3
"""Independent source-evidence integrity checks; semantic judgments from manual review."""
import json,hashlib
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3'); B=Path('/workspace/gitlab_c_ext_trace')
errors=[]; checks=0; cache={}
def walk(x):
 global checks
 if isinstance(x,list):
  for v in x:walk(v)
 elif isinstance(x,dict):
  if x.get('file') and x.get('line') and 'excerpt' in x:
   p=B/x['file'];data=cache.setdefault(str(p),p.read_bytes()); lines=data.decode(errors='replace').split('\n')
   checks+=1
   if '\n'.join(lines[x['line']-1:x.get('end_line',x['line'])])!=x['excerpt']:errors.append({'file':str(p),'line':x['line'],'error':'excerpt'})
   sha=x.get('source_sha256',x.get('sha256'))
   if sha:
    checks+=1
    if hashlib.sha256(data).hexdigest()!=sha:errors.append({'file':str(p),'error':'sha256'})
  for v in x.values():walk(v)
inputs={}
spec={'tables/rails_request_json_source_recipe.jsonl':'c39a54699a021599df92bee380ad0f7be57855257ccd5efd7c24e6331cf5b8a2','tables/rails_request_json_memory_flows.jsonl':'6ed606d05a0e9ea9cfac01f179316787a0e0398216d7733a7f91ab4d27f73230','tables/json_native_request_flow_contract.jsonl':'a5aa8fcc9f5be2ae789abdc8be5ceb5877a6ab361e6430430ae8f24dee2cf36d','reports/json_capacity_runtime_review.json':'2e34bc63226034c1d06c221a77e99fb820e02064c1421da45d08f3dbf4f6c202'}
for rel,sha in spec.items():
 data=(V/rel).read_bytes();inputs[rel]=hashlib.sha256(data).hexdigest();checks+=1
 if inputs[rel]!=sha:errors.append({'file':rel,'error':'frozen_input_hash'})
 walk([json.loads(l) for l in data.splitlines()] if rel.endswith('.jsonl') else json.loads(data))
flows=[json.loads(l) for l in (V/'tables/rails_request_json_memory_flows.jsonl').read_text().splitlines()]
judgments={
 'route_and_phase':'Selected main /- scope draws profile resource/module then resources passkeys create. Controller ancestry reaches ActionController::Base. RouteSet dispatch resolves controller and action; Metal dispatch constructs controller through middleware then process(name). ActionControllerStaticContext reads path_parameters, not JSON params. ParamsWrapper included after Instrumentation/Callbacks and its process_action executes predicate before super under ordinary lookup.',
 'forcing_and_cache':'Exact selected force is request.parameters.key?(_wrapper_key) in _wrapper_enabled? line294, before _perform_parameter_wrapping. JSON format and nonnil inferred wrapper key prerequisites are retained. Combined cache absent and request_parameters cache absent force POST→parse_formatted_parameters→JSON strategy. Later successful wrapper/instrumentation/controller param reads normally reuse caches; no double-parse or earliest-native-parser claim. ParseError rescue only affects failure branch, excluded selected success case.',
 'body_and_options':'Correct positive Content-Length, no Transfer-Encoding/compression, unchanged complete body/RAW_POST_DATA and successful rewind/read transfer selected bytes to raw_post. JSON DEFAULT_PARSERS calls ActiveSupport::JSON.decode; decode passes quirks_mode:true; ParserOptions.prepare leaves this ordinary Hash unchanged; native non-strict config ignores unknown key. Source loading installs native singleton parse, but actual unchanged backend/loading is explicitly a precondition, not observed fact.',
 'native_and_memory':'For selected ASCII object value abc backslash-n def, raw escaped byte span8 reaches rb_str_buf_new and first literal prefix3 reaches MEMCPY. Capacity is not decoded string length or exact heap consumption. Ruby3.3.11 embedded object vs separate ALLOC_N branch is conditional; matching runtime/core semantics retained. No arbitrary pointer/count, overflow or vulnerability inference.',
 'admission':'ParamsWrapper executes before lower action callback chain under normal source lookup. Therefore action authentication/password/CSRF callbacks are not prerequisites for this selected pre-action operation. Outer middleware/routing admission is still required; no universal unauthenticated reachability claim. Earlier JsonValidation may already parse using Oj, then rewind and store metadata without populating selected Rails param caches.',
 'conditions_not_closed':'Source evidence does not prove all middleware states, completed boot, actual deployed parser version, no later monkey patches/Oj replacement, successful allocation or admitted request. Conditional source-supported recipe remains separate from runtime verification and automatic candidate graph.'}
rows=[{'flow_id':f['flow_id'],'status':'source_supported_conditional_flow','terminal_site_id':f['terminal_site_id'],'runtime_verified':False,'judgments':judgments} for f in flows]
report={'status':'PASS' if not errors else 'FAIL','checks':checks,'errors':errors,'source_files_checked':len(cache),'frozen_inputs':inputs,'flows':len(rows),'distinct_terminal_sites':len({r['terminal_site_id'] for r in rows}),'external_routes':1,'new_external_routes':0,'new_preaction_mechanisms':1,'judgments':judgments,'runtime_verified':False,'counting_note':'Two terminal records for one selected existing CE passkeys route/body/mechanism. Separate from candidate census; handpicked conditional recipe, no population recall/accuracy inference.'}
(V/'reports/rails_json_independent_assembly_review.json').write_text(json.dumps(report,indent=2)+'\n')
(V/'tables/rails_json_independent_assembly_review.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
print(json.dumps(report,indent=2))
