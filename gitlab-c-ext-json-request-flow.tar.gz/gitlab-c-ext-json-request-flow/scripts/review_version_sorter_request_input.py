"""Emit bounded manual-source-review evidence; never executes target code."""
import hashlib,json,pathlib
V=pathlib.Path(__file__).resolve().parents[1];B=pathlib.Path('/workspace/gitlab_c_ext_trace')
def rows(p):
 with open(p) as f:
  for l in f:yield json.loads(l)
def excerpt(file,start,end,reason):
 data=(B/file).read_bytes();lines=data.decode().splitlines();assert 1<=start<=end<=len(lines)
 return dict(file=file,line=start,end_line=end,sha256=hashlib.sha256(data).hexdigest(),excerpt='\n'.join(lines[start-1:end]),reason=reason)
def anchored(file,needle,before,after,reason):
 lines=(B/file).read_text().splitlines();hits=[i for i,l in enumerate(lines) if needle in l];assert len(hits)==1,(file,needle,hits)
 return excerpt(file,max(1,hits[0]+1-before),min(len(lines),hits[0]+1+after),reason)
census=[r for r in rows(V/'audit/candidate_census_iteration3/census_path_dimensions.jsonl') if r['gem']=='version_sorter'];assert len(census)==6
ids={r['path_id'] for r in census};decisions={r['baseline_path_id']:r for r in rows(V/'iterations/iteration6/path_decisions.jsonl') if r['baseline_path_id'] in ids};assert len(decisions)==6
out=[]
for profile,prefix,F in [('ce','sources/gitlab/',pathlib.Path('/workspace/gitlab_c_ext_frontend_v2')),('ee','sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/',pathlib.Path('/workspace/gitlab_c_ext_ee_profile'))]:
 evidence=[
 anchored(prefix+'lib/api/issues.rb',"get ':id/issues/:issue_iid/related_merge_requests'",4,12,'Integer issue_iid and project id select a persisted issue; sorter runs before pagination'),
 anchored(prefix+'lib/api/helpers.rb','def user_project',0,2,'Request id resolves project object'),
 anchored(prefix+'lib/api/helpers.rb','def find_project!(id)',0,15,'Project lookup and authorization gates'),
 anchored(prefix+'lib/api/helpers.rb','def find_project_issue(iid, project_id = nil)',0,8,'IID used in persisted IssuesFinder.find_by!, not passed as raw sorter string'),
 anchored(prefix+'app/services/issues/referenced_merge_requests_service.rb','def related_merge_requests(issue)',0,9,'Materialized MR records are preloaded then sorted'),
 anchored(prefix+'app/services/issues/referenced_merge_requests_service.rb','def related_merge_requests_union(issue)',0,11,'Union of extracted references and persisted relation records; feature condition'),
 anchored(prefix+'app/services/issues/referenced_merge_requests_service.rb','def filter_readable_by_user(merge_requests)',0,13,'Authorization and project filters affect which persisted records remain'),
 anchored(prefix+'app/services/issues/referenced_merge_requests_service.rb','def extract_merge_requests(issue, filter: nil)',0,19,'References derive from stored issue attributes and associated notes'),
 anchored(prefix+'app/models/concerns/mentionable.rb','def all_references(current_user = nil, extractor: nil)',0,24,'Stored mentionable attributes feed reference extraction'),
 anchored(prefix+'app/services/issues/referenced_merge_requests_service.rb','def sort_by_iid(merge_requests)',0,2,'Array and project passed to sorter; supplied iid block is not used by downstream implementation'),
 excerpt(prefix+'lib/gitlab/issuable_sorter.rb',5,29,'Group persisted objects by project/namespace; native block actually returns issuable.to_reference(project)'),
 anchored(prefix+'app/models/merge_request.rb','def to_reference(from = nil, full: false)',0,4,'Native parse strings assembled from persisted MR IID and project reference'),
 anchored(prefix+'app/models/project.rb','def to_reference_base(from = nil, full: false, absolute_path: false)',0,6,'Reference prefix uses persisted path/full_path depending on selected project relation'),
 excerpt('sources/gems/version_sorter-2.3.0/ext/version_sorter/version_sorter.c',183,200,'Native callback consumes Ruby-yielded stored-reference strings'),
 excerpt('sources/gems/version_sorter-2.3.0/ext/version_sorter/version_sorter.c',214,249,'Native xcalloc count is RARRAY_LEN of duplicated grouped array; empty array bypasses xcalloc/free loop'),
 excerpt('sources/gems/version_sorter-2.3.0/ext/version_sorter/version_sorter.c',307,313,'VersionSorter.sort registration points to rb_version_sort')]
 ps={r['path_id']:r for r in rows(F/'tables/frontend_paths.jsonl') if r['path_id'] in ids};prefixes={r['prefix_id']:r for r in rows(F/'tables/frontend_ruby_prefixes.jsonl') if r['prefix_id'] in {p['ruby_prefix_id'] for p in ps.values()}};hids={h for p in prefixes.values() for h in p['hops']};hops={r['hop_id']:r for r in rows(F/'tables/frontend_ruby_hops.jsonl') if r['hop_id'] in hids}
 for dim in census:
  if dim['profile']!=profile:continue
  p=ps[dim['path_id']];decision=decisions[dim['path_id']]
  out.append(dict(review_id='version_sorter_input_'+dim['audit_id'],**dim,iteration6_status=decision['status'],status='selection_only_no_direct_current_request_argument_flow_established',ruby_prefix_id=p['ruby_prefix_id'],registration_id=p['registration_id'],hops=[hops[x] for x in prefixes[p['ruby_prefix_id']]['hops']],request_inputs=[dict(expression='params[:id]',role='persisted project selection'),dict(expression='params[:issue_iid]',role='persisted issue lookup',declared_type='Integer')],native_argument_origin='Array of existing readable referenced/persisted MergeRequest records, grouped by stored project relationships',native_string_origin='Ruby block invokes MergeRequest#to_reference(project): stored project path/full_path and stored MR iid',allocation_count_origin='Grouped array cardinality, from persisted relationship/reference data and authorization/feature filters; not a request count field',pagination_order='paginate is called only after related_merge_requests sorting finishes',direct_current_request_content_flow=False,direct_current_request_numeric_count_flow=False,source_to_sink_client_argument_flow_established=False,selection_influence_supported=True,limitations=['Selection among existing records can change data/cardinality but is not proof that the current request supplies or controls native bytes/count.','Prior issue/note/project/MR writes could create stored influence; no multi-request write/permission/state proof performed.','Feature flags, authentication/readability, overridden methods and actual database state remain conditions.','Negative result is bounded to these six frozen paths/two profile entrypoints, not every VersionSorter call or all application flows.'],evidence=evidence,runtime_verified=False))
with (V/'tables/version_sorter_request_input_review.jsonl').open('w') as f:
 for r in out:f.write(json.dumps(r)+'\n')
report=dict(status='bounded_partial_negative_result',paths=len(out),profile_entrypoints=len({r['entrypoint_id'] for r in out}),physical_sites=len({r['physical_site_id'] for r in out}),route_shape='GET :id/issues/:issue_iid/related_merge_requests',direct_current_request_argument_flows_established=0,selection_only_paths=6,evidence_per_profile=len(out[0]['evidence']),key_findings=['Current request selects existing project/issue; records and reference strings come from persisted state.','Actual native block uses to_reference(project), not the unused iid block supplied to IssuableSorter.sort.','Pagination is after sorting and therefore is not a bound on VersionSorter array allocation.','Native pointer-array allocation count is actual grouped result length; no request numeric field flows directly to it.'],next_step='No native-agent escalation warranted for direct client-input flow. A stored-input claim requires a separate cross-request write/authorization/state proof.',frozen_inputs={'iteration6_decisions_sha256':hashlib.sha256((V/'iterations/iteration6/path_decisions.jsonl').read_bytes()).hexdigest()},frozen_graphs_changed=False)
(V/'reports/version_sorter_request_input_feasibility.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
