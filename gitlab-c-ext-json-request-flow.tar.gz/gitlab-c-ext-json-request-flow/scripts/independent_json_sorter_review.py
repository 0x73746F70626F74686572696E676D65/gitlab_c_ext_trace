#!/usr/bin/env python3
"""Independent source-evidence integrity checks; semantic judgments from manual review."""
import json,hashlib
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3'); B=Path('/workspace/gitlab_c_ext_trace')
errors=[]; checks=0; cache={}
def walk(x):
 global checks
 if isinstance(x,list):
  for v in x:walk(v)
 elif isinstance(x,dict):
  if x.get('file') and x.get('line') and 'excerpt' in x:
   p=B/x['file'];data=cache.setdefault(str(p),p.read_bytes()); lines=data.decode(errors='replace').split('\n')
   checks+=1
   if '\n'.join(lines[x['line']-1:x.get('end_line',x['line'])])!=x['excerpt']:errors.append({'file':str(p),'line':x['line'],'error':'excerpt'})
   sha=x.get('source_sha256',x.get('sha256'))
   if sha:
    checks+=1
    if hashlib.sha256(data).hexdigest()!=sha:errors.append({'file':str(p),'error':'sha256'})
  for v in x.values():walk(v)
inputs={}
for rel in ['tables/json_native_request_flow_contract.jsonl','tables/version_sorter_request_input_review.jsonl']:
 data=(V/rel).read_bytes();inputs[rel]=hashlib.sha256(data).hexdigest();walk([json.loads(l) for l in data.splitlines()])
f=json.loads((V/'reports/version_sorter_request_input_freeze.json').read_text())
for rel,m in f['files'].items():
 checks+=1
 if hashlib.sha256((V/rel).read_bytes()).hexdigest()!=m['sha256']:errors.append({'file':rel,'error':'frozen_input'})
report={'status':'PASS' if not errors else 'FAIL','checks':checks,'errors':errors,'source_files_checked':len(cache),'inputs':inputs,'runtime_verified':False,'independent_semantic_judgments':{
 'version_sorter':'Supported bounded negative/selector-only assessment for six CE/EE paths. Current id/issue_iid selects persisted project/issue; related MR union and readability filters produce stored objects. IssuableSorter.sort captures but does not use caller iid block; natural_sort_issuables passes its own to_reference(project) block. Native rb_yield obtains stored project path/iid string; xcalloc length is grouped array cardinality. Pagination occurs after sorting. No direct current-request byte/count argument established; selection can influence stored population, and prior writes are not audited.',
 'json_binding':'Native Init_parser installs Parser.parse singleton arity2 after Ruby fallback class definition. JSON.parse routes through ParserOptions.prepare then Parser.parse; do not infer Ruby Config.new fallback. Ordinary Rails quirks_mode:true Hash passes prepare unchanged (common.rb10-25); native non-strict parser_config_init_i ignores unknown quirks_mode key (parser.c2006-2077). Actual backend activation and absence of subsequent Oj mimic replacement remain conditions.',
 'json_value_branch':'Selected ASCII object wire {"x":"abc\\ndef"} has raw escaped value length8; scanner records first backslash at offset3 and escaped-string branch calls json_string_unescape with is_name=false. rb_str_buf_new capacity argument8 precedes MEMCPY(buffer,p,char,pe-p) count3. This establishes source-controlled copied prefix and derived capacity/count under selected branch, not arbitrary destination/size or vulnerability.',
 'json_encoding':'UTF8 source normal frozen-copy handling; BINARY branch duplicates and retags UTF8. Byte preservation does not assert original request-pointer identity. Matching retained Ruby3.3.11 MEMCPY/allocator semantics and successful source operations remain assumptions.'},'scope':'Native contract and bounded sorter review; Rails full request admission/cache/lookup assembly reviewed separately when frozen.'}
(V/'reports/independent_json_sorter_source_review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
