#!/usr/bin/env python3
"""Parse retained RBI syntax as non-runtime declarations, never lookup definitions."""
import gzip,json,pathlib,hashlib,collections
from ruby_full_graph import P,OUT,rows,emit,uid
stats=collections.Counter()
with gzip.open(OUT/'tables/ruby_interfaces.jsonl.gz','wt') as out:
 for row in rows(OUT/'tables/ruby_interface_recovery_candidates.jsonl.gz'):
  path=pathlib.Path(row.get('canonical_path') or row['path']);data=path.read_bytes();tree=P.parse(data);decl=[];todo=[tree.root_node]
  while todo:
   n=todo.pop()
   if n.type in ('method','singleton_method','class','module'):decl.append(dict(kind=n.type,line=n.start_point.row+1,start_byte=n.start_byte,end_byte=n.end_byte))
   todo.extend(reversed(n.named_children))
  emit(out,dict(node_id='rubyinterface_'+uid(str(path)),kind='interface_only_source',path=str(path),sha256=hashlib.sha256(data).hexdigest(),has_parse_error=tree.root_node.has_error,declarations=decl,runtime_lookup_eligible=False))
  stats['files']+=1;stats['declarations']+=len(decl);stats['parse_error_files']+=tree.root_node.has_error
(OUT/'reports/ruby_interface_coverage.json').write_text(json.dumps(stats,indent=2)+'\n')
print(json.dumps(stats))
