"""Resolve hardlink exceptions after verify_staging_duplicates.py, read-only."""
import tarfile,json,hashlib
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_results');O=Path('/workspace/gitlab_c_ext_full_graph/reports');report=json.loads((O/'staging_duplicate_verification.json').read_text());x=report['comparisons'][1];links=[]
with tarfile.open(x['archive'],'r|xz') as t:
 for m in t:
  if m.islnk() or m.issym():
   p=R/m.name; target=R/m.linkname if m.islnk() else p.parent/m.linkname
   ph=hashlib.sha256(p.read_bytes()).hexdigest();th=hashlib.sha256(target.read_bytes()).hexdigest();links.append(dict(member=m.name,kind='hardlink' if m.islnk() else 'symlink',linkname=m.linkname,staging_sha256=ph,target_sha256=th,match=ph==th))
verified=all(z['match'] for z in links) and len(links)==len(x['errors'])==len(x['extra_stage_files']) and {z['member'].removeprefix('corrected-results/') for z in links}==set(x['extra_stage_files'])
(O/'staging_duplicate_link_verification.json').write_text(json.dumps(dict(base_report='staging_duplicate_verification.json',links=links,all_prior_regular_members_verified=True,corrected_stage_verified_regenerable_duplicate=verified,deleted=False),indent=2)+'\n')
