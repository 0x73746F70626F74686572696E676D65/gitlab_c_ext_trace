#!/usr/bin/env python3
"""Conservative final target exclusion and additive frozen memory-effect annotation.
No source/table inputs modified. Replaces only this graph's generated edges.
"""
import gzip,json,hashlib,os,sys,collections,functools,re
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from native_header_memory_models import parse_directives,false,header_witness
from build_native_graph import primitive_type
G=Path('/workspace/gitlab_c_ext_full_graph');R=Path('/workspace/gitlab_c_ext_trace');V=Path('/workspace/gitlab_c_ext_v3')
def rows(p):
 if p.exists():
  with (gzip.open(p,'rt') if p.suffix=='.gz' else p.open()) as f:
   for line in f:yield json.loads(line)
def main():
 bp=G/'tables/native_boundaries.jsonl.gz'; bq=bp.with_suffix('.finalizing.gz'); seen=set()
 with gzip.open(bq,'wt',compresslevel=3) as out:
  for row in rows(bp):
   if row['boundary_id'] in seen:continue
   seen.add(row['boundary_id']);out.write(json.dumps(row,separators=(',',':'))+'\n')
 os.replace(bq,bp)
 bad={r['node_id'] for r in rows(G/'tables/native_boundaries.jsonl.gz') if r['kind']=='legacy_definition_not_recovered'}
 files={r['file_id']:r for r in rows(G/'tables/native_files.jsonl.gz')}
 includes=collections.defaultdict(list)
 @functools.lru_cache(maxsize=128)
 def directives(fid):
  return {r['line']:r for r in parse_directives((R/files[fid]['path']).read_bytes())[0]}
 for inc in rows(G/'tables/native_includes.jsonl.gz'):
  if not inc.get('target_file_id'):continue
  source=directives(inc['file_id']).get(inc['line'])
  if source is None or false(source['conditions']):continue
  includes[inc['file_id']].append((inc['target_file_id'],inc['include_id'],[dict(c,file=files[inc['file_id']]['path']) for c in source['conditions']]))
 @functools.lru_cache(maxsize=20000)
 def path_to(source,target):
  todo=collections.deque([(source,[],[])]);seen={source}
  while todo:
   at,ids,gs=todo.popleft()
   if at==target:return {'include_path':ids,'include_conditions':gs}
   for dst,eid,cond in includes.get(at,[]):
    if dst not in seen:seen.add(dst);todo.append((dst,ids+[eid],gs+cond))
  return None
 cpp_unsafe=set();memory_witnesses={}
 @functools.lru_cache(maxsize=128)
 def read_source(path):return path.read_bytes()
 for call in rows(G/'tables/native_call_index.jsonl.gz'):
  if call.get('syntax')=='ast_call' and primitive_type(call['callee'],call.get('arguments',[])):
   memory_witnesses[call['call_id']]=header_witness(R/call['file'],call['line'],re.sub(r'^(?:::|std::)','',call['callee']),read_source)
  if call.get('language')=='cpp' and primitive_type(call['callee'],call.get('arguments',[])) and not call['callee'].startswith(('std::','::')) and not all(re.fullmatch(r'[0-9]+|nullptr|true|false',a.strip()) for a in call.get('arguments',[])):cpp_unsafe.add(call['call_id'])
 include_demotions=include_qualified=cpp_memory_demotions=memory_header_demotions=0
 p=G/'tables/native_edges.jsonl.gz';q=p.with_suffix('.finalizing.gz');count=changed=0
 with gzip.open(q,'wt',compresslevel=3) as out:
  for row in rows(p):
   count+=1
   if row['target_id'] in bad and row.get('traversable'):
    row.update(traversable=False,resolution='possible_unrecovered_legacy_definition');row['evidence']['finalizer_exclusion']='Target definition retained only from prior parse and not recovered by current parser';changed+=1
   if row.get('traversable') and row['kind']=='call_has_memory_evidence':
    witness=memory_witnesses.get(row['source_id'])
    if witness is None:
     row.update(traversable=False,resolution='possible_memory_API_header_unproved');memory_header_demotions+=1
    else:
     row['conditions']+=witness['conditions'];row['evidence']['validated_memory_header_witness']=witness
   if row.get('traversable') and row['kind']=='call_has_memory_evidence' and row['source_id'] in cpp_unsafe:
    row.update(traversable=False,resolution='possible_cpp_memory_overload_or_ADL');cpp_memory_demotions+=1
   proof=row.get('evidence',{}).get('cross_translation_unit_evidence')
   if row.get('traversable') and proof:
    target=row.get('evidence',{}).get('target_definition_file_id');source=row.get('file_id')
    if proof.get('kind')=='source_include_definition':qualified=path_to(source,target)
    else:qualified=next((p for d in proof.get('declarations',[]) if (p:=path_to(source,d['file_id'])) is not None),None)
    if qualified is None:
     row.update(traversable=False,resolution='possible_include_path_inactive_or_unmodeled');include_demotions+=1
    else:
     row['conditions']+=qualified['include_conditions'];row['evidence']['validated_include_witness']=qualified;include_qualified+=1
   out.write(json.dumps(row,separators=(',',':'))+'\n')
 os.replace(q,p)
 annotations=0
 with gzip.open(G/'tables/native_memory_effect_annotations.jsonl.gz','wt',compresslevel=3) as out:
  for row in rows(V/'tables/physical_site_memory_semantics_v1.jsonl'):
   out.write(json.dumps(dict(annotation=row,provenance='frozen_v3_memory_semantics_overlay_v1',applicability='Conditional matching Ruby3.3.11 API implementation; caller values and deployed version remain unknown; no generic heap-allocation guarantee'),separators=(',',':'))+'\n');annotations+=1
 report=dict(edge_rows=count,memory_header_demotions=memory_header_demotions,cpp_memory_demotions=cpp_memory_demotions,include_path_demotions=include_demotions,include_path_qualified_edges=include_qualified,demoted_unrecovered_targets=changed,unrecovered_target_nodes=len(bad),memory_effect_annotations=annotations,edge_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 (G/'reports/native_finalization.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
