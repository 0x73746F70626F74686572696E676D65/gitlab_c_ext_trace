#!/usr/bin/env python3
"""Cycle-safe retained relative-include witnesses for conditional memory API dispatch.
Unknown search paths are not guessed. Literal #if0 branches are excluded.
"""
import sys,re,json,gzip,hashlib,collections,functools
from pathlib import Path
G=Path('/workspace/gitlab_c_ext_full_graph');R=Path('/workspace/gitlab_c_ext_trace')
sys.path.insert(0,str(G/'scripts'))
from build_native_graph import key,CONVERT,COERCE

def rows(p):
 if p.exists():
  with gzip.open(p,'rt') as f:
   for line in f:yield json.loads(line)
@functools.lru_cache(maxsize=128)
def parse_directives(data):
 data=re.sub(rb'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|/\*[\s\S]*?\*/|//[^\n]*',lambda m:m[0] if m[0].startswith((b'"',b"'")) else re.sub(rb'[^\n]',b' ',m[0]),data)
 stack=[];result=[];definitions=[]
 for number,line in enumerate(data.decode('utf8','replace').split('\n'),1):
  m=re.match(r'\s*#\s*(\w+)\s*(.*)',line)
  if not m:continue
  op,value=m.groups()
  if op in {'if','ifdef','ifndef'}:stack.append(dict(kind=op,expression=value.strip(),branch='body',line=number))
  elif op=='else' and stack:stack[-1]=dict(stack[-1],branch='else')
  elif op=='elif' and stack:stack[-1]=dict(stack[-1],kind='elif',expression=value.strip(),branch='body')
  elif op=='endif' and stack:stack.pop()
  elif op in {'define','undef'}:definitions.append(dict(name=value.split('(')[0].split()[0] if value.strip() else '',line=number,kind=op,conditions=[dict(x) for x in stack]))
  elif op=='include':
   target=re.fullmatch(r'([<\"])([^>\"]+)[>\"]\s*(?://.*)?',value)
   if target:result.append(dict(name=target[2],quoted=target[1]=='"',line=number,conditions=[dict(x) for x in stack]))
 return result,definitions

def false(conditions):
 def literal(c):
  return re.sub(r'\s+','',c['expression']).strip('()')
 return any(c['kind']=='elif' or c['kind']=='if' and ((literal(c)=='0' and c['branch']=='body') or (literal(c)=='1' and c['branch']=='else')) for c in conditions)
def expected_headers(name):
 norm=re.sub(r'^(?:::|std::)','',name)
 ruby=norm.startswith(('rb_','ruby_')) or norm in COERCE or CONVERT.fullmatch(norm) or norm in {'ALLOC','ALLOC_N','REALLOC_N','ALLOCA_N','ALLOCV','ALLOCV_N','ALLOCV_END','xfree','xmalloc','xcalloc','xrealloc'}
 if ruby:return {'ruby.h','ruby/ruby.h'},True
 groups={'malloc':{'stdlib.h','cstdlib','malloc.h'},'calloc':{'stdlib.h','cstdlib','malloc.h'},'realloc':{'stdlib.h','cstdlib','malloc.h'},'free':{'stdlib.h','cstdlib','malloc.h'},'alloca':{'alloca.h','stdlib.h'},'bcopy':{'strings.h'},'bzero':{'strings.h'}}
 return groups.get(norm,{'string.h','cstring'} if norm in {'memcpy','memmove','memset','strcpy','strncpy','strcat','strncat','strdup','strndup'} else set()),False

def header_witness(path,line,api,read_bytes=lambda p:p.read_bytes()):
 expected,ruby=expected_headers(api)
 if not expected:return None
 todo=collections.deque([(path,line,[],[])]);seen=set();evidence=None
 while todo:
  current,before,chain,conditions=todo.popleft();token=(str(current),before)
  if token in seen:continue
  seen.add(token);source=read_bytes(current);inc,defs=parse_directives(source)
  if re.search(rb'\b'+re.escape(api.encode())+rb'\s*\([^;{}]*\)\s*\{',source):return None
  # An observed custom redefinition/undef of the API prevents this model.
  if any(d['line']<before and d['name']==api and not false(d['conditions']) for d in defs):return None
  for i in inc:
   if i['line']>=before or false(i['conditions']):continue
   gs=conditions+[dict(c,file=str(current)) for c in i['conditions']]
   part=dict(file=str(current),line=i['line'],header=i['name'],quoted=i['quoted']);local=(current.parent/i['name']).resolve()
   if i['quoted'] and local.is_file():todo.append((local,float('inf'),chain+[part],gs));continue
   if i['name'] in expected:
    if evidence is None:evidence=dict(include_path=chain+[part],conditions=gs,canonical_header=i['name'],model='matching_standard_or_Ruby_API_header',assumptions=['Actual header search and API implementation match the named canonical model.','No unobserved build-injected macro substitution or symbol interposition; actual execution/allocation is not established.'])
 # Scan all traversed retained includes for API mutations even after finding witness.
 return evidence

def build():
 funcs={};defs=collections.defaultdict(set);pending=collections.defaultdict(list)
 for n in rows(G/'tables/native_nodes.jsonl.gz'):
  if n['node_type'] in {'function','macro'}:funcs[n['node_id']]=n;defs[n['file_id']].add(n.get('name'))
 for e in rows(G/'tables/native_edges.jsonl.gz'):
  if e['kind']=='call_has_memory_evidence' and not e.get('traversable') and e['resolution']!='excluded_literal_preprocessor':pending[e['source_id']].append(e['target_id'])
 @functools.lru_cache(maxsize=128)
 def read(p):return p.read_bytes()
 counts=collections.Counter();outpath=G/'tables/native_header_memory_edges.jsonl.gz'
 with gzip.open(outpath,'wt',compresslevel=3) as out:
  for c in rows(G/'tables/native_call_index.jsonl.gz'):
   cid=c['call_id']
   if cid not in pending:continue
   name=c['callee'];norm=re.sub(r'^(?:::|std::)','',name);owner=funcs.get(c.get('function_id'),{})
   if c.get('language')=='cpp' and not name.startswith(('std::','::')) and not all(re.fullmatch(r'[0-9]+|nullptr|true|false',a.strip()) for a in c.get('arguments',[])):continue
   if c.get('syntax')!='ast_call' or c.get('parse_region_has_errors') or c.get('unevaluated_contexts') or norm in owner.get('shadowed_identifiers',[]) or norm in defs[c['file_id']]:continue
   witness=header_witness(R/c['file'],c['line'],norm,read)
   if witness is None:counts['no_witness']+=1;continue
   for target in pending[cid]:
    row=dict(edge_id=key('header_memory_edge',cid,target),source_id=cid,target_id=target,kind='call_has_memory_evidence',resolution='conditional_source_resolved',traversable=True,language=c['language'],file_id=c['file_id'],file=c['file'],line=c['line'],source_context=c['source_context'],conditions=c.get('conditions',[])+witness['conditions'],evidence=dict(primitive_semantic_class='source_include_chain_API_model',header_witness=witness,fresh_allocation='not_implied'))
    out.write(json.dumps(row,separators=(',',':'))+'\n');counts['added_edges']+=1
 report=dict(counts=dict(counts),edge_sha256=hashlib.sha256(outpath.read_bytes()).hexdigest(),scope='Source-relative include fixed point only; no header-directory guessing, conditional matching canonical-header/API model.')
 (G/'reports/native_header_memory_models.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':build()
