"""Actual static producer parses fixtures; no C compiler/runtime invoked."""
import pathlib,json,tempfile,hashlib,importlib.util,gzip,contextlib,io
ROOT=pathlib.Path('/workspace/gitlab_c_ext_full_graph');PRODUCER=ROOT/'scripts/build_native_graph.py'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 if not p.exists():return []
 with gzip.open(p,'rt') as f:return [json.loads(l) for l in f]
def main():
 h=sha(PRODUCER);s=importlib.util.spec_from_file_location('nativeprod',PRODUCER);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
 cases=[('local_malloc_definition',{'a.c':'#include <stdlib.h>\nvoid *malloc(unsigned long n){return 0;} void f(void){malloc(8);}'},False),('parameter_malloc_shadow',{'a.c':'#include <stdlib.h>\nvoid f(void *(*malloc)(unsigned long)){malloc(8);}'},False),('missing_header',{'a.c':'void f(void){malloc(8);}'},False),('fake_local_ruby_header',{'a.c':'#include "ruby.h"\nvoid f(void){rb_str_new(0,0);}','ruby.h':'int unrelated;'},False),('wrong_standard_header',{'a.c':'#include <string.h>\nvoid f(void){malloc(8);}'},False),('literal_inactive_header',{'a.c':'#if 0\n#include <ruby.h>\n#endif\nvoid f(void){rb_str_new(0,0);}'},False),('standard_allocator_positive',{'a.c':'#include <stdlib.h>\nvoid f(void){malloc(8);}'},True)]
 results=[]
 for name,files,expected in cases:
  with tempfile.TemporaryDirectory() as td:
   r=pathlib.Path(td)/'r';g=pathlib.Path(td)/'g';src=r/'sources/gems/fixture';src.mkdir(parents=True);(r/'tables').mkdir();(g/'reports').mkdir(parents=True)
   for f,code in files.items():(src/f).write_text(code+'\n')
   (r/'tables/c_source_gems.jsonl').write_text(json.dumps(dict(gem_id='fixture',canonical_gem_id='fixture',source_dir=str(src)))+'\n');(r/'tables/gems.jsonl').write_text(json.dumps(dict(gem_id='fixture',name='fixture',version='0',source_dir=str(src)))+'\n');m.R=r;m.G=g
   with contextlib.redirect_stdout(io.StringIO()):m.build()
   edges=read(g/'tables/native_edges.jsonl.gz');selected=[e for e in edges if e['kind']=='call_has_memory_evidence' and e.get('traversable')]
   results.append(dict(fixture_id=name,status='PASS' if bool(selected)==expected else 'FAIL',source_files=files,expected_resolved_sink_relation=expected,actual_resolved_sink_edges=selected))
 assert sha(PRODUCER)==h,'Source changed during review; rerun'
 report=dict(status='PASS' if all(x['status']=='PASS' for x in results) else 'FAIL',producer_sha256=h,fixtures=results,passed=sum(x['status']=='PASS' for x in results),target_code_executed=False)
 p=ROOT/'reports'/('independent_memory_gate_regressions_'+h[:12]+'.json');p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(report=str(p),sha256=sha(p),passed=report['passed'],failed=[x['fixture_id'] for x in results if x['status']=='FAIL'])))
if __name__=='__main__':main()
