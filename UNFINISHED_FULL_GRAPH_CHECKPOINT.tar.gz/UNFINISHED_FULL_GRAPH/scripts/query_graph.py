#!/usr/bin/env python3
"""Expand complete sink/API relations or retrieve all corridor edges incl cycles.
Results are conditional structural connectivity, never jointly feasible path claims.
"""
import argparse,base64,collections,gzip,json,zlib
from pathlib import Path
from compose_graph import jsonlines,eligible,csr
from array import array

def emit(x):print(json.dumps(x,sort_keys=True))
def viewdir(root,view):
 manifest=json.loads((root/'reachability/manifest.json').read_text())
 if manifest.get('status')!='PASS_COMPLETE_ADMITTED_GRAPH_CLOSURE':raise ValueError('Reachability composition is not finalized')
 for v in manifest['views']:
  if v['view']==view:return root/'reachability'/v.get('directory','native_source'),manifest
 raise ValueError(('unknown view',view))
def selected_edges(root,view,manifest):
 paths=[('native_edges.jsonl.gz',set(manifest['native_admitted_kinds']),None)]
 if view!='native_source':paths += [(name,set(manifest['ruby_admitted_kinds']),view) for name in ['ruby_edges.jsonl.gz','binding_edges.jsonl.gz'] if (root/'tables'/name).exists()]
 for name,kinds,ctx in paths:
  for e in jsonlines(root/'tables'/name):
   if eligible(e,kinds,ctx):yield e

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',default='/workspace/gitlab_c_ext_full_graph');sub=ap.add_subparsers(dest='mode',required=True)
 for mode in ['sinks','apis','between','witness']:
  p=sub.add_parser(mode);p.add_argument('--view',required=True)
  if mode in ['sinks','between','witness']:p.add_argument('--api',required=True)
  if mode in ['apis','between','witness']:p.add_argument('--sink',required=True)
 p=sub.add_parser('node');p.add_argument('id');p=sub.add_parser('edge');p.add_argument('id');p=sub.add_parser('boundaries');p.add_argument('--node',required=True)
 a=ap.parse_args();root=Path(a.root)
 if a.mode in ['node','edge','boundaries']:
  names=['native_nodes.jsonl.gz','ruby_nodes.jsonl.gz'] if a.mode=='node' else ['native_edges.jsonl.gz','ruby_edges.jsonl.gz','binding_edges.jsonl.gz'] if a.mode=='edge' else ['native_boundaries.jsonl.gz','ruby_boundaries.jsonl.gz']
  found=0
  for name in names:
   p=root/'tables'/name
   if not p.exists():continue
   for rownum,r in enumerate(jsonlines(p),1):
    match=r.get('node_id')==a.id if a.mode=='node' else r.get('edge_id')==a.id if a.mode=='edge' else a.node in [r.get('node_id'),r.get('source_id'),r.get('target_id')]
    if match:emit(dict(table=name,row=rownum,record=r));found+=1
  if not found:raise SystemExit('No matching records')
  return
 directory,manifest=viewdir(root,a.view)
 if a.mode=='sinks':
  target=None
  for r in jsonlines(directory/'api_sink_relations.jsonl.gz'):
   if r['api_node_id']==a.api:target=r;break
  if target is None:raise SystemExit('API is not an entry node in this view')
  bits=None
  for r in jsonlines(root/'reachability/sink_sets.jsonl.gz'):
   if r['sink_set_id']==target['sink_set_id']:bits=int.from_bytes(zlib.decompress(base64.b64decode(r['payload'])),'little');break
  assert bits is not None;found=0
  for r in jsonlines(root/'reachability/sink_index.jsonl.gz'):
   if bits & (1<<r['sink_index']):emit(dict(view=a.view,api_node_id=a.api,sink_node_id=r['node_id'],sink_index=r['sink_index'],sink_set_id=target['sink_set_id'],conditional_structural_relation=True));found+=1
  assert found==target['sink_count'];return
 if a.mode=='apis':
  idx=None
  for r in jsonlines(root/'reachability/sink_index.jsonl.gz'):
   if r['node_id']==a.sink:idx=r['sink_index'];break
  if idx is None:raise SystemExit('Unknown sink')
  allowed=set()
  for r in jsonlines(root/'reachability/sink_sets.jsonl.gz'):
   b=zlib.decompress(base64.b64decode(r['payload']));byte=idx//8
   if byte<len(b) and b[byte]&(1<<(idx%8)):allowed.add(r['sink_set_id'])
  for r in jsonlines(directory/'api_sink_relations.jsonl.gz'):
   if r['sink_set_id'] in allowed:emit(dict(view=a.view,api_node_id=r['api_node_id'],sink_node_id=a.sink,component_id=r['component_id'],conditional_structural_relation=True))
  return
 # Query-time uncapped full corridor. Native view suffix seed factoring is expanded exactly here.
 ids=[];lookup={};ss=array('I');tt=array('I')
 def number(n):
  if n not in lookup:lookup[n]=len(ids);ids.append(n)
  return lookup[n]
 for e in selected_edges(root,a.view,manifest):ss.append(number(e['source_id']));tt.append(number(e['target_id']))
 start=number(a.api);end=number(a.sink);fwd=csr(len(ids),ss,tt);rev=csr(len(ids),tt,ss)
 def closure(node,graph,parents=False):
  seen={node};todo=collections.deque([node]);parent={}
  while todo:
   v=todo.popleft()
   for j in range(graph[0][v],graph[0][v+1]):
    w=graph[1][j]
    if w not in seen:seen.add(w);todo.append(w);parent[w]=v
  return (seen,parent) if parents else seen
 forward,parents=closure(start,fwd,True)
 if end not in forward:raise SystemExit('No admitted structural path in selected view')
 if a.mode=='witness':
  path=[end]
  while path[-1]!=start:path.append(parents[path[-1]])
  path.reverse();pairs={(ids[s],ids[t]):i for i,(s,t) in enumerate(zip(path,path[1:]))}
  emit(dict(type='representative_shortest_witness',view=a.view,node_path=[ids[x] for x in path],joint_guard_feasibility_proven=False,not_all_walks=True))
  for e in selected_edges(root,a.view,manifest):
   pair=(e['source_id'],e['target_id'])
   if pair in pairs:emit(dict(type='witness_edge_alternative',position=pairs[pair],edge=e))
 else:
  corridor=forward & closure(end,rev);names={ids[i] for i in corridor}
  emit(dict(type='complete_finite_structural_corridor',view=a.view,api=a.api,sink=a.sink,node_count=len(names),cycles_preserved=True,joint_guard_feasibility_proven=False))
  for e in selected_edges(root,a.view,manifest):
   if e['source_id'] in names and e['target_id'] in names:emit(dict(type='edge',edge=e))
  for name in ['native_nodes.jsonl.gz','ruby_nodes.jsonl.gz']:
   p=root/'tables'/name
   if p.exists():
    for n in jsonlines(p):
     if n['node_id'] in names:emit(dict(type='node',node=n))
if __name__=='__main__':main()
