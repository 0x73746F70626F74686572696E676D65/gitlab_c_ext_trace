"""Adversarial synthetic Ruby parsed by actual producer; target Ruby NEVER executed."""
import pathlib,tempfile,importlib.util,collections,io,json,hashlib,sys
ROOT=pathlib.Path('/workspace/gitlab_c_ext_full_graph');PRODUCER=ROOT/'scripts/ruby_full_graph.py'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
class FixtureCorpus:
 def __init__(self,files):self.files={f:dict(file_id=hashlib.sha256(f.encode()).hexdigest()[:24]) for f in files}
 def contexts(self,file):return ['ee'] if file.startswith('ee/') else ['ce']
def run():
 original=sha(PRODUCER);spec=importlib.util.spec_from_file_location('rubyproducer',PRODUCER);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 cases=[
 ('singleton_own_before_extend',{'a.rb':'module M; def f; module_sink; end; end\nclass A; extend M; def self.f; own_sink; end; end'},('A','f','singleton','ce'),'A',None),
 ('attr_reader_shadows_old_def',{'a.rb':'class A; def foo; old_sink; end; attr_reader :foo; def run; foo; end; end'},('A','foo','instance','ce'),None,'old_sink'),
 ('define_method_shadows_old_def',{'a.rb':'class A; def foo; old_sink; end; define_method(:foo) { other_sink }; def run; foo; end; end'},('A','foo','instance','ce'),None,'old_sink'),
 ('remove_method_old_def',{'a.rb':'class A; def foo; old_sink; end; remove_method :foo; def run; foo; end; end'},('A','foo','instance','ce'),None,'old_sink'),
 ('alias_keyword_overwrites_old_def',{'a.rb':'class A; def g; old_sink; end; def f; new_sink; end; alias g f; def run; g; end; end'},('A','g','instance','ce'),None,'old_sink'),
 ('prepend_precedence',{'a.rb':'module M; def work; module_sink; end; end\nclass A; def work; own_sink; end; prepend M; end'},('A','work','instance','ce'),'M',None),
 ('alias_method_capture_time',{'a.rb':'class A; def f; first_sink; end; alias_method :g, :f; def f; second_sink; end; end'},('A','g','instance','ce'),'A','second_sink'),
 ('profile_no_crossmix',{'ce/a.rb':'class A; def run; work; end; end','ee/a.rb':'class A; def work; ee_sink; end; end'},('A','work','instance','ce'),None,'ee_sink'),
 ('singleton_scope_include_not_instance',{'a.rb':'module M; def f; module_sink; end; end\nclass A; class << self; include M; end; end'},('A','f','instance','ce'),None,'module_sink'),
 ('unforced_block_no_execution',{'a.rb':'class Native; def self.work; end; end\nclass A; def run; callback = -> { Native.work }; 0; end; end'},None,None,None),
 ('block_self_not_lexical_owner',{'a.rb':'class A; def work; own_sink; end; def run; other.instance_eval { work }; end; end'},None,None,None),
 ('private_singleton_explicit_receiver',{'a.rb':'class A; def self.f; own_sink; end; private_class_method :f; end\nA.f'},None,None,None),
 ('constructor_known_override',{'a.rb':'class Other; def work; other_sink; end; end\nclass A; def self.new; Other.new; end; def work; wrong_sink; end; end\nA.new.work'},None,None,None),
 ('lexical_constant_first',{'a.rb':'class X; def self.work; top_sink; end; end\nmodule A; class X; def self.work; nested_sink; end; end; class B; def run; X.work; end; end; end'},None,None,None)
 ]
 results=[]
 for name,files,query,want_owner,forbidden in cases:
  with tempfile.TemporaryDirectory() as td:
   base=pathlib.Path(td)
   for f,text in files.items():p=base/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text+'\n')
   m.B=base;model=m.Model(FixtureCorpus(files))
   for f in files:model.parse(f,1)
   model.finalize();outputs={k:io.StringIO() for k in ('nodes','edges','bindings','boundaries','files')}
   for f in files:model.parse(f,2,outputs)
   parsed={k:[json.loads(x) for x in v.getvalue().splitlines()] for k,v in outputs.items()};nodes={r['node_id']:r for r in parsed['nodes']};dispatch=[e for e in parsed['edges'] if e['kind']=='ruby_dispatch'];ok=True;detail={}
   if query:
    targets,reason,ev=model.lookup(*query);detail=dict(query=query,targets=targets,reason=reason)
    if want_owner is not None:ok=bool(targets) and all(t['owner']==want_owner for t in targets)
    if forbidden:
     def body(t):
      if t.get('alias_target_id'):
       t=next((d for ds in model.defs.values() for d in ds if d.get('node_id')==t['alias_target_id']),t)
      return files[t['file']][t['byte_offset']:t.get('end_byte',len(files[t['file']]))]
     ok=ok and all(forbidden not in body(t) for t in targets)
   elif name=='unforced_block_no_execution':
    bad=[e for e in parsed['edges'] if e.get('traversable') and nodes.get(e['target_id'],{}).get('kind')=='deferred_block'];ok=not bad;detail=dict(bad_edges=bad)
   elif name=='block_self_not_lexical_owner':
    bad=[e for e in dispatch if nodes.get(e['source_id'],{}).get('method')=='work'];ok=not bad;detail=dict(bad_edges=bad)
   elif name=='private_singleton_explicit_receiver':
    bad=[e for e in dispatch if nodes.get(e['source_id'],{}).get('receiver')=='A' and nodes[e['source_id']]['method']=='f'];ok=not bad;detail=dict(bad_edges=bad)
   elif name=='constructor_known_override':
    bad=[e for e in dispatch if nodes.get(e['source_id'],{}).get('receiver')=='A.new' and nodes[e['source_id']]['method']=='work' and e.get('evidence',{}).get('receiver_owner')=='A'];ok=not bad;detail=dict(bad_edges=bad)
   elif name=='lexical_constant_first':
    edges=[e for e in dispatch if nodes.get(e['source_id'],{}).get('receiver')=='X' and nodes[e['source_id']]['method']=='work'];ok=bool(edges) and all(e.get('evidence',{}).get('receiver_owner')=='A::X' for e in edges);detail=dict(edges=edges)
   results.append(dict(fixture_id=name,status='PASS' if ok else 'FAIL',source_files=files,actual=detail,target_code_executed=False))
 assert sha(PRODUCER)==original,'Producer changed during review; rerun snapshot'
 report=dict(status='PASS' if all(x['status']=='PASS' for x in results) else 'FAIL',producer_sha256=original,fixture_count=len(results),passed=sum(x['status']=='PASS' for x in results),fixtures=results,meaning='Actual Python analyzer parsed synthetic Ruby; no Ruby execution. Source fixture tests are not production precision/recall.')
 out=ROOT/'reports'/('independent_ruby_regressions_'+original[:12]+'.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(report=str(out),sha256=sha(out),passed=report['passed'],failed=[x['fixture_id'] for x in results if x['status']=='FAIL'])))
if __name__=='__main__':run()
