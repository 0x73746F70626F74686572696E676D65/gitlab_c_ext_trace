#!/usr/bin/env python3
"""Full retained-source native graph. Static parsing only; no builds/target code.
Structural connectivity and source-target alternatives are not execution proof.
"""
import argparse,bisect,collections,functools,gzip,hashlib,json,re,sys,time
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_trace');G=Path('/workspace/gitlab_c_ext_full_graph')
sys.path.insert(0,str(R/'scripts'))
from analyze_c import PARSERS,EXTS,key,txt,walk,ident,primitive,REG
EXTRA_REG={'rb_define_method_id','rb_define_private_method_id','rb_define_protected_method_id','rb_define_singleton_method_id','rb_define_alias','rb_define_alias_id'}
NS={'rb_define_class','rb_define_module','rb_define_class_under','rb_define_module_under','rb_define_class_id','rb_define_module_id','rb_define_class_id_under','rb_define_module_id_under','rb_const_get','rb_const_get_at','rb_path2class','rb_path_to_class'}
CONVERT=re.compile(r'(?:(?:INT|UINT|LONG|ULONG|LL|ULL|OFFT|SIZET|SSIZET|DBL|FIX|CHR)2NUM|rb_(?:int2inum|uint2inum|long2inum|ulong2inum|ll2inum|ull2inum|dbl2big|intern|intern2|intern3|intern_str|intern_const|to_symbol))$')
COERCE={'StringValue','StringValueCStr','StringValuePtr','SafeStringValue','rb_check_string_type','rb_obj_as_string','rb_String','rb_ary_to_ary','rb_Array','rb_Integer','rb_Float'}
CPP_COPY={'copy','copy_n','copy_backward','fill','fill_n','uninitialized_copy','uninitialized_copy_n','uninitialized_fill','uninitialized_fill_n'}
IDENT=re.compile(r'^[A-Za-z_]\w*$')
def rows(p):
 if p.exists():
  with (gzip.open(p,'rt') if p.suffix=='.gz' else p.open()) as f:
   for line in f:
    if line.strip():yield json.loads(line)
def primitive_type(name,args=()):
 norm=re.sub(r'^(?:::|std::)','',name)
 norm=re.sub(r'^(?:__builtin___|__)(memcpy|memmove|memset|strcpy|strncpy|strcat|strncat)_chk$',r'\1',norm)
 if name.startswith('std::') and (norm in CPP_COPY or norm=='move' and len(args)>=3):return 'cpp_buffer_algorithm'
 return primitive(norm) or ('ruby_conditional_numeric_or_symbol_api' if CONVERT.fullmatch(norm) else 'ruby_coercion_possible_allocation' if norm in COERCE else 'ruby_namespace_constructor' if norm.startswith('rb_define_class') or norm.startswith('rb_define_module') or norm in {'rb_singleton_class','rb_class_new_instance','rb_class_new_instance_kw'} else None)
def source_role(path):
 parts=Path(path).parts
 for names,role in [({'test','tests','spec','specs'},'test'),({'example','examples','benchmark','benchmarks'},'example'),({'vendor','third_party','third-party','deps','ports'},'vendor'),({'ext','extension','extensions'},'extension')]:
  if set(parts)&names:return role
 return 'repository_source'
def selected(p):return p.suffix.lower() in EXTS or str(p).endswith(('.c.in','.h.in'))
def guards(n,b):
 result=[];child=n;parent=n.parent
 while parent:
  if parent.type.startswith('preproc_if') or parent.type in ('preproc_else','preproc_elif','if_statement','switch_statement','case_statement','while_statement','for_statement','do_statement','conditional_expression'):
   expr=parent.child_by_field_name('condition') or parent.child_by_field_name('name') or parent.child_by_field_name('value')
   value=txt(b,expr);branch='else' if child.type in ('else_clause','preproc_else','preproc_elif') else 'body'
   result.append(dict(kind=parent.type,expression=value,branch=branch,line=parent.start_point.row+1,byte_offset=parent.start_byte,condition_evaluated=False))
  child=parent;parent=parent.parent
 return result
def literal_false(gs):return any(g['kind']=='preproc_if' and ((g['expression'].strip() in ('0','(0)') and g['branch']!='else') or (g['expression'].strip() in ('1','(1)') and g['branch']=='else')) for g in gs)
class Output:
 def __init__(self,out):
  self.out=out;out.mkdir(parents=True,exist_ok=True);self.handles={};self.counts=collections.Counter()
 def put(self,name,row):
  if name not in self.handles:self.handles[name]=gzip.open(self.out/(name+'.jsonl.gz'),'wt',compresslevel=3)
  self.handles[name].write(json.dumps(row,separators=(',',':'),ensure_ascii=True)+'\n');self.counts[name]+=1
 def close(self):
  for f in self.handles.values():f.close()

def build(limit=None):
 start=time.time();out=Output(G/'tables');stats=collections.Counter();filemeta={};bindings=list(rows(R/'tables/c_source_gems.jsonl'));source_by_gid={b['canonical_gem_id']:Path(b['source_dir']) for b in bindings};gems={g['gem_id']:g for g in rows(R/'tables/gems.jsonl')}
 for old in rows(R/'tables/c_files.jsonl'):
  f=dict(old);f.update(source_context='locked_gem_source',legacy_file=True);filemeta[f['file_id']]=f
 known={(f['gem_id'],str((R/f['path']).resolve())) for f in filemeta.values()}
 for gid,src in source_by_gid.items():
  if not src.exists():continue
  for p in sorted(src.rglob('*')):
   if not p.is_file() or not selected(p) or (gid,str(p.resolve())) in known:continue
   rel=str(p.relative_to(R)) if p.is_relative_to(R) else str(p);fid=key('file',gid,str(p.relative_to(src)));filemeta[fid]=dict(file_id=fid,gem_id=gid,path=rel,source_context='locked_gem_source',legacy_file=False,corpus_role=source_role(str(p.relative_to(src))),build_selection='not_evaluated',gem_name=gems.get(gid,{}).get('name'),version=gems.get(gid,{}).get('version'));known.add((gid,str(p.resolve())))
 for family in ('runtime','external_models'):
  root=R/'sources'/family
  if not root.exists():continue
  for src in sorted(root.iterdir()):
   if not src.is_dir():continue
   gid=key('source_context',family,src.name)
   for p in sorted(src.rglob('*')):
    if not p.is_file() or not selected(p):continue
    fid=key('file',gid,str(p.relative_to(src)));filemeta[fid]=dict(file_id=fid,gem_id=gid,path=str(p.relative_to(R)),source_context=family,legacy_file=False,corpus_role=source_role(str(p.relative_to(src))),build_selection='not_evaluated',gem_name=None,version=None)
 # Independent retained-file census closes unassociated/investigation source gaps.
 physical_known={str((R/f['path']).resolve()) for f in filemeta.values()}
 for recovery in rows(Path('/workspace/gitlab_c_ext_full_graph/tables/native_recovery_candidates.jsonl.gz')):
  path=Path(recovery['canonical_path'])
  if R!=Path('/workspace/gitlab_c_ext_trace') or str(path) in physical_known or not path.exists():continue
  gid=key('source_context','unassociated_retained',str(path.parent));fid=key('file',gid,path.name)
  filemeta[fid]=dict(file_id=fid,gem_id=gid,path=str(path.relative_to(R)) if path.is_relative_to(R) else str(path),source_context=recovery.get('family','unassociated_retained'),legacy_file=False,corpus_role=recovery.get('source_role','unassociated_retained'),build_selection='unassociated_no_package_proof',source_census_id=recovery['source_id'])
  physical_known.add(str(path))
 membership={x['file_id']:x for x in rows(R/'tables/c_file_membership.jsonl')}
 old_sites={s['site_id']:s for s in rows(R/'tables/primitive_sites.jsonl')};old_links=list(rows(R/'tables/primitive_evidence_sites.jsonl'));old_prims={p['primitive_id']:p for p in rows(R/'tables/c_primitives.jsonl')};sites_seen=set();primitive_seen=set();calls_seen=set();funcs={};byfile=collections.defaultdict(list);bygem=collections.defaultdict(list);global_objects=collections.defaultdict(set);declarations=collections.defaultdict(list);include_specs=collections.defaultdict(list);cpp_unsafe_files=set();build_scopes={};callback_assignments=collections.defaultdict(list);legacy_regs={x['registration_id']:x for x in rows(R/'tables/c_registrations.jsonl')};reg_seen=set();ns_seen=set();candidate_sets=set();pending_memory=collections.defaultdict(list);old_ast_storage={};old_functions={f['function_id']:f for f in rows(R/'tables/c_functions.jsonl')}
 # Preserve baseline physical sites and evidence IDs even if a parser cannot recover an expression.
 for sid,s in old_sites.items():out.put('native_nodes',dict(node_id=sid,node_type='memory_site',source_context='locked_gem_source',**s));sites_seen.add(sid)
 def edge(src,dst,kind,resolution='conditional_source_resolved',conditions=None,**e):
  allowed={'function_contains_call','call_targets_function_or_macro','registration_binds_c_function','call_has_memory_evidence','scope_has_memory_evidence','legacy_memory_evidence','evidence_identifies_physical_site'}
  traversable=kind in allowed and resolution in {'source_resolved','conditional_source_resolved'} and not literal_false(conditions or [])
  if literal_false(conditions or []):resolution='excluded_literal_preprocessor'
  out.put('native_edges',dict(edge_id=key('native_edge',src,dst,kind,resolution),source_id=src,target_id=dst,kind=kind,resolution=resolution,traversable=traversable,conditions=conditions or [],language=e.pop('language','c'),**e))
 def boundary(node,kind,detail,**e):out.put('native_boundaries',dict(boundary_id=key('native_boundary',node,kind),node_id=node,kind=kind,resolution='unresolved',detail=detail,**e));stats['boundary_'+kind]+=1
 def primitive_site(f,n,owner,op,category,pid,cid=None,site_kind='call_token',anchor=None,evidence='ast_call'):
  if pid in old_prims:
   if cid is None:old_ast_storage[pid]=guards(n,b)
   return # Old sites/links imported exactly after parse.
  fid=f['file_id'];gid=f['gem_id'];anchor=n.start_byte if anchor is None else anchor;path=f['path'];digest=f['sha256'];sid=key('site',path,digest,site_kind,anchor,op)
  if sid not in sites_seen:
   out.put('native_nodes',dict(node_id=sid,node_type='memory_site',site_id=sid,gem_id=gid,file_id=fid,file=path,line=n.start_point.row+1,byte_offset=anchor,operation=op,primitive_type=category,site_kind=site_kind,source_sha256=digest,source_context=f['source_context'],memory_effect='candidate_not_guaranteed_allocation'));sites_seen.add(sid)
  if pid not in primitive_seen:
   out.put('native_nodes',dict(node_id=pid,node_type='primitive_evidence',primitive_id=pid,site_id=sid,call_id=cid,function_id=owner,gem_id=gid,file_id=fid,file=path,line=n.start_point.row+1,byte_offset=anchor,operation=op,primitive_type=category,evidence=evidence,source_context=f['source_context']));primitive_seen.add(pid)
   if cid:pending_memory[cid].append(pid)
   else:edge(owner or fid,pid,'scope_has_memory_evidence',conditions=guards(n,b),file_id=fid,file=path,line=n.start_point.row+1,evidence={'primitive_semantic_class':'source_storage_syntax_not_guaranteed_heap_allocation'})
   edge(pid,sid,'evidence_identifies_physical_site',file_id=fid,file=path,line=n.start_point.row+1)
 def register_call(f,n,owner,callee,args,syntax='ast_call',offset=None):
  fid=f['file_id'];gid=f['gem_id'];off=n.start_byte if offset is None else offset;cid=key('call',fid,off,callee)
  if cid in calls_seen:return cid
  calls_seen.add(cid);gs=guards(n,b);line=n.start_point.row+1 if offset is None else bisect.bisect_right(line_offsets,off)
  unevaluated=[];ancestor=n.parent
  while ancestor:
   if ancestor.type in {'sizeof_expression','alignof_expression','decltype','noexcept_expression','requires_expression','lambda_expression'}:unevaluated.append(ancestor.type)
   ancestor=ancestor.parent
  call=dict(unevaluated_contexts=unevaluated,call_id=cid,node_id=cid,node_type='call',file_id=fid,gem_id=gid,file=f['path'],line=line,byte_offset=off,function_id=owner,callee=callee,arguments=args,syntax=syntax,language=f['language'],source_context=f['source_context'],conditions=gs,parse_region_has_errors=n.has_error)
  out.put('native_nodes',call);out.put('native_call_index',call);edge(owner or fid,cid,'function_contains_call' if owner else 'translation_unit_contains_call',resolution='possible_unevaluated_or_lambda_context' if unevaluated else 'conditional_source_resolved',conditions=gs,file_id=fid,file=f['path'],line=line,language=f['language'],source_context=f['source_context'])
  category=primitive_type(callee,args)
  if category:
   opmatch=re.search(r'[A-Za-z_]\w*$',callee);op=opmatch[0] if opmatch else callee;anchor=off+(opmatch.start() if opmatch else 0);primitive_site(f,n,owner,op,category,key('primitive',cid),cid,anchor=anchor,evidence=syntax)
  if callee in REG|EXTRA_REG:
   regid=key('reg',cid);legacy=legacy_regs.get(regid);glob=callee=='rb_define_global_function';alloc=callee=='rb_define_alloc_func';idx=0 if glob else 1;target_idx=1 if alloc else idx+1;target=args[target_idx] if len(args)>target_idx else '';target=re.sub(r'\b(?:RUBY_METHOD_FUNC|RB_METHOD_FUNC)\s*\((\w+)\)',r'\1',target);target=re.sub(r'^\([^)]*\)\s*','',target).strip().lstrip('&')
   reg=dict(legacy) if legacy else dict(registration_id=regid,call_id=cid,gem_id=gid,file_id=fid,line=line,function_id=owner,registration_api=callee,receiver_expression='rb_mKernel' if glob else args[0] if args else None,ruby_name='allocate' if alloc else args[idx].strip('"') if len(args)>idx and re.fullmatch(r'"[^"\\]*"',args[idx]) else None,c_function_expression=target,arity=args[target_idx+1] if len(args)>target_idx+1 else None)
   reg.update(node_id=regid,source_context=f['source_context'],file=f['path'],source_byte=off,conditions=gs,initializer_function_id=owner,legacy_target_is_candidate=True);out.put('native_registrations',reg);out.put('native_nodes',dict(node_type='registration',**reg));edge(regid,cid,'registration_declaration_evidence',file_id=fid,file=f['path'],line=line);reg_seen.add(regid)
  if callee in {'rb_include_module','rb_prepend_module','rb_extend_object'}:out.put('native_composition_calls',call)
  if callee in NS:
   sid=key('ns',cid);var=None;parent=n.parent
   if parent and parent.type=='assignment_expression':var=txt(b,parent.child_by_field_name('left'))
   elif parent and parent.type=='init_declarator':var=ident(parent.child_by_field_name('declarator'),b)
   out.put('native_namespaces',dict(namespace_id=sid,call_id=cid,function_id=owner,file_id=fid,gem_id=gid,line=line,byte_offset=off,api=callee,arguments=args,source_variable=var,conditions=gs,source_context=f['source_context']));ns_seen.add(sid)
  return cid
 files=list(filemeta.values());files.sort(key=lambda x:(not x['legacy_file'],x['path'],x['file_id']))
 if limit:files=files[:limit]
 for ix,f in enumerate(files,1):
  fid=f['file_id'];gid=f['gem_id'];path=R/f['path'];b=path.read_bytes();digest=hashlib.sha256(b).hexdigest()
  if f.get('sha256'):assert digest==f['sha256'],('changed source',path)
  f['sha256']=digest;f['bytes']=len(b);line_offsets=[0]+[m.end() for m in re.finditer(b'\n',b)]
  lang=f.get('language') or ('cpp' if path.suffix in {'.cc','.cpp','.cxx','.hpp','.hh','.hxx','.ipp','.mm'} else 'c');header=path.suffix in {'.h','.hpp','.hh','.hxx','.inc','.inl','.ipp'}
  if not f['legacy_file'] and header and re.search(rb'(?m)^\s*(?:namespace\s+\w+|template\s*<|class\s+\w+|(?:inline\s+)?constexpr\b)',b):lang='cpp'
  tree=PARSERS[lang].parse(b);error_count=sum(n.type=='ERROR' or n.is_missing for n in walk(tree.root_node))
  if not f['legacy_file'] and header and error_count>10:
   alt='c' if lang=='cpp' else 'cpp';other=PARSERS[alt].parse(b);cnt=sum(n.type=='ERROR' or n.is_missing for n in walk(other.root_node))
   if cnt<error_count:tree=other;lang=alt;error_count=cnt
  f['language']=lang;f['parse_error_count']=error_count;f['scope_membership']=membership.get(fid,{}).get('package_membership','unresolved_not_package_or_build_proof');out.put('native_files',f);out.put('native_nodes',dict(node_id=fid,node_type='source_file',**f));stats['files']+=1;stats['parse_error_nodes']+=error_count
  if error_count:boundary(fid,'parse_error_regions','Unpreprocessed grammar has ERROR/missing nodes; unidentified edges may remain.',file_id=fid,file=f['path'],error_nodes=error_count)
  if path.suffix in {'.inc','.inl','.y','.rl','.l','.m','.mm'} or str(path).endswith('.in'):boundary(fid,'fragment_or_generator_input','Non-standalone fragment/generator/Objective-C input; C/C++ grammar does not establish generated/runtime semantics.',file_id=fid,file=f['path'])
  ranges=[];node_functions={}
  for n in walk(tree.root_node):
   if n.type not in ('function_definition','preproc_function_def','preproc_def'):continue
   decl=n.child_by_field_name('declarator');name=ident(decl,b) if n.type=='function_definition' else txt(b,n.child_by_field_name('name'))
   if not name:continue
   fnid=key('fn',fid,n.start_byte,name);macro=n.type!='function_definition';shadow=set()
   if not macro:
    for item in walk(n):
     if item.type in ('parameter_declaration','init_declarator','pointer_declarator') and item.child_by_field_name('declarator') is not None:shadow.add(ident(item.child_by_field_name('declarator'),b))
     elif item.type=='declaration':
      for child in item.named_children:
       if child.type in ('identifier','array_declarator'):shadow.add(ident(child,b))
   cpp_context=[];anc=n.parent
   while anc:
    if anc.type in {'namespace_definition','class_specifier','struct_specifier','template_declaration','lambda_expression'}:cpp_context.append(anc.type)
    anc=anc.parent
   fn=dict(cpp_context=cpp_context,function_id=fnid,node_id=fnid,node_type='macro' if macro else 'function',gem_id=gid,file_id=fid,file=f['path'],name=name,line=n.start_point.row+1,end_line=n.end_point.row+1,byte_offset=n.start_byte,end_byte=n.end_byte,kind='macro' if macro else 'function',is_static=bool(re.search(r'\bstatic\b',txt(b,n)[:max(0,decl.start_byte-n.start_byte)])) if decl else False,language=lang,parse_has_errors=n.has_error,shadowed_identifiers=sorted(shadow),conditions=guards(n,b),source_context=f['source_context'])
   funcs[fnid]=fn;byfile[(fid,name)].append(fnid);bygem[(gid,name)].append(fnid);node_functions[(n.start_byte,n.end_byte)]=fnid;ranges.append((n.start_byte,n.end_byte,fnid,macro));out.put('native_nodes',fn);edge(fid,fnid,'translation_unit_defines',conditions=fn['conditions'],file_id=fid,file=f['path'],line=fn['line']);stats['functions']+=1
  def ownerof(n):
   here=n
   while here:
    found=node_functions.get((here.start_byte,here.end_byte))
    if found:return found
    here=here.parent
   return None
  seen_offsets=set()
  pp_depth=0
  for no,line_text in enumerate(b.decode('utf8','replace').split('\n'),1):
   match=re.match(r'\s*#\s*include\s*([<\"])([^>\"]+)[>\"]',line_text)
   if match:include_specs[fid].append(dict(line=no,name=match[2],quoted=match[1]=='\"',conditional_depth=pp_depth))
   if re.match(r'\s*#\s*(?:if|ifdef|ifndef)\b',line_text):pp_depth+=1
   elif re.match(r'\s*#\s*endif\b',line_text):pp_depth=max(0,pp_depth-1)
  if lang=='cpp' and re.search(rb'\busing\s+(?:namespace\b|[A-Za-z_])',b):cpp_unsafe_files.add(fid)
  for n in walk(tree.root_node):
   owner=ownerof(n)
   if n.type=='function_declarator' and owner is None:
    name=ident(n,b)
    if name:declarations[(fid,name)].append(dict(file_id=fid,line=n.start_point.row+1,conditions=guards(n,b),signature=txt(b,n)))
   if n.type=='call_expression':
    callee=txt(b,n.child_by_field_name('function'));an=n.child_by_field_name('arguments');args=[txt(b,x) for x in an.named_children] if an else [];register_call(f,n,owner,callee,args);seen_offsets.add(n.start_byte)
   elif n.type in ('preproc_function_def','preproc_def'):
    val=n.child_by_field_name('value')
    if val:
     for match in re.finditer(rb'\b([A-Za-z_]\w*)\s*\(',b[val.start_byte:val.end_byte]):register_call(f,n,owner,match[1].decode(),[],'macro_token_candidate',val.start_byte+match.start())
   elif n.type in ('assignment_expression','init_declarator') and owner:
    left=n.child_by_field_name('left') or n.child_by_field_name('declarator');right=n.child_by_field_name('right') or n.child_by_field_name('value');lhs=ident(left,b) if n.type=='init_declarator' else txt(b,left);rhs=txt(b,right).strip().lstrip('&')
    if lhs:
     assignment=dict(assignment_id=key('callback_assignment',fid,n.start_byte),function_id=owner,lhs=lhs,rhs=rhs,line=n.start_point.row+1,byte_offset=n.start_byte,file_id=fid,conditions=guards(n,b),candidate_function_designator=bool(IDENT.fullmatch(rhs)))
     callback_assignments[(owner,lhs)].append(assignment)
     if assignment['candidate_function_designator']:out.put('native_callback_assignments',assignment)
   elif n.type=='declaration' and owner is None:
    for child in n.named_children:
     if child.type in ('identifier','init_declarator','pointer_declarator','array_declarator'):global_objects[fid].add(ident(child,b))
   elif n.type in ('new_expression','delete_expression'):
    op='new' if n.type=='new_expression' else 'delete';pid=key('primitive',fid,n.start_byte,n.type);primitive_site(f,n,owner,op,'allocation' if op=='new' else 'deallocation',pid,site_kind='cpp_allocation_expression')
   elif n.type=='array_declarator' and owner and funcs[owner]['kind']=='function':
    parent=n.parent
    while parent and parent.type not in ('declaration','parameter_declaration','field_declaration','translation_unit'):parent=parent.parent
    declaration=txt(b,parent);size=txt(b,n.child_by_field_name('size'))
    if parent and parent.type=='declaration' and not re.search(r'\b(?:static|extern)\b',declaration[:80]) and size and not re.search(r'\(\s*\*\s*\w+\s*\)\s*\[',declaration):primitive_site(f,n,owner,'stack_array','automatic_or_symbolic_stack_array',key('primitive',fid,n.start_byte,n.end_byte,'array'),site_kind='automatic_array_declarator')
  # Lexical primitive evidence retains candidate sites in unsupported parse regions.
  masked=re.sub(rb'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:b' '*len(m[0]),b)
  from types import SimpleNamespace
  for match in re.finditer(rb'\b([A-Za-z_]\w*)\s*\(',masked):
   name=match[1].decode();pos=match.start()
   if pos in seen_offsets or not primitive_type(name) or any(a<=pos<z and macro for a,z,_,macro in ranges):continue
   contained=[x for x in ranges if x[0]<=pos<x[1]];owner=min(contained,key=lambda r:r[1]-r[0])[2] if contained else None
   proxy=SimpleNamespace(start_byte=pos,end_byte=match.end(),start_point=SimpleNamespace(row=bisect.bisect_right(line_offsets,pos)-1),has_error=True,parent=None);register_call(f,proxy,owner,name,[],'lexical_primitive_candidate')
  if ix%250==0:print(json.dumps({'phase':'parse','files':ix,'total':len(files),'functions':len(funcs),'calls':len(calls_seen),'seconds':round(time.time()-start)}),flush=True)
  del tree
 # Close streaming intermediate before resolution.
 handle=out.handles.pop('native_call_index',None)
 if handle:handle.close()
 if not limit:
  # Retain every old function/call/evidence node; unrecovered ones remain explicit boundaries.
  for fnid,old in old_functions.items():
   if fnid in funcs:continue
   fn=dict(old,node_id=fnid,node_type=old['kind'],source_context='locked_gem_source',legacy_candidate_only=True);funcs[fnid]=fn;byfile[(fn['file_id'],fn['name'])].append(fnid);bygem[(fn['gem_id'],fn['name'])].append(fnid);out.put('native_nodes',fn);boundary(fnid,'legacy_definition_not_recovered','Prior function ID retained but new parse did not recover source definition; no resolution promotion.')
  for old in rows(R/'tables/c_calls.jsonl'):
   cid=old['call_id']
   if cid in calls_seen:continue
   calls_seen.add(cid);call=dict(old,node_id=cid,node_type='call',source_context='locked_gem_source',legacy_candidate_only=True);out.put('native_nodes',call);out.put('native_legacy_call_index',call);edge(old.get('function_id') or old['file_id'],cid,'legacy_scope_contains_candidate');boundary(cid,'legacy_call_not_recovered','Prior lexical/macro/other candidate retained, not source-resolved by new AST.')
  if 'native_legacy_call_index' in out.handles:out.handles.pop('native_legacy_call_index').close()
 for pid,p in old_prims.items():
  if limit and p['file_id'] not in {f['file_id'] for f in files}:continue
  if pid not in primitive_seen:out.put('native_nodes',dict(node_id=pid,node_type='primitive_evidence',source_context='locked_gem_source',**p));primitive_seen.add(pid)
  if p.get('call_id'):pending_memory[p['call_id']].append(pid)
  else:edge(p.get('function_id') or p['file_id'],pid,'legacy_memory_evidence',resolution='conditional_source_resolved' if pid in old_ast_storage else 'possible_legacy_memory_candidate',file_id=p['file_id'],line=p['line'],conditions=old_ast_storage.get(pid,[]),evidence={'primitive_semantic_class':'source_storage_syntax' if pid in old_ast_storage else 'unverified_legacy_candidate'})
 for link in old_links:
  if link['primitive_id'] in primitive_seen:edge(link['primitive_id'],link['site_id'],'evidence_identifies_physical_site',evidence=link)
 for rid,reg in legacy_regs.items():
  if rid in reg_seen or limit:continue
  row=dict(reg,node_id=rid,legacy_target_is_candidate=True,source_context='locked_gem_source');out.put('native_nodes',dict(node_type='registration',**row));out.put('native_registrations',row);reg_seen.add(rid)
 handle=out.handles.pop('native_registrations',None)
 if handle:handle.close()
 # Source-only include paths: quoted relative headers are exact; others alternatives.
 path_fids={(f['gem_id'],str((R/f['path']).resolve())):f['file_id'] for f in files}
 includes=collections.defaultdict(list)
 for fid,specs in include_specs.items():
  f=filemeta[fid]
  for inc in specs:
   target=path_fids.get((f['gem_id'],str(((R/f['path']).parent/inc['name']).resolve()))) if inc['quoted'] else None
   row=dict(include_id=key('full_include',fid,inc['line'],inc['name']),file_id=fid,target_file_id=target,resolution='source_relative_include' if target else 'unresolved_header_search_path',**inc)
   out.put('native_includes',row)
   if target:includes[fid].append((target,row['include_id']))
 @functools.lru_cache(maxsize=32)
 def included(fid):
  seen={fid:[]};todo=collections.deque([fid])
  while todo:
   here=todo.popleft()
   for target,eid in includes.get(here,[]):
    if target not in seen:seen[target]=seen[here]+[eid];todo.append(target)
  return seen
 # Only literal create_makefile with unchanged default sources: no dynamic source lists/chdir.
 for gid,src in source_by_gid.items():
  for extconf in src.rglob('extconf.rb'):
   text=extconf.read_text(errors='replace');clean='\n'.join(x for x in text.split('\n') if not x.lstrip().startswith('#'))
   matches=list(re.finditer(r"(?m)^\s*create_makefile\s*(?:\(\s*)?['\"]([^'\"]+)['\"]",clean))
   if len(matches)!=1 or re.search(r'\$(?:srcs|objs|srcdir|VPATH)\b|\b(?:Dir\.)?chdir\b|\b(?:SRC|OBJS|SRCS)\s*=',clean):continue
   members=[f['file_id'] for f in files if f['gem_id']==gid and (R/f['path']).parent==extconf.parent and Path(f['path']).suffix in {'.c','.cc','.cpp','.cxx'}]
   if not members:continue
   scope=key('build_scope',gid,str(extconf));record=dict(build_scope_id=scope,gem_id=gid,extconf=str(extconf.relative_to(R)),source_sha256=hashlib.sha256(extconf.read_bytes()).hexdigest(),extension=matches[0][1],file_ids=members,condition='Literal create_makefile and default mkmf source-directory selection; successful matching build and no externally injected source/link override assumed.',selection='conditional_default_mkmf_sources',source_rule={'file':'sources/runtime/ruby-v3_3_11/lib/mkmf.rb','lines':[2295,2297], 'model':'orig_srcs glob SRC_EXT in srcdir; srcs=$srcs||orig_srcs','applicability':'matching mkmf source-selection semantics required'})
   out.put('native_build_scopes',record)
   for member in members:build_scopes[member]=record
 def candidates(fid,gid,name):
  local=byfile.get((fid,name),[])
  if local:return local
  reachable=included(fid);header=[x for x in bygem.get((gid,name),[]) if funcs[x]['file_id'] in reachable]
  if header:return header
  return [x for x in bygem.get((gid,name),[]) if not funcs[x].get('is_static') and funcs[x]['kind']=='function']
 def cross_tu_supported(fid,target,name):
  fn=funcs[target];reachable=included(fid)
  if fn['file_id'] in reachable:return dict(kind='source_include_definition',include_path=reachable[fn['file_id']])
  scope=build_scopes.get(fid)
  if fn.get('is_static') or not scope or fn['file_id'] not in scope['file_ids']:return None
  visible=[decl for path in reachable for decl in declarations.get((path,name),[])]
  if not visible:return None
  defs=[x for x in bygem[(fn['gem_id'],name)] if not funcs[x].get('is_static') and funcs[x]['kind']=='function' and funcs[x]['file_id'] in scope['file_ids']]
  if len(defs)!=1:return None
  return dict(kind='conditional_mkmf_build_scope_and_visible_declaration',build_scope_id=scope['build_scope_id'],declarations=visible,condition=scope['condition'])
 def cpp_supported(call,fn):
  if fn.get('cpp_context') or call['file_id'] in cpp_unsafe_files:return False
  if call.get('unevaluated_contexts'):return False
  # Global non-overloaded free functions with no ADL-associated argument types.
  return all(re.fullmatch(r'(?:[0-9]+(?:\.[0-9]+)?[uUlLfF]*|true|false|nullptr|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])\')',a.strip()) for a in call.get('arguments',[]))

 def memory_semantics(call):
  cid=call['call_id'];pids=pending_memory.get(cid,[])
  if not pids:return
  name=call['callee'];fid=call['file_id'];owner=funcs.get(call.get('function_id'),{});norm=re.sub(r'^(?:::|std::)','',name)
  visible=included(fid);headers=[i['name'] for i in include_specs.get(fid,[]) if i['line']<call['line'] and i.get('conditional_depth',1)==0 and (not i['quoted'] or not ((R/filemeta[fid]['path']).parent/i['name']).exists())]
  shadow=norm in owner.get('shadowed_identifiers',[]) or norm in global_objects[fid]
  defs=[x for f in visible for x in byfile.get((f,norm),[])]
  ruby=norm.startswith(('rb_','ruby_')) or norm in COERCE or bool(CONVERT.fullmatch(norm)) or norm in {'ALLOC','ALLOC_N','REALLOC_N','ALLOCA_N','ALLOCV','ALLOCV_N','ALLOCV_END','xfree','xmalloc','xcalloc','xrealloc'}
  standard=norm in {'malloc','calloc','realloc','free','alloca','memcpy','memmove','memset','bcopy','bzero','strcpy','strncpy','strcat','strncat','strdup','strndup'}
  standard_headers={'malloc':{'stdlib.h','cstdlib','malloc.h'},'calloc':{'stdlib.h','cstdlib','malloc.h'},'realloc':{'stdlib.h','cstdlib','malloc.h'},'free':{'stdlib.h','cstdlib','malloc.h'},'alloca':{'alloca.h','stdlib.h'},'bcopy':{'strings.h'},'bzero':{'strings.h'}}
  header_ok=(ruby and any(h=='ruby.h' or h.startswith('ruby/') for h in headers)) or (standard and any(h in standard_headers.get(norm,{'string.h','cstring'}) for h in headers))
  valid=call.get('syntax')=='ast_call' and not call.get('legacy_candidate_only') and not call.get('parse_region_has_errors') and not call.get('unevaluated_contexts') and not shadow and not defs and header_ok
  resolution='conditional_source_resolved' if valid else 'possible_memory_api_name_only'
  for pid in pids:edge(cid,pid,'call_has_memory_evidence',resolution,conditions=call.get('conditions',[]),file_id=fid,line=call['line'],evidence={'primitive_semantic_class':'unshadowed_declared_api_model' if valid else 'candidate_only','matching_header_api_assumption':bool(valid),'headers':sorted(set(headers)) if valid else [],'fresh_allocation':'not_implied','local_definition_or_shadow':bool(shadow or defs)})
  if not valid:boundary(cid,'memory_operation_semantics_unresolved','Memory-like name or legacy evidence is not a verified memory operation; local definitions, macros, declaration/configuration and grammar require resolution.',file_id=fid,line=call['line'])
 def resolve(call,registration=False):
  cid=call.get('registration_id') if registration else call['call_id'];name=call.get('c_function_expression','') if registration else call['callee'];fid=call['file_id'];gid=call['gem_id'];owner=funcs.get(call.get('function_id'),{});conditions=call.get('conditions',[]);candidate_ids=[]
  if IDENT.fullmatch(name):candidate_ids=candidates(fid,gid,name)
  shadow=name in owner.get('shadowed_identifiers',[]) or name in global_objects[fid]
  callback=callback_assignments.get((call.get('function_id'),name),[]) if not registration else []
  if shadow or not IDENT.fullmatch(name):
   for assignment in callback:
    if not assignment['candidate_function_designator']:continue
    for target in byfile.get((fid,assignment['rhs']),[]):
     if funcs[target]['kind']!='function':continue
     edge(cid,target,'source_assignment_callback_candidate','possible_callback_assignment_not_points_to_proof',conditions=conditions+assignment['conditions'],file_id=fid,line=call['line'],evidence={'assignment_id':assignment['assignment_id'],'lhs':assignment['lhs'],'rhs':assignment['rhs']});stats['callback_candidate_edges']+=1
   boundary(cid,'indirect_or_shadowed_call','Member/function-pointer/local-shadowed call; assignments are possible targets only, aliases/escapes/order unknown.',file_id=fid,line=call['line']);return
  if not candidate_ids:boundary(cid,'unresolved_callee_or_registration','No source-qualified unique target; external API/build-generated/macro/indirect resolution remains open.',file_id=fid,line=call['line'],callee=name);return
  unsupported=[target for target in candidate_ids if funcs[target]['file_id']!=fid and not cross_tu_supported(fid,target,name)]
  if unsupported:
   setid=key('candidate_set',gid,name,*sorted(unsupported))
   if setid not in candidate_sets:
    out.put('native_candidate_sets',dict(candidate_set_id=setid,gem_id=gid,name=name,target_ids=sorted(unsupported),resolution='possible_cross_translation_unit_symbol_only'));candidate_sets.add(setid)
   out.put('native_candidate_references',dict(reference_id=key('candidate_ref',cid,setid),node_id=cid,candidate_set_id=setid,kind='registration_target_alternatives' if registration else 'call_target_alternatives',traversable=False,conditions=conditions))
   candidate_ids=[x for x in candidate_ids if x not in set(unsupported)]
   boundary(cid,'cross_tu_linkage_unproved','Name-only alternatives retained as normalized candidate set, not execution edges.',file_id=fid,line=call['line'],candidate_set_id=setid)
  for target in candidate_ids:
   fn=funcs[target];samefile=fn['file_id']==fid;gs=conditions+fn.get('conditions',[])
   if literal_false(gs):resolution='excluded_literal_preprocessor'
   elif call.get('legacy_candidate_only') or fn.get('legacy_candidate_only'):resolution='possible_legacy_candidate'
   elif not samefile and not cross_tu_supported(fid,target,name):resolution='possible_cross_translation_unit_symbol_only'
   elif len(candidate_ids)>1:resolution='ambiguous_same_file_definitions'
   elif fn['kind']=='macro' or not registration and call.get('syntax')!='ast_call':resolution='possible_macro_expansion_or_lexical_candidate'
   elif (fn.get('language')=='cpp' or owner.get('language')=='cpp') and (registration or not cpp_supported(call,fn)):resolution='possible_cpp_lookup'
   elif fn.get('parse_has_errors') or call.get('parse_region_has_errors'):resolution='possible_parse_error_context'
   else:resolution='conditional_source_resolved'
   edge(cid,target,'registration_binds_c_function' if registration else 'call_targets_function_or_macro',resolution,conditions=gs,file_id=fid,file=filemeta.get(fid,{}).get('path'),line=call['line'],language=fn.get('language','c'),source_context=call.get('source_context'),evidence={'target_definition_file_id':fn['file_id'],'target_definition_line':fn['line'],'lookup':'same_file' if samefile else 'same_gem_external_name_only','runtime_linkage':'not_established','preprocessor':'not_executed','cross_translation_unit_evidence':cross_tu_supported(fid,target,name) if not samefile else None,'cpp_subset':'global_free_function_literal_or_no_arguments_no_using_or_overload' if fn.get('language')=='cpp' and resolution=='conditional_source_resolved' else None});stats['target_'+resolution]+=1
  if candidate_ids and all(funcs[x]['file_id']!=fid and not cross_tu_supported(fid,x,name) for x in candidate_ids):boundary(cid,'cross_tu_linkage_unproved','Candidate symbols retained; declarations/include/build/linker association not established.',file_id=fid,line=call['line'],candidate_ids=candidate_ids)
 for p in (G/'tables/native_call_index.jsonl.gz',G/'tables/native_legacy_call_index.jsonl.gz'):
  for call in rows(p):memory_semantics(call);resolve(call)
 for reg in rows(G/'tables/native_registrations.jsonl.gz'):resolve(reg,True)
 out.close();report=dict(status='static_native_graph_complete_for_selected_files',counts=dict(out.counts),resolution_counts=dict(stats),source_files=len(files),all_inventory_files=len(filemeta),functions=len(funcs),calls=len(calls_seen),physical_sites=len(sites_seen),primitive_evidence=len(primitive_seen),seconds=round(time.time()-start),limitations=['All graph containment/target relations are static and context conditional; arbitrary walks need not be branch feasible.','C++ lookup, cross-TU/linkage, macro expansion and function pointers are alternatives/boundaries, not proven direct targets.','No preprocessing, compilation, build hooks, target code, extension runtime tests or source deletion.','Memory API invocations/sites do not imply fresh allocation or attacker-controlled data.','Full retained source roles include tests/vendors/native tools and auxiliary/runtime; package/build membership not silently inferred.'])
 (G/'reports/native_graph_coverage.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--source-root',type=Path,default=R);ap.add_argument('--limit',type=int);ap.add_argument('--output-root',type=Path,default=G);a=ap.parse_args();R=a.source_root;G=a.output_root;G.mkdir(parents=True,exist_ok=True);(G/'reports').mkdir(exist_ok=True);build(a.limit)
