#!/usr/bin/env python3
"""Precommitted stratified unique-relation sample; normalized frozen edge JSONL input.
No target code execution. No graph traversal limits. SQLite dedup avoids retaining graph in RAM.
Input fields: edge_id,profile,layer,relation_family,resolution_technique,graph_partition,
source_node_id,target_node_id (null allowed for unresolved boundary), plus evidence fields.
"""
import argparse,pathlib,json,hashlib,sqlite3,heapq,collections,gzip
SEED='gitlab-full-graph-edge-audit-20260930-v1'
FIELDS=('profile','layer','relation_family','resolution_technique','graph_partition')
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--input',action='append',required=True);p.add_argument('--out',required=True);p.add_argument('--per-stratum',type=int,default=3);a=p.parse_args();assert a.per_stratum>0
 out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
 files=[pathlib.Path(x).resolve() for x in a.input];manifest=[dict(path=str(x),sha256=digest(x)) for x in files];dataset=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
 dbfile=out/'dedup.sqlite';assert not dbfile.exists(),'Refuse overwrite prior sample';db=sqlite3.connect(dbfile);db.execute('CREATE TABLE seen(k TEXT PRIMARY KEY, stratum TEXT)');counts=collections.Counter();heaps=collections.defaultdict(list);duplicates=0;total=0
 for path in files:
  with (gzip.open(path,'rt') if path.suffix=='.gz' else path.open()) as f:
   for number,line in enumerate(f,1):
    row=json.loads(line);total+=1
    for key in (*FIELDS,'edge_id','source_node_id','target_node_id'):assert key in row,(str(path),number,key)
    assert row['graph_partition'] in ('resolved','candidate','boundary')
    stratum=tuple(row[k] for k in FIELDS)
    identity=[row['profile'],row['layer'],row['relation_family'],row['graph_partition'],row['source_node_id'],row['target_node_id']]
    unit=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()
    try:db.execute('INSERT INTO seen VALUES(?,?)',(unit,json.dumps(stratum)))
    except sqlite3.IntegrityError:
     prior=db.execute('SELECT stratum FROM seen WHERE k=?',(unit,)).fetchone()[0]
     assert prior==json.dumps(stratum),'Same semantic relation has conflicting stratum metadata; normalize before sampling'
     duplicates+=1;continue
    stratum=tuple(row[k] for k in FIELDS);counts[stratum]+=1
    rank=int(hashlib.sha256((SEED+'|'+unit).encode()).hexdigest(),16)
    item=(-rank,unit,dict(row,sample_source_file=str(path),sample_source_line=number,audit_unit_id=unit))
    heap=heaps[stratum]
    if len(heap)<a.per_stratum:heapq.heappush(heap,item)
    elif rank < -heap[0][0]:heapq.heapreplace(heap,item)
 db.commit();db.close();selected=[];strata=[]
 for st in sorted(counts):
  n=min(a.per_stratum,counts[st]);label='|'.join(st);strata.append(dict(stratum=label,N=counts[st],n=n))
  for _,unit,row in sorted(heaps[st],key=lambda x:-x[0]):selected.append(dict(row,dataset_id=dataset,stratum=label,stratum_population=counts[st],stratum_sample_size=n,audit_id='audit_'+unit[:24]))
 (out/'sample.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in selected))
 report=dict(seed=SEED,dataset_id=dataset,inputs=manifest,input_rows=total,unique_relations=sum(counts.values()),duplicate_evidence_relations=duplicates,sample_size=len(selected),strata=strata,algorithm='lowest SHA256(seed|semantic_unit_id) per stratum; deterministic pseudorandom sampling without replacement',deduplication='profile/layer/relation_family/graph_partition/source_node_id/target_node_id; first evidence row retained; conflicting technique metadata rejected',limit='Audit sample size only, no graph-enumeration cap. Interpret as review-verdict frequencies, not runtime precision. Conditions must be reviewed from complete edge evidence, not first row alone if duplicated.')
 (out/'sampling_manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(dataset_id=dataset,sample_size=len(selected),strata=len(strata))))
if __name__=='__main__':main()
