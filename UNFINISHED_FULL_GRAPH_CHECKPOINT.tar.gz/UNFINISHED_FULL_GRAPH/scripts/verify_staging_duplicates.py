import tarfile,hashlib,json,os
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_results');O=Path('/workspace/gitlab_c_ext_full_graph/reports/staging_duplicate_verification.json')
def digest(f):
 h=hashlib.sha256()
 while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
reports=[]
for archive,folder in [('gitlab-frontend-results.tar.xz','frontend-results'),('gitlab-frozen-v2-path-results.tar.xz','corrected-results')]:
 seen=set();errors=[];total=0;members=0
 with tarfile.open(R/archive,'r|xz') as tar:
  for m in tar:
   if not m.isfile():
    if not m.isdir():errors.append({'member':m.name,'reason':'nonregular_member_requires_manual_check'})
    continue
   p=R/m.name
   if not p.is_relative_to(R/folder):errors.append({'member':m.name,'reason':'unexpected_archive_prefix'});continue
   seen.add(str(p.relative_to(R/folder)));members+=1;total+=m.size
   ah=digest(tar.extractfile(m))
   if not p.is_file() or p.is_symlink():errors.append({'member':m.name,'reason':'missing_or_symlink_stage'});continue
   with p.open('rb') as f:sh=digest(f)
   if ah!=sh:errors.append({'member':m.name,'reason':'content_hash_mismatch','archive_sha256':ah,'staging_sha256':sh})
 actual={str(p.relative_to(R/folder)) for p in (R/folder).rglob('*') if p.is_file() or p.is_symlink()};extra=sorted(actual-seen)
 with (R/archive).open('rb') as f:archive_hash=digest(f)
 reports.append(dict(archive=str(R/archive),archive_sha256=archive_hash,staging=str(R/folder),regular_members=members,verified_bytes=total,extra_stage_files=extra,errors=errors,verified_regenerable_duplicate=not errors and not extra,deleted=False))
 O.write_text(json.dumps({'scope':'Read-only bytewise SHA256 comparison of every archive regular member and full staging file census; no deletion','comparisons':reports},indent=2)+'\n')
 print(folder,members,total,'errors',len(errors),'extra',len(extra),flush=True)
