"""Runs actual source analyzer against synthetic C/C++ files; never compiles/executes targets."""
import pathlib,json,tempfile,hashlib,importlib.util,gzip,contextlib,io
ROOT=pathlib.Path('/workspace/gitlab_c_ext_full_graph');PRODUCER=ROOT/'scripts/build_native_graph.py'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 if not p.exists():return []
 with gzip.open(p,'rt') as f:return [json.loads(l) for l in f]
def run():
 before=sha(PRODUCER);s=importlib.util.spec_from_file_location('nativeprod',PRODUCER);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
 cases=[('foreign_static_registration',{'a.c':'void init(void){rb_define_method(0,"work",work,0);}','b.c':'static void work(void){free(0);}'},'work','registration_binds_c_function',False),('parameter_shadow',{'a.c':'void helper(void){} void run(void (*helper)(void)){helper();}'},'helper','call_targets_function_or_macro',False),('registration_parameter_shadow',{'a.c':'void work(void){} void init(void (*work)(void)){rb_define_method(0,"work",work,0);}'},'work','registration_binds_c_function',False),('conditional_definitions',{'a.c':'#if FEATURE\nstatic void work(void){free(0);}\n#else\nstatic void work(void){}\n#endif\nvoid run(void){work();}'},'work','call_targets_function_or_macro',False),('cross_tu_without_build',{'a.c':'void run(void){extern void target(void);target();}','b.c':'void target(void){free(0);}'},'target','call_targets_function_or_macro',False),('cpp_member_not_free',{'a.cpp':'void work(){} struct A{void work();}; void run(A a){a.work();}'},'work','call_targets_function_or_macro',False),('direct_positive',{'a.c':'static void work(void){} void run(void){work();}'},'work','call_targets_function_or_macro',True)]
 results=[]
 for name,files,target,relation,expected in cases:
  with tempfile.TemporaryDirectory() as td:
   root=pathlib.Path(td);r=root/'r';g=root/'g';src=r/'sources/gems/fixture';src.mkdir(parents=True);(r/'tables').mkdir();(g/'reports').mkdir(parents=True)
   for f,code in files.items():(src/f).write_text(code+'\n')
   (r/'tables/c_source_gems.jsonl').write_text(json.dumps(dict(gem_id='fixture',canonical_gem_id='fixture',source_dir=str(src)))+'\n')
   (r/'tables/gems.jsonl').write_text(json.dumps(dict(gem_id='fixture',name='fixture',version='0',source_dir=str(src)))+'\n')
   m.R=r;m.G=g
   with contextlib.redirect_stdout(io.StringIO()):m.build()
   edges=read(g/'tables/native_edges.jsonl.gz');resolved=[e for e in edges if e.get('resolution')=='conditional_source_resolved' and e.get('kind',e.get('relation'))==relation]
   # Single fixture has only selected direct target calls; primitive/external edges stay boundaries.
   ok=bool(resolved)==expected
   results.append(dict(fixture_id=name,status='PASS' if ok else 'FAIL',source_files=files,expected_resolved_relation=expected,resolved_edges=resolved,all_target_edges=[e for e in edges if e.get('kind',e.get('relation'))==relation],output_tables=[p.name for p in (g/'tables').iterdir()],target_code_executed=False))
 assert sha(PRODUCER)==before,'Producer changed while running; repeat'
 report=dict(status='PASS' if all(x['status']=='PASS' for x in results) else 'FAIL',producer_sha256=before,fixture_count=len(results),passed=sum(x['status']=='PASS' for x in results),fixtures=results)
 p=ROOT/'reports'/('independent_native_regressions_'+before[:12]+'_no_scaffold.json');p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(report=str(p),sha256=sha(p),passed=report['passed'],failed=[x['fixture_id'] for x in results if x['status']=='FAIL'])))
if __name__=='__main__':run()
