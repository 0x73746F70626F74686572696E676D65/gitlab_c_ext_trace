"""Independent retained-source census and reuse inventory. Static file reads only."""
import os,json,gzip,hashlib,collections,time
from pathlib import Path
W=Path('/workspace');B=W/'gitlab_c_ext_trace';O=W/'gitlab_c_ext_full_graph';T=O/'tables';T.mkdir(exist_ok=True)
ROOTS=[B/'sources',W/'gitlab_c_ext_ee_profile/sources']
NATIVE={'.c','.h','.cc','.cpp','.cxx','.hpp','.hh','.hxx','.inc','.inl','.ipp','.y','.rl','.l','.m','.mm'}
RUBY={'.rb','.rake','.gemspec','.ru','.thor','.builder','.jbuilder','.rabl','.podspec'}
NAMES={'Gemfile','Rakefile','Guardfile','Appraisals','Thorfile','Vagrantfile','Brewfile','Podfile','Fastfile','Rantfile','Capfile'}
def rows(p):
 with p.open() as f:
  for l in f:yield json.loads(l)
def h(s):return hashlib.sha256(s.encode()).hexdigest()[:24]
def emit(f,x):f.write(json.dumps(x,separators=(',',':'))+'\n')
def family(path):
 s=str(path)
 if '/sources/gitlab/' in s:return 'gitlab_ce'
 if '/sources/ee_discovery/' in s:return 'gitlab_ee'
 if '/sources/runtime/' in s:return 'runtime_model'
 if '/sources/external_models/' in s:return 'auxiliary_external_model'
 if '/gitlab_c_ext_ee_profile/sources/' in s:return 'ee_profile_gem'
 if '/sources/investigation' in s:return 'investigation_source'
 return 'retained_gem_or_repository'
def role(p):
 parts=set(p.parts)
 if parts & {'spec','specs','test','tests','qa','fixtures','testdata'}:return 'test_fixture'
 if parts & {'example','examples','benchmark','benchmarks','doc','docs'}:return 'example_documentation'
 if parts & {'vendor','third_party','third-party','deps','ports'}:return 'vendored'
 return 'production_or_repository_unresolved'
ast=collections.defaultdict(dict);oldsourceids={};deferred=collections.defaultdict(list);rootgems=collections.defaultdict(list);allgems=[]
for origin in ['gitlab_c_ext_trace','gitlab_c_ext_ruby_expanded','gitlab_c_ext_ee_profile']:
 p=W/origin/'tables/ruby_files.jsonl'
 for r in rows(p):
  path=(B/r['file']).resolve();key=('ruby',r['file_id']);entry=ast[str(path)].setdefault(key,dict(language='ruby',file_id=r['file_id'],sha256=r['sha256'],parse_error=bool(r.get('has_parse_error')),origins=[]));entry['origins'].append(str(p))
for r in rows(B/'tables/c_files.jsonl'):
 path=(B/r['path']).resolve();ast[str(path)][('native',r['file_id'])]=dict(language='native',file_id=r['file_id'],gem_id=r.get('gem_id'),sha256=r['sha256'],parse_error_count=r.get('parse_error_count',0),origins=[str(B/'tables/c_files.jsonl')])
for r in rows(B/'tables/c_deferred_files.jsonl'):deferred[str((B/r['path']).resolve())].append(r)
for r in rows(B/'tables/source_files.jsonl'):oldsourceids[str(B/r['path'])]=r['source_file_id']
for profile,p in [('baseline_all_locks',B/'tables/gems.jsonl'),('ee_primary',W/'gitlab_c_ext_ee_profile/tables/profile_gems.jsonl')]:
 for r in rows(p):
  record=dict(r);record['ledger_profile']=profile;allgems.append(record);root=r.get('source_root') or r.get('source_dir')
  if root and Path(root).exists():rootgems[str(Path(root).resolve())].append(dict(gem_id=r['gem_id'],profile=profile,profile_gem_id=r.get('profile_gem_id'),primary=bool(r.get('primary_bundle'))))
# Physical set avoids source alias inflation; lexical aliases get their own rows.
seen=set();counts=collections.Counter();groups=collections.defaultdict(collections.Counter);gemstats=collections.defaultdict(collections.Counter);missing_index=[];ast_seen=set();hash_cache={};start=time.time()
visited=set()
if (T/'retained_source_coverage.jsonl.gz').exists():
 with gzip.open(T/'retained_source_coverage.jsonl.gz','rt') as previous:
  for line in previous:
   r=json.loads(line);visited.add(r['path']);resolved=r.get('canonical_path',r['path']);ast_seen.add(resolved)
   if r.get('status')=='unreadable':counts['unreadable']+=1;continue
   counts['lexical_files']+=1
   if r['physical_first']:
    seen.add(resolved);counts['physical_files']+=1;counts['physical_bytes']+=r['bytes'];groups[r['family']]['files']+=1
    for lang in ['ruby','native']:
     if r[lang+'_eligible']:counts[lang+'_'+r[lang+'_status']]+=1;groups[r['family']][lang+'_'+r[lang+'_status']]+=1
    for g in r['gem_memberships']:
     key=(g['profile'],g.get('profile_gem_id') or g['gem_id']);gemstats[key]['physical_files']+=1
     for lang in ['ruby','native']:
      if r[lang+'_eligible']:gemstats[key][lang+'_'+r[lang+'_status']]+=1
print('resume_files',len(visited),flush=True)
with gzip.open(T/'retained_source_coverage.jsonl.gz','at',compresslevel=1) as out,gzip.open(T/'ruby_recovery_candidates.jsonl.gz','at',compresslevel=1) as rub,gzip.open(T/'native_recovery_candidates.jsonl.gz','at',compresslevel=1) as nat:
 for root in ROOTS:
  for d,dirs,files in os.walk(root,followlinks=False):
   dirs[:]=sorted(x for x in dirs if x!='.git');files.sort()
   for name in files:
    p=Path(d)/name
    if str(p) in visited:continue
    try:resolved=str(p.resolve())
    except (OSError,RuntimeError) as ex:
     emit(out,dict(source_id='source_'+h(str(p.relative_to(W))),path=str(p),kind='symlink_loop_or_resolution_error',status='unreadable',error=str(ex),family=family(p)));counts['unreadable']+=1;continue
    kind='symlink_file' if p.is_symlink() else 'file';fid='source_'+h(str(p.relative_to(W)));fam=family(p);rr=role(p);suffix=p.suffix.lower();native=suffix in NATIVE or str(p).endswith(('.c.in','.h.in'));ruby=suffix in RUBY or p.name in NAMES
    try:
     if resolved not in hash_cache:
      digest=hashlib.sha256();head=b'';size=0
      with p.open('rb') as f:
       while chunk:=f.read(1024*1024):
        if not head:head=chunk[:256]
        digest.update(chunk);size+=len(chunk)
      hash_cache[resolved]=(digest.hexdigest(),size,head)
     sh,size,head=hash_cache[resolved]
    except (OSError,ValueError) as ex:
     emit(out,dict(source_id=fid,path=str(p),canonical_path=resolved,kind=kind,status='unreadable',error=str(ex),family=fam));counts['unreadable']+=1;continue
    shebang=head.startswith(b'#!') and b'ruby' in head.split(b'\n',1)[0]
    ruby=ruby or shebang
    memberships=[];cur=Path(resolved).parent
    while cur!=cur.parent:
     memberships.extend(rootgems.get(str(cur),[]));cur=cur.parent
    entries=list(ast.get(resolved,{}).values());ast_seen.add(resolved)
    ruby_entries=[e for e in entries if e['language']=='ruby'];c_entries=[e for e in entries if e['language']=='native']
    def status(es,expected):
     if not expected:return 'not_selected_language'
     if not es:return 'missing_ast'
     if any(e['sha256']!=sh for e in es):return 'source_hash_mismatch'
     return 'parsed_with_errors' if any(e.get('parse_error') or e.get('parse_error_count',0)>0 for e in es) else 'parsed'
    rs=status(ruby_entries,ruby);cs=status(c_entries,native)
    if cs=='missing_ast' and resolved in deferred:cs='explicitly_deferred_ast'
    physical=resolved not in seen;seen.add(resolved)
    row=dict(source_id=fid,old_source_file_id=oldsourceids.get(str(p)),path=str(p),canonical_path=resolved,kind=kind,sha256=sh,bytes=size,family=fam,source_role=rr,physical_first=physical,ruby_eligible=ruby,ruby_eligibility='ruby_shebang' if shebang and suffix not in RUBY else 'extension_or_filename',native_eligible=native,ruby_status=rs,native_status=cs,ast_records=entries,deferred_ids=[x['deferred_file_id'] for x in deferred.get(resolved,[])],gem_memberships=memberships,package_membership='retained_repository_association_not_confirmed_build_or_load')
    emit(out,row);counts['lexical_files']+=1
    if physical:
     counts['physical_files']+=1;counts['physical_bytes']+=size;groups[fam]['files']+=1
     for lang,selected,st in [('ruby',ruby,rs),('native',native,cs)]:
      if selected:counts[lang+'_'+st]+=1;groups[fam][lang+'_'+st]+=1
     for g in memberships:
      key=(g['profile'],g.get('profile_gem_id') or g['gem_id']);gemstats[key]['physical_files']+=1
      if ruby:gemstats[key]['ruby_'+rs]+=1
      if native:gemstats[key]['native_'+cs]+=1
    if ruby and rs in ['missing_ast','source_hash_mismatch'] and physical:emit(rub,row)
    if native and cs in ['missing_ast','source_hash_mismatch','explicitly_deferred_ast'] and physical:emit(nat,row)
    if counts['lexical_files']%50000==0:print('files',counts['lexical_files'],'ruby_missing',counts['ruby_missing_ast'],'native_missing',counts['native_missing_ast'],flush=True)
# Every locked row, including auxiliary and actual blockers; no shared failure extrapolation.
with gzip.open(T/'gem_source_coverage.jsonl.gz','wt') as f:
 for r in allgems:
  root=r.get('source_root') or r.get('source_dir');key=(r['ledger_profile'],r.get('profile_gem_id') or r['gem_id']);emit(f,dict(coverage_id='gemcoverage_'+h(str(key)),ledger_profile=r['ledger_profile'],gem_id=r['gem_id'],profile_gem_id=r.get('profile_gem_id'),name=r['name'],locked_version=r.get('locked_version',r.get('version')),platform=r.get('platform'),lockfile=r.get('lockfile'),primary_bundle=r.get('primary_bundle',False),source_root=root,source_available=bool(root and Path(root).exists()),source_status=r.get('status'),source_equivalence=r.get('source_equivalence'),native_classification=r.get('native_classification'),blockers=r.get('blockers',[]),counts=dict(gemstats[key]),qualification='Repository source association; source equivalence/package build/runtime loading not inferred'))
missing_ast_records=[dict(canonical_path=p,ast_records=list(es.values())) for p,es in ast.items() if p not in ast_seen]
with gzip.open(T/'ast_sources_not_in_retained_census.jsonl.gz','wt') as f:
 for r in missing_ast_records:emit(f,r)
summary=dict(status='BASELINE_CENSUS_RECOVERY_PENDING',source_roots=list(map(str,ROOTS)),counts=dict(counts),families={k:dict(v) for k,v in groups.items()},gem_ledger_rows=len(allgems),baseline_primary=sum(r['ledger_profile']=='baseline_all_locks' and r.get('primary_bundle',False) for r in allgems),baseline_primary_sourced=sum(r['ledger_profile']=='baseline_all_locks' and r.get('primary_bundle',False) and bool((r.get('source_root') or r.get('source_dir')) and Path(r.get('source_root') or r.get('source_dir')).exists()) for r in allgems),ast_source_paths_not_in_census=len(missing_ast_records),elapsed_seconds=round(time.time()-start,2),limitations=['Census includes all retained files except .git metadata. Symlink files resolved, directory symlinks not traversed independently to avoid cycles; targets ordinarily appear in retained roots.','Native suffix grammar eligibility includes generator inputs/fragments; parse-error-free does not prove valid translation unit or build selection.','Ruby extensions, known DSL filenames and Ruby shebangs eligible. ERB/RBS and non-Ruby templates counted as source but not standalone Ruby AST.','Primary/auxiliary/profile association retained per gem; no fixture-to-production or source-to-package/runtime implication.'])
(O/'reports/source_coverage_census.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
