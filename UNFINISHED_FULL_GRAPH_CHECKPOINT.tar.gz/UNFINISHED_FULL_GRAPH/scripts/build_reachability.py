#!/usr/bin/env python3
"""Compose complete admitted native and context-isolated Ruby API/sink relations."""
import argparse,collections,gc,hashlib,json,time
from array import array
from pathlib import Path
from compose_graph import *
RUBY_KINDS={'executes_call_if_region_reached','ruby_dispatch','ruby_native_binding','captured_method_alias_invocation','class_body_execution'}
RUBY_APIS={'ruby_method','ruby_alias','generated_accessor'}

def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def nt(n):return n.get('node_type',n.get('kind'))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',default='/workspace/gitlab_c_ext_full_graph');ap.add_argument('--native-only',action='store_true');ap.add_argument('--ruby-kinds',nargs='*');a=ap.parse_args();root=Path(a.root);tables=root/'tables';out=root/'reachability';out.mkdir(exist_ok=True);start=time.time();inputs=[];stats=[];bank=SinkSets()
 (root/'reports').mkdir(exist_ok=True)
 (out/'manifest.json').write_text(json.dumps({'status':'IN_PROGRESS','started_epoch':start})+'\n')
 def inp(n):
  p=tables/n;assert p.exists(),('missing frozen input',str(p));inputs.append(dict(path=str(p.relative_to(root)),sha256=digest(p),bytes=p.stat().st_size));return p
 native_nodes=inp('native_nodes.jsonl.gz');native_edges=inp('native_edges.jsonl.gz');ids=[];known=set();sinks=[];apis=set();duplicates=0
 for n in jsonlines(native_nodes):
  i=n['node_id']
  if i in known:raise ValueError(('duplicate native node_id',i))
  known.add(i);ids.append(i)
  if nt(n)=='memory_site':sinks.append(i)
  if nt(n)=='registration':apis.add(i)
 del known
 sinks.sort();sink_index={n:i for i,n in enumerate(sinks)};gzwrite(out/'sink_index.jsonl.gz',(dict(sink_index=i,node_id=n) for i,n in enumerate(sinks)))
 rejected=collections.Counter();admitted=collections.Counter()
 def edges():
  for e in jsonlines(native_edges):
   if eligible(e,NATIVE_KINDS):admitted[e['kind']]+=1;yield e['source_id'],e['target_id']
   else:rejected[e.get('kind','missing_kind')+'|'+e.get('resolution','missing_resolution')]+=1
 nr=compose(ids,edges(),{n:bank.intern((i,)) for n,i in sink_index.items()},bank);summary=export_view(out/'native_source','native_source',nr,apis);summary.update(admitted_kinds=dict(admitted),excluded_edge_kinds_resolutions=dict(rejected),duplicate_node_rows=duplicates);stats.append(summary)
 # Native execution edges are closed over native nodes; Ruby→native joins may seed ANY existing native node.
 # Retain only native ID/component/set maps while composing separate Ruby contexts.
 native_lookup=nr['lookup'];native_components=nr['components'];native_sets=nr['closures'];del nr,ids,sink_index;gc.collect()
 if not a.native_only:
  rnodes=inp('ruby_nodes.jsonl.gz');edgefiles=[inp('ruby_edges.jsonl.gz')]
  if (tables/'binding_edges.jsonl.gz').exists():edgefiles.append(inp('binding_edges.jsonl.gz'))
  ruby_ids=[];ruby_lookup={};contexts_nodes=collections.defaultdict(set);context_apis=collections.defaultdict(set)
  for n in jsonlines(rnodes):
   nid=n['node_id'];contexts=n.get('contexts',n.get('profiles',[]))
   if nid not in ruby_lookup:ruby_lookup[nid]=len(ruby_ids);ruby_ids.append(nid)
   number=ruby_lookup[nid]
   for ctx in contexts:
    contexts_nodes[ctx].add(number)
    if nt(n) in RUBY_APIS:context_apis[ctx].add(nid)
  context_pairs={};excluded=collections.defaultdict(collections.Counter);included=collections.defaultdict(collections.Counter);kinds=set(a.ruby_kinds) if a.ruby_kinds else RUBY_KINDS
  # Partition endpoints in compact arrays; raw evidence remains in original gzip tables.
  for path in edgefiles:
   for e in jsonlines(path):
    eid=e['edge_id']
    contexts=e.get('contexts',e.get('profiles',[]))
    for ctx in contexts:
     if not eligible(e,kinds,ctx):excluded[ctx][e.get('kind','missing_kind')+'|'+e.get('resolution','missing_resolution')]+=1;continue
     nums=[]
     for nid in [e['source_id'],e['target_id']]:
      if nid not in ruby_lookup:
       if nid not in native_lookup:raise ValueError(('Ruby edge missing endpoint',eid,nid))
       ruby_lookup[nid]=len(ruby_ids);ruby_ids.append(nid)
      nums.append(ruby_lookup[nid])
     if e['source_id'] in native_lookup:raise ValueError(('Native→Ruby/backflow requires full unified composition, not suffix factorization',eid))
     arr=context_pairs.setdefault(ctx,array('I'));arr.extend(nums);contexts_nodes[ctx].update(nums);included[ctx][e['kind']]+=1
  gc.collect()
  for ctx in sorted(contexts_nodes):
   numbers=contexts_nodes.pop(ctx);view_ids=[ruby_ids[i] for i in sorted(numbers)];arr=context_pairs.pop(ctx,array('I'));seed={}
   for n in view_ids:
    if n in native_lookup:seed[n]=native_sets[native_components[native_lookup[n]]]
   r=compose(view_ids,((ruby_ids[arr[i]],ruby_ids[arr[i+1]]) for i in range(0,len(arr),2)),seed,bank)
   dirname=ctx if ctx in ('ce','ee') else 'isolated_'+hashlib.sha256(ctx.encode()).hexdigest()[:24]
   s=export_view(out/dirname,ctx,r,context_apis.get(ctx,set()),seed);s.update(directory=dirname,admitted_kinds=dict(included[ctx]),excluded_edge_kinds_resolutions=dict(excluded[ctx]),native_suffix_seed_nodes=len(seed),profile_isolation='Exact edge contexts only; auxiliary/isolated never implicitly merged into CE/EE');stats.append(s);del r,arr,view_ids,numbers;gc.collect()

 gzwrite(out/'sink_sets.jsonl.gz',bank.records())
 for item in inputs:
  p=root/item['path']
  if p.stat().st_size!=item['bytes'] or digest(p)!=item['sha256']:raise ValueError(('input changed during composition',str(p)))
 report=dict(status='PASS_COMPLETE_ADMITTED_GRAPH_CLOSURE',views=stats,sinks=len(sinks),unique_sink_sets=len(bank.values),input_files=inputs,native_admitted_kinds=sorted(NATIVE_KINDS),ruby_admitted_kinds=sorted(set(a.ruby_kinds) if a.ruby_kinds else RUBY_KINDS),admitted_resolutions=sorted(ADMITTED_RESOLUTIONS),duplicate_edge_policy='All rows retained during composition; parallel edges deduplicated only in SCC condensation. Producer ID uniqueness validated separately.',input_hashes_rechecked=True,seconds=time.time()-start,depth_limit=None,visited_limit=None,path_sampling=False,paths_or_walks_enumerated=False,cycles_retained_in_original_graph=True,scope='Complete finite admitted-edge connectivity; source/guards/arguments jointly satisfiable is NOT inferred. Nonadmitted evidence retained in original tables. Ruby-native suffix factorization assumes no admitted native→Ruby edges and asserts this on bridge source IDs.')
 (root/'reports/reachability_coverage.json').write_text(json.dumps(report,indent=2)+'\n')
 (out/'manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='views'}))
if __name__=='__main__':main()
