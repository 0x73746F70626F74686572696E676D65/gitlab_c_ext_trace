#!/usr/bin/env python3
"""Two-pass source-only Ruby graph. No application execution and no path enumeration."""
import collections,functools,gzip,hashlib,json,pathlib,re,sys,time,argparse,pickle
B=pathlib.Path('/workspace/gitlab_c_ext_trace');OUT=pathlib.Path('/workspace/gitlab_c_ext_full_graph');V=pathlib.Path('/workspace/gitlab_c_ext_v3');CE=pathlib.Path('/workspace/gitlab_c_ext_ruby_expanded');EE=pathlib.Path('/workspace/gitlab_c_ext_ee_profile')
sys.path.insert(0,str(B/'tooling_ruby'));sys.path.insert(0,str(B/'scripts'))
from tree_sitter import Parser,Language
import tree_sitter_ruby
from ruby_lexical_bindings import classify
P=Parser(Language(tree_sitter_ruby.language()))
def uid(*x):return hashlib.sha256('\0'.join(map(str,x)).encode()).hexdigest()[:24]
def rows(p):
 if not p.exists():return
 op=gzip.open if p.suffix=='.gz' else open
 with op(p,'rt') as f:
  for s in f:
   if s.strip():yield json.loads(s)
def writer(name):return gzip.open(OUT/'tables'/(name+'.jsonl.gz'),'wt',compresslevel=5)
def emit(fp,r):fp.write(json.dumps(r,separators=(',',':'),ensure_ascii=False)+'\n')
def fld(n,k):return n.child_by_field_name(k)
def tx(data,n):return data[n.start_byte:n.end_byte].decode('utf8','replace') if n else ''
CONST=re.compile(r'(?:::)?[A-Z]\w*(?:::[A-Z]\w*)*\Z')
AUX=re.compile(r'/(spec|test|tests|fixtures|qa|examples|benchmark|benchmarks|test_projects)/')
CEPREFIX='sources/gitlab/';EEPREFIX='sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/'
GUARDS={'if','unless','if_modifier','unless_modifier','conditional','case','when','while','until','for','rescue'}
SAFE_CLASS_CALLS={'remove_method','undef_method','private','protected','public','private_class_method','public_class_method','attr_reader','attr_writer','attr_accessor','alias_method','include','prepend','extend','module_function','require','require_relative','autoload','freeze','private_constant','public_constant','const_set','define_method','define_singleton_method'}
class Corpus:
 def __init__(self):
  self.files={};self.filegems=collections.defaultdict(set);self.primary={};self.gems={};self.ownership={}
  for root in [B,CE,EE]:
   for r in rows(root/'tables/ruby_files.jsonl'):self.files[r['file']]=r
   for r in rows(root/'tables/ruby_file_gems.jsonl'):self.filegems[r['file_id']].add(r['gem_id'])
  for r in rows(B/'tables/gems.jsonl'):self.gems[r['gem_id']]=r
  self.primary['ce']={g['gem_id'] for g in self.gems.values() if g.get('lockfile')=='Gemfile.lock'}
  config=json.loads((EE/'reports/profile_config.json').read_text());self.primary['ee']=set(config['primary_gem_ids'])
  for r in config.get('extra_gems',[]):self.gems[r['gem_id']]=r
  for r in rows(B/'tables/c_source_gems.jsonl'):
   for p in self.primary:
    if r['gem_id'] in self.primary[p]:self.primary[p].add(r['canonical_gem_id'])
  # Supplemental source census may add files without any old parser row.
  for r in rows(OUT/'tables/ruby_recovery_candidates.jsonl.gz'):
   f=r.get('file') or r.get('path');f=str(pathlib.Path(f).relative_to(B)) if f.startswith(str(B)+'/') else f;self.files.setdefault(f,dict(file=f,file_id=uid(f),corpus='gem'))
  self.scopes=[]
  for g in self.gems.values():
   if g.get('source_dir'):
    root=str(g['source_dir']);root=str(pathlib.Path(root).relative_to(B)) if root.startswith(str(B)+'/') else root
    self.scopes.append((root.rstrip('/')+'/',g['gem_id']))
  self.scopes.sort(key=lambda x:len(x[0]),reverse=True)
 def contexts(self,file):
  if file.startswith(CEPREFIX):base=['ce']
  elif file.startswith(EEPREFIX):base=['ee']
  else:
   fid=self.files[file]['file_id'];gids=self.filegems[fid]
   if not gids:
    best=next((len(p) for p,g in self.scopes if file.startswith(p)),None)
    gids={g for p,g in self.scopes if best==len(p) and file.startswith(p)}
   base=[p for p in ('ce','ee') if gids & self.primary[p]]
   if not base:base=['source:'+uid(next((p for p,g in self.scopes if file.startswith(p)),str(pathlib.PurePosixPath(file).parent)))]
  if AUX.search(file):return ['aux:'+uid(file)+':'+p for p in base]
  return base
class Model:
 def __init__(self,corpus):
  self.corpus=corpus;self.defs=collections.defaultdict(list);self.rels=collections.defaultdict(list);self.aliases=collections.defaultdict(list);self.names=collections.defaultdict(set);self.hooks=collections.defaultdict(set);self.native={};self.pending_owners=[];self.visibility=collections.defaultdict(list);self.stats=collections.Counter();self.meta={}
 def available(self,row,context,file=None):
  contexts=row['contexts'];return context in contexts or context.startswith('aux:') and context.split(':',2)[2] in contexts
 def constant(self,name,lexical,context):
  names=self.names[context]
  if context.startswith('aux:'):names=names|self.names[context.split(':',2)[2]]
  if name.startswith('::'):return name[2:] if name[2:] in names else None
  scopes=list(lexical) if isinstance(lexical,(tuple,list)) else ([lexical] if lexical else [])
  for scope in list(reversed(scopes))+['']:
   c=scope+'::'+name if scope else name
   if c in names:return c
  return None
 def adddef(self,row):
  self.defs[(row['owner'],row['method'],row['method_kind'])].append(row)
  for context in row['contexts']:self.names[context].add(row['owner'])
 def header_owner(self,name,lexical,contexts,file,offset):
  if name.startswith('::'):return name[2:]
  if '::' not in name:return '::'.join(list(lexical[-1:])+[name])
  first,rest=name.split('::',1);parents={self.constant(first,lexical,c) for c in contexts}
  if len(parents)==1 and None not in parents:return next(iter(parents))+'::'+rest
  placeholder='__unresolved_owner_'+uid(file,offset,name)
  self.pending_owners.append(dict(placeholder=placeholder,name=name,lexical=lexical,contexts=contexts));return placeholder
 def parse(self,file,phase,outputs=None):
  data=(B/file).read_bytes();tree=P.parse(data);fid=self.corpus.files[file]['file_id'];contexts=self.corpus.contexts(file);self.stats['phase'+str(phase)+'_files']+=1
  sourcehash=hashlib.sha256(data).hexdigest();method_at={};calls=[];file_scope='rubyfile_'+fid
  def loc(n):return dict(file=file,file_id=fid,line=n.start_point.row+1,end_line=n.end_point.row+1,byte_offset=n.start_byte,end_byte=n.end_byte)
  def nodeout(r):
   if phase==2:emit(outputs['nodes'],dict(**r,contexts=contexts,source_sha256=sourcehash))
  def boundary(n,reason,**extra):
   if phase==2:emit(outputs['boundaries'],dict(boundary_id=uid(file,n.start_byte,n.end_byte,reason,json.dumps(extra,sort_keys=True)),kind=reason,contexts=contexts,**loc(n),**extra));self.stats['boundary_'+reason]+=1
  def relation(n,owner,kind,target,guard,lexical=()):
   if phase==1:
    self.rels[owner].append(dict(id=uid(file,n.start_byte,kind,target),owner=owner,kind=kind,target=target,contexts=contexts,unconditional=not guard,lexical_scopes=list(lexical),**loc(n)))
  def walk(n,owner='',kind='singleton',scope=file_scope,method=None,guards=(),blocks=(),env=None,classbody=True,lexical=()):
   env={} if env is None else env;typ=n.type;here=scope;current_method=method
   if typ in ('ERROR',) or n.is_missing:boundary(n,'unsupported_parse_construct',construct=typ)
   if typ in ('class','module'):
    name=tx(data,fld(n,'name'));owner=self.header_owner(name,lexical,contexts,file,n.start_byte);lexical=lexical+(owner,);kind='singleton';classbody=True;env={};here='rubyscope_'+uid(file,n.start_byte,typ)
    if phase==1:
     for context in contexts:self.names[context].add(owner)
    nodeout(dict(node_id=here,kind='class_body',owner=owner,**loc(n)))
    if phase==2:emit(outputs['edges'],dict(edge_id=uid(scope,here,'class_body'),source_id=scope,target_id=here,kind='class_body_execution',traversable=True,profiles=[x for x in contexts if x in ('ce','ee')],contexts=contexts,resolution='conditional_source_resolved',conditions=list(guards)+['class/module definition evaluated normally'],**loc(n)))
    superclass=fld(n,'superclass')
    if superclass:
     name2=tx(data,superclass).lstrip('<').strip()
     if CONST.fullmatch(name2):relation(n,owner,'superclass',name2,guards,lexical[:-1])
     else:boundary(n,'dynamic_superclass',expression=name2)
   elif typ=='singleton_class':
    if tx(data,fld(n,'value'))=='self':kind='singleton'
    else:kind='dynamic_singleton';boundary(n,'dynamic_singleton_receiver')
   elif typ in ('method','singleton_method'):
    name=tx(data,fld(n,'name'));obj=tx(data,fld(n,'object'));targetowner=owner
    mk='singleton' if typ=='singleton_method' else 'instance'
    if typ=='method' and n.parent and any(x=='singleton_body' for x in blocks):mk='singleton'
    if obj not in ('','self'):
     if CONST.fullmatch(obj):
      targets={self.constant(obj,lexical,c) for c in contexts};targetowner=next(iter(targets)) if len(targets)==1 and None not in targets else '__unresolved_owner_'+uid(file,n.start_byte,obj)
     else:mk='dynamic_singleton'
    mid=uid(file,n.start_byte,'method');here=mid;current_method=mid;env={};classbody=False;method_at[mid]=(targetowner,name,mk)
    row=dict(node_id=mid,kind='ruby_method',owner=targetowner,method=name,method_kind=mk,contexts=contexts,unconditional=not guards,parameters=tx(data,fld(n,'parameters')),**loc(n))
    if phase==1:self.adddef(row)
    nodeout({k:v for k,v in row.items() if k!='contexts'});owner=targetowner;kind=mk
    # A method body is a callable entry, not invoked by merely defining it.
    if phase==2:emit(outputs['edges'],dict(edge_id=uid(scope,mid,'defines_method'),source_id=scope,target_id=mid,kind='defines_method',traversable=False,contexts=contexts,profiles=[x for x in contexts if x in ('ce','ee')],resolution='source_resolved',**loc(n)))
    guards=();blocks=()
   elif typ in ('block','do_block','lambda'):
    parent=n.parent;api=tx(data,fld(parent,'method')) if parent and parent.type=='call' else '';args=fld(parent,'arguments') if parent else None;named=literal_name(data,args.named_children[0]) if args and args.named_children else None
    define_literal=classbody and api in ('define_method','define_singleton_method') and named and tx(data,fld(parent,'receiver')) in ('','self')
    bid='rubyblock_'+uid(file,n.start_byte,n.end_byte,typ);here=bid;classbody=False
    if define_literal:
     kind='singleton' if api=='define_singleton_method' else 'instance';current_method=bid
     row=dict(node_id=bid,kind='ruby_method',owner=owner,method=named,method_kind=kind,contexts=contexts,unconditional=not guards,parameters=tx(data,fld(n,'parameters')),**loc(n))
     if phase==1:self.adddef(row)
     nodeout({k:v for k,v in row.items() if k!='contexts'})
    else:nodeout(dict(node_id=bid,kind='deferred_block',lexical_owner=owner,enclosing_method_id=method,**loc(n)))
    if phase==2:emit(outputs['edges'],dict(edge_id=uid(scope,bid,'defines_block'),source_id=scope,target_id=bid,kind='defines_deferred_block',traversable=False,contexts=contexts,profiles=[x for x in contexts if x in ('ce','ee')],resolution='source_resolved',**loc(n)));boundary(n,'deferred_block_invocation_unresolved',block_id=bid)
    blocks=() if define_literal else blocks+(bid,);env=dict(env)
   elif typ in GUARDS:
    cond=fld(n,'condition') or fld(n,'value');guards=guards+('source_guard:'+typ+':'+tx(data,cond),)
   if phase==1 and typ=='alias' and classbody:
    destination=tx(data,fld(n,'name')).lstrip(':');original=tx(data,fld(n,'alias')).lstrip(':');mk='singleton' if 'singleton_body' in blocks else 'instance'
    if re.fullmatch(r'[A-Za-z_]\w*[!?=]?',destination) and re.fullmatch(r'[A-Za-z_]\w*[!?=]?',original):self.aliases[owner].append(dict(id='rubyalias_'+uid(file,n.start_byte),owner=owner,method=destination,original_method=original,method_kind=mk,contexts=contexts,unconditional=not guards,**loc(n)))
    else:self.hooks[owner].add('dynamic_keyword_alias')
   if phase==1 and typ=='undef' and classbody:
    for arg in n.named_children:
     removed=tx(data,arg).lstrip(':')
     if re.fullmatch(r'[A-Za-z_]\w*[!?=]?',removed):self.adddef(dict(node_id='rubyremoved_'+uid(file,n.start_byte,removed),kind='removed_method',owner=owner,method=removed,method_kind='singleton' if 'singleton_body' in blocks else 'instance',contexts=contexts,unconditional=not guards,parameters=None,**loc(n)))
     else:self.hooks[owner].add('dynamic_keyword_undef')
   if phase==1 and typ=='call' and classbody:
    name=tx(data,fld(n,'method'));recv=tx(data,fld(n,'receiver'));args=fld(n,'arguments');argnodes=args.named_children if args else []
    if name in ('private','public','protected','private_class_method','public_class_method') and recv in ('','self'):
     vk='singleton' if name.endswith('_class_method') or 'singleton_body' in blocks else 'instance';vis=name.split('_')[0];vals=[literal_name(data,a) for a in argnodes]
     self.visibility[(owner,vk,file)].append(dict(offset=n.start_byte,names=vals,visibility=vis,conditional=bool(guards)))
    elif name in ('include','prepend','extend') and recv in ('','self'):
     for arg in argnodes:
      target=tx(data,arg)
      if CONST.fullmatch(target):relation(n,owner,('singleton_'+name if 'singleton_body' in blocks and name in ('include','prepend') else name),target,guards,lexical)
      else:self.hooks[owner].add('dynamic_'+name)
     if name=='extend' and any(tx(data,a)=='ActiveSupport::Concern' for a in argnodes):self.hooks[owner].add('ActiveSupport::Concern')
    elif name in ('remove_method','undef_method') and recv in ('','self'):
     for arg in argnodes:
      removed=literal_name(data,arg)
      if removed:self.adddef(dict(node_id='rubyremoved_'+uid(file,n.start_byte,removed),kind='removed_method',owner=owner,method=removed,method_kind='singleton' if 'singleton_body' in blocks else 'instance',contexts=contexts,unconditional=not guards,parameters=None,**loc(n)))
      else:self.hooks[owner].add('dynamic_method_removal')
    elif name in ('attr_reader','attr_writer','attr_accessor') and recv in ('','self'):
     for arg in argnodes:
      attr=literal_name(data,arg)
      if attr:
       for suffix in ([''] if name=='attr_reader' else ['='] if name=='attr_writer' else ['','=']):
        self.adddef(dict(node_id='rubyaccessor_'+uid(file,n.start_byte,attr,suffix),kind='generated_accessor',owner=owner,method=attr+suffix,method_kind='singleton' if 'singleton_body' in blocks else 'instance',contexts=contexts,unconditional=not guards,parameters=None,**loc(n)))
      else:self.hooks[owner].add('dynamic_attribute_definition')
    elif name=='alias_method' and len(argnodes)==2 and recv in ('','self'):
     vals=[literal_name(data,a) for a in argnodes]
     if all(vals):self.aliases[owner].append(dict(id='rubyalias_'+uid(file,n.start_byte),owner=owner,method=vals[0],original_method=vals[1],method_kind='singleton' if 'singleton_body' in blocks else 'instance',contexts=contexts,unconditional=not guards,**loc(n)))
     else:self.hooks[owner].add('dynamic_alias')
    elif name not in SAFE_CLASS_CALLS and recv in ('','self'):self.hooks[owner].add('unmodeled_class_body_call:'+name)
   if phase==1 and typ=='assignment' and classbody:
    lhs=tx(data,fld(n,'left'));rhs=tx(data,fld(n,'right'))
    if CONST.fullmatch(lhs) and CONST.fullmatch(rhs):
     qualified=lhs.lstrip(':') if '::' in lhs else '::'.join(filter(None,[owner,lhs]));self.aliases['@constants'].append(dict(alias=qualified,target=rhs,lexical_owner=owner,lexical_scopes=list(lexical),contexts=contexts,unconditional=not guards,**loc(n)))
   if typ=='singleton_method' and tx(data,fld(n,'name')) in ('included','prepended','extended','append_features','prepend_features','extend_object','method_added','singleton_method_added') and phase==1:self.hooks[owner].add('custom_lookup_hook')
   if typ=='assignment':
    lhs=fld(n,'left');rhs=fld(n,'right')
    if lhs and lhs.type=='identifier':
     env.pop(tx(data,lhs),None)
     if rhs and rhs.type=='call' and tx(data,fld(rhs,'method'))=='new':
      recv=tx(data,fld(rhs,'receiver'))
      if CONST.fullmatch(recv):env[tx(data,lhs)]=(recv,tuple(guards),n.start_byte)
   if phase==2 and typ in ('call','element_reference','binary','unary','operator_assignment','super','yield'):
    calls.append((n,owner,kind,here,current_method,guards,blocks,dict(env),lexical,False))
   if phase==2 and typ=='identifier' and n.parent and n.parent.type in ('body_statement','program','then','else','block_body'):
    calls.append((n,owner,kind,here,current_method,guards,blocks,dict(env),lexical,True))
   for child in n.named_children:
    childguards=guards
    if typ in ('if','unless','if_modifier','unless_modifier'):
     condition=fld(n,'condition');baseguards=guards[:-1];expression=tx(data,condition)
     if child==condition:childguards=baseguards
     else:
      alternative=child.type in ('else','elsif');required=(not alternative) != typ.startswith('unless')
      childguards=baseguards+('source_branch:'+('truthy:' if required else 'falsey:')+expression,)
      if expression in ('true','false','nil') and required!=(expression=='true'):childguards+=('statically_unreachable_literal_branch',)
    walk(child,owner,kind,here,current_method,childguards,blocks+(('singleton_body',) if typ=='singleton_class' else ()),env,classbody,lexical)
  nodeout(dict(node_id=file_scope,kind='file_scope',file=file,file_id=fid,line=1,source_bytes=len(data)))
  walk(tree.root_node)
  if phase==2:
   bare=[(uid(file,n.start_byte,n.end_byte,'ambiguous'),fid,n.start_byte,n.start_point.row+1,tx(data,n)) for n,*rest in calls if rest[-1]]
   bareclasses={r['call_id']:r['classification'] for r in classify(data,bare,file)} if bare else {}
   for record in calls:self.call(data,file,contexts,sourcehash,record,bareclasses,method_at,outputs)
  self.stats['parse_error_files_phase'+str(phase)]+=tree.root_node.has_error
  if phase==2 and 'files' in outputs:emit(outputs['files'],dict(file=file,file_id=fid,canonical_path=str((B/file).resolve()),sha256=sourcehash,parse_regions=getattr(self,'parse_regions',{}).get(file,[]),has_parse_error=tree.root_node.has_error,status='parsed_with_errors' if tree.root_node.has_error else 'parsed',contexts=contexts))
 def finalize(self):
  remap={}
  changed=True
  while changed:
   changed=False
   for pending in self.pending_owners:
    ph=pending['placeholder']
    if ph in remap:continue
    scopes=tuple(remap.get(x,x) for x in pending['lexical']);first,rest=pending['name'].split('::',1);parents={self.constant(first,scopes,c) for c in pending['contexts']}
    if len(parents)==1 and None not in parents and not next(iter(parents)).startswith('__unresolved_owner_'):
     target=next(iter(parents))+'::'+rest;remap[ph]=target;changed=True
     for c in pending['contexts']:self.names[c].add(target)
  def owner_map(x):
   for ph,target in remap.items():
    if x==ph or x.startswith(ph+'::'):return target+x[len(ph):]
   return x
  if remap:
   ds=[d for vs in self.defs.values() for d in vs];self.defs=collections.defaultdict(list)
   for d in ds:d['owner']=owner_map(d['owner']);self.adddef(d)
   rs=[r for vs in self.rels.values() for r in vs];self.rels=collections.defaultdict(list)
   for r in rs:r['owner']=owner_map(r['owner']);r['lexical_scopes']=[owner_map(x) for x in r['lexical_scopes']];self.rels[r['owner']].append(r)
   for c in self.names:self.names[c]={owner_map(x) for x in self.names[c]}
   self.hooks=collections.defaultdict(set,{owner_map(k):v for k,v in self.hooks.items()})
   self.visibility=collections.defaultdict(list,{(owner_map(k[0]),k[1],k[2]):v for k,v in self.visibility.items()})
   aa=collections.defaultdict(list)
   for k,vs in self.aliases.items():
    for a in vs:
     if 'owner' in a:a['owner']=owner_map(a['owner'])
     aa[owner_map(k)].append(a)
   self.aliases=aa
  self.constant_links={};self.alias_boundaries=[]
  # Finite names then visited alias resolution; no iteration limit or name expansion.
  for a in self.aliases['@constants']:
   for ctx in a['contexts']:self.names[ctx].add(a['alias'])
  for a in self.aliases['@constants']:
   for ctx in a['contexts']:
    t=self.constant(a['target'],a.get('lexical_scopes',()),ctx)
    if t and a['unconditional']:self.constant_links.setdefault((ctx,a['alias']),set()).add(t)
  for owner,aliases in self.aliases.items():
   if owner=='@constants':continue
   for a in aliases:
    prior=[m for m in self.defs[(owner,a['original_method'],a['method_kind'])] if m['file']==a['file'] and m['byte_offset']<a['byte_offset'] and m['unconditional']]
    if prior and a['unconditional']:
     chosen=max(prior,key=lambda m:m['byte_offset']);visibility=chosen.get('native_visibility','public');uncertain=False
     for v in sorted(self.visibility[(owner,a['method_kind'],a['file'])],key=lambda z:z['offset']):
      if v['offset']>=a['byte_offset']:continue
      if (not v['names'] and v['offset']<chosen['byte_offset']) or a['original_method'] in v['names']:visibility=v['visibility'];uncertain=uncertain or v['conditional']
     aliasrow=dict(a,node_id=a['id'],kind='ruby_alias',alias_target_id=chosen['node_id'],native_visibility=visibility)
     if uncertain:aliasrow['unconditional']=False
     self.adddef(aliasrow)
    else:
     self.alias_boundaries.append(a);self.adddef(dict(a,node_id=a['id'],kind='removed_method',unresolved_alias=True))
  self.cache={}
  sys.setrecursionlimit(max(sys.getrecursionlimit(),10*(len(self.rels)+len({k[0] for k in self.defs}))+1000))
 def canonical(self,name,owner,ctx):
  x=self.constant(name,owner,ctx);seen=set()
  while x and (ctx,x) in self.constant_links:
   if x in seen:return None,'constant_alias_cycle'
   seen.add(x);targets=self.constant_links[(ctx,x)]
   if len(targets)!=1:return None,'ambiguous_constant_alias'
   x=next(iter(targets))
  return x,None if x else 'constant_not_resolved_in_context'
 def lookup(self,owner,method,kind,ctx,trail=()):
  key=(owner,method,kind,ctx)
  if not trail and key in self.cache:return self.cache[key]
  result=self._lookup(owner,method,kind,ctx,trail)
  if not trail:self.cache[key]=result
  return result
 def _lookup(self,owner,method,kind,ctx,trail=()):
  key=(owner,method,kind,ctx)
  if key in self.cache:return self.cache[key]
  if (owner,kind) in trail:return [],'inheritance_cycle',[]
  trail=trail+((owner,kind),);relations=[r for r in self.rels[owner] if self.available(r,ctx)];evidence=[]
  def resolve_mixins(kinds):
   rs=[r for r in relations if r['kind'] in kinds]
   if not rs:return [],None,[]
   if len({r['file'] for r in rs})>1:return [],'mixin_reopening_order_unresolved',[r['id'] for r in rs]
   groups=collections.defaultdict(list)
   for r in rs:groups[r['byte_offset']].append(r)
   path=[]
   for off in sorted(groups,reverse=True):
    # include A,B preserves argument order; separate includes reverse call order.
    for r in groups[off]:
     path.append(r['id'])
     if not r['unconditional']:return [],'conditional_mixin_activation',path
     target,reason=self.canonical(r['target'],r.get('lexical_scopes',()),ctx)
     if reason:return [],reason,path
     if self.hooks[target]:return [],'mixin_hooks_or_dynamic_definition_unresolved',path
     result,reason,used=self.lookup(target,method,'instance',ctx,trail)
     path+=used
     if result or reason not in (None,'method_not_found'):return result,reason,path
   return [],None,path
  before={'prepend'} if kind=='instance' else {'singleton_prepend'}
  result,reason,path=resolve_mixins(before);evidence+=path
  if result or reason:return result,reason,evidence
  own=[r for r in self.defs[(owner,method,kind)] if self.available(r,ctx)]
  if own:
   if any(not r['unconditional'] for r in own):return [],'conditional_method_definition',[r['node_id'] for r in own]
   if len(own)>1 and any(r['kind']=='native_registration' for r in own):return [],'native_registration_installation_order_unresolved',[r['node_id'] for r in own]
   if len({r['file'] for r in own})>1:return [],'definition_reopening_order_unresolved',[r['node_id'] for r in own]
   target=max(own,key=lambda r:r.get('byte_offset',0))
   if target['kind']=='removed_method':return [],'explicit_method_removal_or_undef_requires_lookup_semantics',[target['node_id']]
   result=([target],None,evidence)
   self.cache[key]=result;return result
  if kind in ('instance','singleton'):
   result,reason,path=resolve_mixins({'include'} if kind=='instance' else {'extend','singleton_include'});evidence+=path
   if result or reason:return result,reason,evidence
  parents=[r for r in relations if r['kind']=='superclass']
  if parents:
   targets=set()
   for r in parents:
    target,reason=self.canonical(r['target'],r.get('lexical_scopes',()),ctx);evidence.append(r['id'])
    if reason or not r['unconditional']:return [],reason or 'conditional_superclass',evidence
    targets.add(target)
   if len(targets)!=1:return [],'ambiguous_superclass',evidence
   result,reason,path=self.lookup(next(iter(targets)),method,kind,ctx,trail);evidence+=path
   return result,reason,evidence
  return [],'method_not_found',evidence
 def call(self,data,file,contexts,sourcehash,record,bareclasses,method_at,out):
  n,owner,kind,scope,method,guards,blocks,env,lexical,bare=record;typ=n.type;fid=self.corpus.files[file]['file_id'];cid=uid(file,n.start_byte,n.end_byte,'ambiguous' if bare else 'call');loc=dict(file=file,file_id=fid,line=n.start_point.row+1,byte_offset=n.start_byte,end_byte=n.end_byte)
  name=tx(data,n) if bare else tx(data,fld(n,'method'));recv=fld(n,'receiver');args=fld(n,'arguments')
  if typ=='element_reference':name='[]';recv=fld(n,'object')
  elif typ in ('binary','unary','operator_assignment'):
   name=tx(data,fld(n,'operator'));recv=fld(n,'operand') if typ=='unary' else fld(n,'left')
   if name in ('and','or','&&','||','..','...'):return
   if typ=='operator_assignment':name=name[:-1]
   if typ=='unary' and name in ('+','-'):name+='@'
  elif typ in ('super','yield'):name=typ
  if not name:return
  if bare and bareclasses.get(cid) in ('local_variable_read','parameter_read'):
   self.stats['noncall_lexical_reads']+=1;return
  recvtext=tx(data,recv);argtext=tx(data,args);node=dict(node_id=cid,kind='ruby_call',method=name,receiver=recvtext,arguments=argtext,lexical_owner=owner,enclosing_method_id=method,execution_scope_id=scope,source_guards=list(guards),contexts=contexts,source_sha256=sourcehash,**loc);emit(out['nodes'],node);self.stats['calls']+=1
  def boundary(reason,**extra):
   emit(out['boundaries'],dict(boundary_id=uid(cid,reason,json.dumps(extra,sort_keys=True)),node_id=cid,kind=reason,contexts=contexts,**loc,**extra));self.stats['boundary_'+reason]+=1
  if 'statically_unreachable_literal_branch' in guards:boundary('statically_unreachable_literal_branch');return
  if method in getattr(self,'parse_uncertain_methods',set()) or any(a<=n.start_byte<=b or n.start_byte<=a<n.end_byte for a,b,_ in getattr(self,'parse_regions',{}).get(file,())):
   boundary('parse_recovery_region_not_resolved');return
  if file in getattr(self,'parse_regions',{}):guards=guards+('valid AST region outside recorded parser recovery regions',)
  # Region edge is lexical execution containment, not unconditional reachability.
  emit(out['edges'],dict(edge_id=uid(scope,cid,'contains'),source_id=scope,target_id=cid,kind='executes_call_if_region_reached',traversable=True,profiles=[x for x in contexts if x in ('ce','ee')],contexts=contexts,resolution='conditional_source_resolved',conditions=list(guards)+['execution reaches this source region'],**loc))
  if bare and bareclasses.get(cid)!='syntactic_vcall':boundary('ambiguous_identifier_binding');return
  if name in ('method','instance_method','define_method','define_singleton_method','alias_method','lambda','proc','eval','class_eval','module_eval','instance_eval','instance_exec','class_exec','module_exec','delegate','delegate_missing_to'):
   boundary('metaprogramming_or_method_capture_not_invocation',construct=name);return
  if name in ('send','public_send','__send__'):
   first=args.named_children[0] if args and args.named_children else None;literal=literal_name(data,first)
   if not literal:boundary('dynamic_send_name');return
   name=literal
  if name=='yield':boundary('yield_block_target_requires_callsite_binding');return
  super_dispatch=name=='super'
  if super_dispatch:
   if method not in method_at:boundary('super_unknown_defining_method');return
   defining_owner,name,defining_kind=method_at[method]
  else:defining_owner=defining_kind=None
  if blocks and not super_dispatch and (recv is None or recvtext=='self'):
   boundary('block_self_or_dsl_receiver_unresolved');return
  receiverkind='';targetname='';targetkind='instance';conditions=list(guards)+['source loaded in stated profile/context','ordinary Ruby dispatch without refinements or reflective rebinding']
  if super_dispatch:receiverkind='super';targetname='::'+defining_owner;targetkind=defining_kind
  elif recv and CONST.fullmatch(recvtext):receiverkind='constant';targetname=recvtext;targetkind='singleton'
  elif not recv or recvtext=='self':receiverkind='self';targetname='::'+owner;targetkind=kind
  elif recv.type in ('string','array','hash','regex','integer','float','symbol','simple_symbol'):
   receiverkind='literal';targetname='::'+{'string':'String','array':'Array','hash':'Hash','regex':'Regexp','integer':'Integer','float':'Float','symbol':'Symbol','simple_symbol':'Symbol'}[recv.type]
  elif recv.type=='call' and tx(data,fld(recv,'method'))=='new' and CONST.fullmatch(tx(data,fld(recv,'receiver'))):receiverkind='constructor_result';targetname=tx(data,fld(recv,'receiver'));conditions+=['constructor resolves ordinary Class#new and returns an instance of named receiver; no overridden allocation/initialize return redirection']
  elif recvtext in env:
   targetname,assignment_guards,assignment_offset=env[recvtext]
   if any(g not in guards for g in assignment_guards):boundary('local_constructor_control_flow_merge_unresolved');return
   receiverkind='local_constructor';conditions+=['recorded lexical constructor assignment reaches call without intervening mutation or unknown control-flow merge','ordinary Class#new result type'];conditions+=list(assignment_guards)
  else:boundary('unresolved_receiver',receiver=recvtext);return
  if not targetname or targetname=='::' or '__unresolved_owner_' in targetname:boundary('unknown_lexical_owner');return
  anyedge=False
  for ctx in contexts:
   resolved,why=self.canonical(targetname,lexical,ctx)
   if why:boundary(why,context=ctx,receiver=targetname);continue
   if receiverkind in ('local_constructor','constructor_result'):
    newtargets,newreason,_=self.lookup(resolved,'new','singleton',ctx)
    if newtargets or newreason not in ('method_not_found',None):boundary('constructor_return_type_override_or_lookup_unknown',context=ctx,receiver_owner=resolved,known_new_target_ids=[x['node_id'] for x in newtargets]);continue
   if super_dispatch:
    rels=[r for r in self.rels[resolved] if self.available(r,ctx)]
    if any(r['kind'] in ('include','prepend','extend') for r in rels):boundary('super_defining_position_mixin_unresolved',context=ctx);continue
    parents=[r for r in rels if r['kind']=='superclass'];parent_names={self.canonical(r['target'],r.get('lexical_scopes',()),ctx)[0] for r in parents}
    if len(parent_names)!=1 or None in parent_names or any(not r['unconditional'] for r in parents):boundary('super_parent_binding_unresolved',context=ctx);continue
    resolved=next(iter(parent_names));conditions+=['actual receiver uses retained defining owner at this ancestor position','super forwards enclosing arguments unless explicit argument list; argument transfer remains conditional']
   targets,reason,evidence=self.lookup(resolved,name,targetkind,ctx)
   if not targets:
    boundary(reason or 'dispatch_unresolved',context=ctx,receiver_owner=resolved,method=name,lookup_evidence=evidence);continue
   for target in targets:
    if self.hooks[resolved] or self.hooks[target['owner']]:
     boundary('known_class_body_mutation_or_hook_unmodeled',context=ctx,candidate_target_id=target['node_id'],constructs=sorted(self.hooks[resolved]|self.hooks[target['owner']]));continue
    visibility=target.get('native_visibility','public');visunknown=False
    for v in sorted(self.visibility[(target['owner'],target['method_kind'],target['file'])],key=lambda z:z['offset']):
     if (not v['names'] and v['offset']<target.get('byte_offset',0)) or target['method'] in v['names']:
      visibility=v['visibility'];visunknown=visunknown or v['conditional']
    if visunknown or (visibility!='public' and (recvtext not in ('','self') or node['method']=='public_send')):
     boundary('method_visibility_not_admitted',context=ctx,candidate_target_id=target['node_id'],visibility=visibility);continue
    native=target['kind']=='native_registration';edge=dict(edge_id=uid(cid,target['node_id'],ctx,'dispatch'),source_id=cid,target_id=target['node_id'],kind='ruby_native_binding' if native else 'ruby_dispatch',traversable=True,profiles=[ctx] if ctx in ('ce','ee') else [],contexts=[ctx],resolution='conditional_source_resolved',conditions=conditions+(['native extension initialization installs this exact registration'] if native else []),evidence= dict(receiver_kind=receiverkind,receiver_owner=resolved,method_kind=targetkind,lookup_relation_ids=evidence,target_definition_file=target['file'],target_definition_line=target['line']),**loc)
    emit(out['bindings'] if native else out['edges'],edge);self.stats['bindings' if native else 'dispatch_edges']+=1;anyedge=True
  if not anyedge:self.stats['calls_without_dispatch']+=1

def literal_name(data,n):
 if n is None:return None
 text=tx(data,n)
 if n.type=='simple_symbol':return text[1:]
 if n.type in ('string','symbol') and not any(c.type=='interpolation' for c in n.named_children):
  m=re.fullmatch(r'''["']([^"']+)["']''',text.lstrip(':'));return m[1] if m else None
 return None

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--limit',type=int);ap.add_argument('--phase',choices=['all','definitions','calls'],default='all');a=ap.parse_args();start=time.time()
 if a.phase=='calls':
  with gzip.open(OUT/'ruby_definition_state.pkl.gz','rb') as f:model=pickle.load(f)
  corpus=model.corpus
 else:corpus=Corpus();model=Model(corpus)
 files=sorted(corpus.files)
 if a.limit:files=files[:a.limit]
 for phase in ([1] if a.phase=='definitions' else [2] if a.phase=='calls' else [1,2]):
  out={k:writer(n) for k,n in [('nodes','ruby_nodes'),('edges','ruby_edges'),('bindings','binding_edges'),('boundaries','ruby_boundaries'),('files','ruby_source_manifest')]} if phase==2 else None
  if phase==2:
   from ruby_parse_regions import prepare
   prepare(model,B,P)
   from c_registration_owners import load_into
   load_into(model,OUT,B)
   model.finalize()
   for ds in model.defs.values():
    for d in ds:
     if d['kind'] in ('generated_accessor','removed_method','ruby_alias'):
      emit(out['nodes'],d)
      if d.get('alias_target_id'):emit(out['edges'],dict(edge_id=uid(d['node_id'],d['alias_target_id'],'alias'),source_id=d['node_id'],target_id=d['alias_target_id'],kind='captured_method_alias_invocation',traversable=True,contexts=d['contexts'],profiles=[p for p in d['contexts'] if p in ('ce','ee')],resolution='conditional_source_resolved',conditions=['same-file alias evaluation captures last unconditional preceding definition','no intervening runtime mutation'],file=d['file'],line=d['line']))
  for i,file in enumerate(files):
   try:model.parse(file,phase,out)
   except Exception as e:
    model.stats['phase'+str(phase)+'_file_failures']+=1
    if out:emit(out['boundaries'],dict(boundary_id=uid(file,'parse_failure'),kind='file_analysis_failure',file=file,error=type(e).__name__+':'+str(e)))
   if i%2000==0:print(json.dumps(dict(phase=phase,files=i,total=len(files),elapsed=round(time.time()-start))),flush=True)
  if out:
   for f in out.values():f.close()
  if phase==1:
   with gzip.open(OUT/'ruby_definition_state.pkl.gz','wb',compresslevel=3) as f:pickle.dump(model,f,protocol=5)
 (OUT/'reports/ruby_graph_coverage.json').write_text(json.dumps(dict(files=len(files),elapsed_seconds=time.time()-start,counts=model.stats,limitations=['No path enumeration','Conditional source structure, not runtime proof','Unresolved receiver/lookup/deferred entries retained as boundaries']),indent=2)+'\n')
if __name__=='__main__':main()
