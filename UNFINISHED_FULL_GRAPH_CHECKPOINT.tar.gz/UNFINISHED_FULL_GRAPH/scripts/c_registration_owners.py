"""Function/file scoped, finite C namespace equations; no namespace-depth cap."""
import collections,json,pathlib,re,sys
sys.path.insert(0,"/workspace/gitlab_c_ext_trace/.python")
from tree_sitter import Parser,Language
import tree_sitter_c,tree_sitter_cpp
CP=Parser(Language(tree_sitter_c.language()));CPP=Parser(Language(tree_sitter_cpp.language()))
CORE=set('Object BasicObject Class Module String Array Hash Regexp Integer Float Numeric Symbol IO File Thread ThreadGroup Proc Range Time Struct Data Enumerator TrueClass FalseClass NilClass Binding Method UnboundMethod Encoding Complex Rational Kernel Enumerable Comparable Math GC Process FileTest Errno Warning RubyVM'.split())
def literal(x):
 m=re.fullmatch(r'\s*"([^"\\]*)"\s*',str(x));return m[1] if m else None

def resolve(registrations,namespaces,files,function_for_call,source_root):
 assignments=[];values=collections.defaultdict(set);provenance=collections.defaultdict(set);globals_by_file={};external_by_file={};conditions=[];writes_by_file={};function_ranges={}
 for fid,f in files.items():
  path=f.get('path') or f.get('file');path=pathlib.Path(path);path=source_root/path if not path.is_absolute() else path
  try:data=path.read_text(errors='replace')
  except OSError:continue
  # Column-zero declarations are only a conservative source-global indication.
  raw=data.encode();tree=(CPP if path.suffix in ('.cc','.cpp','.cxx','.hpp') else CP).parse(raw);decls=[];todo=list(tree.root_node.named_children)
  while todo:
   n=todo.pop()
   if n.type=='declaration' and not n.has_error:decls.append(raw[n.start_byte:n.end_byte].decode(errors='replace'))
   elif n.type.startswith('preproc'):todo.extend(n.named_children)
  globals_by_file[fid]={x for d in decls for x in re.findall(r'\bVALUE\s+(\w+)\s*(?:[;=])',d)}
  external_by_file[fid]={x for d in decls if not re.search(r'\bstatic\b',d) for x in re.findall(r'\bVALUE\s+(\w+)\s*(?:[;=])',d)}
  todo=[tree.root_node];writes=[];ranges=[]
  while todo:
   n=todo.pop()
   if n.type=='function_definition':ranges.append((n.start_point.row+1,n.end_point.row+1))
   if n.type in ('assignment_expression','init_declarator'):
    lhs=n.child_by_field_name('left') or n.child_by_field_name('declarator');rhs=n.child_by_field_name('right') or n.child_by_field_name('value')
    if lhs and rhs and lhs.type=='identifier':writes.append((raw[lhs.start_byte:lhs.end_byte].decode(),raw[rhs.start_byte:rhs.end_byte].decode(),n.start_point.row+1))
   todo.extend(n.named_children)
  writes_by_file[fid]=writes;function_ranges[fid]=ranges
 def key(row,var):
  fun=row.get('function_id') or row.get('initializer_function_id') or function_for_call.get(row.get('call_id'))
  return (row['gem_id'],row['file_id'],'global' if var in globals_by_file.get(row['file_id'],()) else fun or 'unknown_function',var)
 unsafe=set()
 for row in registrations+namespaces:
  fid=row['file_id'];line=row.get('line',0);scope=next(((a,b) for a,b in function_ranges.get(fid,[]) if a<=line<=b),None)
  for var,rhs,at in writes_by_file.get(fid,[]):
   if rhs.strip() in ('Qnil','Qfalse','0','NULL') and not any(a<=at<=b for a,b in function_ranges.get(fid,[])):continue
   if var not in globals_by_file.get(fid,()) and (scope is None or not scope[0]<=at<=scope[1]):continue
   if not re.match(r'\s*rb_(?:define_(?:class|module)(?:_under)?|path2class)\s*\(',rhs):unsafe.add(key(row,var))
 for n in namespaces:
  args=n.get('arguments',[]);api=n.get('api') or n.get('method') or n.get('name');ctx=n.get('assignment_context','');match=re.search(r'\b(\w+)\s*=\s*rb_\w+',ctx)
  var=n.get('source_variable') or n.get('assignment_variable') or (match[1] if match else None)
  if not var or not isinstance(args,list):continue
  if api in ('rb_define_class','rb_define_module') and args:assignments.append((key(n,var),None,literal(args[0]),n))
  elif api in ('rb_define_class_under','rb_define_module_under') and len(args)>1:assignments.append((key(n,var),args[0],literal(args[1]),n))
  elif api=='rb_path2class' and args:assignments.append((key(n,var),None,literal(args[0]),n))
 def get(row,expr):
  if expr.startswith(('rb_c','rb_m')) and expr[4:] in CORE:return {expr[4:]}
  k=key(row,expr)
  if k in unsafe:return set()
  found=values.get(k,set())
  if found:return found
  # Referencing a proven file-global from another function is allowed; never
  # merge function-local variables just because they have the same spelling.
  found=values.get((row['gem_id'],row['file_id'],'global',expr),set())
  if found:return found
  if expr in external_by_file.get(row['file_id'],()):
   if any(g==row['gem_id'] and v==expr and scope=='global' and v in external_by_file.get(f,()) for g,f,scope,v in unsafe):return set()
   return set().union(*(vs for (g,f,scope,v),vs in values.items() if g==row['gem_id'] and scope=='global' and v==expr and v in external_by_file.get(f,())))
  return set()
 def depkey(k):
  g,f,scope,v=k
  return (g,'external','global',v) if scope=='global' and v in external_by_file.get(f,()) else k
 dependencies=collections.defaultdict(set)
 for k,parent,child,row in assignments:
  if parent is not None:dependencies[depkey(k)].add(depkey(key(row,parent)))
 cyclic=set()
 for origin in dependencies:
  todo=list(dependencies[origin]);seen=set()
  while todo:
   k=todo.pop()
   if k==origin:cyclic.add(origin);break
   if k in seen:continue
   seen.add(k);todo.extend(dependencies.get(k,()))
 changed=True
 while changed:
  changed=False
  for k,parent,child,row in assignments:
   if child is None or depkey(k) in cyclic:continue
   owners={child} if parent is None else {child if p=='Object' else p+'::'+child for p in get(row,parent)}
   new=owners-values[k]
   if new:values[k].update(new);provenance[k].add(row.get('namespace_id') or row.get('call_id'));changed=True
 byid={r['registration_id']:r for r in registrations};result=[]
 for r in registrations:
  var=r.get('receiver_expression') or '';owners=get(r,var);api=r.get('registration_api');seen=set();target=r
  while api=='rb_define_alias':
   if target['registration_id'] in seen:api='alias_cycle';break
   seen.add(target['registration_id']);target=byid.get(target.get('alias_registration_id'))
   if not target:api='alias_target_unresolved';break
   api=target.get('registration_api')
  kinds=[] if api in ('alias_cycle','alias_target_unresolved') else ['singleton','instance'] if api=='rb_define_module_function' else ['singleton'] if api in ('rb_define_singleton_method','rb_define_singleton_method_id','rb_define_alloc_func') else ['instance']
  if api=='rb_define_global_function':owners={'Kernel'};kinds=['instance']
  if len(owners)==1 and kinds and r.get('ruby_name'):
   result.append(dict(registration_id=r['registration_id'],owner=next(iter(owners)),method=r['ruby_name'],kinds=kinds,resolution='conditional_source_resolved',gem_id=r['gem_id'],file_id=r['file_id'],line=r['line'],scope_key=list(key(r,var)),namespace_evidence=sorted(x for x in provenance[key(r,var)] if x),conditions=['namespace assignments/Init execute normally in source order','proven file-global identity or same enclosing function variable','no later variable reassignment alters registration receiver']))
  else:result.append(dict(registration_id=r['registration_id'],resolution='ambiguous',candidate_owners=sorted(owners),gem_id=r['gem_id'],file_id=r['file_id'],line=r['line'],reason='namespace_variable_or_alias_kind_unresolved',scope_key=list(key(r,var))))
 return result,values,get,key

def load_into(model,output_root,source_root):
 import gzip,hashlib
 from ruby_full_graph import rows,emit,uid
 T=source_root/'tables';NT=output_root/'tables'
 def union(old,new,key):
  out={r[key]:r for r in rows(T/(old+'.jsonl'))}
  for r in rows(NT/(new+'.jsonl.gz')):
   if key in r:out[r[key]]=r
  return list(out.values())
 regs=union('c_registrations','native_registrations','registration_id');ns=union('c_namespaces','native_namespaces','namespace_id');files={r['file_id']:r for r in rows(T/'c_files.jsonl')}
 for r in rows(NT/'native_files.jsonl.gz'):
  if 'file_id' in r:files[r['file_id']]=r
 wanted={n.get('call_id') for n in ns};fun={};composition=[]
 for c in rows(T/'c_calls.jsonl'):
  if c['call_id'] in wanted:fun[c['call_id']]=c.get('function_id')
  if c.get('callee') in ('rb_include_module','rb_prepend_module','rb_extend_object'):composition.append(c)
 composition={r['call_id']:r for r in composition}
 for c in rows(NT/'native_composition_calls.jsonl.gz'):composition[c['call_id']]=c
 relevant={r['file_id'] for r in regs+ns};bound,values,get,key=resolve(regs,ns,{f:files[f] for f in relevant if f in files},fun,source_root)
 regby={r['registration_id']:r for r in regs};binding_by={r['registration_id']:r for r in bound}
 def contexts(gid,file):
  found=[p for p,gs in model.corpus.primary.items() if gid in gs]
  return found or ['source:'+uid(next((p for p,g in model.corpus.scopes if file.startswith(p)),str(pathlib.PurePosixPath(file).parent)))]
 with gzip.open(NT/'ruby_native_owner_bindings.jsonl.gz','wt',compresslevel=5) as out:
  for r in bound:
   f=files.get(r['file_id'],{});file=f.get('path') or f.get('file') or '';ctx=contexts(r['gem_id'],file);r['contexts']=ctx;emit(out,r)
   if r['resolution']!='conditional_source_resolved':continue
   original=regby[r['registration_id']]
   for k in r['kinds']:
    model.adddef(dict(node_id=r['registration_id'],kind='native_registration',owner=r['owner'],method=r['method'],method_kind=k,contexts=ctx,unconditional=True,file=file,file_id=r['file_id'],line=r['line'],byte_offset=original.get('byte_offset',r['line']),native_visibility='private' if 'private' in original['registration_api'] or (original['registration_api']=='rb_define_module_function' and k=='instance') else 'protected' if 'protected' in original['registration_api'] else 'public',namespace_binding_evidence=r['namespace_evidence']))
 with gzip.open(NT/'ruby_native_composition_boundaries.jsonl.gz','wt',compresslevel=5) as out:
  for c in composition.values():
   args=c.get('arguments',[])
   if len(args)<2:continue
   left=get(c,args[0]);right=get(c,args[1]);fid=c['file_id'];file=files.get(fid,{}).get('path','');ctx=contexts(c['gem_id'],file)
   if len(left)!=1 or len(right)!=1:emit(out,dict(boundary_id=uid(c['call_id'],'composition'),kind='native_mixin_owner_unresolved',call_id=c['call_id'],file=file,line=c['line'],contexts=ctx));continue
   owner=next(iter(left));target=next(iter(right));kind={'rb_include_module':'include','rb_prepend_module':'prepend','rb_extend_object':'extend'}[c['callee']]
   model.rels[owner].append(dict(id=c['call_id'],owner=owner,kind=kind,target='::'+target,contexts=ctx,unconditional=True,lexical_scopes=[],file=file,file_id=fid,line=c['line'],byte_offset=c.get('byte_offset',c['line']),native_activation_conditional=True))
 for n in ns:
  api=n.get('api');args=n.get('arguments',[]);var=re.search(r'(\w+)\s*=\s*rb_\w+',n.get('assignment_context',''))
  if api not in ('rb_define_class','rb_define_class_under') or not var:continue
  owners=get(n,var[1]);parentexpr=args[1] if api=='rb_define_class' and len(args)>1 else args[2] if len(args)>2 else None;parents=get(n,parentexpr) if parentexpr else set()
  if len(owners)==1 and len(parents)==1:
   owner=next(iter(owners));parent=next(iter(parents));file=files.get(n['file_id'],{}).get('path','');ctx=contexts(n['gem_id'],file)
   model.rels[owner].append(dict(id=n['namespace_id'],owner=owner,kind='superclass',target='::'+parent,contexts=ctx,unconditional=True,lexical_scopes=[],file=file,file_id=n['file_id'],line=n['line'],byte_offset=n.get('byte_offset',n['line']),native_activation_conditional=True))
 model.stats['native_registrations_considered']=len(regs);model.stats['native_owner_bound']=sum(r['resolution']=='conditional_source_resolved' for r in bound)
