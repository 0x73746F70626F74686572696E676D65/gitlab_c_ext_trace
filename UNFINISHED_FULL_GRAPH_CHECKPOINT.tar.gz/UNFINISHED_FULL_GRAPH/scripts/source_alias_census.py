import os,json,gzip
from pathlib import Path
B=Path('/workspace/gitlab_c_ext_trace');O=Path('/workspace/gitlab_c_ext_full_graph');roots=[B/'sources',Path('/workspace/gitlab_c_ext_ee_profile/sources')];records=[]
for root in roots:
 for d,dirs,files in os.walk(root,followlinks=False):
  dirs[:]=sorted(x for x in dirs if x!='.git')
  for name in dirs+files:
   p=Path(d)/name
   if not p.is_symlink():continue
   r=dict(path=str(p),link_target=os.readlink(p),directory_alias=name in dirs)
   try:
    target=p.resolve();r.update(canonical_target=str(target),target_exists=target.exists(),target_inside_retained_roots=any(target.is_relative_to(x) for x in roots),status='alias_to_retained_corpus' if any(target.is_relative_to(x) for x in roots) else 'outside_retained_root_boundary')
   except (OSError,RuntimeError) as e:r.update(status='symlink_resolution_error',error=str(e))
   records.append(r)
with gzip.open(O/'tables/source_aliases.jsonl.gz','wt',compresslevel=1) as f:
 for r in records:f.write(json.dumps(r,separators=(',',':'))+'\n')
(O/'reports/source_alias_census.json').write_text(json.dumps(dict(alias_rows=len(records),directory_aliases=sum(r['directory_alias'] for r in records),resolution_errors=sum(r['status']=='symlink_resolution_error' for r in records),outside_root_targets=sum(r['status']=='outside_retained_root_boundary' for r in records),missing_targets=sum(r.get('target_exists') is False for r in records),scope='Explicit symbolic-link aliases; directory aliases do not multiply physical source-file counts. No symlink cycles followed.'),indent=2)+'\n')
print(len(records))
