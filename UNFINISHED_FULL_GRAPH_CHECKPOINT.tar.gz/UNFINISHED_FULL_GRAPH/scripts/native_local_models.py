#!/usr/bin/env python3
"""Bounded source rules: one-call expression macros and adjacent pointer initialization.
No target code execution. Source guards remain conditions, never runtime proof.
"""
import sys,re,json,gzip,hashlib,collections,argparse
from pathlib import Path
sys.path.insert(0,'/workspace/gitlab_c_ext_trace/scripts')
from analyze_c import PARSERS,txt,walk,ident,key
sys.path.insert(0,str(Path(__file__).parent))
from build_native_graph import guards,literal_false
G=Path('/workspace/gitlab_c_ext_full_graph');R=Path('/workspace/gitlab_c_ext_trace')
def rows(p):
 if p.exists():
  with gzip.open(p,'rt') as f:
   for line in f:yield json.loads(line)
def analyze_text(b):
 if isinstance(b,str):b=b.encode()
 tree=PARSERS['c'].parse(b);functions={};macros=collections.defaultdict(list);global_vars=set();all_macros=set()
 for n in walk(tree.root_node):
  if n.type in {'preproc_function_def','preproc_def'}:
   name=txt(b,n.child_by_field_name('name'));all_macros.add(name);macros[name].append(n)
  if n.type=='function_definition':
   name=ident(n.child_by_field_name('declarator'),b);functions.setdefault(name,[]).append(n)
 def shadow(fn,name):
  for n in walk(fn):
   if n.type in {'parameter_declaration','init_declarator'} and ident(n.child_by_field_name('declarator'),b)==name:return True
   if n.type=='declaration':
    for child in n.named_children:
     if child.type in {'identifier','pointer_declarator','array_declarator'} and ident(child,b)==name:return True
  return False
 def target_ok(name,argc,owner):
  defs=functions.get(name,[])
  if len(defs)!=1 or name in all_macros or shadow(owner,name):return None
  target=defs[0]
  if target.has_error:return None
  fd=target.child_by_field_name('declarator')
  while fd and fd.type!='function_declarator':fd=fd.child_by_field_name('declarator')
  pars=fd.child_by_field_name('parameters') if fd else None
  ps=[x for x in pars.named_children if x.type=='parameter_declaration'] if pars else []
  if pars is None or '...' in txt(b,pars):return None
  expected=0 if len(ps)==1 and txt(b,ps[0]).strip()=='void' else len(ps)
  return target if expected==argc else None
 results=[]
 for defs in functions.values():
  for owner in defs:
   if owner.has_error:continue
   body=owner.child_by_field_name('body')
   for call in walk(body):
    if call.type!='call_expression':continue
    ancestor=call.parent;unevaluated=False
    while ancestor is not None and ancestor!=body:
     if ancestor.type in {'sizeof_expression','alignof_expression','generic_expression'}:unevaluated=True
     ancestor=ancestor.parent
    if unevaluated:continue
    name=txt(b,call.child_by_field_name('function'));args=call.child_by_field_name('arguments');argc=len(args.named_children) if args else 0
    defs_macro=macros.get(name,[])
    if len(defs_macro)!=1:continue
    macro=defs_macro[0];params=macro.child_by_field_name('parameters');value=macro.child_by_field_name('value');text=txt(b,value).strip()
    if not params or not value or macro.start_byte>=call.start_byte or re.search(rb'(?m)^\s*#\s*undef\s+'+name.encode()+rb'\b',b):continue
    ps=[txt(b,x) for x in params.named_children]
    if len(ps)!=argc or any(not re.fullmatch(r'\w+',x) for x in ps) or any(x in text for x in ('#','\\',';','{','}')):continue
    # Single syntactic call only; identifiers/literals as args avoid nested effects and operators.
    m=re.fullmatch(r'([A-Za-z_]\w*)\s*\(([^()]*)\)',text)
    if not m or m[1] in ps:continue
    actual=[x.strip() for x in m[2].split(',')] if m[2].strip() else []
    if any(not re.fullmatch(r'(?:[A-Za-z_]\w*|[0-9]+)',x) for x in actual):continue
    if any(x not in ps and not x.isdigit() for x in actual):continue
    if re.search(rb'(?m)^\s*#\s*include\b',b[macro.end_byte:call.start_byte]):continue
    target=target_ok(m[1],len(actual),owner)
    gs=guards(call,b)+guards(macro,b)+(guards(target,b) if target else [])
    if target is None or literal_false(gs):continue
    results.append(dict(model='single_call_expression_macro',call_byte=call.start_byte,callee=name,target_byte=target.start_byte,target_name=m[1],definition_byte=macro.start_byte,line=call.start_point.row+1,conditions=gs,argument_expressions=actual,assumptions=['Matching C preprocessing/build; no injected macro overrides or interposition.','Argument-dependent execution/termination is not established.']))
   statements=body.named_children if body else []
   for first,second in zip(statements,statements[1:]):
    if first.type!='declaration' or second.type not in {'expression_statement','return_statement'}:continue
    inits=[n for n in first.named_children if n.type=='init_declarator']
    if len(inits)!=1:continue
    init=inits[0];decl=init.child_by_field_name('declarator');rhs_text=txt(b,init.child_by_field_name('value')).strip();rhs_match=re.fullmatch(r'&?\s*([A-Za-z_]\w*)',rhs_text);rhs=rhs_match[1] if rhs_match else '';var=ident(decl,b)
    if not var or not re.search(r'\(\s*\*',txt(b,decl)) or not re.fullmatch(r'[A-Za-z_]\w*',rhs):continue
    calls=[n for n in walk(second) if n.type=='call_expression']
    if len(calls)!=1:continue
    call=calls[0]
    if len(second.named_children)!=1 or second.named_children[0]!=call:continue
    callee=txt(b,call.child_by_field_name('function'));args=call.child_by_field_name('arguments');argc=len(args.named_children) if args else 0
    if callee not in {var,'(*'+var+')'} or var in all_macros:continue
    if any(n.type in {'assignment_expression','update_expression','call_expression'} for arg in args.named_children for n in walk(arg)):continue
    target=target_ok(rhs,argc,owner);gs=guards(call,b)+(guards(target,b) if target else [])
    if target is None or literal_false(gs):continue
    results.append(dict(model='adjacent_local_pointer_initialization',call_byte=call.start_byte,callee=callee,target_byte=target.start_byte,target_name=rhs,definition_byte=init.start_byte,line=call.start_point.row+1,conditions=gs,assumptions=['Compatible successful C build; exact function designator initializer and immediately following call.','No intervening statement, alias escape, reassignment or argument-side mutation.']))
 return results

def build():
 functions={};macronames=collections.defaultdict(set);pointers=collections.defaultdict(set);files={x['file_id']:x for x in rows(G/'tables/native_files.jsonl.gz')}
 for n in rows(G/'tables/native_nodes.jsonl.gz'):
  if n['node_type'] in {'function','macro'}:
   functions[(n['file_id'],n.get('byte_offset'),n.get('name'))]=n['node_id']
   if n['node_type']=='macro':macronames[n['file_id']].add(n.get('name'))
 for a in rows(G/'tables/native_callback_assignments.jsonl.gz'):
  if a.get('candidate_function_designator'):pointers[a['file_id']].add(a['lhs'])
 selected=set()
 for call in rows(G/'tables/native_call_index.jsonl.gz'):
  if call.get('syntax')=='ast_call' and (call['callee'] in macronames[call['file_id']] or call['callee'] in pointers[call['file_id']] or call['callee'].strip('(*)') in pointers[call['file_id']]):selected.add(call['file_id'])
 count=collections.Counter();path=G/'tables/native_local_model_edges.jsonl.gz'
 with gzip.open(path,'wt',compresslevel=3) as out:
  for fid in sorted(selected):
   f=files[fid]
   if f['language']!='c':continue
   data=(R/f['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==f['sha256']
   for model in analyze_text(data):
    cid=key('call',fid,model['call_byte'],model['callee']);target=functions.get((fid,model['target_byte'],model['target_name']))
    if not target:continue
    row=dict(edge_id=key('native_model_edge',cid,target,model['model']),source_id=cid,target_id=target,kind='call_targets_function_or_macro',resolution='conditional_source_resolved',traversable=True,language='c',file_id=fid,file=f['path'],line=model['line'],source_context=f['source_context'],conditions=model['conditions'],evidence=model)
    out.write(json.dumps(row,separators=(',',':'))+'\n');count[model['model']]+=1
 report=dict(selected_source_files=len(selected),edge_counts=dict(count),scope='All eligible retained C sources; limited exact source patterns, not general macro expansion or points-to.',edge_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
 (G/'reports/native_local_models.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':build()
