#!/usr/bin/env python3
"""Uncapped finite-graph SCC closure. Structural conditional connectivity, not feasibility."""
from array import array
from collections import deque
import base64,gzip,hashlib,json,zlib
from pathlib import Path
ADMITTED_RESOLUTIONS={'source_resolved','conditional_source_resolved'}
NATIVE_KINDS={'function_contains_call','call_targets_function_or_macro','registration_binds_c_function','call_has_memory_evidence','scope_has_memory_evidence','legacy_memory_evidence','evidence_identifies_physical_site'}

def jsonlines(path):
 op=gzip.open if str(path).endswith('.gz') else open
 with op(path,'rt') as f:
  for line in f:
   if line.strip():yield json.loads(line)

def gzwrite(path,rows):
 with open(path,'wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as f:
  for row in rows:f.write((json.dumps(row,sort_keys=True,separators=(',',':'))+'\n').encode())

def eligible(edge,kinds,context=None):
 if edge.get('resolution') not in ADMITTED_RESOLUTIONS or edge.get('traversable') is False or edge.get('kind') not in kinds:return False
 if context is None:return True
 return context in edge.get('contexts',edge.get('profiles',[]))

def csr(n,sources,targets):
 offsets=array('Q',[0])*(n+1)
 for x in sources:offsets[x+1]+=1
 for i in range(n):offsets[i+1]+=offsets[i]
 position=array('Q',offsets);neighbors=array('I',[0])*len(targets)
 for s,t in zip(sources,targets):neighbors[position[s]]=t;position[s]+=1
 return offsets,neighbors

class SinkSets:
 """Intern closures; tiny sparse tuples avoid O(max-sink-index) singleton allocation."""
 def __init__(self):self.values=[()];self.ids={():0};self.stable={}
 def intern(self,value):
  if not isinstance(value,int):
   value=tuple(sorted(set(value)))
   if any(p<0 for p in value):raise ValueError('negative sink index')
   if len(value)>32:
    bits=0
    for p in value:bits|=1<<p
    value=bits
  if isinstance(value,int):
   if value<0:raise ValueError('negative bitmap')
   if value.bit_count()<=32:value=tuple(self.positions(value))
  if value in self.ids:return self.ids[value]
  i=len(self.values);self.values.append(value);self.ids[value]=i;return i
 @staticmethod
 def positions(bits):
  while bits:
   b=bits & -bits;yield b.bit_length()-1;bits^=b
 def bits(self,i):
  v=self.values[i]
  if isinstance(v,int):return v
  bits=0
  for p in v:bits|=1<<p
  return bits
 def merge(self,a,b):
  if a==b or b==0:return a
  if a==0:return b
  x,y=self.values[a],self.values[b]
  if isinstance(x,tuple) and isinstance(y,tuple):
   value=tuple(sorted(set(x)|set(y)))
   if len(value)<=32:return self.intern(value)
  return self.intern(self.bits(a)|self.bits(b))
 def union(self,ids):
  value=()
  for i in ids:
   other=self.values[i]
   if not other:continue
   if not value:value=other;continue
   if isinstance(value,tuple) and isinstance(other,tuple):
    merged=tuple(sorted(set(value)|set(other)))
    if len(merged)<=32:value=merged;continue
   if isinstance(value,tuple):
    b=0
    for p in value:b|=1<<p
    value=b
   if isinstance(other,tuple):
    b=0
    for p in other:b|=1<<p
    other=b
   value|=other
  return self.intern(value)
 def members(self,i):
  v=self.values[i];return iter(v) if isinstance(v,tuple) else self.positions(v)
 def count(self,i):
  v=self.values[i];return len(v) if isinstance(v,tuple) else v.bit_count()
 def contains(self,i,sink):
  v=self.values[i];return sink in v if isinstance(v,tuple) else bool(v & (1<<sink))
 def raw(self,i):
  b=self.bits(i);return b.to_bytes((b.bit_length()+7)//8,'little')
 def key(self,i):
  if i not in self.stable:self.stable[i]='sinkset_'+hashlib.sha256(self.raw(i)).hexdigest()[:32]
  return self.stable[i]
 def records(self):
  for i in range(len(self.values)):
   yield dict(sink_set_id=self.key(i),sink_count=self.count(i),encoding='zlib_base64_little_endian_bitset_trimmed',payload=base64.b64encode(zlib.compress(self.raw(i),9)).decode())

def compose(node_ids,edges,seeds,bank=None):
 """Every edge retained structurally, cycles condensed. No depth, visited or path cap."""
 bank=bank if bank is not None else SinkSets();n=len(node_ids);lookup={x:i for i,x in enumerate(node_ids)}
 sources=array('I');targets=array('I')
 for s,t in edges:
  if s not in lookup or t not in lookup:raise ValueError(('missing endpoint',s,t))
  sources.append(lookup[s]);targets.append(lookup[t])
 forward=csr(n,sources,targets);reverse=csr(n,targets,sources)
 seen=bytearray(n);cursor=array('Q',forward[0][:-1]);order=array('I');stack=array('I')
 for root in range(n):
  if seen[root]:continue
  seen[root]=1;stack.append(root)
  while stack:
   v=stack[-1]
   if cursor[v]<forward[0][v+1]:
    w=forward[1][cursor[v]];cursor[v]+=1
    if not seen[w]:seen[w]=1;stack.append(w)
   else:order.append(stack.pop())
 comp=array('I',[0xffffffff])*n;count=0
 for root in reversed(order):
  if comp[root]!=0xffffffff:continue
  comp[root]=count;stack.append(root)
  while stack:
   v=stack.pop()
   for j in range(reverse[0][v],reverse[0][v+1]):
    w=reverse[1][j]
    if comp[w]==0xffffffff:comp[w]=count;stack.append(w)
  count+=1
 del seen,cursor,order,stack
 # Condensation topology deduplicates edge pairs only; original edge alternatives remain in producer tables.
 pairs={(int(comp[s])<<32)|int(comp[t]) for s,t in zip(sources,targets) if comp[s]!=comp[t]}
 cs=array('I');ct=array('I');indegree=array('I',[0])*count
 for p in sorted(pairs):s=p>>32;t=p & 0xffffffff;cs.append(s);ct.append(t);indegree[t]+=1
 del pairs
 dag=csr(count,cs,ct);queue=deque(i for i,d in enumerate(indegree) if not d);topo=array('I')
 while queue:
  v=queue.popleft();topo.append(v)
  for j in range(dag[0][v],dag[0][v+1]):
   w=dag[1][j];indegree[w]-=1
   if not indegree[w]:queue.append(w)
 assert len(topo)==count
 closures=array('I',[0])*count
 seed_groups={}
 for node,setid in seeds.items():
  if node not in lookup:raise ValueError(('seed missing node',node))
  seed_groups.setdefault(comp[lookup[node]],[]).append(setid)
 for c in reversed(topo):
  child_ids=(closures[dag[1][j]] for j in range(dag[0][c],dag[0][c+1]))
  closures[c]=bank.union(__import__('itertools').chain(seed_groups.get(c,()),child_ids))
 digests=[hashlib.sha256() for _ in range(count)];sizes=array('I',[0])*count
 for node in sorted(node_ids):c=comp[lookup[node]];digests[c].update(node.encode()+b'\0');sizes[c]+=1
 ids=['scc_'+d.hexdigest()[:32] for d in digests]
 cyclic=bytearray(count)
 for c,size in enumerate(sizes):cyclic[c]=size>1
 for s,t in zip(sources,targets):
  if s==t:cyclic[comp[s]]=1
 return dict(node_ids=node_ids,lookup=lookup,components=comp,component_ids=ids,component_sizes=sizes,cyclic=cyclic,closures=closures,dag_sources=cs,dag_targets=ct,bank=bank,edges=len(sources),forward=forward,reverse=reverse)

def reachable(result,start,reverse=False):
 lookup=result['lookup'];topology=result['reverse' if reverse else 'forward'];seen={lookup[start]};todo=[lookup[start]]
 while todo:
  v=todo.pop()
  for j in range(topology[0][v],topology[0][v+1]):
   w=topology[1][j]
   if w not in seen:seen.add(w);todo.append(w)
 return {result['node_ids'][i] for i in seen}

def export_view(output,view,result,apis,external_seed_nodes=()):
 """Complete factorized API×sink relation: API→SCC→interned sink bitmap."""
 out=Path(output);out.mkdir(parents=True,exist_ok=True);bank=result['bank'];comps=result['components'];closure=result['closures'];ids=result['component_ids'];external=set(external_seed_nodes)
 gzwrite(out/'node_components.jsonl.gz',(dict(view=view,node_id=n,component_id=ids[comps[i]],backward_reachable_from_memory=bool(closure[comps[i]]),external_native_seed=n in external) for i,n in enumerate(result['node_ids'])))
 gzwrite(out/'components.jsonl.gz',(dict(view=view,component_id=ids[c],node_count=result['component_sizes'][c],has_cycle=bool(result['cyclic'][c]),sink_set_id=bank.key(closure[c]),sink_count=bank.count(closure[c])) for c in range(len(ids))))
 gzwrite(out/'condensation_edges.jsonl.gz',(dict(view=view,source_component_id=ids[s],target_component_id=ids[t]) for s,t in zip(result['dag_sources'],result['dag_targets'])))
 gzwrite(out/'api_sink_relations.jsonl.gz',(dict(view=view,api_node_id=n,component_id=ids[comps[result['lookup'][n]]],sink_set_id=bank.key(closure[comps[result['lookup'][n]]]),sink_count=bank.count(closure[comps[result['lookup'][n]]])) for n in sorted(apis) if n in result['lookup']))
 return dict(view=view,nodes=len(comps),edges=result['edges'],sccs=len(ids),cyclic_sccs=sum(result['cyclic']),backward_reachable_nodes=sum(bool(closure[c]) for c in comps),api_nodes=sum(n in result['lookup'] for n in apis),api_sink_pairs=sum(bank.count(closure[comps[result['lookup'][n]]]) for n in apis if n in result['lookup']),depth_cap=None,visited_cap=None,path_sampling=False,semantics='conditional structural connectivity; joint guard/argument feasibility is not inferred')
