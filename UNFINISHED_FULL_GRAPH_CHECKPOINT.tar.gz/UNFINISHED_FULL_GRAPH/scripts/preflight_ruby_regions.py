#!/usr/bin/env python3
import gzip,json,pickle,time,hashlib
from ruby_full_graph import Model,Corpus,B,OUT,P,emit
from ruby_parse_regions import prepare
start=time.time()
with gzip.open(OUT/'ruby_definition_state.pkl.gz','rb') as f:model=pickle.load(f)
prepare(model,B,P)
with gzip.open(OUT/'tables/ruby_parse_recovery_regions.jsonl.gz','wt') as f:
 for file,regions in model.parse_regions.items():emit(f,dict(file=file,regions=regions))
(OUT/'reports/ruby_parse_recovery_preflight.json').write_text(json.dumps(dict(files=len(model.corpus.files),error_files=len(model.parse_regions),uncertain_methods=len(model.parse_uncertain_methods),state_sha256=hashlib.sha256((OUT/'ruby_definition_state.pkl.gz').read_bytes()).hexdigest(),seconds=time.time()-start),indent=2)+'\n')
print((OUT/'reports/ruby_parse_recovery_preflight.json').read_text())
