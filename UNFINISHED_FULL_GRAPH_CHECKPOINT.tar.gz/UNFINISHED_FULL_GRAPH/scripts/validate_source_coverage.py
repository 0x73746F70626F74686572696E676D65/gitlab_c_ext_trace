import gzip,json,collections,hashlib
from pathlib import Path
O=Path('/workspace/gitlab_c_ext_full_graph');T=O/'tables'
def rows(name):
 with gzip.open(T/name,'rt') as f:
  for l in f:yield json.loads(l)
summary=json.loads((O/'reports/source_coverage_census.json').read_text());ids=set();physical=set();paths=set();counts=collections.Counter();errors=[];checks=0;known_gems=set();prim=collections.defaultdict(collections.Counter)
for g in rows('gem_source_coverage.jsonl.gz'):
 key=(g['ledger_profile'],g['profile_gem_id'] or g['gem_id']);known_gems.add(key)
 if g['primary_bundle']:
  prim[g['ledger_profile']]['all']+=1;prim[g['ledger_profile']]['sourced' if g['source_available'] else 'blocked']+=1
  checks+=1
  if not g['source_available'] and not g['blockers']:errors.append(['missing_specific_blocker',g['coverage_id']])
for r in rows('retained_source_coverage.jsonl.gz'):
 checks+=2
 if r['source_id'] in ids:errors.append(['duplicate_source_id',r['source_id']])
 if r['path'] in paths:errors.append(['duplicate_lexical_path',r['path']])
 ids.add(r['source_id']);paths.add(r['path'])
 if r.get('status')=='unreadable':counts['unreadable']+=1;continue
 counts['lexical_files']+=1
 if r['physical_first']:
  checks+=1
  if r['canonical_path'] in physical:errors.append(['duplicate_physical_first',r['canonical_path']])
  physical.add(r['canonical_path']);counts['physical_files']+=1;counts['physical_bytes']+=r['bytes']
  for lang in ['ruby','native']:
   if r[lang+'_eligible']:counts[lang+'_'+r[lang+'_status']]+=1
 for a in r['ast_records']:
  checks+=1
  if a['sha256']!=r['sha256']:errors.append(['source_ast_hash_disagreement',r['source_id'],a['file_id']])
 for g in r['gem_memberships']:
  checks+=1
  if (g['profile'],g['profile_gem_id'] or g['gem_id']) not in known_gems:errors.append(['unknown_gem_membership',r['source_id'],g])
for k,v in summary['counts'].items():
 checks+=1
 if counts[k]!=v:errors.append(['summary_count',k,v,counts[k]])
for f,lang,allowed in [('ruby_recovery_candidates.jsonl.gz','ruby',{'missing_ast','source_hash_mismatch'}),('native_recovery_candidates.jsonl.gz','native',{'missing_ast','source_hash_mismatch','explicitly_deferred_ast'})]:
 seen=set()
 for r in rows(f):
  checks+=3
  if r['source_id'] not in ids or r[lang+'_status'] not in allowed or r['canonical_path'] in seen:errors.append(['invalid_recovery_row',f,r['source_id']])
  seen.add(r['canonical_path'])
 counts[f+'_rows']=len(seen)
assert prim['baseline_all_locks']=={'all':820,'sourced':742,'blocked':78}
assert prim['ee_primary']=={'all':820,'sourced':742,'blocked':78}
report=dict(status='PASS' if not errors else 'FAIL',checks=checks,errors=errors,readable_lexical_files=counts['lexical_files'],physical_files=counts['physical_files'],unreadable=counts['unreadable'],primary_profiles={k:dict(v) for k,v in prim.items()},recovery_rows={k:counts[k] for k in counts if k.endswith('_rows')},scope='Every census row PK/path uniqueness, physical-first uniqueness, all original AST hash agreements, all gem references, exact summary/recovery closure. Hashes were computed from retained bytes by census; this pass checks metadata consistency without reading all source bytes again.',source_mutation=False)
(O/'reports/source_coverage_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
