"""Parser recovery regions are not eligible as resolved call/definition evidence."""
def prepare(model,base,parser):
 import collections,gzip,json,hashlib,pathlib
 model.parse_regions={};model.parse_uncertain_methods=set()
 cache=pathlib.Path('/workspace/gitlab_c_ext_full_graph');report=cache/'reports/ruby_parse_recovery_preflight.json';cached=False
 if report.exists() and (cache/'tables/ruby_parse_recovery_regions.jsonl.gz').exists():
  info=json.loads(report.read_text())
  if info.get('files')==len(model.corpus.files) and info.get('state_sha256')==hashlib.sha256((cache/'ruby_definition_state.pkl.gz').read_bytes()).hexdigest():
   with gzip.open(cache/'tables/ruby_parse_recovery_regions.jsonl.gz','rt') as f:
    model.parse_regions={r['file']:r['regions'] for r in map(json.loads,f)}
   cached=True
 if not cached:
  for file in sorted(model.corpus.files):
   data=(base/file).read_bytes();root=parser.parse(data).root_node
   if not root.has_error:continue
   regions=[];todo=[root]
   while todo:
    n=todo.pop()
    if n.type=='ERROR' or n.is_missing:regions.append((n.start_byte,n.end_byte,n.type))
    if n.has_error:todo.extend(n.children)
   model.parse_regions[file]=regions
 for ds in model.defs.values():
  for d in ds:
   if any(d.get('byte_offset',0)<=b and a<=d.get('end_byte',0) for a,b,_ in model.parse_regions.get(d['file'],())):
    d['unconditional']=False;d['parse_recovery_unresolved']=True;model.parse_uncertain_methods.add(d['node_id'])
 for rs in model.rels.values():
  for r in rs:
   if any(a<=r.get('byte_offset',0)<=b for a,b,_ in model.parse_regions.get(r['file'],())):r['unconditional']=False
 model.stats['parse_uncertain_method_definitions']=len(model.parse_uncertain_methods)
