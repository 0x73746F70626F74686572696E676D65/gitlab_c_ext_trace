"""Supplement census with Ruby interface inputs and embedded-template boundaries."""
import json,gzip,collections
from pathlib import Path
O=Path('/workspace/gitlab_c_ext_full_graph');counts=collections.Counter();byfamily=collections.defaultdict(collections.Counter)
with gzip.open(O/'tables/source_language_boundaries.jsonl.gz','wt',compresslevel=1) as out,gzip.open(O/'tables/ruby_interface_recovery_candidates.jsonl.gz','wt',compresslevel=1) as recover:
 for l in gzip.open(O/'tables/retained_source_coverage.jsonl.gz','rt'):
  r=json.loads(l)
  if not r.get('physical_first'):continue
  p=Path(r['path']);name=p.name
  if p.suffix=='.rbi':kind='ruby_interface_definition';action='ruby_ast_recovery_required_not_runtime_method_implementation'
  elif p.suffix in {'.erb','.haml','.slim','.rhtml'}:kind='embedded_ruby_template';action='template_host_grammar_not_parsed_by_standalone_Ruby_parser'
  elif p.suffix=='.rbs':kind='ruby_signature';action='RBS_grammar_boundary_not_Ruby_runtime_code'
  elif name.endswith(('.rb.in','.rb.tt')):kind='generated_ruby_template';action='generation_input_boundary_not_evaluated'
  else:continue
  q=dict(source_id=r['source_id'],path=r['path'],canonical_path=r['canonical_path'],sha256=r['sha256'],family=r['family'],source_role=r['source_role'],kind=kind,analysis_status=action,gem_memberships=r['gem_memberships']);out.write(json.dumps(q,separators=(',',':'))+'\n');counts[kind]+=1;byfamily[r['family']][kind]+=1
  if kind=='ruby_interface_definition':r.update(ruby_eligible=True,ruby_status='missing_ast' if not any(e['language']=='ruby' for e in r['ast_records']) else 'parsed',ruby_eligibility='rbi_interface',runtime_role='interface_signature_not_runtime_implementation');recover.write(json.dumps(r,separators=(',',':'))+'\n')
(O/'reports/source_language_boundaries.json').write_text(json.dumps(dict(counts=dict(counts),families={k:dict(v) for k,v in byfamily.items()},scope='Supplemental explicit language boundaries; does not promote template text/signatures to resolved runtime calls.'),indent=2)+'\n');print(counts)
