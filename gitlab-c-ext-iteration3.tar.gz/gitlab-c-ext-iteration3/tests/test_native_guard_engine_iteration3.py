import sys,unittest,tempfile,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from native_guard_engine_iteration3 import *
class GuardTests(unittest.TestCase):
 def setup_c(self,code,callee='sink'):
  b=code.encode();t=CP['c'].parse(b);fn=next(n for n in walk(t.root_node)if n.type=='function_definition');node=next(n for n in walk(fn)if n.type=='call_expression'and tx(b,n.child_by_field_name('function'))==callee);return b,fn,node
 def decisions(self,code,env):
  b,fn,n=self.setup_c(code);e,_=direct_locals(fn,n,b,env);return[(guard_truth(g,k,b,e),w)for g,w,k in branch_guards(n,fn,b)]
 def test_argument_arity_contradiction(self):self.assertEqual(self.decisions('void f(int n){if(!n){sink();}}',{'n':val('int',1)}),[(False,True)])
 def test_no_block_contradiction(self):self.assertEqual(self.decisions('void f(){if(rb_block_given_p()){sink();}}',{'$block':val('bool',False)}),[(False,True)])
 def test_call_in_predicate_is_not_guarded_by_itself(self):self.assertEqual(self.decisions('void f(){if(sink()){other();}}',{}),[])
 def test_else_means_negation(self):self.assertEqual(self.decisions('void f(int n){if(n>1){other();}else{sink();}}',{'n':val('int',2)}),[(True,False)])
 def test_unknown_stays_unknown(self):self.assertEqual(self.decisions('void f(){if(globalflag){sink();}}',{}),[(None,True)])
 def test_shortcircuit_certain_false(self):self.assertEqual(self.decisions('void f(){if(0 && unknown){sink();}}',{}),[(False,True)])
 def test_local_literal(self):self.assertEqual(self.decisions('void f(){int n=3;if(n==0){sink();}}',{}),[(False,True)])
 def test_unknown_branch_assignment_kills(self):self.assertEqual(self.decisions('void f(int n){if(other){n=0;}if(!n){sink();}}',{'n':val('int',1)}),[(None,True)])
 def test_false_branch_does_not_assign(self):self.assertEqual(self.decisions('void f(int n){if(0){n=0;}if(!n){sink();}}',{'n':val('int',1)}),[(False,True)])
 def test_nested_shadow_does_not_change_outer(self):self.assertEqual(self.decisions('void f(int n){{int n=0;}if(!n){sink();}}',{'n':val('int',1)}),[(False,True)])
 def test_type_predicate(self):self.assertEqual(self.decisions('void f(VALUE x){if(TYPE(x)==T_STRING){sink();}}',{'x':val('ruby_type','hash')}),[(False,True)])
 def test_scan_args_preserves_positional_count(self):self.assertEqual(self.decisions('void f(int n,VALUE *args){n=rb_scan_args(n,args,"02:",&x,&y,&opts);if(!n){sink();}}',{'n':val('int',1),'$keyword_count':val('int',0)}),[(False,True)])
 def test_keyword_count_removed(self):self.assertEqual(self.decisions('void f(int n,VALUE *args){n=rb_scan_args(n,args,"02:",&x,&y,&opts);if(!n){sink();}}',{'n':val('int',1),'$keyword_count':val('int',1)}),[(True,True)])
 def test_address_escape_invalidates(self):self.assertEqual(self.decisions('void f(int n){mutate(&n);if(!n){sink();}}',{'n':val('int',1)}),[(None,True)])
 def test_switch_distinct_branch(self):self.assertEqual(self.decisions('void f(int mode){switch(mode){case 1: sink();break;case 2: other();}}',{'mode':val('int',2)}),[(False,True)])
 def test_switch_grouped_cases(self):self.assertEqual(self.decisions('void f(int mode){switch(mode){case 1: case 2: sink();break;}}',{'mode':val('int',1)}),[(True,True)])
 def test_switch_fallthrough(self):self.assertEqual(self.decisions('void f(int mode){switch(mode){case 1: other();case 2: sink();break;}}',{'mode':val('int',1)}),[(True,True)])
 def test_symbol_option_scalar_mode(self):self.assertEqual(self.decisions('void f(VALUE opts){int mode=0;VALUE v;if(Qnil!=(v=rb_hash_lookup(opts,mode_sym))){if(v==rails_sym){mode=2;}else if(v==strict_sym){mode=1;}}switch(mode){case 1:sink();break;case 2:other();}}',{'opts':val('ruby_hash',{'mode':['ruby_symbol','rails']}),'mode_sym':val('ruby_symbol','mode'),'rails_sym':val('ruby_symbol','rails'),'strict_sym':val('ruby_symbol','strict')}),[(False,True)])
 def test_loop_counter_not_initial_constant(self):self.assertEqual(self.decisions('void f(){int count=0;while(next()){count++;}if(count==0){sink();}}',{}),[(None,True)])
 def test_for_update_not_run_before_body(self):self.assertEqual(self.decisions('void f(){for(int i=0;i<2;i+=2){if(i==2){sink();}}}',{}),[(None,True),(None,True)])
 def test_unknown_compound_assignment(self):self.assertEqual(self.decisions('void f(int n){n+=2;if(n==2){sink();}}',{}),[(None,True)])
 def test_pointer_escape_via_struct_initializer(self):self.assertEqual(self.decisions('void f(){int n=0;struct S s={.ptr=&n};mutate(&s);if(n==0){sink();}}',{}),[(None,True)])
 def test_uninitialized_nested_shadow(self):self.assertEqual(self.decisions('void f(int n){{int n;n=0;}if(!n){sink();}}',{'n':val('int',1)}),[(False,True)])
 def test_outer_value_through_block_local(self):self.assertEqual(self.decisions('void f(){int mode=0;{int v=2;mode=v;}if(mode==1){sink();}}',{}),[(False,True)])
 def test_oj_style_block_locals(self):self.assertEqual(self.decisions('void f(int argc,VALUE *argv){int mode=0;if(argc>=2){VALUE opts=argv[1];VALUE v;if(Qnil!=(v=rb_hash_lookup(opts,mode_sym))){if(v==rails_sym){mode=2;}else if(v==strict_sym){mode=1;}}}switch(mode){case 1:sink();break;case 2:other();}}',{'argc':val('int',2),'argv[1]':val('ruby_hash',{'mode':['ruby_symbol','rails']}),'mode_sym':val('ruby_symbol','mode'),'rails_sym':val('ruby_symbol','rails'),'strict_sym':val('ruby_symbol','strict')}),[(False,True)])
 def test_ruby_integer_representation_unknown(self):self.assertEqual(self.decisions('void f(VALUE x){if(TYPE(x)==T_FIXNUM){sink();}}',{'x':val('ruby_integer',1)}),[(None,True)])
 def test_ruby_literal_fact(self):
  for code,count,block in [('Thing.new("x")',1,False),('Thing.new("x") { work }',1,True),('Thing.new(*items)',None,False),('Thing.new(mode: :rails)',1,False)]:
   b=code.encode();t=RP.parse(b);n=next(n for n in walk(t.root_node)if n.type=='call');rel='synthetic.rb';cid=hashlib.sha256('\0'.join(map(str,[rel,n.start_byte,n.end_byte,'call'])).encode()).hexdigest()[:24]
   with tempfile.TemporaryDirectory()as d:
    p=Path(d)/'synthetic.rb';p.write_bytes(b);v=ruby_native_call_facts(p,{'file':rel,'line':1,'method':'new','call_id':cid});self.assertEqual(v['argument_count'],count);self.assertEqual(v['block'],block)
 def view_decisions(self,code,values):return self.decisions(code,{'argv':argv_view(values)})
 def test_view_dereference(self):self.assertEqual(self.view_decisions('void f(VALUE *argv){if(TYPE(*argv)==T_STRING){sink();}}',[val('ruby_type','hash')]),[(False,True)])
 def test_view_subscript_spaces(self):self.assertEqual(self.view_decisions('void f(VALUE *argv){if(TYPE(argv [ 0 ])==T_STRING){sink();}}',[val('ruby_type','string')]),[(True,True)])
 def test_view_offset(self):self.assertEqual(self.view_decisions('void f(VALUE *argv){VALUE *p=argv+1;if(TYPE(*p)==T_STRING){sink();}}',[None,val('ruby_type','string')]),[(True,True)])
 def test_view_integer_plus_pointer(self):self.assertEqual(self.view_decisions('void f(VALUE *argv){if(TYPE(*(1+argv))==T_HASH){sink();}}',[None,val('ruby_type','hash')]),[(True,True)])
 def test_view_outside_bounds_unknown(self):self.assertEqual(self.view_decisions('void f(VALUE *argv){if(TYPE(argv[2])==T_HASH){sink();}}',[val('ruby_type','hash')]),[(None,True)])
 def test_view_negative_unknown(self):self.assertEqual(self.view_decisions('void f(VALUE *argv){if(TYPE(*(argv-1))==T_HASH){sink();}}',[val('ruby_type','hash')]),[(None,True)])
 def test_view_unknown_offset(self):self.assertEqual(self.view_decisions('void f(VALUE *argv){if(TYPE(*(argv+i))==T_HASH){sink();}}',[val('ruby_type','hash')]),[(None,True)])
 def test_view_unknown_value_not_type_assumed(self):self.assertEqual(self.view_decisions('void f(VALUE *argv){if(TYPE(*argv)==T_HASH){sink();}}',[None]),[(None,True)])
 def test_view_mutated_alias_unknown(self):self.assertEqual(self.view_decisions('void f(VALUE *argv){VALUE *p=argv;mutate(p);if(TYPE(*p)==T_HASH){sink();}}',[val('ruby_type','hash')]),[(None,True)])
 def test_view_alias_increment_unknown(self):self.assertEqual(self.view_decisions('void f(VALUE *argv){VALUE *p=argv;p++;if(TYPE(*p)==T_HASH){sink();}}',[val('ruby_type','hash')]),[(None,True)])
 def test_view_element_write_unknown(self):self.assertEqual(self.view_decisions('void f(VALUE *argv){argv[0]=x;if(TYPE(*argv)==T_HASH){sink();}}',[val('ruby_type','hash')]),[(None,True)])
 def test_view_unpassed_unknown_call_preserves_vector(self):self.assertEqual(self.view_decisions('void f(VALUE *argv){unknown();if(TYPE(*argv)==T_HASH){sink();}}',[val('ruby_type','hash')]),[(True,True)])
 def test_view_normal_integer_arithmetic(self):self.assertEqual(self.decisions('void f(){int x=1+2;if(x==3){sink();}}',{}),[(True,True)])
 def test_view_reinterpret_cast_unknown(self):self.assertEqual(self.view_decisions('void f(VALUE *argv){if(TYPE(*((char*)argv))==T_HASH){sink();}}',[val('ruby_type','hash')]),[(None,True)])
 def test_view_value_cast(self):self.assertEqual(self.view_decisions('void f(VALUE *argv){if(TYPE(*((const VALUE*)argv))==T_HASH){sink();}}',[val('ruby_type','hash')]),[(True,True)])
if __name__=='__main__':unittest.main()
