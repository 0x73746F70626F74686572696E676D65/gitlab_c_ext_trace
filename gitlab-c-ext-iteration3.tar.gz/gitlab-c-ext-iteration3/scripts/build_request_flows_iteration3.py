#!/usr/bin/env python3
"""Add reviewed request candidates with guarded encoding alternatives, not proof.
No target execution and no modifications to prior iteration records.
"""
import pathlib,json,hashlib,copy,collections
from request_flow_engine import cite
B=pathlib.Path('/workspace/gitlab_c_ext_trace');V=pathlib.Path('/workspace/gitlab_c_ext_v3');ROOTS={'ce':pathlib.Path('/workspace/gitlab_c_ext_frontend_v2'),'ee':pathlib.Path('/workspace/gitlab_c_ext_ee_profile')};EE='sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/'
def rows(p):return [json.loads(l) for l in p.open() if l.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify_evidence(ev):
 assert sha(B/ev['file'])==ev.get('source_sha256',ev.get('sha256')),ev['file']
 # All attached reviewers used source excerpts with retained content.
 if ev.get('excerpt'):assert ev['excerpt'] in (B/ev['file']).read_text(),ev

def main():
 recipe=V/'fixtures/request_flow_contracts_iteration3.json';spec=json.loads(recipe.read_text());revfile=V/'tables/review_request_candidates_iteration2.jsonl';reviews={x['candidate_id']:x for x in rows(revfile)};priorfile=V/'tables/request_memory_flows_iteration2.jsonl';prior={x['profile']:x for x in rows(priorfile) if 'passkey' in x['flow_id']};model_file=V/'tables/oj_request_encoding_models.jsonl';model=rows(model_file)[0];links={x['candidate_id']:x for x in rows(V/'tables/request_candidate_encoding_models.jsonl')};models={};entries={};out=[]
 for profile,root in ROOTS.items():
  models[profile]={c['candidate_id']:c for c in rows(V/f'profiles/{profile}/tables/request_arg_candidates.jsonl')};entries[profile]=rows(root/'tables/frontend_entrypoints.jsonl')
 runtime_file=V/'tables/ruby_runtime_contracts_iteration3.jsonl';runtime={r['model_id']:r for r in rows(runtime_file)}
 for r in runtime.values():
  assert r['status']=='source_supported_conditional_contract'
  for ev in r['evidence']:verify_evidence(ev)
 for ev in model['evidence']:verify_evidence(ev)
 for contract in spec['cases']:
  cid=contract['candidate_id'];profile=contract['profile'];c=models[profile][cid];review=reviews[cid];base=prior[profile];assert review['verdict']=='supported_conditional' and review['profile']==profile
  for ev in review['evidence']:verify_evidence(ev)
  ep=[e for e in entries[profile] if set(e.get('method_ids',[]))&set(c['handler_method_ids'])];assert len(ep)==1 and ep[0]['method']==contract['action'] and ep[0]['owner']==contract['handler']
  evidence=[]
  # Begin at the current request source; never import the old passkey source/admission.
  for i,ev in enumerate(review['evidence']):evidence.append(dict(ev,hop_id=f'{cid}_ruby_{i}',hop_kind='reviewed_request_route_or_Ruby_transfer',confidence='independently_reviewed_conditional_Ruby_segment'))
  wanted={'safe_validate','wrapper','size','bodyguard','ojcall','registration','argv','callback','handler','shift','input','setinput','pointer','protect','parse2','cursor','token','span','sink'}
  for ev in base['evidence']:
   if ev['id'] in wanted:
    assert sha(B/ev['file'])==ev.get('source_sha256',ev.get('sha256'));evidence.append(dict(ev,hop_id=f'{cid}_nativechain_{ev["id"]}',hop_kind='shared_wrapper_or_native_source_relation',confidence='prior_independent_native_contract_under_guards'))
  binary=copy.deepcopy(model);binary['model_reference']={'path':str(model_file.relative_to(V)),'sha256':sha(model_file)}
  flow={'flow_id':'iteration3_'+cid,'iteration':3,'profile':profile,'gitlab_sha':base['gitlab_sha'],'candidate_id':cid,'route_scope_occurrence_id':c['route_scope_occurrence_id'],'baseline_entrypoint_id':ep[0]['entrypoint_id'],'handler_method_ids':c['handler_method_ids'],'entrypoint':ep[0],'selected_route':contract['route'],'selected_action':contract['action'],'manual_source_contract':contract,'request_source':contract['request_source'],'source_identity':c['source_identity'],'source_argument_position':1,'argument_position_convention':'Ruby and C primitive positions are 1-based; explicit argv indices remain 0-based','source_to_wrapper_transfer':contract['transfer'],'Ruby_call_prefix':c['ruby_call_path'],'registration_ids':base['registration_ids'],'typed_native_boundaries':base['typed_native_boundaries'],'constructor_bridges':[m for m in base['constructor_bridges'] if m['receiver']=='Gitlab::Json::StreamValidator'],'terminal_site_id':base['terminal_site_id'],'terminal_primitive_ids':base['terminal_primitive_ids'],'terminal_operation':'rb_str_new','terminal_arguments':[{'position':1,'expression':'key','meaning':'unescaped key span in selected parser-input String','influence':'content under UTF8 branch; request-content relationship unresolved across external BINARY conversion unless explicit preserving assumption holds','pointer_control':'runtime-managed String address, not attacker-chosen address'},{'position':2,'expression':'klen','meaning':'closing quote minus key start in selected String','influence':'derived_length_or_count','bound':'UTF8: within original <=20MiB body; BINARY: within returned String, original size does not bound it absent conversion semantics'}],'selected_input':spec['selected_input'],'admission_conditions':review['conditions'],'auth_context':review['auth'],'review_unresolved':review['unresolved'],'route_conditions':c['route_conditions'],'encoding_alternatives':[{'branch_id':'utf8_no_conversion','guard':'RB_ENCODING_GET(native input)==oj_utf8_encoding_index','status':'source_supported_conditional_branch','input_encoding_observed':False,'argument_identity':'pi.json aliases selected original String buffer under no-conversion guard','memory_influence':['content','derived_length_or_count'],'body_byte_bound':20971520,'bound_scope':'guard on original body and unchanged UTF8 parse buffer','inherited_guard':'normal method bindings, allocations and scanner/first-key callbacks permit branch; runtime encoding not established'}, {'branch_id':'binary_conversion_returned_string','guard':'ASCII-only object String tagged BINARY, RB_ENCODING_GET != oj_utf8_encoding_index','status':'partial_external_conversion_semantics','encoding_model_id':model['model_id'],'candidate_link':links[cid],'model_reference':binary['model_reference'],'external_boundary':model['external_boundary'],'value_model':model['value_model'],'bounds':model['bounds'],'evidence':model['evidence'],'remaining_gap':'Source retains explicit call/returned String→key continuation, but request-byte preservation and size equivalence through Ruby-core rb_str_conv_enc not proved'}],'status':'source_evidenced_conditional_encoding_alternatives_with_partial_boundary','complete_source_parsed_path_claim':False,'runtime_execution':False,'vulnerability_claim':False,'automatic_verified_label':False,'value_transfer_evidence':evidence,'review_references':[{'path':str(revfile.relative_to(V)),'sha256':sha(revfile),'candidate_id':cid},{'path':str(priorfile.relative_to(V)),'sha256':sha(priorfile),'reused_native_contract_flow_id':base['flow_id']}],'counting':'One record per reviewed profile-bound source route; encoding alternatives are not counted separately; all five share one native physical site'}
  conv=copy.deepcopy(runtime['ruby3311_ascii_binary_to_utf8_preserves_bytes_v1']);ctor=copy.deepcopy(runtime['ruby3311_class_new_allocate_initialize_v1'])
  branch=flow['encoding_alternatives'][1]
  branch['historical_external_gap_reference']=branch.pop('model_reference')
  branch['historical_candidate_encoding_link']=branch.pop('candidate_link')
  branch['status']='source_supported_conditional_runtime_model'
  branch['runtime_model_reference']={'path':str(runtime_file.relative_to(V)),'sha256':sha(runtime_file),'model_id':conv['model_id']}
  branch['runtime_source_contract']=conv
  branch['external_boundary']={'function':'rb_str_conv_enc','implementation_now_source_reviewed':True,'conditions':conv['preconditions'],'bytes_and_length_preserved_under_conditions':True,'storage_identity':'unspecified; use returned String pointer, never equate original address','runtime_deployment_equivalence_proven':False}
  branch['bounds']={'original_body_guard_bytes':20971520,'returned_body_bound_under_ASCII_runtime_contract':20971520,'key_count_bound':'at most returned String byte extent','uncovered_cases':'non-ASCII general transcoder and other encodings excluded; no bound inferred for those cases'}
  branch['remaining_gap']='Actual request encoding and deployed runtime semantics/admission remain conditions; generic non-ASCII transcoder not covered'
  branch['value_model'][1]['alias_relation_to_original']='new duplicate object for BINARY to UTF8; source bytes/length equal under reviewed ASCII fast path; raw storage identity unspecified'
  branch['evidence']+=conv['evidence']
  flow['constructor_bridges']=[{'receiver':'Gitlab::Json::StreamValidator','kind':'source_reviewed_conditional_runtime_constructor_model','relation':'inherited Class#new -> class allocator -> initialize with original arguments','runtime_source_contract':ctor,'reference':{'path':str(runtime_file.relative_to(V)),'sha256':sha(runtime_file),'model_id':ctor['model_id']},'remaining_gap':'runtime method lookup and deployment equivalence remain conditional; not universal constructor behavior'}]
  flow['status']='source_supported_conditional_flow_with_runtime_models'
  flow['terminal_arguments'][0]['influence']='content under selected UTF8 branch or reviewed ASCII-only BINARY conversion contract'
  flow['terminal_arguments'][1]['bound']='Within selected returned String extent; <=20MiB under UTF8 or reviewed ASCII-preserving BINARY branch, not a generic non-ASCII conversion bound'
  flow['historical_gap_disposition']='Prior Ruby review encoding gaps are addressed only by the selected UTF8 or ASCII-BINARY reviewed runtime branch; observations of runtime encoding/deployment and general transcoding are still absent.'
  flow['memory_operation_semantics']='rb_str_new is an inventoried Ruby string constructor/copy site, not proof of a fresh heap allocation on each invocation; embedded string representation is possible. Derived parsed key length is not an arbitrary direct size parameter or chosen native address. No malloc-descendant expansion is claimed.'
  if profile=='ee':flow['EE_native_source_binding']=base['EE_native_source_binding']
  out.append(flow)
 p=V/'tables/request_memory_flows_iteration3.jsonl';p.write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in out));assert len({x['flow_id'] for x in out})==len(out)
 report={'status':'pass_structural_and_source_agreement_checks','iteration':3,'profile_route_records':len(out),'distinct_source_site_families':len(set(x['selected_action']+'|'+x['manual_source_contract']['handler'] for x in out)),'profiles':dict(collections.Counter(x['profile'] for x in out)),'distinct_native_site_ids':len(set(x['terminal_site_id'] for x in out)),'encoding_alternatives_per_record':2,'binary_branches_with_reviewed_ASCII_runtime_contract':len(out),'general_non_ASCII_conversion_covered':False,'unconditional_runtime_paths_proven':0,'recipe_sha256':sha(recipe),'output_sha256':sha(p),'output_bytes':p.stat().st_size,'no_exhaustive_coverage_or_accuracy_estimate':True}
 (V/'reports/request_flow_iteration3_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
