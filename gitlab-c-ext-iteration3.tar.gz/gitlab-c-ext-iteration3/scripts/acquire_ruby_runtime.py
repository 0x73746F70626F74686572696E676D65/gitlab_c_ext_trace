#!/usr/bin/env python3
"""Direct official GitHub source acquisition only; never runs Ruby/build hooks."""
import subprocess,json,datetime,hashlib,os
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');D=Path('/workspace/gitlab_c_ext_trace/sources/runtime/ruby-v3_3_11');URL='https://github.com/ruby/ruby.git';TAG='v3_3_11'
report=dict(url=URL,tag=TAG,retrieval_started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),attempts=[],runtime_equivalence='Source at requested release tag; not evidence installed/deployed runtime matches this commit.',execution_policy='Git and static Python only; no Ruby execution/build/hooks.')
def run(args,timeout=30):
 try:
  p=subprocess.run(args,capture_output=True,timeout=timeout);res=dict(args=args,exit_code=p.returncode,stdout=p.stdout.decode('utf8','replace')[-6000:],stderr=p.stderr.decode('utf8','replace')[-3000:]);report['attempts'].append(res)
  if p.returncode:raise RuntimeError(res)
  return p.stdout
 except subprocess.TimeoutExpired:
  report['attempts'].append(dict(args=args,status='timeout',seconds=timeout));raise
try:
 remote=run(['git','ls-remote',URL,'refs/tags/'+TAG,'refs/tags/'+TAG+'^{}'])
 if not (D/'.git').exists():run(['git','clone','--depth','1','--single-branch','--branch',TAG,'--config','core.autocrlf=false',URL,str(D)],90)
 commit=run(['git','-C',str(D),'rev-parse','HEAD']).decode().strip();tree=run(['git','-C',str(D),'rev-parse','HEAD^{tree}']).decode().strip()
 report.update(commit=commit,tree=tree,source_dir=str(D),remote_tag_matches_commit=any(x.split()[0]==commit for x in remote.decode().splitlines()))
 assert report['remote_tag_matches_commit']
 entries=run(['git','-C',str(D),'ls-tree','-rz','HEAD']);manifest=[];issues=[]
 for e in entries.split(b'\0'):
  if not e:continue
  meta,name=e.split(b'\t',1);mode,typ,blob=meta.decode().split();p=D/os.fsdecode(name)
  if typ!='blob':issues.append(dict(path=os.fsdecode(name),type=typ));continue
  data=os.fsencode(os.readlink(p)) if mode=='120000' else p.read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  assert actual==blob,(p,actual,blob)
  manifest.append(dict(file=str(p),relative_path=os.fsdecode(name),mode=mode,git_blob=blob,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
 (V/'tables/ruby_runtime_source_manifest.jsonl').write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in manifest))
 report.update(status='acquired_full_tracked_tree',files=len(manifest),tracked_bytes=sum(x['bytes'] for x in manifest),all_tracked_blob_hashes_verified=True,nonblob_entries=issues,retention='Full tagged git checkout retained, including .git shallow provenance; submodule contents if any not implied.')
except Exception as e:report.update(status='failed',error=str(e))
finally:
 report['retrieval_completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(V/'reports/ruby_runtime_acquisition.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='attempts'}))
