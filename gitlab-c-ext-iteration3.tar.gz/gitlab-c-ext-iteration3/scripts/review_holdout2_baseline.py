#!/usr/bin/env python3
"""Serialize independent manual source review, not an automatic feasibility analyzer."""
import json,hashlib,collections
from pathlib import Path
D=Path('/workspace/gitlab_c_ext_v3/audit/holdout2_20260930');B=Path('/workspace/gitlab_c_ext_trace')
def rows(p):return [json.loads(l) for l in p.open()]
rs=rows(D/'path_sample.jsonl');methods=json.loads((D/'target_methods.json').read_text());cache={}
def ev(f,n):
 if f not in cache:cache[f]=(B/f).read_bytes()
 return dict(file=f,line=n,context=cache[f].decode(errors='replace').split('\n')[n-1])
notes={
'J001':('contradicted','Default draft:nil selects create_review, not selected publish_draft_note at12. Independently HTML5 own parse103 shadows selected HTML4 ancestor parse.',[( 'app/services/draft_notes/publish_service.rb',5),('app/services/draft_notes/publish_service.rb',11)]),
'J002':('unresolved','Terminal error construction requires CompatMode/RailsMode and safe!=Yes; sc_parse copies mutable oj_default_options. Caller only provides max_integer_digits; selected mode/guard not established.',[]),
'J003':('contradicted','escape_uri receives s.to_s String; selected rb_utf8_str_new empty branch requires NIL_P(str). ERB monkeypatch activation also not established.',[]),
'J004':('contradicted','HMACToken passes only leeway,verify_iat,algorithm. DecodeConfiguration.to_h has no x5c; selected X5cKeyFinder branch returns early without @options[:x5c]. Conditional global monkeypatches not assumed.',[]),
'J005':('unresolved','Selected RE2 options constructor matches supplied log_errors Hash. However entrypoint enforces image DiffNote while selected Note builder requires note.for_issue?; no source-backed feasible note satisfying both established. DiffNote declared types omit Issue; EE type additions/state invariants not exhaustively proven.',[]),
'J006':('unresolved','Selected compatibility macro requires RB_PASS_CALLED_KEYWORDS undefined; build-header condition unresolved.',[]),
'J007':('contradicted','protected? calls fetch(ref_name) using dry_run:false default; selected discrepancy call requires dry_run.',[]),
'J008':('contradicted','Event.json_schema parses bundled JSON object to Hash; JSONSchemer selected String arm cannot apply.',[]),
'J009':('supported_static_chain','Issue related-MR service invokes sorter with Array; rb_version_sort duplicates array before sorting. Ordinary receiver/loading/auth conditions separate.',[]),
'J010':('supported_static_chain','Changelog template configuration String enters Parser.parse inherited from Parslet::Atoms::Base, Source.new, StringScanner allocator. Timeout block invokes parse; retained constructor allocation supported conditionally.',[]),
'J011':('supported_static_chain','GraphQL own compressed_checkpoint method calls registered Deflate.deflate; terminal VALUE args[2] is a fixed small stack array, not heap allocation or evidence of large-stack risk.',[]),
'J012':('contradicted','Event.json_schema Hash cannot take JSONSchemer String branch; selected native frame growth additionally remains guarded.',[]),
'J013':('supported_static_chain','Speedscope supplies block/raw:true; stackprof_run ensures block then results, raw timestamps array construction conditional on successful profiler startup.',[]),
'J014':('supported_static_chain','Controller includes CycleAnalyticsParams; request String date uses Date.parse. date__parse invokes unconditional asp_string macro for normalization. Authorization/input acceptance remain conditional.',[]),
'J015':('supported_static_chain','Registered RequestContext middleware calls start_thread_context; enabled LocalTimer invokes registered monotonic_time and ULL2NUM. Integer conversion may not allocate.',[]),
'J016':('contradicted','HTML5::Document has its own parse103; selected HTML4::Document.parse is shadowed. Selected inherited XML read_io also not final HTML4 binding.',[]),
'J017':('supported_static_chain','Validated URL path through recording_request (yielding block), Gitaly stub TLS credentials creates native wrapper. Cache miss and TLS configuration required, not claimed runtime established.',[]),
'J018':('unresolved','Unix Filesystem.stat error path accesses FFI errno and INT2NUM. Local links supported but platform loader and statvfs error outcome not established; conversion not necessarily allocating.',[]),
'J019':('contradicted','Event.json_schema Hash cannot take JSONSchemer String arm. after_commit callback scheduling is additional conditional edge, not immediate execution proof.',[]),
'J020':('contradicted','Event.json_schema Hash cannot take JSONSchemer String arm; mimic JSON override loading also conditional.',[]),
'J021':('contradicted','ProtectedBranch.protected? omits dry_run, defaultfalse; discrepancy call at32 guarded dry_run cannot occur along selected chain.',[]),
'J022':('supported_static_chain','MemoryReport creates fresh StringIO without arguments; native allocator wrapsNULL at221, initializer !ptr branch261 allocates StringIO struct at82.',[]),
'J023':('contradicted','Event.json_schema Hash cannot take JSONSchemer String branch. Local Yajl initial bytestack realloc otherwise supported.',[]),
'J024':('contradicted','GzipReader.read receives MAXIMUM_BODY_SIZE+1 positive Integer; selected gzfile_read_all call requires NIL_P(vlen).',[])}
extra={
'J001':[('sources/gems/nokogiri-1.19.4/lib/nokogiri/html5/document.rb',103)],
'J002':[('sources/gems/oj-3.17.6/ext/oj/parse.c',1331),('sources/gems/oj-3.17.6/ext/oj/scp.c',129)],
'J003':[('sources/gems/escape_utils-1.3.0/lib/escape_utils/url/erb.rb',4),('sources/gems/escape_utils-1.3.0/ext/escape_utils/escape_utils.c',40)],
'J004':[('sources/expansion/jwt-2.10.3--jwt/lib/jwt/configuration/decode_configuration.rb',56),('sources/expansion/jwt-2.10.3--jwt/lib/jwt/decode.rb',64)],
'J005':[('sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/app/graphql/mutations/notes/update/image_diff_note.rb',41),('sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/app/models/diff_note.rb',14)],
'J006':[('sources/gems/stringio-3.2.0/ext/stringio/stringio.c',34)],
'J007':[('sources/gitlab/app/services/protected_branches/cache_service.rb',11)],
'J010':[('sources/expansion/parslet-1.8.2--kschiess/lib/parslet/atoms/base.rb',26)],
'J016':[('sources/gems/nokogiri-1.19.4/lib/nokogiri/html5/document.rb',103)],
'J021':[('sources/gitlab/app/services/protected_branches/cache_service.rb',11)],
'J022':[('sources/gems/stringio-3.2.0/ext/stringio/stringio.c',221)],
'J024':[('sources/gems/zlib-3.2.3/ext/zlib/zlib.c',4089)]}
for k in ['J008','J012','J019','J020','J023']:
 prefix='sources/gitlab/' if k in ['J008','J012','J019'] else 'sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/'
 n=87 if prefix=='sources/gitlab/' else 81
 extra[k]=[(prefix+'lib/gitlab/event_store/event.rb',n),('sources/expansion/json_schemer-2.4.0--davishmcclurg/lib/json_schemer.rb',252)]
out=[]
for r in rs:
 aid=r['audit_id'];status,reason,_=notes[aid];hs=[]
 for h in r['ruby_hops']+r['native_hops']:
  evidence=[ev(h['file'],h['line'])];m=methods.get(h.get('target_id'))
  if m:evidence.append(ev(m['file'],m['line']))
  if h.get('target_file') and h.get('target_line'):evidence.append(ev(h['target_file'],h['target_line']))
  hs.append(dict(hop_id=h['hop_id'],kind=h.get('kind',h.get('type')),verdict='source_relation_present_context_conditioned',evidence=evidence,reason='Actual local source expression/target inspected; whole-chain selected-branch judgment recorded separately, not implied by local presence.'))
 proof=[ev(f,n) for f,n in extra.get(aid,[])]
 out.append(dict(audit_id=aid,path_id=r['path']['path_id'],profile=r['profile'],status=status,reason=reason,hops=hs,decisive_evidence=proof,runtime_feasibility='unknown',authorization='unknown',attacker_data_control='unknown',review_scope='Independent actual source review before inspecting iteration2 results; local links plus selected-branch feasibility. Source relation presence alone is not chain proof.',source_dossier=str(D/(aid+'_dossier.txt'))))
(D/'baseline_reviews.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in out));(D/'baseline_review_summary.json').write_text(json.dumps(dict(counts=dict(collections.Counter(x['status'] for x in out)),paths=len(out),hops=sum(len(x['hops']) for x in out)),indent=2))
(D/'reviewed_source_manifest.json').write_text(json.dumps([dict(file=f,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)) for f,data in sorted(cache.items())],indent=2))
files=[D/n for n in ['path_sample.jsonl','unique_edge_sample.jsonl','baseline_reviews.jsonl','baseline_review_summary.json','reviewed_source_manifest.json']]
(D/'baseline_judgments_freeze.json').write_text(json.dumps(dict(description='Manual baseline path judgments frozen before reading iteration2 results',files=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)for p in files]),indent=2))
print((D/'baseline_review_summary.json').read_text())
