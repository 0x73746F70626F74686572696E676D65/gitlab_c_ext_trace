#!/usr/bin/env python3
"""Bounded source-only Ruby literal/hash transformer evaluator. Never executes Ruby.
Unknown dispatch/branches return unknown; this is not a general Ruby interpreter.
"""
import sys,json,copy,pathlib,ast
sys.path.insert(0,'/workspace/gitlab_c_ext_trace/tooling_ruby')
from tree_sitter import Parser,Language
import tree_sitter_ruby
P=Parser(Language(tree_sitter_ruby.language()))
def unknown():return {'kind':'unknown'}
def value(kind,literal=None):
 r={'kind':kind}
 if literal is not None:r['literal']=literal
 return r
class Source:
 def __init__(self,data,file='<fixture>'):
  self.data=data.encode() if isinstance(data,str) else data;self.file=file;self.tree=P.parse(self.data);self.methods={};self.evidence=[]
  self.method_context={};self.context_stack=[];self.active_methods=[]
  def visit(n,owner=(),kind='instance',conditional=False):
   if n.type in ('class','module'):
    name=self.text(n.child_by_field_name('name'));owner=tuple(name.lstrip(':').split('::')) if '::' in name else owner+(name,)
    kind='instance'
   if n.type=='singleton_class':
    if self.text(n.child_by_field_name('value'))!='self':conditional=True
    kind='singleton'
   if n.type in ('method','singleton_method'):
    name=self.text(n.child_by_field_name('name'));mk=kind
    if n.type=='singleton_method':
     if self.text(n.child_by_field_name('object'))!='self':conditional=True
     mk='singleton'
    self.methods.setdefault(name,[]).append(n)
    self.method_context[n.start_byte]=(owner,mk,conditional)
    return
   if n.type in ('if','unless','case','if_modifier','unless_modifier','block','do_block','while','until'):conditional=True
   for c in n.named_children:visit(c,owner,kind,conditional)
  visit(self.tree.root_node)
 def invalidate(self,objects):
  seen=set()
  def walk(obj):
   if id(obj) in seen:return
   seen.add(id(obj))
   if obj.get('kind') in ('Hash','Array','String'):
    vals=obj.get('items',{})
    for child in (vals.values() if isinstance(vals,dict) else vals):walk(child)
    obj.clear();obj.update(unknown())
  for obj in objects:walk(obj)
 def eval_method(self,method,args,keywords=None,depth=0):
  if method.start_byte in self.active_methods or len(self.active_methods)>=4:
   self.invalidate(args);return unknown()
  owner,kind,conditional=self.method_context[method.start_byte]
  if conditional:self.invalidate(args);return unknown()
  self.context_stack.append((owner,kind));self.active_methods.append(method.start_byte)
  try:return self.eval(self.field(method,'body'),self.bind(method,args,keywords),depth+1)
  finally:self.active_methods.pop();self.context_stack.pop()
 def text(self,n):return self.data[n.start_byte:n.end_byte].decode() if n else ''
 def field(self,n,k):return n.child_by_field_name(k) if n else None
 def note(self,n,rule):self.evidence.append({'file':self.file,'line':n.start_point.row+1,'byte_offset':n.start_byte,'rule':rule,'context':self.text(n)[:400]})
 def bind(self,method,args,keywords=None):
  env={};ps=self.field(method,'parameters');i=0;keywords=keywords or {};used=set()
  for p in ps.named_children if ps else []:
   name=self.text(self.field(p,'name')) or self.text(p)
   if p.type=='identifier':env[name]=args[i] if i<len(args) else unknown();i+=1
   elif p.type=='optional_parameter':env[name]=args[i] if i<len(args) else self.eval(self.field(p,'value'),env);i+=1
   elif p.type=='keyword_parameter':env[name]=keywords.get(name,self.eval(self.field(p,'value'),env));used.add(name)
   elif p.type=='hash_splat_parameter':env[name.lstrip('*')]={'kind':'Hash','items':{k:v for k,v in keywords.items() if k not in used},'closed':False}
   elif p.type=='splat_parameter':env[name.lstrip('*')]={'kind':'Array','items':args[i:],'closed':True};i=len(args)
   else:env[name]=unknown()
  return env
 def eval(self,n,env,depth=0):
  if n is None or depth>32:return unknown()
  t=n.type;tx=self.text(n)
  if t in ('identifier','instance_variable'):
   if t=='identifier' and tx not in env:
    self.invalidate(list(env.values()));self.note(n,'unbound_identifier_possible_implicit_dispatch')
   return env.get(tx,unknown())
  if t=='nil':return value('Nil')
  if t in ('true','false'):return value('Boolean',t=='true')
  if t=='integer':
   try:return value('Integer',int(tx.replace('_',''),0) if tx.startswith(('0x','0b','0o')) else int(tx.replace('_','')))
   except ValueError:return unknown()
  if t in ('simple_symbol','hash_key_symbol'):return value('Symbol',tx.lstrip(':'))
  if t=='string':
   if any(c.type=='interpolation' for c in n.named_children):
    self.invalidate(list(env.values()));self.note(n,'interpolation_effects_unresolved');return value('String')
   try:return value('String',ast.literal_eval(tx))
   except (ValueError,SyntaxError):return value('String')
  if t=='hash':
   out={'kind':'Hash','items':{},'closed':True}
   for p in n.named_children:
    if p.type!='pair':out['closed']=False;out['items'].clear();continue
    k=self.eval(self.field(p,'key'),env,depth+1);v=self.eval(self.field(p,'value'),env,depth+1)
    if k.get('kind') in ('Symbol','String') and 'literal' in k:out['items'][(k['literal'] if k['kind']=='Symbol' else '\0str:'+k['literal'])]=v
    else:out['closed']=False
   return out
  if t=='array':return {'kind':'Array','items':[self.eval(c,env,depth+1) for c in n.named_children],'closed':True}
  if t=='element_reference':
   obj=self.eval(self.field(n,'object'),env,depth+1);args=[c for c in n.named_children if c!=self.field(n,'object')];k=self.eval(args[0],env,depth+1) if len(args)==1 else unknown()
   if obj['kind']=='Hash' and 'literal'in k:return obj.get('items',{}).get(k['literal'] if k['kind']=='Symbol' else '\0str:'+k['literal'],value('Nil') if obj.get('closed') else unknown())
   return unknown()
  if t in ('method','singleton_method','class','module','singleton_class'):return unknown()
  if t in ('body_statement','then','else','program','parenthesized_statements'):
   result=value('Nil')
   for c in n.named_children:
    if c.type=='comment':continue
    if c.type in ('return','break','next','redo','retry'):
     self.invalidate(list(env.values()));self.note(c,'unsupported_early_control_transfer');return unknown()
    result=self.eval(c,env,depth+1)
   return result
  if t=='assignment':
   left=self.field(n,'left');v=self.eval(self.field(n,'right'),env,depth+1)
   if left.type in ('identifier','instance_variable'):env[self.text(left)]=v;self.note(n,'source_assignment')
   elif left.type=='element_reference':
    obj=self.eval(self.field(left,'object'),env,depth+1);ks=[c for c in left.named_children if c!=self.field(left,'object')];k=self.eval(ks[0],env,depth+1) if len(ks)==1 else unknown()
    if obj['kind']=='Hash' and k.get('kind') in ('Symbol','String') and 'literal'in k:obj.setdefault('items',{})[k['literal'] if k['kind']=='Symbol' else '\0str:'+k['literal']]=v;self.note(n,'source_hash_element_assignment')
    else:self.invalidate([obj])
   else:
    self.invalidate(list(env.values()))
    def clear_names(q):
     if q.type in ('identifier','instance_variable'):env[self.text(q)]=unknown()
     for c in q.named_children:clear_names(c)
    clear_names(left)
   return v
  if t=='operator_assignment':
   left=self.field(n,'left');a=self.eval(left,env,depth+1);right=self.field(n,'right');op=self.text(self.field(n,'operator'))
   if op=='||=' and a['kind'] not in ('unknown','Nil') and not(a['kind']=='Boolean' and a.get('literal') is False):return a
   if op=='||=' and a['kind']=='Nil':v=self.eval(right,env,depth+1)
   else:v=unknown()
   if left.type=='identifier':env[self.text(left)]=v
   return v
  if t=='binary':
   a=self.eval(self.field(n,'left'),env,depth+1);b=self.eval(self.field(n,'right'),env,depth+1);op=self.text(self.field(n,'operator'))
   if op=='||':
    if a['kind']=='Nil' or (a['kind']=='Boolean' and a.get('literal') is False):return b
    if a['kind']!='unknown':return a
   return unknown()
  if t=='call':
   recv=self.field(n,'receiver');name=self.text(self.field(n,'method'));an=self.field(n,'arguments')
   # Ruby evaluates receiver before arguments. Preserve aliases for invalidation.
   receiver=self.eval(recv,env,depth+1) if recv is not None else None
   args=[self.eval(a,env,depth+1) for a in an.named_children] if an else []
   current=self.context_stack[-1] if self.context_stack else ((),'instance')
   candidates=[] if getattr(self,'summary_resolver',None) is not None else [m for m in self.methods.get(name,[]) if self.method_context[m.start_byte]==(*current,False)]
   if (recv is None or self.text(recv)=='self') and len(candidates)==1 and self.field(n,'block') is None:
    self.note(n,'source_method_same_lexical_owner_kind_conditional_normal_dispatch')
    return self.eval_method(candidates[0],args,depth=depth)
   if name=='to_s' and not args and recv is not None and receiver['kind'] in ('String','Integer','Symbol','Nil','Boolean'):
    self.note(n,'standard_builtin_to_s_normal_return');return value('String')
   self.invalidate(args+([receiver] if receiver is not None else []))
   if recv is None or self.text(recv)=='self':self.invalidate(list(env.values()))
   self.note(n,'unknown_call_invalidates_mutable_arguments_receiver_and_aliases')
   return unknown()
  # Unsupported branches cannot mutate known values and be treated as definite.
  if t in ('if','unless','case','if_modifier','unless_modifier','while','until','begin','rescue','ensure','for'):
   assigned=[]
   def invalidate(x):
    if x.type in ('assignment','operator_assignment'):
     lhs=self.field(x,'left')
     if lhs and lhs.type=='identifier':assigned.append(self.text(lhs))
     elif lhs and lhs.type=='element_reference':
      obj=self.field(lhs,'object')
      if obj and obj.type=='identifier':assigned.append(self.text(obj))
    for c in x.named_children:invalidate(c)
   invalidate(n)
   self.invalidate(list(env.values()))
   for name in assigned:env[name]=unknown()
   self.note(n,'unsupported_control_flow_invalidates_assignments');return unknown()
  # Unsupported expression may contain arbitrary calls or writes; do not leave
  # mutable aliases looking constant after skipped effects.
  def effects(q):
   return q.type in ('call','assignment','operator_assignment') or any(effects(c) for c in q.named_children)
  if effects(n):self.invalidate(list(env.values()));self.note(n,'unsupported_expression_effects_invalidate_mutables')
  return unknown()
 def env_before(self,method,byte,args=None,keywords=None):
  env=self.bind(method,args or [],keywords);body=self.field(method,'body');owner,kind,_=self.method_context[method.start_byte]
  self.context_stack.append((owner,kind))
  for n in body.named_children if body else []:
   if n.end_byte<=byte:self.eval(n,env)
   elif n.start_byte<=byte<n.end_byte:
    # Don't infer facts from arbitrary selected branches or deferred blocks.
    if n.type not in ('call','assignment'):
     self.invalidate(list(env.values()));self.note(n,'target_inside_unsupported_control_context')
    break
  self.context_stack.pop()
  return env

class FlowReturn(Exception):
 def __init__(self,result):self.result=result

def truth(v):
 if v.get('kind')=='unknown':return None
 if v.get('kind')=='Nil':return False
 if v.get('kind')=='Boolean':return v.get('literal')
 return True

def join_values(a,b):return copy.deepcopy(a) if a==b else unknown()

class FlowSource(Source):
 def __init__(self,data,file='<fixture>'):
  super().__init__(data,file);self.summary_resolver=None;self.flow_notes=[]
 def eval_method(self,method,args,keywords=None,depth=0):
  if method.start_byte in self.active_methods or len(self.active_methods)>=4:
   self.invalidate(args);return unknown()
  owner,kind,conditional=self.method_context[method.start_byte]
  if conditional:self.invalidate(args);return unknown()
  env,issues=self.bind_explicit(method,dict(positional=args,keywords=keywords or {},unresolved=[]))
  if issues:self.invalidate(args);return unknown()
  self.context_stack.append((owner,kind));self.active_methods.append(method.start_byte)
  try:
   try:return self.eval(self.field(method,'body'),env,depth+1)
   except FlowReturn as ret:return ret.result
  finally:self.active_methods.pop();self.context_stack.pop()
 def bind_explicit(self,method,pack=None):
  params=self.field(method,'parameters');ps=list(params.named_children) if params else []
  names=[self.text(self.field(p,'name')) or self.text(p) for p in ps]
  blank={name:unknown() for name in names};issues=[]
  if pack is None:return blank,['incoming_arguments_unknown']
  if pack.get('unresolved') or any(p.type in ('splat_parameter','hash_splat_parameter','forward_parameter','destructured_parameter') for p in ps):return blank,['splat_forwarding_or_parameter_shape_unresolved']
  args=pack['positional'];keywords=pack['keywords'];env={};i=0;used=set();optional=False
  for p,name in zip(ps,names):
   if p.type=='identifier':
    if optional:return blank,['trailing_required_parameter_unresolved']
    if i>=len(args):return blank,['missing_required_positional_argument']
    env[name]=args[i];i+=1
   elif p.type=='optional_parameter':
    optional=True;env[name]=args[i] if i<len(args) else self.eval(self.field(p,'value'),env);i+=1
   elif p.type=='keyword_parameter':
    used.add(name)
    if name in keywords:env[name]=keywords[name]
    elif self.field(p,'value') is not None:env[name]=self.eval(self.field(p,'value'),env)
    else:return blank,['missing_required_keyword']
   elif p.type=='block_parameter':env[name]=unknown()
   else:return blank,['unsupported_parameter_node:'+p.type]
  if len(args)>i or set(keywords)-used:return blank,['arity_or_unknown_keywords']
  return copy.deepcopy(env),issues
 def argument_pack(self,call,env):
  an=self.field(call,'arguments');pos=[];kw={};bad=[]
  for n in an.named_children if an else []:
   if n.type=='block_argument':
    self.invalidate(list(env.values()));continue
   if n.type in ('splat_argument','hash_splat_argument','forward_argument'):bad.append(n.type);self.invalidate(list(env.values()));continue
   if n.type=='pair':
    key=self.eval(self.field(n,'key'),env)
    if key.get('kind')!='Symbol' or 'literal' not in key:bad.append('dynamic_keyword');continue
    kw[key['literal']]=self.eval(self.field(n,'value'),env)
   else:pos.append(self.eval(n,env))
  return copy.deepcopy(dict(positional=pos,keywords=kw,unresolved=bad))
 def invalidate_writes(self,node,env):
  if node is None:return
  pending=[node]
  while pending:
   q=pending.pop()
   if q.type in ('assignment','operator_assignment'):
    left=self.field(q,'left')
    if left and left.type in ('identifier','instance_variable'):env[self.text(left)]=unknown()
    elif left and left.type=='element_reference':
     obj=self.field(left,'object')
     if obj and self.text(obj) in env:self.invalidate([env[self.text(obj)]])
   pending.extend(q.named_children)
 def eval(self,n,env,depth=0):
  if n is None:return value('Nil')
  if depth>32:return unknown()
  t=n.type
  if t=='string':
   tx=self.text(n)
   if any(c.type=='interpolation' for c in n.named_children):
    self.invalidate(list(env.values()));return value('String')
   return value('String',tx[1:-1]) if len(tx)>=2 and tx[0] in ('\"', "'") and '\\' not in tx else value('String')
  if t=='integer' and len(self.text(n).replace('_',''))>1 and self.text(n).replace('_','').startswith('0') and self.text(n).replace('_','').isdigit():return value('Integer')
  if t=='return':
   args=list(n.named_children);arg=args[0] if args else None
   if arg and arg.type=='argument_list':arg=arg.named_children[0] if len(arg.named_children)==1 else None
   raise FlowReturn(self.eval(arg,env,depth+1) if arg else value('Nil'))
  if t in ('body_statement','then','else','program','parenthesized_statements'):
   result=value('Nil')
   for c in n.named_children:
    if c.type!='comment':result=self.eval(c,env,depth+1)
   return result
  if t=='unary':
   op=self.text(self.field(n,'operator'));operand=self.field(n,'operand') or (n.named_children[-1] if n.named_children else None);v=truth(self.eval(operand,env,depth+1))
   return value('Boolean',not v) if op in ('!','not') and v is not None else unknown()
  if t=='binary':
   op=self.text(self.field(n,'operator'));left=self.eval(self.field(n,'left'),env,depth+1)
   if op in ('&&','and','||','or'):
    tr=truth(left)
    if op in ('&&','and') and tr is False or op in ('||','or') and tr is True:return left
    if tr is not None:return self.eval(self.field(n,'right'),env,depth+1)
    self.invalidate(list(env.values()));self.invalidate_writes(self.field(n,'right'),env);return unknown()
   right=self.eval(self.field(n,'right'),env,depth+1)
   if op in ('==','!=') and left['kind']!='unknown' and right['kind']!='unknown':
    if left['kind']!=right['kind']:eq=False
    elif left['kind']=='Nil':eq=True
    elif 'literal'in left and 'literal'in right:eq=left['literal']==right['literal']
    else:return unknown()
    return value('Boolean',eq if op=='==' else not eq)
   return unknown()
  if t in ('if','elsif','unless','if_modifier','unless_modifier'):
   cond=truth(self.eval(self.field(n,'condition'),env,depth+1));flip=t.startswith('unless')
   body=self.field(n,'consequence') or self.field(n,'body');alt=self.field(n,'alternative')
   if cond is not None:return self.eval(body if cond!=flip else alt,env,depth+1)
   states=[];results=[];returns=[]
   for branch in (body,alt):
    e=copy.deepcopy(env)
    try:r=self.eval(branch,e,depth+1);states.append(e);results.append(r)
    except FlowReturn as ret:returns.append(ret.result)
   if not states:raise FlowReturn(join_values(*returns) if len(returns)==2 else unknown())
   env.clear()
   for name in set.union(*(set(e) for e in states)):env[name]=copy.deepcopy(states[0].get(name,unknown())) if all(e.get(name,unknown())==states[0].get(name,unknown()) for e in states) else unknown()
   return results[0] if len(results)==1 else join_values(*results)
  if t=='call':
   recv=self.field(n,'receiver');name=self.text(self.field(n,'method'));args=self.field(n,'arguments')
   if name in ('eval','binding','local_variable_set','instance_eval','instance_exec','class_eval','module_eval','class_exec','module_exec'):
    for var in env:env[var]=unknown()
   if self.field(n,'block') is not None:
    self.invalidate(list(env.values()));self.invalidate_writes(self.field(n,'block'),env)
   if recv is not None and name in ('nil?','is_a?','kind_of?','instance_of?'):
    obj=self.eval(recv,env,depth+1)
    if name=='nil?' and args is None:return value('Boolean',obj['kind']=='Nil') if obj['kind']!='unknown' else unknown()
    if args and len(args.named_children)==1:
     typename=self.text(args.named_children[0]).lstrip(':')
     if typename in ('Hash','String','Array','Symbol','Integer','NilClass','TrueClass','FalseClass') and obj['kind']!='unknown':
      actual='NilClass' if obj['kind']=='Nil' else 'TrueClass' if obj.get('literal') is True else 'FalseClass' if obj.get('literal') is False else obj['kind']
      return value('Boolean',actual==typename)
   if self.summary_resolver is not None:
    resolved=self.summary_resolver(self,n,env,depth)
    if resolved is not None:return resolved
  if t not in ('identifier','instance_variable','nil','true','false','integer','simple_symbol','hash_key_symbol','hash','array','element_reference','assignment','operator_assignment','call','method','singleton_method','class','module','singleton_class'):
   self.invalidate_writes(n,env)
  return super().eval(n,env,depth)
 def case_match(self,known,pattern,env):
  patterns=pattern.named_children if pattern and pattern.type=='pattern' else [pattern]
  results=[]
  for n in patterns:
   if n is None:continue
   if n.type=='constant' and self.text(n) in ('Hash','String','Array','Symbol','Integer','NilClass','TrueClass','FalseClass'):
    if known['kind']=='unknown':results.append(None)
    else:
     actual='NilClass' if known['kind']=='Nil' else 'TrueClass' if known.get('literal') is True else 'FalseClass' if known.get('literal') is False else known['kind'];results.append(actual==self.text(n))
   else:
    v=self.eval(n,env)
    if known['kind']=='unknown' or v['kind']=='unknown':results.append(None)
    elif known['kind']!=v['kind']:results.append(False)
    elif known['kind']=='Nil':results.append(True)
    elif 'literal' in known and 'literal'in v:results.append(known['literal']==v['literal'])
    else:results.append(None)
  return True if True in results else None if None in results else False
 def env_at(self,method,call,initial):
  env=copy.deepcopy(initial);guards=[];target=call.start_byte;unsupported=[]
  def contains(n):return n is not None and n.start_byte<=target<n.end_byte
  def walk(n):
   if n is None:return
   if n==call:return
   if n.type in ('body_statement','then','else','program','parenthesized_statements'):
    for child in n.named_children:
     if contains(child):walk(child);return
     if child.end_byte<=target:self.eval(child,env)
    return
   if n.type in ('if','elsif','unless','if_modifier','unless_modifier'):
    cond=self.field(n,'condition');body=self.field(n,'consequence') or self.field(n,'body');alt=self.field(n,'alternative')
    if contains(cond):walk(cond);return
    known=self.eval(cond,env);tr=truth(known);take_body=contains(body);expected=not n.type.startswith('unless') if take_body else n.type.startswith('unless')
    guards.append(dict(file=self.file,line=n.start_point.row+1,expression=self.text(cond),known_value=copy.deepcopy(known),required_truth=expected,compatible=None if tr is None else tr==expected,construct=n.type))
    if tr is not None and tr!=expected:raise FlowReturn({'kind':'incompatible_guard'})
    walk(body if take_body else alt);return
   if n.type=='case':
    subject=self.field(n,'value')
    if contains(subject):walk(subject);return
    known=self.eval(subject,env);prior_true=False;prior_unknown=False
    for branch in n.named_children:
     if branch.type not in ('when','else'):continue
     matches=[self.case_match(known,p,env) for p in branch.named_children if p.type=='pattern'] if branch.type=='when' else []
     matched=(True if True in matches else None if None in matches else False) if branch.type=='when' else (False if prior_true else None if prior_unknown else True)
     if contains(branch):
      compatible=False if prior_true or matched is False else None if prior_unknown or matched is None else True
      guards.append(dict(file=self.file,line=branch.start_point.row+1,expression=self.text(self.field(branch,'pattern')) if branch.type=='when' else 'else',subject=self.text(subject),known_value=copy.deepcopy(known),compatible=compatible,construct='case_'+branch.type))
      if compatible is False:raise FlowReturn({'kind':'incompatible_guard'})
      walk(self.field(branch,'body') if branch.type=='when' else branch);return
     prior_true|=matched is True;prior_unknown|=matched is None
    return
   if n.type in ('block','do_block'):
    unsupported.append('block_invocation_conditional')
    self.invalidate(list(env.values()))
    params=self.field(n,'parameters')
    pending=[params] if params else []
    pending+=list(n.named_children)
    writes=set()
    while pending:
     q=pending.pop()
     if q.type in ('assignment','operator_assignment'):
      lhs=self.field(q,'left')
      if lhs and lhs.type=='identifier':writes.add(self.text(lhs))
     if params and params.start_byte<=q.start_byte<params.end_byte and q.type=='identifier':writes.add(self.text(q))
     pending.extend(q.named_children)
    for name in writes:env[name]=unknown()
   elif n.type in ('lambda','rescue','ensure','while','until','for'):
    unsupported.append(n.type)
    for name in env:env[name]=unknown()
   for child in n.named_children:
    if contains(child):walk(child);return
    if child.end_byte<=target and child.type not in ('identifier','constant','scope_resolution','method_parameters'):self.eval(child,env)
  self.context_stack.append(self.method_context[method.start_byte][:2])
  try:
   walk(self.field(method,'body'));return dict(env=env,guards=guards,unreachable=False,unsupported=unsupported)
  except FlowReturn as ret:return dict(env=env,guards=guards,unreachable=True,reason='guard_contradiction' if ret.result.get('kind')=='incompatible_guard' else 'unconditional_earlier_return',unsupported=unsupported)
  finally:self.context_stack.pop()
