import json,hashlib
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_v3');D=R/'audit/holdout3_20260930';B=Path('/workspace/gitlab_c_ext_trace')
def rows(p):return [json.loads(l)for l in p.open()]
errors=[];checks=0
for x in json.loads((D/'baseline_judgments_freeze.json').read_text())['files']:
 checks+=1
 if hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()!=x['sha256']:errors.append(x['path'])
s={x['path']['path_id']:x for x in rows(D/'path_sample.jsonl')};prior={x['path']['path_id']for d in [B/'audit/end_to_end_20260930',R/'audit/holdout_20260930',R/'audit/holdout2_20260930']for x in rows(d/'path_sample.jsonl')}
assert len(s)==20 and not set(s)&prior
for r in rows(D/'baseline_reviews.jsonl'):
 expected=[h['hop_id']for h in s[r['path_id']]['ruby_hops']+s[r['path_id']]['native_hops']];checks+=1
 if [h['hop_id']for h in r['hops']]!=expected:errors.append(r['audit_id'])
 for e in [e for h in r['hops']for e in h['evidence']]+r['decisive_evidence']:
  checks+=1
  if (B/e['file']).read_text(errors='replace').split('\n')[e['line']-1]!=e['context']:errors.append(e)
errata=json.loads((R/'reports/ee_lookup_scope_errata_iteration2.json').read_text());ids=set(errata['edge_ids']);T=Path('/workspace/gitlab_c_ext_ee_profile/tables');rh={h['hop_id']:h for h in rows(T/'frontend_ruby_hops.jsonl')};pr={x['prefix_id']:x for x in rows(T/'frontend_ruby_prefixes.jsonl')};affected=[]
for p in rows(T/'frontend_paths.jsonl'):
 if any(rh[h].get('edge_id')in ids for h in pr[p['ruby_prefix_id']]['hops']):affected.append(p['path_id'])
report=dict(status='PASS' if not errors and not affected else 'FAIL',checks=checks,errors=errors,paths=20,training144_path_overlap=0,ee_scope_correction_count=len(ids),ee_existing_frontend_paths_affected=len(affected),affected_paths=affected,semantic_scope='Manual source judgments; integrity checks alone not semantics proof.')
(D/'holdout_validation.json').write_text(json.dumps(report,indent=2));print(report)
