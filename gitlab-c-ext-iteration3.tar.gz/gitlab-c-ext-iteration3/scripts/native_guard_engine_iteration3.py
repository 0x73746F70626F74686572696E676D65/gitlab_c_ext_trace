"""Conservative static guard evaluation. No target code execution.
Known facts describe direct call syntax and local scalar propagation only.
An unknown predicate is never treated as true/false. Syntactic branch exclusion
is stronger than the historical call-graph label but not a runtime proof.
"""
import sys,re,hashlib
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_trace')
sys.path.insert(0,str(R/'.python'))
from tree_sitter import Parser,Language
import tree_sitter_c,tree_sitter_cpp
CP={'c':Parser(Language(tree_sitter_c.language())),'cpp':Parser(Language(tree_sitter_cpp.language()))}
# Ruby grammar shares ABI; pinned 0.25.2 parser package.
sys.path.insert(0,str(R/'tooling_ruby'))
import tree_sitter_ruby
RP=Parser(Language(tree_sitter_ruby.language()))
def walk(n):
 yield n
 for c in n.named_children:yield from walk(c)
def tx(b,n):return b[n.start_byte:n.end_byte].decode(errors='replace')if n else ''
def val(k,v):return (k,v)
def truth(v):
 if v is None:return None
 if v[0]=='int':return bool(v[1])
 if v[0]=='bool':return v[1]
 return None
def integer(v):return v[1]if v and v[0]in('int','bool')else None
def argv_view(values, offset=0):
 return val('argv_view', {'values':values,'offset':offset})
def view_item(v,index=0):
 if not v or v[0]!='argv_view' or not isinstance(index,int):return None
 i=v[1]['offset']+index;xs=v[1]['values']
 return tuple(xs[i]) if 0<=i<len(xs) and xs[i] is not None else None
def shift_view(v,amount):
 if not v or v[0]!='argv_view' or not isinstance(amount,int):return None
 i=v[1]['offset']+amount
 return argv_view(v[1]['values'],i) if 0<=i<=len(v[1]['values']) else None
def eval_c(n,b,env):
 if n is None:return None
 t=n.type;s=tx(b,n)
 if t=='parenthesized_expression':return eval_c(n.named_children[0],b,env)if n.named_children else None
 if t=='number_literal':
  try:return val('int',int(re.sub(r'[uUlL]+$','',s),0))
  except:return None
 if t=='subscript_expression':
  v=eval_c(n.child_by_field_name('argument'),b,env);i=integer(eval_c(n.child_by_field_name('index'),b,env))
  if v and v[0]=='argv_view':return view_item(v,i)
 if t=='pointer_expression':
  if tx(b,n.child_by_field_name('operator'))=='*':return view_item(eval_c(n.child_by_field_name('argument'),b,env))
  return None
 if t in ('identifier','field_expression','subscript_expression'):
  if s in env:return env[s]
  if s in ('true','false'):return val('bool',s=='true')
  if s in ('NULL','nullptr'):return val('int',0)
  if s in ('Qnil','Qtrue','Qfalse','Qundef'):return val('ruby_const',s)
  if re.fullmatch(r'T_[A-Z]+',s):return val('enum',s)
  return None
 if t=='assignment_expression':return eval_c(n.child_by_field_name('right'),b,env)
 if t=='cast_expression':
  v=eval_c(n.child_by_field_name('value'),b,env)
  if v and v[0]=='argv_view' and not re.fullmatch(r'(?:const\s+)?VALUE\s*\*',tx(b,n.child_by_field_name('type')).strip()):return None
  return v
 if t=='unary_expression':
  v=eval_c(n.child_by_field_name('argument'),b,env);op=tx(b,n.child_by_field_name('operator'))
  if op=='!':return val('bool',not truth(v))if truth(v)is not None else None
  if op=='-' and integer(v)is not None:return val('int',-integer(v))
  return None
 if t=='binary_expression':
  a=eval_c(n.child_by_field_name('left'),b,env);z=eval_c(n.child_by_field_name('right'),b,env);op=tx(b,n.child_by_field_name('operator'))
  if op=='&&':
   if truth(a)is False or truth(z)is False:return val('bool',False)
   if truth(a)is True and truth(z)is True:return val('bool',True)
   return None
  if op=='||':
   if truth(a)is True or truth(z)is True:return val('bool',True)
   if truth(a)is False and truth(z)is False:return val('bool',False)
   return None
  if a is None or z is None:return None
  if op=='+' and a[0]=='argv_view':return shift_view(a,integer(z))
  if op=='+' and z[0]=='argv_view':return shift_view(z,integer(a))
  if op=='-' and a[0]=='argv_view':return shift_view(a,-integer(z)) if integer(z)is not None else None
  if a[0]=='argv_view' or z[0]=='argv_view':return None
  if op in ('==','!=') and (a[0]==z[0] and a[0]not in ('ruby_hash','ruby_type') or ('ruby_const' in (a[0],z[0]) and set((a[0],z[0]))<={'ruby_const','ruby_symbol','ruby_hash','ruby_type','ruby_integer'})):return val('bool',(a==z)if op=='=='else(a!=z))
  aa,zz=integer(a),integer(z)
  if aa is not None and zz is not None:
   if op in ('==','!=','<','>','<=','>='):return val('bool',{'==':aa==zz,'!=':aa!=zz,'<':aa<zz,'>':aa>zz,'<=':aa<=zz,'>=':aa>=zz}[op])
   if op=='+':return val('int',aa+zz)
   if op=='-':return val('int',aa-zz)
  return None
 if t=='call_expression':
  name=tx(b,n.child_by_field_name('function'));an=n.child_by_field_name('arguments');args=an.named_children if an else[]
  if name=='rb_block_given_p':return env.get('$block')
  if name in ('rb_hash_lookup','rb_hash_aref')and len(args)==2:
   obj=eval_c(args[0],b,env);key=eval_c(args[1],b,env)
   if obj and obj[0]=='ruby_hash'and key and key[0]=='ruby_symbol':
    v=obj[1].get(key[1]);return tuple(v)if v is not None else None
  if name in ('rb_type','TYPE')and len(args)==1:
   a=eval_c(args[0],b,env)
   if a and a[0]=='ruby_type':return val('enum','T_'+a[1].upper())
   if a and a[0]=='ruby_hash':return val('enum','T_HASH')
  if name in ('RB_TYPE_P','RB_TYPE_P_RAW')and len(args)==2:
   a,z=[eval_c(x,b,env)for x in args]
   if a and z and a[0]=='ruby_type'and z[0]=='enum':return val('bool','T_'+a[1].upper()==z[1])
  if name=='NIL_P'and len(args)==1:
   a=eval_c(args[0],b,env)
   if a and a[0]=='ruby_const':return val('bool',a[1]=='Qnil')
   if a and a[0]in('ruby_type','ruby_hash','ruby_symbol','ruby_integer'):return val('bool',False)
  if name=='rb_scan_args'and len(args)>=3:
   count=eval_c(args[0],b,env);fmt=tx(b,args[2]).strip('"');kw=env.get('$keyword_count')
   if count and ':'not in fmt:return count
   if count and kw is not None:return val('int',integer(count)-integer(kw))
  return None
 return None

def branch_guards(node,func,b):
 """Exact enclosing if arms only; unknown switch/loop conditions are retained."""
 out=[];child=node;p=node.parent
 while p and p!=func:
  if p.type=='if_statement':
   cond=p.child_by_field_name('condition');con=p.child_by_field_name('consequence');alt=p.child_by_field_name('alternative');positive=con is not None and con.start_byte<=node.start_byte<con.end_byte
   if cond and ((con is not None and con.start_byte<=node.start_byte<con.end_byte) or (alt is not None and alt.start_byte<=node.start_byte<alt.end_byte)):out.append((cond,positive,'if_arm'))
  elif p.type in ('while_statement','for_statement','do_statement'):
   cond=p.child_by_field_name('condition')
   body=p.child_by_field_name('body')
   if cond and p.type!='do_statement'and body is not None and body.start_byte<=node.start_byte<body.end_byte:out.append((cond,True,'loop_body'))
  elif p.type=='case_statement':out.append((p,True,'switch_case'))
  child=p;p=p.parent
 return list(reversed(out))

def direct_locals(func,node,b,env):
 """Apply preceding local assignments only when guard dominance is decidable.
Unknown guarded writes kill tracked values; field writes are not inferred.
Address escape kills scalar facts unless recognized rb_scan_args API.
"""
 env=dict(env);events=[];shadows={}
 # Bounded pointer views are valid only absent earlier unknown writes/escape.
 # Fail closed for any potentially aliasing pointer mutation; no heap model.
 if any(v and v[0]=='argv_view' for v in env.values()):
  unsafe=False
  pointer_names={tx(b,n.child_by_field_name('declarator')) for n in walk(func) if n.type=='pointer_declarator'}
  alias_names={k for k,v in env.items() if v and v[0]=='argv_view'}
  # Syntactic overapproximation of local aliases; never implies pointer equality.
  for _ in range(len(pointer_names)+1):
   for use in walk(func):
    if use.type!='init_declarator':continue
    d=use.child_by_field_name('declarator');r=use.child_by_field_name('value')
    if d and d.type=='pointer_declarator' and r and set(re.findall(r'[A-Za-z_]\w*',tx(b,r))) & alias_names:
     alias_names.add(tx(b,d.child_by_field_name('declarator')))
  def mentions_view(n):return bool(n and set(re.findall(r'[A-Za-z_]\w*',tx(b,n))) & alias_names)
  pure={'rb_type','TYPE','RB_TYPE_P','RB_TYPE_P_RAW','NIL_P','rb_block_given_p','rb_scan_args'}
  for use in walk(func):
   if use.start_byte>=node.start_byte:continue
   if use.type in ('assignment_expression','update_expression'):
    lhs=use.child_by_field_name('left') if use.type=='assignment_expression' else use.child_by_field_name('argument')
    rhs=use.child_by_field_name('right')
    if mentions_view(lhs) or mentions_view(rhs):unsafe=True
   if use.type=='init_declarator':
    d=use.child_by_field_name('declarator');r=use.child_by_field_name('value')
    if mentions_view(r) and r.type=='initializer_list':unsafe=True
   if use.type=='pointer_expression' and tx(b,use).lstrip().startswith('&') and mentions_view(use):unsafe=True
   if use.type=='call_expression' and tx(b,use.child_by_field_name('function')) not in pure:
    args=use.child_by_field_name('arguments')
    # A view element is a Ruby VALUE, not the pointer vector. Passing an
    # element may mutate the Ruby object (unmodeled), but not argv storage.
    if args:
     for arg in args.named_children:
      if mentions_view(arg) and arg.type not in ('subscript_expression',) and not (arg.type=='pointer_expression' and tx(b,arg.child_by_field_name('operator'))=='*'):unsafe=True
  if unsafe:env={k:v for k,v in env.items() if not v or v[0]!='argv_view'}

 def close_scopes(offset):
  for scope,name in sorted(list(shadows),key=lambda x:x[0].end_byte):
   if scope.end_byte<=offset:
    old=shadows.pop((scope,name))
    if old is None:env.pop(name,None)
    else:env[name]=old
 for n in walk(func):
  if n.start_byte>=node.start_byte:continue
  close_scopes(n.start_byte)
  if n.type=='declaration':
   scope=n.parent
   while scope and scope.type!='compound_statement':scope=scope.parent
   if scope:
    for item in n.named_children:
     decl=item.child_by_field_name('declarator')if item.type=='init_declarator'else item
     if decl and decl.type=='pointer_declarator':decl=decl.child_by_field_name('declarator')
     if decl and decl.type=='identifier':
      name=tx(b,decl)
      if (scope,name)not in shadows:shadows[(scope,name)]=env.get(name)
      env.pop(name,None)
   continue
  if n.type=='init_declarator':lhs=n.child_by_field_name('declarator');rhs=n.child_by_field_name('value')
  elif n.type=='assignment_expression':lhs=n.child_by_field_name('left');rhs=n.child_by_field_name('right')
  elif n.type=='update_expression':
   for v in n.named_children:
    if v.type=='identifier':env.pop(tx(b,v),None)
   continue
  else:continue
  if lhs is not None and lhs.type=='pointer_declarator':lhs=lhs.child_by_field_name('declarator')
  if lhs is None or lhs.type!='identifier':continue
  if n.type=='assignment_expression' and tx(b,n.child_by_field_name('operator'))!='=':
   env.pop(tx(b,lhs),None);continue
  # A preceding nested function/lambda is not executed here.
  p=n.parent;deferred=False
  while p and p!=func:
   if p.type in ('lambda_expression','function_definition'):deferred=True
   p=p.parent
  if deferred:continue
  states=[]
  for g,w,k in branch_guards(n,func,b):
   q=guard_truth(g,k,b,env)
   states.append(None if q is None else q==w)
  if False in states:continue
  name=tx(b,lhs);v=eval_c(rhs,b,env)if None not in states else None
  if v is None:env.pop(name,None)
  else:env[name]=v;events.append({'file_line':n.start_point.row+1,'assignment':tx(b,n),'value':v})
 close_scopes(node.start_byte)
 # Loop-carried writes invalidate scalar invariants even when the write occurs
 # lexically after this iteration's sink. For updates are executed after body.
 for loop in walk(func):
  if loop.type not in ('for_statement','while_statement','do_statement')or loop.start_byte>=node.start_byte:continue
  for change in walk(loop):
   lhs=change.child_by_field_name('left')if change.type=='assignment_expression'else change.child_by_field_name('declarator')if change.type=='init_declarator'else next((a for a in change.named_children if a.type=='identifier'),None)if change.type=='update_expression'else None
   if lhs is not None and lhs.type=='identifier':env.pop(tx(b,lhs),None)
 # Address escape through a struct initializer/local pointer is just as real as
 # direct call argument escape. Do not assume a local remains unmodified.
 for use in walk(func):
  if use.start_byte>=node.start_byte:continue
  if use.type=='pointer_expression'and tx(b,use).lstrip().startswith('&'):
   ident=use.child_by_field_name('argument')
   if ident is not None and ident.type=='identifier':env.pop(tx(b,ident),None)
 # Conservatively invalidate variables with address passed into preceding calls.
 for n in walk(func):
  if n.start_byte>=node.start_byte or n.type!='call_expression':continue
  callee=tx(b,n.child_by_field_name('function'))
  args=n.child_by_field_name('arguments')
  if args:
   for a in args.named_children:
    m=re.fullmatch(r'&\s*([A-Za-z_]\w*)',tx(b,a))
    if m:env.pop(m[1],None)
 return env,events

def function_params(func,b):
 d=func.child_by_field_name('declarator')
 if d is None:return[]
 par=next((x for x in walk(d)if x.type=='parameter_list'),None)
 out=[]
 for x in par.named_children if par else[]:
  d=x.child_by_field_name('declarator');ids=[v for v in walk(d)if v.type=='identifier']if d else[]
  out.append(tx(b,ids[-1])if ids else None)
 return out

def ruby_fact(n,b):
 if n.type in ('string','heredoc_body'):return val('ruby_type','string')
 if n.type in ('hash','keyword_hash'):return val('ruby_type','hash')
 if n.type=='array':return val('ruby_type','array')
 if n.type=='nil':return val('ruby_const','Qnil')
 if n.type in ('true','false'):return val('ruby_const','Q'+n.type)
 if n.type=='integer':return val('ruby_integer',None)
 return None

def ruby_native_call_facts(path,hop):
 b=path.read_bytes();tree=RP.parse(b);matches=[]
 for n in walk(tree.root_node):
  if n.type not in ('call','identifier'):continue
  if n.start_point.row+1!=hop['line']:continue
  name=tx(b,n.child_by_field_name('method'))if n.type=='call'else tx(b,n)
  if name!=hop.get('method'):continue
  cid=hashlib.sha256('\0'.join(map(str,[hop['file'],n.start_byte,n.end_byte,'ambiguous'if n.type=='identifier'else'call'])).encode()).hexdigest()[:24]
  if cid==hop['call_id']:matches.append(n)
 if len(matches)!=1:return{'status':'unresolved_ruby_call_anchor','matches':len(matches)}
 n=matches[0];an=n.child_by_field_name('arguments');args=list(an.named_children)if an else[];block=n.child_by_field_name('block');unknown=any(x.type in ('splat_argument','hash_splat_argument','forward_argument')for x in args);pos=[];kw=[];blockpass=[]
 for a in args:
  if a.type=='pair':kw.append(a)
  elif a.type=='block_argument':blockpass.append(a)
  else:pos.append(a)
 vals=[ruby_fact(a,b)for a in pos]
 if kw:vals.append(val('ruby_type','hash'))
 return{'status':'exact_source_call_syntax','file':hop['file'],'line':hop['line'],'call_id':hop['call_id'],'argument_count':None if unknown else len(vals),'argument_values':vals,'keyword_count':None if unknown else int(bool(kw)),'block':None if blockpass else bool(block),'source_expression':tx(b,n),'limitation':'Unknown Ruby variables remain unknown; no arbitrary interprocedural Ruby value inference.'}

def guard_truth(node,kind,b,env):
 if kind!='switch_case':return truth(eval_c(node,b,env))
 block=node.parent;switch=block.parent if block else None
 if switch is None or switch.type!='switch_statement':return None
 value=eval_c(switch.child_by_field_name('condition'),b,env)
 if value is None:return None
 cases=[c for c in block.named_children if c.type=='case_statement'];labels=[];known=True
 for case in cases:
  c=case.child_by_field_name('value');v=eval_c(c,b,env)if c else None
  if c and v is None:known=False
  labels.append(v)
 if not known:return None
 start=next((i for i,v in enumerate(labels)if v==value),None)
 if start is None:start=next((i for i,c in enumerate(cases)if c.child_by_field_name('value')is None),None)
 if start is None:return False
 target=next(i for i,c in enumerate(cases)if c==node)
 if start>target:return False
 for c in cases[start:target]:
  if any(n.type in ('break_statement','return_statement','goto_statement')for n in c.named_children):return False
 return True
