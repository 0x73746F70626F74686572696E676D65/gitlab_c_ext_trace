#!/usr/bin/env python3
"""Apply generic guard compatibility to frozen frontend witnesses, additive v3 overlay."""
import argparse,json,collections,hashlib
from pathlib import Path
from native_guard_engine_iteration3 import *
V=Path('/workspace/gitlab_c_ext_v3');T=R/'tables'
def rows(p):
 with p.open()as f:
  for s in f:yield json.loads(s)
def write(name,rs):
 with (V/'tables'/f'{name}_iteration3.jsonl').open('w')as f:
  for x in rs:f.write(json.dumps(x,separators=(',',':'))+'\n')
def key(*s):return hashlib.sha256('\0'.join(map(str,s)).encode()).hexdigest()[:24]
ap=argparse.ArgumentParser();ap.add_argument('--facts',type=Path);args=ap.parse_args();extra={(x.get('profile'),x.get('ruby_prefix_id'),x['call_id']):x for x in rows(args.facts)}if args.facts else{}
files={x['file_id']:x for x in rows(T/'c_files.jsonl')};regs={x['registration_id']:x for x in rows(T/'c_registrations.jsonl')};tails={x['tail_id']:x for x in rows(T/'frontend_native_tails.jsonl')};hops={x['hop_id']:x for x in rows(T/'frontend_native_hops.jsonl')};sites={x['site_id']:x for x in rows(T/'primitive_sites.jsonl')};pmap={x['primitive_id']:x['site_id']for x in rows(T/'primitive_evidence_sites.jsonl')}
constant_cache={};cache={};function_cache={};fact_cache={};assess_cache={};guard_rows={};decisions=[];counter=collections.Counter()
def parsed(f):
 if f not in cache:
  b=(R/f).read_bytes();lang='cpp'if Path(f).suffix in('.cpp','.cc','.hpp','.hh','.cxx')else'c';cache[f]=(b,CP[lang].parse(b))
 return cache[f]
def constants(f):
 if f in constant_cache:return constant_cache[f]
 sources=[R/f];b=(R/f).read_text(errors='replace')
 for inc in re.findall(r'^\s*#\s*include\s*"([^"/]+)"',b,re.M):
  p=(R/f).parent/inc
  if p.is_file():sources.append(p)
 found={};evidence=[]
 for p in sources:
  text=p.read_text(errors='replace')
  cb=text.encode();ct=CP['c'].parse(cb);global_variables=set()
  for declaration in ct.root_node.named_children:
   if declaration.type!='declaration':continue
   for item in declaration.named_children:
    d=item.child_by_field_name('declarator')if item.type=='init_declarator'else item
    if d is not None and d.type=='identifier':global_variables.add(tx(cb,d))
  for m in re.finditer(r'\b([A-Za-z_]\w*)\s*=\s*ID2SYM\(rb_intern\("([^"\\]+)"\)\)',text):
   name=m[1]
   if name not in global_variables:continue
   found[name]=val('ruby_symbol',m[2]);evidence.append({'file':str(p.relative_to(R)),'line':text[:m.start()].count('\n')+1,'expression':m[0]})
  for block in re.finditer(r'enum(?:\s+\w+)?\s*\{([^}]+)\}',text,re.S):
   for m in re.finditer(r"([A-Za-z_]\w*)\s*=\s*('([^'\\])'|[0-9]+)",block[1]):
    value=ord(m[3])if m[3]else int(m[2]);found[m[1]]=val('int',value);evidence.append({'file':str(p.relative_to(R)),'line':text[:block.start()].count('\n')+1,'expression':m[0]})
 constant_cache[f]=(found,evidence);return found,evidence

def function(f,line,name=None):
 k=(f,line,name)
 if k not in function_cache:
  b,t=parsed(f);xs=[n for n in walk(t.root_node)if n.type=='function_definition'and n.start_point.row+1==line]
  function_cache[k]=xs[0]if len(xs)==1 else None
 return function_cache[k]
def anchor(h,fn,b):
 if fn is None:return None
 if h['kind']=='c_call':
  xs=[n for n in walk(fn)if n.type=='call_expression'and n.start_point.row+1==h['line']and tx(b,n.child_by_field_name('function'))==h['callee']]
  return xs[0]if len(xs)==1 else None
 if h['kind']=='function_to_primitive':
  s=sites[pmap[h['primitive_id']]];off=s['byte_offset'];n=fn.descendant_for_byte_range(off,off+1)
  while n and n!=fn:
   if n.type in('call_expression','array_declarator','new_expression','delete_expression'):return n
   n=n.parent
 return None

def normalize_fact(v):
 if v is None or not isinstance(v,(list,tuple)) or not v or v[0]=='unknown':return None
 k,z=v
 if k=='ruby_hash':return ['ruby_hash',{a:normalize_fact(b)for a,b in z.items()}]
 if k=='ruby_string':return ['ruby_type','string']
 if k=='ruby_integer':return ['ruby_integer',z]
 if k=='ruby_nil':return ['ruby_const','Qnil']
 if k=='ruby_boolean':return ['ruby_const','Qtrue'if z else'Qfalse']
 return list(v)

def merge_facts(base,imported,hop):
 if not imported or imported.get('status')!='conditional_source_facts':return base
 assert imported['source_file']==hop['file'] and imported['source_line']==hop['line']
 assert hashlib.sha256((R/hop['file']).read_bytes()).hexdigest()==imported['source_sha256']
 out=dict(base);out['imported_source_evidence']=imported.get('source_evidence',[]);out['imported_assumptions']=imported.get('assumptions',[])
 if imported.get('arity')is not None:out['argument_count']=imported['arity']
 if imported.get('block_given')is not None:out['block']=imported['block_given']
 source=base.get('argument_values',[]);values=imported.get('argument_values',[]);out['argument_values']=[normalize_fact(v) or (source[i]if i<len(source)else None)for i,v in enumerate(values)]
 return out

def entry_env(reg,fn,b,facts):
 params=function_params(fn,b);env={};env['$block']=val('bool',facts['block'])if facts.get('block')is not None else None
 env['$keyword_count']=val('int',facts['keyword_count'])if facts.get('keyword_count')is not None else None
 argc=facts.get('argument_count');vals=facts.get('argument_values',[])
 if reg.get('arity')=='-1'and len(params)>=2:
  env['$argv_name']=val('name',params[1])
  if argc is not None:env[params[0]]=val('int',argc)
  if argc is not None and len(vals)==argc:env[params[1]]=argv_view(vals)
 elif reg.get('arity')not in('-1','-2'):
  for name,v in zip(params[1:],vals):
   if name and v is not None:env[name]=tuple(v)
 return{a:b for a,b in env.items()if b is not None}

def assess(tail,facts):
 context=key(tail['tail_id'],json.dumps(facts,sort_keys=True));result=[];native=[hops[h]for h in tail['hops']];reg=regs[tail['registration_id']];first=next((h for h in native if h['kind']=='registration_to_function'),None)
 if not first:return{'status':'unresolved','reason':'registration_function_missing','guards':[]}
 f=first['target_file'];fn=function(f,first['target_line']);b,_=parsed(f)
 if fn is None:return{'status':'unresolved','reason':'entry_function_AST_anchor_missing','guards':[]}
 env=entry_env(reg,fn,b,facts);unresolved=facts.get('status')!='exact_source_call_syntax';false=False
 if unresolved:result.append({'status':'unresolved','reason':'Ruby_call_AST_anchor_unresolved'})
 for h in native:
  if h['kind']not in('c_call','function_to_primitive'):continue
  if h['file']!=f:unresolved=True;result.append({'hop_id':h['hop_id'],'status':'unresolved','reason':'macro_or_cross_source_body_not_current_function'});continue
  node=anchor(h,fn,b)
  if node is None:unresolved=True;result.append({'hop_id':h['hop_id'],'status':'unresolved','reason':'unique_AST_anchor_missing'});continue
  const,constant_evidence=constants(f);at,assignments=direct_locals(fn,node,b,{**const,**env})
  for cond,positive,kind in branch_guards(node,fn,b):
   q=None if cond.has_error else guard_truth(cond,kind,b,at);status='unresolved'if q is None else'retained'if q==positive else'contradicted'
   gid=key(context,h['hop_id'],cond.start_byte,positive);record={'guard_id':gid,'hop_id':h['hop_id'],'file':f,'line':cond.start_point.row+1 if cond else h['line'],'expression':tx(b,cond),'required_truth':positive,'evaluated_truth':q,'status':status,'kind':kind,'condition_AST_has_error':cond.has_error,'call_target_resolution':h.get('resolution'),'facts':{k:v for k,v in at.items()if k not in const or re.search(r'\b'+re.escape(k)+r'\b',tx(b,cond))},'local_assignment_evidence':assignments,'constant_evidence_file':f,'context_id':context};guard_rows[gid]=record;result.append({'guard_id':gid,'hop_id':h['hop_id'],'status':status});unresolved|=status=='unresolved';false|=status=='contradicted'
  if h['kind']=='c_call':
   nf=h['target_file'];nfn=function(nf,h['target_line']);nb,_=parsed(nf)
   if nfn is None:unresolved=True;result.append({'hop_id':h['hop_id'],'status':'unresolved','reason':'target_function_AST_anchor_missing'});continue
   argsn=node.child_by_field_name('arguments');argv=list(argsn.named_children)if argsn else[];newenv={k:v for k,v in at.items()if k=='$block'};params=function_params(nfn,nb)
   for name,an in zip(params,argv):
    v=eval_c(an,b,at)
    if name and v is not None:newenv[name]=v
    # Keyword cardinality survives only an unshifted complete argv view.
    if name and v and v[0]=='argv_view' and v[1]['offset']==0:
     newenv['$argv_name']=val('name',name)
     if '$keyword_count' in at:newenv['$keyword_count']=at['$keyword_count']
   env=newenv;f=nf;fn=nfn;b=nb
 status='contradicted'if false else'unresolved'if unresolved else'retained_no_extracted_guard_contradiction'
 return{'context_id':context,'status':status,'guards':result,'entry_facts':facts,'limitation':'retained is not proven feasible; guards outside enclosing if/loop ancestry, alias/memory writes, callbacks, build conditions and arbitrary Ruby dataflow remain unmodeled.'}

for profile,root in [('ce',Path('/workspace/gitlab_c_ext_frontend_v2')),('ee',Path('/workspace/gitlab_c_ext_ee_profile'))]:
 p=list(rows(root/'tables/frontend_paths.jsonl'));need={x['ruby_prefix_id']for x in p};prefix={x['prefix_id']:x for x in rows(root/'tables/frontend_ruby_prefixes.jsonl')if x['prefix_id']in need};rh={x['hop_id']:x for x in rows(root/'tables/frontend_ruby_hops.jsonl')}
 for x in p:
  hs=[rh[k]for k in prefix[x['ruby_prefix_id']]['hops']];last=next((h for h in reversed(hs)if h.get('target_type')=='registration'),None)
  if last is None:facts={'status':'native_ruby_edge_missing'}
  else:
   cid=last['call_id']
   if cid not in fact_cache:fact_cache[cid]=ruby_native_call_facts(R/last['file'],last)
   facts=merge_facts(dict(fact_cache[cid]),extra.get((profile,x['ruby_prefix_id'],cid),{}),last)
  k=key(x['native_tail_id'],json.dumps(facts,sort_keys=True))
  if k not in assess_cache:assess_cache[k]=assess(tails[x['native_tail_id']],facts)
  a=assess_cache[k];row={'decision_id':key(profile,x['path_id'],'native_guards'),'profile':profile,'path_id':x['path_id'],'native_tail_id':x['native_tail_id'],'ruby_prefix_id':x['ruby_prefix_id'],'imported_fact_key':[profile,x['ruby_prefix_id'],last.get('call_id')if last else None],'registration_id':x['registration_id'],'status':a['status'],'context_id':a.get('context_id',k),'native_call_id':last.get('call_id')if last else None,'reason':a.get('reason')};decisions.append(row);counter[(profile,a['status'])]+=1
write('native_guard_constants',({'file':f,'facts':v[0],'evidence':v[1]}for f,v in constant_cache.items()));write('native_guard_decisions',decisions);write('native_guard_contexts',assess_cache.values());write('native_guard_constraints',guard_rows.values());write('native_ruby_call_facts',({'call_id':k,**v}for k,v in fact_cache.items()))
report={'profiles':[{'profile':p,'status':s,'paths':n}for(p,s),n in counter.items()],'paths':len(decisions),'contexts':len(assess_cache),'constraint_rows':len(guard_rows),'call_fact_rows':len(fact_cache),'parsed_source_files':len(cache),'semantics':'Only source-provable predicate contradictions excluded. Retained means no contradiction under modeled guards, never verified runtime chain. Unknown guards and unsupported AST targets remain explicit. Inputs frozen unchanged.','models':['Ruby explicit arity, keyword hash and explicit/no block syntax','C scalar arguments, literal Ruby types, direct local scalar assignment, rb_scan_args positional arity','C enclosing if/else and loop guards; exact scalar switch with grouped/fallthrough cases; source-initialized Ruby symbols and explicit enum constants','C direct-call argument propagation including argc arithmetic and argv literal type elements','Optional contextual source-local Ruby abstract hash facts, independently supplied with source hashes/evidence'],'not_modeled':['C heap/struct alias flow and options fields','Ruby interprocedural variable values except optional imported facts','preprocessor configuration, function-pointer/callback flow','early returns and interdependent predicates','build-selected definitions, link/load activation']}
(V/'reports/native_guard_coverage_iteration3.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
