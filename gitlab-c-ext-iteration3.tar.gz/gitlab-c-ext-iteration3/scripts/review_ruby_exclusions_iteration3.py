"""Materialize independent source review of two newly excluded guard families.
Manual source reasoning is stated explicitly; input hashes detect later changes.
No holdout data used. No model or decision tables are mutated.
"""
import json,hashlib,collections
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_trace');V=Path('/workspace/gitlab_c_ext_v3')
def load(p):return [json.loads(x)for x in p.read_text().splitlines()]
def evidence(f,a,z,reason):
 b=(R/f).read_bytes();return dict(file=f,line=a,end_line=z,sha256=hashlib.sha256(b).hexdigest(),excerpt='\n'.join(b.decode().split('\n')[a-1:z]),reason=reason)
inputs=[];out=[];population=[]
for profile in ['ce','ee']:
 ps={k:V/f'tables/{profile}_ruby_{k}_iteration3.jsonl' for k in ['argument_facts','argument_bindings','argument_affected_paths']}
 inputs += [dict(file=str(p.relative_to(V)),sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in ps.values()]
 facts=load(ps['argument_facts']);bindings=load(ps['argument_bindings']);paths=load(ps['argument_affected_paths']);groups=collections.defaultdict(list)
 for f in facts:
  if f['status']=='incompatible':groups[(f['file'],f['line'])].append(f)
 for (file,line),fs in groups.items():
  family='default_false_lexical_block_guard' if 'cache_service' in file else 'fresh_closed_hash_absent_symbol_key'
  population.append(dict(profile=profile,family=family,facts=len(fs),prefixes=len(set(f['ruby_prefix_id']for f in fs)),paths=sum(x['ruby_prefix_id']in{f['ruby_prefix_id']for f in fs}for x in paths)))
  for f in [fs[0],fs[-1]]:
   bs=[x for x in bindings if x['ruby_prefix_id']==f['ruby_prefix_id']and x['target_method_id']==f['method_id']]
   assert len(bs)==1;b=bs[0];pp=[x['path_id']for x in paths if x['ruby_prefix_id']==f['ruby_prefix_id']]
   if family=='default_false_lexical_block_guard':
    ev=[evidence(b['source_file'],68,76,'Caller invokes fresh constructor result.fetch(ref_name) with no dry_run keyword, and passes lexical caller block.'),evidence(file,11,34,'Default false remains captured in with_redis block; block only declares redis, never reassigns dry_run; selected discrepancy call requires true.')]
    reason='Given this selected fetch definition receives this call, omitted keyword binds immutable false. The inner block captures dry_run; Redis/metrics calls do not rebind that local in retained code. Required dry_run truth is false, even when earlier conditional break does not exit. Passed caller block has a different lexical environment.'
    risks=['Constructor .new result class and selected method dispatch are conditional, not independently proven for arbitrary runtime overrides.','Unsupported block invocation decides whether body executes; it cannot make unchanged captured false true under ordinary Ruby semantics.']
   else:
    ev=[evidence(b['source_file'],63,77,'Constructor completes before .execute argument evaluation; literal Hash is newly built with three explicit symbol keys and no splat/default proc.'),evidence(file,39,49,'First statement checks missing messaging_callback_context; no prior mutation or call receives params in this method before the guard.')]
    reason='Actual argument is an explicit fresh Hash literal with input/event/triggered_by_username only. Unknown calls computing values occur before the new Hash is passed, so cannot add a key to this not-yet-exposed Hash. Direct execute formal params is unchanged before first guard. Absent symbol key returns nil under ordinary Hash#[]; this selected execute_flow arm is excluded, although later execute_flow arms remain possible.'
    risks=['Constructor and execute lookup remain assumed exact; no arbitrary override exclusion.','Unknown value contents do not imply unknown key set for this explicit literal; global Hash monkey patches excluded by normal builtin assumption.']
   out.append(dict(review_id='native_ruby3_'+f['fact_id'],profile=profile,fact_id=f['fact_id'],ruby_prefix_id=f['ruby_prefix_id'],binding_id=b['binding_id'],family=family,verdict='supported_conditional_exclusion',whole_prefix_verdict='not_established',reason=reason,remaining_conditions=risks,evidence=ev,sample_path_ids=pp[:2],all_affected_paths_in_context=len(pp),runtime_auth_request_control='unknown',holdout_reviews_read=False))
(V/'tables/review_ruby_exclusions_native_iteration3.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n'for x in out))
report=dict(review_rows=len(out),unique_guard_families=2,population=population,inputs=inputs,all_sample_verdicts='supported_conditional_exclusion',false_exclusions_identified=0,scope='Independent manual source semantics for six contexts and representative affected paths. Covers every newly contradicting guard family observed. Not end-to-end reachability proof or empirical precision estimate.',holdout_reviews_read=False)
(V/'reports/review_ruby_exclusions_native_iteration3.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='inputs'}))
