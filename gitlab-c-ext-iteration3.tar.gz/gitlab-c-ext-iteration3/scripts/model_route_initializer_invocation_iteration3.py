#!/usr/bin/env python3
"""Additive source-reviewed invocation contract; no frozen route/flow mutations."""
import hashlib,json
from pathlib import Path
from route_scope_analysis import BASE,P,uid
V=Path('/workspace/gitlab_c_ext_v3')
def ev(file,anchor,line=None):
 data=(BASE/file).read_bytes();ls=data.decode().splitlines();found=[i for i,l in enumerate(ls) if anchor in l and (line is None or i+1==line)];assert len(found)==1,(file,anchor,found)
 return dict(file=file,line=found[0]+1,context=ls[found[0]],sha256=hashlib.sha256(data).hexdigest())
def yields_in_method(data,name):
 root=P.parse(data).root_node;nodes=[];stack=[root]
 while stack:
  n=stack.pop();m=n.child_by_field_name('name')
  if n.type in ('method','singleton_method') and m and data[m.start_byte:m.end_byte].decode()==name:nodes.append(n)
  stack.extend(n.named_children)
 assert len(nodes)==1
 out=[];stack=[nodes[0]]
 while stack:
  n=stack.pop()
  if n.type=='yield':out.append(n.start_point.row+1)
  stack.extend(n.named_children)
 return sorted(out)
framework='sources/wrappers/rails-7.2.3.1/activesupport/lib/active_support/notifications.rb';fdata=(BASE/framework).read_bytes()
assert yields_in_method(fdata,'subscribed')==[260]
models=[];mappings=[]
for profile,prefix in [('ce','sources/gitlab'),('ee','sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2')]:
 file=prefix+'/lib/initializer_connections.rb';data=(BASE/file).read_bytes();assert yields_in_method(data,'warn_if_database_connection')==[25]
 evidence=[ev(prefix+'/config/routes.rb','InitializerConnections.warn_if_database_connection do'),ev(file,'def self.warn_if_database_connection'),ev(file,'callback = ->('),ev(file,'ActiveSupport::Notifications.subscribed(callback,'),ev(file,'      yield'),ev(framework,'def subscribed(callback,'),ev(framework,'subscriber = notifier.subscribe(pattern, callback, monotonic: monotonic)'),ev(framework,'        yield',260),ev(framework,'        unsubscribe(subscriber)'),ev(prefix+'/Gemfile.lock','    activesupport (7.2.3.1)')]
 mid='invocation_'+uid(profile,file,'warn_if_database_connection','subscribed')
 model=dict(model_id=mid,profile=profile,status='source_supported_conditional_block_invocation_model',receiver='InitializerConnections',method='warn_if_database_connection',evidence=evidence,execution_order=['construct diagnostic lambda without invoking its body','invoke ActiveSupport::Notifications.subscribed with callback and sql.active_record pattern','notifier.subscribe must return normally','Notifications.subscribed yields to supplied wrapper block','wrapper yield invokes original config/routes.rb caller block','Notifications.subscribed ensure unsubscribes, including exceptional caller exit'],guarantee='one syntactic direct yield per subscribed invocation after subscription returns normally; no branch or delayed scheduler encloses that yield',conditions=['retained methods selected; no runtime redefinition/prepend redirects receiver','required constants and framework loaded','subscription returns normally; exceptions before yield prevent invocation','route block may raise, return nonlocally or stop partway; downstream declarations not guaranteed','cleanup unsubscribe and SQL diagnostic callbacks can raise; normal completion not asserted'],non_claims=['not proof Rails routes.draw or included route DSL completes','not evidence diagnostic lambda is eagerly invoked','not proof endpoint handler is callable or authorization passes'],supersedes_only='block_invocation_semantics_unproven condition for this exact wrapper call, conditionally',frozen_inputs_unchanged=True)
 models.append(model)
 for l in (V/'profiles'/profile/'tables/route_scope_bindings.jsonl').open():
  r=json.loads(l)
  for c in r['conditions']:
   if c.get('role')=='block_invocation_semantics_unproven' and c['file']==prefix+'/config/routes.rb' and c['line']==6 and 'InitializerConnections.warn_if_database_connection' in c['context']:
    mappings.append(dict(model_id=mid,profile=profile,scope_occurrence_id=r['scope_occurrence_id'],original_condition=c,refined_condition='source_supported_invocation_subject_to_model_conditions',other_conditions_preserved=True));break
for name,rs in [('route_initializer_invocation_models_iteration3',models),('route_initializer_invocation_effects_iteration3',mappings)]:
 (V/'tables'/f'{name}.jsonl').write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in rs))
report=dict(status='PASS_source_anchor_AST_and_reference_checks',models=len(models),affected_scope_occurrences={p:sum(r['profile']==p for r in mappings) for p in ('ce','ee')},models_sha256=hashlib.sha256((V/'tables/route_initializer_invocation_models_iteration3.jsonl').read_bytes()).hexdigest(),meaning='additive resolution of one specific wrapper invocation hole; no new complete paths or exposure claims',parent_source_calls='exact config/routes.rb line6 in each profile',frozen_flows_modified=False)
(V/'reports/route_initializer_invocation_iteration3.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
