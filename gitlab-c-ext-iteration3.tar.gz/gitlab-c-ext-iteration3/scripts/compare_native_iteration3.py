import json,collections
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3')
def rows(n):return [json.loads(s)for s in(V/'tables'/f'{n}.jsonl').read_text().splitlines()]
a={(x['profile'],x['path_id']):x for x in rows('native_guard_decisions_iteration2')};b=rows('native_guard_decisions_iteration3');out=[];counts=collections.Counter()
for x in b:
 old=a[(x['profile'],x['path_id'])]
 if old['status']!=x['status']:
  out.append(dict(profile=x['profile'],path_id=x['path_id'],before=old['status'],after=x['status'],old_context_id=old['context_id'],context_id=x['context_id'],native_tail_id=x['native_tail_id'],registration_id=x['registration_id']))
  counts[(x['profile'],old['status'],x['status'])]+=1
(V/'tables/native_iteration3_changed_decisions.jsonl').write_text(''.join(json.dumps(x)+'\n'for x in out))
r=dict(changed_paths=len(out),transitions=[dict(profile=p,before=a,after=b,paths=n)for(p,a,b),n in counts.items()],reversions=[x for x in out if x['before']=='contradicted'and x['after']!='contradicted'],semantics='Changed decisions only; no surviving path is verified. Reversions require source review before freeze.')
(V/'reports/native_iteration3_changes.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='reversions'}))
