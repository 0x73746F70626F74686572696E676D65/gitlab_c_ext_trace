#!/usr/bin/env python3
import json,pathlib,hashlib,random,collections
B=pathlib.Path('/workspace/gitlab_c_ext_trace');OLD=B/'audit/end_to_end_20260930';OUT=pathlib.Path('/workspace/gitlab_c_ext_v3/audit/holdout3_20260930');SEED=202609300901
OUT.mkdir(parents=True,exist_ok=True)
rng=random.Random(SEED)
def rows(p):
 with p.open() as f:
  for l in f:
   if l.strip():yield json.loads(l)
def idx(p,k):return {x[k]:x for x in rows(p)}
def write(name,rs):
 with (OUT/name).open('w') as f:
  for r in rs:f.write(json.dumps(r,sort_keys=True)+'\n')
def locus(h):return (h.get('file'),h.get('line'),h.get('method',h.get('callee',h.get('kind',h.get('type')))))
FIRST=pathlib.Path('/workspace/gitlab_c_ext_v3/audit/holdout_20260930')
SECOND=pathlib.Path('/workspace/gitlab_c_ext_v3/audit/holdout2_20260930')
training=list(rows(OLD/'path_sample.jsonl'))+list(rows(FIRST/'path_sample.jsonl'))+list(rows(SECOND/'path_sample.jsonl'));exclude={x['path']['path_id'] for x in training};trhop={h['hop_id'] for x in training for h in x['ruby_hops']+x['native_hops']};trloci={locus(h) for x in training for h in x['ruby_hops']+x['native_hops']};errors=set()
def canonical(f):
 return f.replace('sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/','gitlab/').replace('sources/gitlab/','gitlab/')
exclude.update(x['source_path_id'] for x in rows(FIRST/'unique_edge_sample.jsonl'))
trhop.update(x['hop']['hop_id'] for x in rows(FIRST/'unique_edge_sample.jsonl'))
exclude.update(x['source_path_id'] for x in rows(SECOND/'unique_edge_sample.jsonl'))
trhop.update(x['hop']['hop_id'] for x in rows(SECOND/'unique_edge_sample.jsonl'))
for p in list(OLD.glob('review_*.jsonl'))+[FIRST/'baseline_reviews.jsonl',SECOND/'baseline_reviews.jsonl']:
 for r in rows(p):
  if r.get('audit_id') not in {x['audit_id'] for x in training}:continue
  for e in r.get('decisive_evidence',[]):
   if e.get('file') and e.get('line'):errors.add((canonical(e['file']),e['line']))
  for h in r.get('hops',r.get('hop_reviews',r.get('per_hop',r.get('per_hop_verdicts',[])))):
   verdict=str(h.get('verdict',h.get('status',h.get('composed_path_context_verdict',''))))
   if 'contradict' in verdict or 'unresolved' in verdict:
    if h.get('file') and h.get('line'):errors.add((canonical(h['file']),h['line']))
    for e in h.get('evidence',h.get('source_evidence',[])):
     if isinstance(e,dict) and e.get('file') and e.get('line'):errors.add((canonical(e['file']),e['line']))
nt=idx(B/'tables/frontend_native_tails.jsonl','tail_id');nh=idx(B/'tables/frontend_native_hops.jsonl','hop_id');g=idx(B/'tables/gems.jsonl','gem_id');groups=collections.defaultdict(list);edgepop={};man=json.loads((OLD/'freeze_manifest.json').read_text())
for profile,root in [('ce',pathlib.Path('/workspace/gitlab_c_ext_frontend_v2')),('ee',pathlib.Path('/workspace/gitlab_c_ext_ee_profile'))]:
 t=root/'tables';en=idx(t/'frontend_entrypoints.jsonl','entrypoint_id');ex=idx(t/'frontend_exposure.jsonl','entrypoint_id');pr=idx(t/'frontend_ruby_prefixes.jsonl','prefix_id');rh=idx(t/'frontend_ruby_hops.jsonl','hop_id')
 for p in rows(t/'frontend_paths.jsonl'):
  if p['path_id'] in exclude:continue
  hs=[rh[i] for i in pr[p['ruby_prefix_id']]['hops']];ns=[nh[i] for i in nt[p['native_tail_id']]['hops']];allh=hs+ns;length=len(allh);lb='short_1_8' if length<=8 else 'medium_9_14' if length<=14 else 'long_15_plus';gn=g[p['gem_id']]['name'];overerr=sorted(set((canonical(h['file']),h['line']) for h in allh)&errors);k=(profile,en[p['entrypoint_id']]['kind'],gn,p['native_confidence'],lb)
  b={'dataset_id':man['dataset_id'],'profile':profile,'root':str(root),'path':p,'entrypoint':en[p['entrypoint_id']],'exposure':ex[p['entrypoint_id']],'ruby_hops':hs,'native_hops':ns,'native_tail':nt[p['native_tail_id']],'gem':g[p['gem_id']],'length':length,'stratum':'|'.join(k),'training_error_locus_overlap':overerr,'training_hop_overlap':[h['hop_id'] for h in allh if h['hop_id'] in trhop],'training_source_locus_overlap':[list(locus(h)) for h in allh if locus(h) in trloci]};groups[k].append(b)
  for h in allh:
   if h['hop_id'] not in trhop and h.get('type',h.get('kind')) not in ['entrypoint','method_body']:
    edgepop[(profile,h['hop_id'])]={'profile':profile,'hop':h,'source_path_id':p['path_id'],'training_error_locus_overlap':(canonical(h['file']),h['line']) in errors}
# Coverage-balanced strata selection; deliberately not a uniform probability sample of all paths.
keys=sorted(groups);rng.shuffle(keys);chosen=[];seen=collections.Counter()
while keys and len(chosen)<20:
 def score(k):return (seen[('profilekind',k[0],k[1])],seen[('gem',k[2])],seen[('confidence',k[3])],seen[('length',k[4])])
 k=min(keys,key=score);keys.remove(k);pop=sorted(groups[k],key=lambda b:b['path']['path_id']);novel=[b for b in pop if not b['training_error_locus_overlap']];pool=novel or pop;b=dict(rng.choice(pool));b.update(audit_id=f'K{len(chosen)+1:03}',design='coverage_balanced_strata_seeded_within_novel_error_locus_pool',stratum_population=len(pop),selection_pool_size=len(pool),new_error_locus=bool(novel));chosen.append(b)
 for c in [('profilekind',k[0],k[1]),('gem',k[2]),('confidence',k[3]),('length',k[4])]:seen[c]+=1
write('path_sample.jsonl',chosen)
eg=collections.defaultdict(list)
for e in edgepop.values():eg[(e['profile'],e['hop'].get('kind',e['hop'].get('type')))].append(e)
es=[]
for k,pop in sorted(eg.items()):
 pop.sort(key=lambda e:e['hop']['hop_id']);novel=[e for e in pop if not e['training_error_locus_overlap']];pool=novel or pop
 for e in rng.sample(pool,min(2,len(pool))):es.append(dict(e,audit_id=f'KE{len(es)+1:03}',stratum='|'.join(k),stratum_population=len(pop),selection_pool_size=len(pool)))
write('unique_edge_sample.jsonl',es)
assert len(chosen)==20 and not {x['path']['path_id'] for x in chosen}&exclude
files=[]
for p in [OUT/'path_sample.jsonl',OUT/'unique_edge_sample.jsonl',pathlib.Path(__file__)]:files.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(OUT/'holdout_design.json').write_text(json.dumps({'seed':SEED,'selection_frozen_before_iteration3_results_inspected':True,'baseline_dataset_id':man['dataset_id'],'baseline_commit':'0f25e217','training_paths_excluded':len(exclude),'path_sample_size':len(chosen),'unique_edge_sample_size':len(es),'available_strata':len(groups),'sampled_strata':len(chosen),'new_error_locus_paths':sum(x['new_error_locus'] for x in chosen),'fully_new_hop_paths':sum(not x['training_hop_overlap'] for x in chosen),'selection':'Greedy coverage balance over profile/frontend then gem/native-confidence/length; seeded random selection in each selected stratum, preferring no exact training error locus. Not a probability sample of entire population; no weighted global precision estimate permitted. Exact source overlap is retained and does not claim semantic independence.','files':files},indent=2));print((OUT/'holdout_design.json').read_text())
