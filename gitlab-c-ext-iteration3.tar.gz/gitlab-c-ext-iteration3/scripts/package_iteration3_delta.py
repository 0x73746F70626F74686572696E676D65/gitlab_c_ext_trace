#!/usr/bin/env python3
"""Compact immutable iteration3 delta; requires previous V3 companion; never publishes."""
import argparse,gzip,hashlib,io,json,shutil,tarfile
from pathlib import Path
from package_v3_publication import verify_manifest,digest
R=Path('/workspace/gitlab_c_ext_v3');D=R/'publication/iteration3'
def main():
 required=['iterations/iteration3/freeze_manifest.json','reports/native_iteration3_freeze.json','reports/ruby_arguments_iteration3_manifest.json','audit/holdout3_20260930/iteration3_comparison_summary.json']
 for n in required:assert (R/n).exists(),('pending required freeze/review',n)
 checks=[dict(manifest=n,verified_files=verify_manifest(R/n)) for n in required[:3]]
 prior=R/'publication/gitlab-c-ext-v3.tar.gz';prior_hash=digest(prior)
 D.mkdir(parents=True,exist_ok=True);stage=D/'gitlab-c-ext-iteration3'
 if stage.exists():shutil.rmtree(stage)
 stage.mkdir();selected=set()
 patterns=['iterations/iteration3/*','audit/holdout2_20260930/*','audit/holdout3_20260930/*','audit/holdout_20260930/*iteration3*','reports/*iteration3*.json','reports/*iteration3*.txt','reports/flow3_independent_assembly_review.json','reports/request_flow_latest_index_validation.json','reports/review_slack*.json','reports/ruby_runtime_acquisition.json','tables/*iteration3*.jsonl','tables/request_flow_latest_index.jsonl','tables/flow3_independent_assembly_review.jsonl','fixtures/*iteration3*','schemas/*iteration3*','scripts/*iteration3*.py','scripts/*holdout2*.py','scripts/*holdout3*.py','scripts/combine_iteration_overlay.py','scripts/validate_overlay.py','scripts/package_iteration3_delta.py','scripts/package_v3_publication.py','scripts/build_request_flow_index.py','scripts/acquire_ruby_runtime.py','tests/*iteration3*.py']
 for pat in patterns:
  for p in R.glob(pat):
   if p.is_file() and p.suffix not in ('.log','.pyc'):selected.add(p)
 # Native3 made no status changes; retain complete root3 path decisions, native3 changed tables,
 # frozen native2 provenance and full local hashes rather than duplicating identical large ledgers.
 omit={'native_guard_decisions_iteration3.jsonl','native_guard_constraints_iteration3.jsonl','native_guard_constants_iteration3.jsonl','native_guard_contexts_iteration3.jsonl','native_ruby_call_facts_iteration3.jsonl'}
 omitted=[p for p in selected if p.name in omit];selected-=set(omitted)
 for p in sorted(selected):
  dst=stage/p.relative_to(R);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
 (stage/'omitted_local_artifacts.json').write_text(json.dumps([dict(path=str(p.relative_to(R)),durable_location=str(p),bytes=p.stat().st_size,sha256=digest(p),reason='native3 has zero guard/path-status changes; previous archive plus native3 frozen local ledger') for p in omitted],indent=2)+'\n')
 # A small selected-source catalog only, not the complete runtime tree manifest.
 sources=set()
 def collect(x):
  if isinstance(x,dict):
   for k,v in x.items():
    if k in ('file','path','source_file') and isinstance(v,str) and v.startswith('sources/runtime/') and (Path('/workspace/gitlab_c_ext_trace')/v).is_file():sources.add(v)
    collect(v)
  elif isinstance(x,list):
   for v in x:collect(v)
 for name in ['tables/ruby_runtime_contracts_iteration3.jsonl','tables/ruby_runtime_contract_supplement_iteration3.jsonl','reports/flow3_independent_assembly_review.json']:
  p=R/name
  if not p.exists():continue
  if p.suffix=='.jsonl':
   for l in p.open():collect(json.loads(l))
  else:collect(json.loads(p.read_text()))
 (stage/'selected_runtime_source_catalog.json').write_text(json.dumps([dict(file=f,bytes=(Path('/workspace/gitlab_c_ext_trace')/f).stat().st_size,sha256=digest(Path('/workspace/gitlab_c_ext_trace')/f),durable_location=str(Path('/workspace/gitlab_c_ext_trace')/f)) for f in sorted(sources)],indent=2)+'\n')
 (stage/'prerequisites.json').write_text(json.dumps(dict(prior_archive=str(prior),sha256=prior_hash,source_root='/workspace/gitlab_c_ext_trace',analysis_root=str(R),standalone=False),indent=2)+'\n')
 index=(D/'ITERATION3_INDEX.txt').read_text()
 for label,rel in [('Frozen combined iteration3 summary','iterations/iteration3/summary.json'),('Fresh holdout3 comparison','audit/holdout3_20260930/iteration3_comparison_summary.json')]:
  index+='\n'+label+'\n'+json.dumps(json.loads((R/rel).read_text()),indent=2)+'\n'
 (stage/'INDEX.txt').write_text(index)
 catalog=[dict(path=str(p.relative_to(stage)),bytes=p.stat().st_size,sha256=digest(p),rows=sum(1 for _ in p.open('rb')) if p.suffix=='.jsonl' else None) for p in sorted(stage.rglob('*')) if p.is_file()]
 (stage/'table_catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
 (stage/'package_validation.json').write_text(json.dumps(dict(status='PASS',freeze_checks=checks,files=len(catalog),bytes=sum(x['bytes'] for x in catalog),scope='Frozen input hashes, included file catalog and archive content verification; semantic conclusions remain conditional'),indent=2)+'\n')
 (stage/'SHA256SUMS').write_text(''.join(f'{digest(p)}  {p.relative_to(stage)}\n' for p in sorted(stage.rglob('*')) if p.is_file()))
 arc=R/'publication/gitlab-c-ext-iteration3.tar.gz'
 with arc.open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0,compresslevel=9) as gz,tarfile.open(fileobj=gz,mode='w') as t:
  for p in sorted(stage.rglob('*')):
   if p.is_file():
    info=tarfile.TarInfo('gitlab-c-ext-iteration3/'+str(p.relative_to(stage)));info.size=p.stat().st_size;info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(p.read_bytes()))
 expected={'gitlab-c-ext-iteration3/'+str(p.relative_to(stage)):digest(p) for p in stage.rglob('*') if p.is_file()}
 with tarfile.open(arc,'r:gz') as t:actual={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers()}
 assert expected==actual
 assert digest(prior)==prior_hash,'prior published companion changed during packing'
 report=dict(status='PASS',archive=str(arc),bytes=arc.stat().st_size,sha256=digest(arc),members=len(actual),prior_archive_preserved=True)
 (D/'archive_validation.json').write_text(json.dumps(report,indent=2)+'\n');(D/'SHA256SUMS').write_text(f"{report['sha256']}  {arc.name}\n");print(json.dumps(report))
if __name__=='__main__':main()
