import json,pathlib
B=pathlib.Path('/workspace/gitlab_c_ext_trace');D=pathlib.Path('/workspace/gitlab_c_ext_v3/audit/holdout3_20260930');rs=[json.loads(l) for l in (D/'path_sample.jsonl').open()]
want={h.get('target_id') for r in rs for h in r['ruby_hops'] if h.get('target_type')=='ruby_method'};mid={}
for root in [pathlib.Path('/workspace/gitlab_c_ext_ruby_expanded'),pathlib.Path('/workspace/gitlab_c_ext_ee_profile')]:
 for l in (root/'tables/ruby_methods.jsonl').open():
  r=json.loads(l)
  if r['method_id'] in want:mid[r['method_id']]=r
cache={}
def span(file,line,before=3,after=4):
 if file not in cache:cache[file]=(B/file).read_text(errors='replace').split('\n')
 ls=cache[file];return '\n'.join(f'{i+1}: {ls[i]}' for i in range(max(0,line-before-1),min(len(ls),line+after)))
for r in rs:
 parts=[r['audit_id']+' '+r['stratum']]
 for ev in r['exposure'].get('registration_evidence',[]):
  if ev.get('file') and ev.get('line'):parts+=['EXPOSURE '+ev['file'],span(ev['file'],ev['line'],2,3)]
 for h in r['ruby_hops']+r['native_hops']:
  parts += [str({k:v for k,v in h.items() if k in ['method','receiver','type','kind','target_function_name','target_file','target_line']})+' '+h['file'],span(h['file'],h['line'])]
  m=mid.get(h.get('target_id'))
  if m:parts+=['TARGET '+m['namespace']+'#'+m['method']+' '+m['file'],span(m['file'],m['line'],1,2)]
 (D/(r['audit_id']+'_dossier.txt')).write_text('\n'.join(parts))
(D/'target_methods.json').write_text(json.dumps(mid));print('wrote',len(rs))
