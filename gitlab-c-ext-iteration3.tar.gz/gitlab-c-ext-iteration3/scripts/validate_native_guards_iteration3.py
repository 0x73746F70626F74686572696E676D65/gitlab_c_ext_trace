import json,hashlib,collections
from pathlib import Path
from native_guard_engine_iteration3 import *
V=Path('/workspace/gitlab_c_ext_v3');T=V/'tables';errors=[];checks=collections.Counter()
def rows(name):
 with(T/(name+'.jsonl')).open()as f:
  for s in f:yield json.loads(s)
contexts={x['context_id']:x for x in rows('native_guard_contexts_iteration3')};constraints={x['guard_id']:x for x in rows('native_guard_constraints_iteration3')};const={x['file']:x for x in rows('native_guard_constants_iteration3')};cache={};wanted=collections.defaultdict(set)
for x in constraints.values():wanted[x['file']].add((x['line'],x['expression']))
for id,x in constraints.items():
 f=x['file']
 if f not in cache:
  b=(R/f).read_bytes();t=CP['cpp'if Path(f).suffix in('.cpp','.cc','.hpp','.hh','.cxx')else'c'].parse(b);index=collections.defaultdict(list);lines={z[0]for z in wanted[f]}
  for n in walk(t.root_node):
   if n.start_point.row+1 in lines:
    z=(n.start_point.row+1,tx(b,n))
    if z in wanted[f]:index[z].append(n)
  cache[f]=(b,t,index)
 b,t,index=cache[f];nodes=index[(x['line'],x['expression'])]
 # Parenthesized conditions/case nodes have exact retained text and source line.
 checks['guard_source_anchor']+=1
 if not nodes:errors.append({'guard_id':id,'reason':'source_anchor_missing'});continue
 env={k:tuple(v)for k,v in const[f]['facts'].items()};env.update({k:tuple(v)for k,v in x['facts'].items()})
 values={None if n.has_error else guard_truth(n,x['kind'],b,env)for n in nodes};checks['guard_abstract_recompute']+=1
 if x['evaluated_truth']not in values:errors.append({'guard_id':id,'reason':'recomputed_truth_disagrees','values':list(values),'stored':x['evaluated_truth']})
 status='unresolved'if x['evaluated_truth']is None else'retained'if x['evaluated_truth']==x['required_truth']else'contradicted'
 checks['guard_status']+=1
 if status!=x['status']:errors.append({'guard_id':id,'reason':'status_disagrees'})
for id,c in contexts.items():
 for g in c['guards']:
  if g.get('guard_id'):
   checks['context_constraint_FK']+=1
   if g['guard_id']not in constraints:errors.append({'context_id':id,'reason':'missing_constraint'})
for d in rows('native_guard_decisions_iteration3'):
 checks['decision_context_FK']+=1
 if d['context_id']not in contexts:errors.append({'decision_id':d['decision_id'],'reason':'missing_context'})
 elif d['status']!=contexts[d['context_id']]['status']:errors.append({'decision_id':d['decision_id'],'reason':'context_status_mismatch'})
report={'status':'pass'if not errors else'fail','checks':dict(checks),'errors':errors,'semantics':'Integrity/source-anchor and evaluator reproducibility checks, not independent semantic proof or empirical accuracy.27 independent synthetic contract tests are separately run.'};(V/'reports/native_guard_validation_iteration3.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'checks':sum(checks.values()),'errors':len(errors)}))
