#!/usr/bin/env python3
"""Read-only comparison against frozen independent manual source judgments; no graph repair."""
import json, hashlib, collections
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_v3'); B=Path('/workspace/gitlab_c_ext_trace'); D=R/'audit/holdout_20260930'; I=R/'iterations/iteration3'
def rows(p):
 with p.open() as f:
  for l in f: yield json.loads(l)
def write(p,x): p.write_text(json.dumps(x,indent=2)+'\n')
def jl(p,x):p.write_text(''.join(json.dumps(a)+'\n' for a in x))
freeze=json.loads((I/'freeze_manifest.json').read_text()); errors=[]
for x in freeze['inputs']+freeze['outputs']:
 p=Path(x['path']); data=p.read_bytes()
 if len(data)!=x['bytes'] or hashlib.sha256(data).hexdigest()!=x['sha256']:errors.append(str(p))
reviews={x['path_id']:x for x in rows(D/'baseline_reviews.jsonl')}; edges=list(rows(D/'unique_edge_sample.jsonl')); wanted=set(reviews)|{x['source_path_id'] for x in edges}
decisions={x['baseline_path_id']:x for x in rows(I/'path_decisions.jsonl') if x['baseline_path_id'] in wanted}
comparison=[]
for pid,r in reviews.items():
 d=decisions[pid]; s=d['status']; result='partial_remains_unresolved'
 if s=='candidate_not_disproved':result={'contradicted':'known_contradiction_not_detected','unresolved':'unresolved_candidate_not_validated','supported_static_chain':'consistent_with_conditional_source_review'}[r['status']]
 elif s=='rejected_static_contradiction':result='correct_rejection' if r['status']=='contradicted' else 'potential_false_exclusion'
 comparison.append(dict(audit_id=r['audit_id'],path_id=pid,baseline_status=r['status'],overlay_status=s,independent_assessment=result,contradictions=d['contradictions'],unresolved_conditions=d['unresolved_conditions'],manual_evidence=[h for h in r['hops'] if h['verdict'] not in ['supported_static_link']],runtime_verified=False))
comparison.sort(key=lambda x:x['audit_id']);jl(D/'iteration3_comparison.jsonl',comparison)
edgeeffects=[]
for e in edges:
 d=decisions[e['source_path_id']]
 edgeeffects.append(dict(audit_id=e['audit_id'],hop_id=e['hop']['hop_id'],local_source_verdict='supported_static_link',source_path_id=e['source_path_id'],source_path_overlay_status=d['status'],effect_scope='Overlay classifies whole contextual paths, not standalone local links; a partial/rejected containing path does not contradict local edge support.',contradictions=d['contradictions'],unresolved_conditions=d['unresolved_conditions']))
jl(D/'iteration3_unique_edge_effects.jsonl',edgeeffects)
flowchecks=[]
for f in rows(R/'tables/request_memory_flows.jsonl'):
 errs=[]
 for e in f['evidence']:
  data=(B/e['file']).read_bytes(); lines=data.decode().split('\n')
  if hashlib.sha256(data).hexdigest()!=e['source_sha256'] or lines[e['line']-1]!=e['source_text']:errs.append(e['id'])
 flowchecks.append(dict(flow_id=f['flow_id'],status='unresolved' if f['status']=='partial' else 'source_supported_conditional_flow',evidence_rows_checked=len(f['evidence']),source_errors=errs,runtime_verified=False,manual_review='Actual Ruby request propagation, native registration, callback/IO argument transfer, enclosing guards and pointer/count sink expressions inspected. Normal dispatch/loading and stated input/IO conditions required.',limitation='Decompressed output remains unresolved; the two complete conditional flows do not establish authentication feasibility, arbitrary address/size control, deployment reachability or vulnerability. Native review prose cites scp.c88 for rb_str_new; actual pinned sink is scp.c85, correctly located in the flow evidence.'))
write(D/'iteration3_flow_review.json',flowchecks)
summary=dict(iteration_id=freeze['iteration_id'],scope='40 balanced novelty-selected heldout paths, disjoint original80, plus16 unique relational edges. Not a probability sample; no global precision/recall estimate.',freeze_integrity=dict(files_checked=len(freeze['inputs'])+len(freeze['outputs']),errors=errors),cross_tab=dict(collections.Counter(x['baseline_status']+' -> '+x['overlay_status'] for x in comparison)),known_contradicted_candidates=[x['audit_id'] for x in comparison if x['independent_assessment']=='known_contradiction_not_detected'],unresolved_candidates=[x['audit_id'] for x in comparison if x['independent_assessment']=='unresolved_candidate_not_validated'],correct_rejections=[x['audit_id'] for x in comparison if x['independent_assessment']=='correct_rejection'],potential_false_exclusions=[x['audit_id'] for x in comparison if x['independent_assessment']=='potential_false_exclusion'],unique_edge_count=len(edgeeffects),unique_edge_containing_path_statuses=dict(collections.Counter(x['source_path_overlay_status'] for x in edgeeffects)),flow_source_errors=sum(len(x['source_errors']) for x in flowchecks),interpretation='Candidate_not_disproved is an incompletely filtered candidate, not a supported or feasible path. Partial classifications correctly withhold conclusions even where manual review knows more. Original escape-utils zero-init rejections remain independently supported; additional decisions are compared with prior frozen manual judgments. No sampled supported chain was rejected. Rejected baseline path IDs and original review evidence remain retained.',next_iteration_caveat='These heldout loci are now disclosed. Repairs informed by this comparison are training on this sample; fresh heldout evidence is needed for further independent accuracy claims.')
write(D/'iteration3_comparison_summary.json',summary)
print(json.dumps(summary,indent=2))
