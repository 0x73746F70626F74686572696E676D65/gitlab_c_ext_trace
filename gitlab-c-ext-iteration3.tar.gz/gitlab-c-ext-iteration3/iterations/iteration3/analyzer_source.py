#!/usr/bin/env python3
"""Compose additive conservative repair decisions without mutating frozen witnesses."""
import json,pathlib,hashlib,collections,datetime,sys,argparse
V=pathlib.Path(__file__).resolve().parents[1];B=pathlib.Path('/workspace/gitlab_c_ext_trace');sys.path.insert(0,str(V/'scripts'))
from deferred_execution import classify_call
ROOTS={'ce':B.parent/'gitlab_c_ext_frontend_v2','ee':B.parent/'gitlab_c_ext_ee_profile'}
def rows(p):
 with pathlib.Path(p).open() as f:
  for l in f:
   if l.strip():yield json.loads(l)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--iteration',required=True);ap.add_argument('--native-decisions',required=True,help='Explicit frozen native decisions; original iteration1 was withdrawn');ap.add_argument('--ee-lookup-corrections');ap.add_argument('--ruby-decisions',action='append',default=[]);a=ap.parse_args();O=V/'iterations'/a.iteration;O.mkdir(parents=True,exist_ok=True)
 if (O/'freeze_manifest.json').exists():raise SystemExit('Iteration already frozen; use a new ID')
 (O/'analyzer_source.py').write_bytes(pathlib.Path(__file__).read_bytes())
 native={(r['profile'],r['path_id']):r for r in rows(a.native_decisions)};ruby={(r['profile'],r['path_id']):r for rp in a.ruby_decisions for r in rows(rp)};regions=collections.defaultdict(list)
 for r in rows(V/'tables/ruby_deferred_regions.jsonl'):regions[r['file']].append(r)
 inputs=[pathlib.Path(a.native_decisions),V/'tables/ruby_deferred_regions.jsonl'];corrections={r['edge_id']:r for r in rows(a.ee_lookup_corrections)} if a.ee_lookup_corrections else {};inputs.extend([pathlib.Path(a.ee_lookup_corrections)] if a.ee_lookup_corrections else []);inputs.extend(pathlib.Path(rp) for rp in a.ruby_decisions);summary={};used_lookup={};used_regions={};deferred_decisions=[]
 with (O/'path_decisions.jsonl').open('w') as out:
  for profile,root in ROOTS.items():
   lp=V/'tables'/f'{profile}_lookup_edge_decisions.jsonl';cp=V/'tables'/f'{profile}_path_ruby_calls.jsonl';inputs.extend([lp,cp]);look=collections.defaultdict(list)
   for r in rows(lp):look[r.get('edge_id',r['id'])].append(r)
   if profile=='ee':
    for eid,r in corrections.items():look[eid]=[dict(r,id=eid,decision_id='scope_correction_'+eid,kind='profile_scope_correction')]
   calls={r['call_id']:r for r in rows(cp)}
   prefixes={r['prefix_id']:r for r in rows(root/'tables/frontend_ruby_prefixes.jsonl')};hops={r['hop_id']:r for r in rows(root/'tables/frontend_ruby_hops.jsonl')};counts=collections.Counter();cause=collections.Counter();prefix_results={}
   for p in rows(root/'tables/frontend_paths.jsonl'):
    pid=p['ruby_prefix_id']
    if pid not in prefix_results:
     reject=[];holes=[]
     for hid in prefixes[pid]['hops']:
      h=hops[hid];e=look.get(h.get('edge_id'))
      if e:
       for item in e:used_lookup[(profile,item.get('decision_id',item.get('id')),item.get('kind'))]=item
       if all(item['decision']=='shadowed' for item in e):reject.append({'kind':'shadowed_ruby_target','hop_id':hid,'edge_id':h['edge_id'],'source_decisions':e})
       elif any(item['decision'].startswith('unresolved') for item in e):holes.append({'kind':'unresolved_method_precedence','hop_id':hid,'edge_id':h['edge_id'],'reasons':[item['reason'] for item in e if item['decision'].startswith('unresolved')]})
      if h.get('call_id') in calls:
       c=calls[h['call_id']];d=classify_call(c,regions.get(c['file'],[]))
       if d:
        for r in regions[c['file']]:
         if r['region_id'] in d['region_ids']:used_regions[r['region_id']]=r
        if d['classification']=='requires_invocation':holes.append({'kind':'deferred_invocation_required','hop_id':hid,'call_id':c['call_id'],'decision':d})
     prefix_results[pid]=(reject,holes)
    rejected,holes=prefix_results[pid];rejected=list(rejected);holes=list(holes);ng=native[(profile,p['path_id'])]
    if ng['status']=='contradicted':rejected.append({'kind':'native_guard_contradiction','decision_id':ng['decision_id'],'context_id':ng['context_id']})
    elif ng['status']=='unresolved':holes.append({'kind':'native_guard_unresolved','decision_id':ng['decision_id'],'context_id':ng['context_id']})
    rg=ruby.get((profile,p['path_id']))
    if rg:
     if rg['status']=='contradicted':rejected.append({'kind':'ruby_argument_guard_contradiction','decision_id':rg['decision_id']})
     elif rg['status']=='unresolved':holes.append({'kind':'ruby_argument_guard_unresolved','decision_id':rg['decision_id']})
     elif rg['status'] not in ('no_extracted_contradiction','not_examined'):raise ValueError('Unknown Ruby decision status: '+rg['status'])
    status='rejected_static_contradiction' if rejected else 'partial_unresolved_conditions' if holes else 'candidate_not_disproved'
    counts[status]+=1;cause.update(set(x['kind'] for x in rejected+holes))
    r={'iteration':a.iteration,'profile':profile,'baseline_path_id':p['path_id'],'entrypoint_id':p['entrypoint_id'],'ruby_prefix_id':pid,'native_tail_id':p['native_tail_id'],'baseline_terminal_site_id':p['terminal_site_id'],'status':status,'contradictions':rejected,'unresolved_conditions':holes,'terminal_site_id':p['terminal_site_id'] if status=='candidate_not_disproved' else None,'runtime_verified':False,'source_to_sink_argument_flow_established':False}
    out.write(json.dumps(r,separators=(',',':'))+'\n')
   summary[profile]={'baseline_paths':sum(counts.values()),'status_counts':dict(counts),'cause_path_counts_overlapping':dict(cause),'unique_prefixes':len(prefix_results),'note':'Survivors are not independently verified chains. No new route/flow coverage added by this filtering overlay; source-backed coverage additions remain separate until integrated.'}
 for name,rs in [('lookup_support',list(used_lookup.values())),('deferred_support',list(used_regions.values()))]:
  with (O/f'{name}.jsonl').open('w') as f:
   for r in rs:f.write(json.dumps(r)+'\n')
 (O/'summary.json').write_text(json.dumps(summary,indent=2));frozen=[{'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)} for p in inputs];outputs=[{'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(O.glob('*')) if p.is_file()];manifest={'iteration':a.iteration,'invocation':sys.argv,'script_snapshot':str(O/'analyzer_source.py'),'script_reproduction':'Place analyzer_source.py under the v3 scripts directory before invocation so relative artifact roots remain correct.','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_dataset_id':'97267dd258e01a46620e45d398eee914e53c46e431bae5b4ff5f1354bab1a849','inputs':frozen,'outputs':outputs};manifest['iteration_id']=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest();(O/'freeze_manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({'iteration_id':manifest['iteration_id'],'summary':summary},indent=2))
if __name__=='__main__':main()
