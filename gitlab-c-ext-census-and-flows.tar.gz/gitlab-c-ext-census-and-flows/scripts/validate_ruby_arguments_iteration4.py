import collections,hashlib,json,pathlib
V=pathlib.Path(__file__).resolve().parents[1];B=pathlib.Path('/workspace/gitlab_c_ext_trace')
def rows(p):
 with open(p) as f:
  for l in f:yield json.loads(l)
checks=0;errors=[];counts={};hashes={}
def check(v,label):
 global checks
 checks+=1
 if not v:errors.append(label)
for profile in ('ce','ee'):
 F=pathlib.Path('/workspace/gitlab_c_ext_frontend_v2' if profile=='ce' else '/workspace/gitlab_c_ext_ee_profile')
 paths={r['path_id']:r for r in rows(F/'tables/frontend_paths.jsonl')};hops={r['hop_id']:r for r in rows(F/'tables/frontend_ruby_hops.jsonl')};calls={r['call_id']:r for r in rows(V/'tables'/f'{profile}_path_ruby_calls.jsonl')}
 tables={}
 for stem,key in [('ruby_argument_facts','fact_id'),('ruby_argument_bindings','binding_id'),('ruby_path_decisions','decision_id')]:
  rs=list(rows(V/'tables'/f'{profile}_{stem}_iteration4.jsonl'));check(len({r[key] for r in rs})==len(rs),profile+stem+' PK');tables[stem]=rs
 facts={r['fact_id']:r for r in tables['ruby_argument_facts']};bindings={r['binding_id']:r for r in tables['ruby_argument_bindings']}
 for r in facts.values():
  c=calls.get(r['call_id']);h=hops.get(r['hop_id']);check(c is not None and h is not None,r['fact_id']+' FK')
  if c:check((r['file'],r['line'],r['method_id'])==(c['file'],c['line'],c['enclosing_method_id']),r['fact_id']+' source metadata')
  if r['file'] not in hashes:hashes[r['file']]=hashlib.sha256((B/r['file']).read_bytes()).hexdigest()
  check(hashes[r['file']]==r['source_sha256'],r['fact_id']+' source hash')
  check(r['status']!='incompatible' or r['unreachable'],r['fact_id']+' contradiction flag')
  if profile=='ee':check(not r['file'].startswith('sources/gitlab/'),r['fact_id']+' profile scope')
 for r in bindings.values():
  check(r['source_call_id'] in calls and r['hop_id'] in hops,r['binding_id']+' FK')
  check(r['status']!='unknown_binding' or bool(r['reasons']),r['binding_id']+' actual uncertainty')
  check(r['status']!='bound_under_exact_dispatch' or not r['reasons'] and r['arguments'] is not None and not r['arguments']['unresolved'],r['binding_id']+' bound contract')
  if profile=='ee':check(not any(r[k].startswith('sources/gitlab/') for k in ('source_file','target_file')),r['binding_id']+' profile scope')
 decisions=tables['ruby_path_decisions'];check({r['path_id'] for r in decisions}==set(paths),profile+' exact population');check(len(decisions)==len(paths),profile+' population uniqueness')
 for r in decisions:
  check(r['ruby_prefix_id']==paths[r['path_id']]['ruby_prefix_id'],r['decision_id']+' prefix FK')
  evidence=[facts.get(x['fact_id']) for x in r['evidence']];check(all(e is not None for e in evidence),r['decision_id']+' evidence FK')
  check(all(x in bindings for x in r['unresolved_transfer_binding_ids']),r['decision_id']+' binding FK')
  check(r['status']!='contradicted' or any(e and e['status']=='incompatible' for e in evidence),r['decision_id']+' contradiction evidence')
  check(r['status']!='unresolved' or bool(r['unresolved_transfer_binding_ids']) or any(e and any(g['compatible'] is None for g in e['guards']) for e in evidence),r['decision_id']+' concrete unresolved')
 affected=list(rows(V/'tables'/f'{profile}_ruby_argument_affected_paths_iteration4.jsonl'));check({r['path_id'] for r in affected}=={r['path_id'] for r in decisions if r['status']=='contradicted'},profile+' affected equivalence')
 counts[profile]={k:len(v) for k,v in tables.items()};counts[profile]['statuses']=dict(collections.Counter(r['status'] for r in decisions))
for profile in ('ce','ee'):
 summaries=list(rows(V/'tables'/f'{profile}_fixed_json_summaries_iteration4.jsonl'));check(len(summaries)==len({r['summary_id'] for r in summaries}),profile+' summary PK')
 for r in summaries:
  check(hashlib.sha256((B/r['file']).read_bytes()).hexdigest()==r['source_sha256'],r['summary_id']+' source hash')
  if r.get('data_file'):check(hashlib.sha256((B/r['data_file']).read_bytes()).hexdigest()==r['sha256'],r['summary_id']+' retained JSON hash')
report=dict(status='pass' if not errors else 'fail',checks=checks,errors=errors,counts=counts,source_hashes_checked=len(hashes),scope='Structural integrity and source agreement; semantic exclusion review is separate.')
(V/'reports/ruby_arguments_iteration4_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if errors:raise SystemExit(1)
