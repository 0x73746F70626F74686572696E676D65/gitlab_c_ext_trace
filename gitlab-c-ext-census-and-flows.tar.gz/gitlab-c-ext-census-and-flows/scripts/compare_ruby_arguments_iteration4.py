import collections,json,pathlib
V=pathlib.Path(__file__).resolve().parents[1];out={}
for profile in ('ce','ee'):
 def facts(iteration):
  with open(V/'tables'/f'{profile}_ruby_argument_facts_iteration{iteration}.jsonl') as f:return {(r['ruby_prefix_id'],r['hop_id']):r for r in map(json.loads,f)}
 old=facts(3);new=facts(4);delta=collections.Counter();improved=[]
 for key,r in new.items():
  a=old[key];delta[(a['status'],r['status'])]+=1
  if a['binding_issues'] and not r['binding_issues']:improved.append(dict(ruby_prefix_id=key[0],hop_id=key[1],call_id=r['call_id'],file=r['file'],line=r['line'],before=a['binding_issues'],after=r['binding_issues']))
 def paths(i):
  with open(V/'tables'/f'{profile}_ruby_path_decisions_iteration{i}.jsonl') as f:return {r['path_id']:r['status'] for r in map(json.loads,f)}
 before=paths(3);after=paths(4);assert set(before)==set(after)
 out[profile]=dict(context_status_transitions={' -> '.join(k):v for k,v in delta.items()},parameter_binding_issues_removed=len(improved),path_status_changes=sum(before[k]!=v for k,v in after.items()),new_exclusions=sum(v=='contradicted' and before[k]!='contradicted' for k,v in after.items()))
 with open(V/'tables'/f'{profile}_ruby_argument_binding_gains_iteration4.jsonl','w') as f:
  for r in improved:f.write(json.dumps(r)+'\n')
(V/'reports/ruby_argument_delta_iteration4.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
