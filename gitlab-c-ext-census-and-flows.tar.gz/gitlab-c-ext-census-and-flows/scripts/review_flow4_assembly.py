#!/usr/bin/env python3
"""Independent frozen-flow structural checks and manually reviewed semantic verdicts."""
import json,hashlib,collections
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_v3');B=Path('/workspace/gitlab_c_ext_trace');cache={};errors=[];checks=0
spec={'tables/request_memory_flows_iteration4.jsonl':'6bab338cbc8b59c2525fe3998d9859e861eaca4f52cf7db9627a062bc4056f0a','tables/request_flow_index_iteration4.jsonl':'c06f00d86cc3307ea6275a562633a3b0d52b51f3f655c27b130af41ff3ea4859','tables/ruby_runtime_contracts_iteration3.jsonl':'d61f8d676e8dbe5ef7b146b3816564164f087cc3cb6d22b9c91fa2d3621d2a9f'}
def walk(x):
 global checks
 if isinstance(x,list):
  for v in x:walk(v)
 elif isinstance(x,dict):
  if x.get('file') and x.get('line') and ('excerpt'in x or 'source_text'in x):
   p=B/x['file']
   if p not in cache:cache[p]=p.read_bytes()
   data=cache[p];lines=data.decode(errors='replace').split('\n');n=x['line'];expected=x.get('excerpt',x.get('source_text'));actual='\n'.join(lines[n-1:x.get('end_line',n)])
   checks+=1
   if expected!=actual:errors.append(dict(file=str(p),line=n,kind='excerpt_mismatch'))
   digest=x.get('source_sha256',x.get('sha256'))
   if digest:
    checks+=1
    if hashlib.sha256(data).hexdigest()!=digest:errors.append(dict(file=str(p),kind='hash_mismatch'))
  for v in x.values():walk(v)

allrows=[]
for rel,sha in spec.items():
 data=(R/rel).read_bytes();checks+=1
 if hashlib.sha256(data).hexdigest()!=sha:errors.append(dict(file=rel,kind='frozen_input_hash'))
 rows=[json.loads(l)for l in data.splitlines()];walk(rows)
 if 'request_memory_flows'in rel:allrows+=rows
verdicts=[]
for f in allrows:
 verdicts.append(dict(flow_id=f['flow_id'],status='source_supported_conditional_flow',runtime_verified=False,source_recipe_not_automatic_graph_proof=True,terminal_site_id=f['terminal_site_id'],reviewed_chain='Main non-organization router mounts API::API; api/v4 prefix and explicit Slack options/interactions mounts; concern before filter verifies request; endpoint reads selected form payload; safe_parse constructs validator; sc_parse String branch derives pointer/length; first unescaped object key invokes rb_str_new before handler callback.',signature_conditions='Secret and timestamp/signature present, age difference<60, secure HMAC comparison succeeds. Future timestamps not rejected by absolute-skew test; no vulnerability inference. No claim arbitrary user can produce valid Slack signature.',request_identity='Rack POST decodes form data, GET.merge(POST), Grape merges route args. Parent nil-array-coercion filter enumerates params, caching decoded payload before signature verifier reads raw body; verification rewind/read does not remove cached params. Selected scalar form payload/no conflicting query or route key required; signature does not establish all merged params integrity.',native_conditions='Nonempty JSON object under validator limits, valid encoding, first simple unescaped key. UTF8 uses original buffer; ASCII-only BINARY conversion uses reviewed Ruby3.3.11 byte-preserving duplicate/relabel model then returned pointer. Other encodings/general transcoding excluded.',remaining_unknown=['actual runtime build/source equivalence','dynamic method/prepend and middleware behavior','real request authentication/admission feasibility','actual String encoding','attacker ability to influence Slack-produced bytes'],memory_control='Content and derived bounded key length; no chosen pointer address, arbitrary length, exploit or vulnerability claim.'))
report=dict(status='PASS'if not errors else'FAIL',frozen_inputs=spec,checks=checks,errors=errors,source_files_checked=len(cache),flows=len(verdicts),conditional_terminal_sites=len({r['terminal_site_id']for r in verdicts}),assembly_review='Two CE Grape Slack routes have source-supported conditional form-payload→Oj validation-phase key-constructor recipes, reusing one existing physical site. Not runtime verified, not a population accuracy sample.',core_review_reuse='Independent flow3 core model review retained; same frozen model bytes reused with stated normal-constructor and ASCII conversion conditions.',key_source_notes=['coerce_nil_params_to_array! enumerates params at common_helpers.rb21, establishing parent form param caching before child Slack verify filter in selected inherited filter ordering.','Request.verify! reads raw body after rewind, does not rewind again; selected cached param case avoids assuming later unread raw stream.','API::Base/Grape registered endpoint instance binding reviewed; declaration is request execution under framework/model conditions, not automatically proven deployed endpoint.'])
(R/'reports/flow4_independent_assembly_review.json').write_text(json.dumps(report,indent=2));(R/'tables/flow4_independent_assembly_review.jsonl').write_text(''.join(json.dumps(x)+'\n'for x in verdicts));print(json.dumps(report,indent=2))
