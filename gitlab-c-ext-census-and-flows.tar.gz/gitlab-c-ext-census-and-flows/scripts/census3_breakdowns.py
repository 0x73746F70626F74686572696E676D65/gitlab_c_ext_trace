#!/usr/bin/env python3
import json,collections,hashlib,csv
from pathlib import Path
B=Path('/workspace/gitlab_c_ext_trace');R=Path('/workspace/gitlab_c_ext_v3');D=R/'audit/candidate_census_iteration3'
def rows(p):
 with p.open() as f:
  for l in f:yield json.loads(l)
pop={r['audit_id']:r for r in rows(D/'path_sample.jsonl')};review=list(rows(D/'census_results.jsonl'));report=json.loads((D/'census_summary.json').read_text());icu=set(report['external_contract_sensitivity']['affected_audit_ids']);wanted={r['path']['terminal_primitive_id']for r in pop.values()}
prims={r['primitive_id']:r for r in rows(B/'tables/c_primitives.jsonl')if r['primitive_id']in wanted};enriched=[]
for r in review:
 x=pop[r['audit_id']];p=prims[x['path']['terminal_primitive_id']];bucket='additional_unreviewed_external_ICU_contracts'if r['audit_id']in icu else {'supported_static_chain':'conditional_source_supported','unresolved':'other_unresolved','contradicted':'contradicted'}[r['status']]
 enriched.append(dict(audit_id=r['audit_id'],path_id=r['path_id'],profile=r['profile'],bucket=bucket,entrypoint_id=x['path']['entrypoint_id'],frontend=('middleware' if 'middleware' in x['exposure'].get('exposure_category','') else x['exposure'].get('kind',x['entrypoint'].get('kind'))),gem=r['gem'],primitive_id=p['primitive_id'],physical_site_id=x['path']['terminal_site_id'],primitive_kind=p.get('primitive_type',p.get('kind',p.get('type'))),operation=p.get('primitive',p.get('callee',p.get('name')))))
def count(rr):return dict(path_records=len(rr),distinct_entrypoints=len({r['entrypoint_id']for r in rr}),entrypoint_ids=sorted({r['entrypoint_id']for r in rr}),distinct_physical_sites=len({r['physical_site_id']for r in rr}),physical_site_ids=sorted({r['physical_site_id']for r in rr}),distinct_primitive_evidence_records=len({r['primitive_id']for r in rr}))
groups=[]
for dims in [('profile',),('bucket',),('profile','bucket'),('frontend',),('gem',),('primitive_kind',),('bucket','frontend'),('bucket','gem'),('bucket','primitive_kind'),('profile','bucket','frontend'),('profile','bucket','gem'),('profile','bucket','primitive_kind')]:
 g=collections.defaultdict(list)
 for r in enriched:g[tuple(r[k]for k in dims)].append(r)
 for key,rr in sorted(g.items(),key=lambda kv:str(kv[0])):groups.append(dict(dimensions=list(dims),values=dict(zip(dims,key)),**count(rr)))
ce={r['physical_site_id']for r in enriched if r['profile']=='ce'};ee={r['physical_site_id']for r in enriched if r['profile']=='ee'}
out=dict(scope='Exact frozen151 candidate census only. Physical-site sets overlap across profiles/buckets; never sum distinct counts as if disjoint. No source-global recall bound.',overall=count(enriched),profile_site_union=dict(ce=len(ce),ee=len(ee),shared=len(ce&ee),union=len(ce|ee),ce_only=len(ce-ee),ee_only=len(ee-ce),shared_site_ids=sorted(ce&ee)),groups=groups)
(D/'census_breakdowns.json').write_text(json.dumps(out,indent=2)+'\n');(D/'census_path_dimensions.jsonl').write_text(''.join(json.dumps(r)+'\n'for r in enriched));print(json.dumps({k:v for k,v in out.items()if k!='groups'},indent=2))

with (D/'census_breakdowns.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['dimensions','profile','bucket','frontend','gem','primitive_kind','path_records','distinct_entrypoints','distinct_physical_sites']);w.writeheader()
 for g in groups:w.writerow(dict(dimensions='|'.join(g['dimensions']),**g['values'],**{k:g[k]for k in ['path_records','distinct_entrypoints','distinct_physical_sites']}))
