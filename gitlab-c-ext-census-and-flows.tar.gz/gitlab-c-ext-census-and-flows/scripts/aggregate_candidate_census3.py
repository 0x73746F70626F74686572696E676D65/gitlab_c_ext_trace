#!/usr/bin/env python3
import json,hashlib,collections
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_v3');D=R/'audit/candidate_census_iteration3';B=Path('/workspace/gitlab_c_ext_trace')
def rows(p):return [json.loads(l)for l in p.open()]
def dump(n,x):(D/n).write_text(json.dumps(x,indent=2)+'\n')
pop=rows(D/'path_sample.jsonl');byid={r['audit_id']:r for r in pop};errors=[];checks=0;cache={}
inputs=[];allr=[]
for owner in ['provenance_validation','native_analysis','edge_audit']:
 p=D/('review_'+owner+'.jsonl');rr=rows(p);inputs.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size));assigned={r['audit_id']for r in rows(D/('assignment_'+owner+'.jsonl'))}
 if assigned!={r['audit_id']for r in rr}:errors.append(dict(kind='assignment_coverage',owner=owner))
 for r in rr:
  base=byid[r['audit_id']];hs=r.get('hops',r.get('per_hop',r.get('perhop')));expected=[h['hop_id']for h in base['ruby_hops']+base['native_hops']]
  checks+=1
  if expected!=[h['hop_id']for h in hs]:errors.append(dict(kind='ordered_hops',audit_id=r['audit_id']))
  if r['path_id']!=base['path']['path_id']:errors.append(dict(kind='path_id',audit_id=r['audit_id']))
  allr.append(dict(audit_id=r['audit_id'],path_id=r['path_id'],profile=r['profile'],gem=base['gem']['name'],status=r['status'],reviewer=owner,review_file=str(p),reason=r.get('reason',r.get('wholechain_reason')),runtime_verified=False))
def walk(x):
 global checks
 if isinstance(x,list):
  for v in x:walk(v)
 elif isinstance(x,dict):
  f=x.get('file');n=x.get('start_line',x.get('line'));expr=x.get('excerpt',x.get('source_text',x.get('context')))
  if f and isinstance(n,int) and isinstance(expr,str):
   if f not in cache:cache[f]=(B/f).read_bytes()
   data=cache[f];ls=data.decode(errors='replace').split('\n');end=x.get('end_line',n+expr.count('\n'));checks+=1
   if '\n'.join(ls[n-1:end])!=expr:errors.append(dict(kind='source_excerpt',file=f,line=n))
   sha=x.get('source_sha256',x.get('sha256'))
   if sha:
    checks+=1
    if hashlib.sha256(data).hexdigest()!=sha:errors.append(dict(kind='source_hash',file=f))
  for v in x.values():walk(v)
for inp in inputs:walk(rows(Path(inp['path'])))
blind=rows(D/'review_root_blind_duplicates.jsonl');walk(blind);reviews={r['audit_id']:r for r in allr};dup=[]
for r in blind:
 primary=reviews[r['audit_id']];v='supported_static_chain'if r['verdict']=='supported_conditional'else r['verdict'];dup.append(dict(audit_id=r['audit_id'],path_id=r['path_id'],assigned_verdict=primary['status'],blind_verdict=v,agree=v==primary['status'],reason=r['reason'],resolution='Preserve original judgments. External ICU contract sensitivity reported family-wide, not silent selective relabel.'if v!=primary['status']else'Independent verdict agreement; detailed prerequisites remain.'))
icu=[r['audit_id']for r in allr if r['gem']=='charlock_holmes'and r['status']=='supported_static_chain'and any(h.get('callee')=='rb_encdec_buildmatch'for h in byid[r['audit_id']]['native_hops'])]
sf=[r['audit_id']for r in allr if any(h['file'].endswith('/date_core.c')and h['line']==8228 for h in byid[r['audit_id']]['native_hops'])]
counts=collections.Counter(r['status']for r in allr);sensitivity=counts.copy();sensitivity['supported_static_chain']-=len(icu);sensitivity['unresolved']+=len(icu)
qualified=[]
for aid in sf:qualified.append(dict(audit_id=aid,path_id=byid[aid]['path']['path_id'],terminal_site_id=byid[aid]['path'].get('terminal_site_id'),qualification='LONG2NUM(sf) invocation supported, but valid nanoseconds0..999999999 fit Fixnum in reviewed32/64-bit tagged VALUE model; selected conversion returns immediate integer. Do not count this terminal as an established heap allocation or request-controlled size.',reason_scope='Terminal effect distinct from source invocation/connectivity; original chain verdict not altered.'))
(D/'census_results.jsonl').write_text(''.join(json.dumps(r)+'\n'for r in sorted(allr,key=lambda r:r['audit_id'])))
dump('blind_duplicate_comparison.json',dup);dump('terminal_memory_effect_qualifications.json',qualified)
contrad=[r for r in allr if r['status']=='contradicted'];dump('contradiction_followup.json',dict(paths=contrad,families=[dict(family='normal_initialized_Time_zone_excludes_Date_today_fallback',audit_ids=['C082','C132','C135','C139'],source_constraints=['Rails configuration default time_zone UTC','active_support.initialize_time_zone assigns Time.zone_default','GitLab time_zone initializer dereferences Time.zone.name','Time.zone getter uses local zone OR default'],repair_boundary='Model initializer invariant only under explicit normal successful boot and no unsupported later global mutation. Do not remove alternate Time.zone.today path.'),dict(family='Ruby3311_encoding_header_excludes_legacy_charlock_macro_arm',audit_ids=['C059','C123'],source_constraints=['runtime Ruby3.3.11 include/ruby.h15 defines HAVE_RUBY_ENCODING_H1','charlock common.h includes ruby.h then conditional #else rb_str_new2'],repair_boundary='Pin source configuration/runtime headers; do not globally remove fallback for all Ruby/build versions.')]))
report=dict(scope='Full census of frozen iteration3 candidate_not_disproved class only; no inference about rejected/partial paths, complete original graph, all endpoints, all gems or runtime reachability.',population=151,profile_population=dict(collections.Counter(r['profile']for r in pop)),iteration_id='5c88395340596b216070e4dcd52395a12ce9d27473b6bc60bf8719306865cdd2',inclusion_probability=1,sampling_uncertainty='None for this exact151-record census; reviewer uncertainty, shared-edge dependence and model/runtime assumptions remain.',primary_disjoint_buckets={'conditional_source_supported':99,'additional_unreviewed_external_ICU_contracts':20,'other_unresolved':26,'contradicted':6},raw_counts=dict(counts),raw_percentages={k:round(v/151*100,3)for k,v in counts.items()},profile_counts={p:dict(collections.Counter(r['status']for r in allr if r['profile']==p))for p in ['ce','ee']},blind_duplicate_count=len(dup),blind_agreement=sum(x['agree']for x in dup),blind_disagreements=[x['audit_id']for x in dup if not x['agree']],external_contract_sensitivity=dict(rule='If retained external ICU detection/name return contracts must themselves be resolved rather than conditional call prerequisites, withhold all supported text-match paths as unresolved.',affected_audit_ids=sorted(icu),affected_count=len(icu),counts=dict(sensitivity),original_judgments_overwritten=False),terminal_effect_qualification=dict(path_records=len(sf),distinct_physical_sites=len({byid[aid]['path']['terminal_site_id'] for aid in sf}),physical_site_ids=sorted({byid[aid]['path']['terminal_site_id'] for aid in sf}),audit_ids=sorted(sf),description='LONG2NUM(sf) selected invocation need not allocate; valid subsecond sf fits immediate Fixnum. Inventory-site connectivity is distinct from actual memory effect.'),precision_interpretation='119 conditional supported chain judgments are not119 observed successful requests or allocations. Six contradicted paths and26 unresolved paths remain in candidate class; no automatic verified label. Primary disjoint buckets separate99 conditional source-supported,20 additional ICU-contract-dependent,26 other unresolved,6 contradicted. Strict source-contract collapse99/46/6 is policy sensitivity, not new ground truth. Do not present a runtime accuracy percentage.',validation=dict(status='PASS'if not errors else'FAIL',checks=checks,source_files=len(cache),errors=errors),review_inputs=inputs)
dump('census_summary.json',report)
manifest=[D/n for n in ['census_breakdowns.json','census_breakdowns.csv','census_path_dimensions.jsonl','census_review.txt','path_sample.jsonl','census_results.jsonl','census_summary.json','blind_duplicate_comparison.json','terminal_memory_effect_qualifications.json','contradiction_followup.json']]+[Path(i['path'])for i in inputs]+[D/'review_root_blind_duplicates.jsonl']
dump('publication_freeze.json',dict(files=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)for p in manifest],immutable_prior_graph=True))
print(json.dumps(report,indent=2))
