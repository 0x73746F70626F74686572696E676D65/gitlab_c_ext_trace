import argparse,collections,copy,hashlib,json,pathlib,re,time
from ruby_argument_flow_iteration4 import FlowSource,FlowReturn,unknown
from fixed_json_iteration4 import FixedJSON
V=pathlib.Path(__file__).resolve().parents[1];B=pathlib.Path('/workspace/gitlab_c_ext_trace')
def rows(p):
 with open(p) as f:
  for l in f:yield json.loads(l)
def uid(*args):return hashlib.sha256('\0'.join(map(str,args)).encode()).hexdigest()[:24]
def alias_shape(pack):
 seen=collections.defaultdict(list)
 def visit(v,path):
  if isinstance(v,dict):
   if v.get('kind') in ('Hash','Array','String'):seen[id(v)].append(path)
   for k,x in v.items():visit(x,path+'.'+str(k))
  elif isinstance(v,list):
   for i,x in enumerate(v):visit(x,path+'['+str(i)+']')
 visit(pack,'args');return sorted(sorted(paths) for paths in seen.values() if len(paths)>1)
def excluded(file):return any(x in file for x in ('/spec/','/test/','/tests/','/fixtures/','/qa/','/examples/','/benchmark/','/vendor/'))
class Repo:
 def __init__(self,methods,inheritance,bare_calls=()):
  self.bare_calls=set(bare_calls);self.methods=methods;self.bykey=collections.defaultdict(list);self.sources={};self.nodes={};self.calls={};self.cache={};self.active=[];self.prepended={r['owner'] for r in inheritance if r['kind']=='prepend'}
  for m in methods.values():self.bykey[(m['namespace'],m['method'],m['kind'])].append(m)
  self.owners={m['namespace'] for m in methods.values()};self.fixed=FixedJSON(self,B)
 def source(self,file):
  if file not in self.sources:
   src=FlowSource((B/file).read_bytes(),file);src.summary_resolver=self.summary;self.sources[file]=src
   index=collections.defaultdict(list);todo=[src.tree.root_node]
   while todo:
    n=todo.pop()
    if n.type in ('call','identifier'):index[n.start_byte].append(n)
    todo.extend(n.named_children)
   self.calls[file]=index
  return self.sources[file]
 def method(self,mid):
  if mid not in self.nodes:
   m=self.methods[mid];s=self.source(m['file']);opts=[n for n in s.methods.get(m['method'],[]) if n.start_point.row+1==m['line']];self.nodes[mid]=opts[0] if len(opts)==1 else None
  return self.nodes[mid]
 def call(self,c):
  s=self.source(c['file']);opts=[n for n in self.calls[c['file']].get(c['byte_offset'],[]) if (n.type=='call' and s.text(s.field(n,'method'))==c['method'] and s.text(s.field(n,'receiver'))==c.get('receiver','')) or (n.type=='identifier' and c['call_id'] in self.bare_calls and s.text(n)==c['method'] and not c.get('receiver'))]
  return opts[0] if len(opts)==1 else None
 def owner_candidates(self,name,context):
  if name.startswith('::'):return {name.lstrip(':')} if name.lstrip(':') in self.owners else set()
  parts=context.split('::') if context else [];names={name}|{'::'.join(parts[:i]+[name]) for i in range(len(parts),0,-1)}
  return names&self.owners
 def summary(self,src,node,env,depth):
  builtin=self.fixed.builtin(src,node,env,depth)
  if builtin is not None:return builtin
  recv=src.field(node,'receiver');name=src.text(src.field(node,'method'));current=src.context_stack[-1] if src.context_stack else ((),'instance')
  if name in ('new','send','public_send','__send__','eval','class_eval','module_eval','instance_eval') or src.field(node,'block') is not None:return None
  if recv is None or src.text(recv)=='self':owners={'::'.join(current[0])};kind=current[1]
  elif re.fullmatch(r'(?:::)?[A-Z]\w*(?:::[A-Z]\w*)*',src.text(recv)):
   owners=self.owner_candidates(src.text(recv),'::'.join(current[0]));kind='singleton'
  else:return None
  if len(owners)!=1:return None
  owner=next(iter(owners));opts=self.bykey.get((owner,name,kind),[])
  if len(opts)!=1 or kind=='instance' and owner in self.prepended:return None
  m=opts[0];mid=m['method_id']
  if mid in self.active or len(self.active)>=4:return None
  target=self.method(mid)
  if target is None or target.has_error:return None
  other=self.source(m['file'])
  if other.method_context[target.start_byte][2]:return None
  pack=src.argument_pack(node,env)
  if pack['unresolved']:return None
  self.active.append(mid)
  try:
   result=self.fixed.memo(other,target,m) if not pack['positional'] and not pack['keywords'] else None
   if result is None:result=other.eval_method(target,pack['positional'],pack['keywords'],depth+1)
  finally:self.active.pop()
  src.invalidate(list(env.values()));src.note(node,'exact_owner_source_summary_conditional_normal_dispatch')
  src.flow_notes.append(dict(file=src.file,line=node.start_point.row+1,target_method_id=mid,target_file=m['file'],target_line=m['line'],abstract_return=copy.deepcopy(result)))
  return result

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--profile',choices=['ce','ee'],required=True);a=ap.parse_args();start=time.time()
 G=pathlib.Path('/workspace/gitlab_c_ext_ruby_expanded' if a.profile=='ce' else '/workspace/gitlab_c_ext_ee_profile');F=pathlib.Path('/workspace/gitlab_c_ext_frontend_v2') if a.profile=='ce' else G
 contract=json.load(open(G/'reports/frontend_input_contract.json'));prefixes=tuple(contract['gitlab_source_prefixes'])
 primary={g['gem_id'] for g in rows(B/'tables/gems.jsonl') if g.get('lockfile')=='Gemfile.lock'} if a.profile=='ce' else set(json.load(open(G/'reports/profile_config.json'))['primary_gem_ids']);gfiles={r['file_id'] for r in rows(G/'tables/ruby_file_gems.jsonl') if r['gem_id'] in primary}
 def eligible(r):return not excluded(r['file']) and not(a.profile=='ee' and r['file'].startswith('sources/gitlab/')) and (r['file'].startswith(prefixes) or r['file_id'] in gfiles)
 methods={r['method_id']:r for r in rows(G/'tables/ruby_methods.jsonl') if eligible(r)};inheritance=[r for r in rows(G/'tables/ruby_inheritance.jsonl') if eligible(r)];repo=Repo(methods,inheritance,{r['call_id'] for r in rows(G/'tables/ruby_ambiguous_identifier_classification.jsonl') if r['classification']=='syntactic_vcall'})
 lookup={r['edge_id']:r['decision'] for r in rows(V/'tables'/f'{a.profile}_lookup_edge_summary.jsonl')};targets=collections.defaultdict(set)
 for e in rows(G/'tables/ruby_dispatch_edges.jsonl'):
  if e.get('primary_bundle_compatible') is True and lookup.get(e['edge_id']) not in ('shadowed','unresolved'):targets[e['source_call_id']].add((e['target_type'],e['target_id']))
 calls={r['call_id']:r for r in rows(V/'tables'/f'{a.profile}_path_ruby_calls.jsonl')};hops={r['hop_id']:r for r in rows(F/'tables/frontend_ruby_hops.jsonl')};paths=list(rows(F/'tables/frontend_paths.jsonl'));used={p['ruby_prefix_id'] for p in paths};bindings=[];facts=[];badprefix=set();reasons=collections.Counter();cache={};not_examined=collections.defaultdict(set)
 for prefix in rows(F/'tables/frontend_ruby_prefixes.jsonl'):
  if prefix['prefix_id'] not in used:continue
  incoming=None;incoming_mid=None;incompatible=False
  for hid in prefix['hops']:
   hop=hops[hid];cid=hop.get('call_id')
   if cid not in calls:continue
   c=calls[cid];mid=c.get('enclosing_method_id');md=methods.get(mid);src=repo.source(c['file']);node=repo.call(c)
   if node is None or md is None:
    incoming=None;incoming_mid=None;reasons['missing_exact_AST_or_method']+=1;not_examined[prefix['prefix_id']].add(cid);continue
   method=repo.method(mid)
   if method is None or method.has_error or node.has_error:incoming=None;incoming_mid=None;reasons['source_parse_error_or_missing_method']+=1;not_examined[prefix['prefix_id']].add(cid);continue
   pack=incoming if incoming_mid==mid else None
   key=(cid,json.dumps(dict(arguments=pack,aliases=alias_shape(pack)),sort_keys=True))
   if key not in cache:
    initial,bind_issues=src.bind_explicit(method,pack);src.evidence=[];src.flow_notes=[]
    state=src.env_at(method,node,initial)
    try:
     src.context_stack.append(src.method_context[method.start_byte][:2]);arguments=src.argument_pack(node,state['env']) if not state['unreachable'] else dict(positional=[],keywords={},unresolved=['unreachable_call'])
    except FlowReturn:arguments=dict(positional=[],keywords={},unresolved=['return_inside_argument_context'])
    finally:src.context_stack.pop()
    cache[key]=dict(formal_values=copy.deepcopy(initial),binding_issues=bind_issues,guards=state['guards'],unreachable=state['unreachable'],reason=state.get('reason'),unsupported=state['unsupported'],arguments=arguments,source_evidence=copy.deepcopy(src.evidence),source_summaries=copy.deepcopy(src.flow_notes))
   result=copy.deepcopy(cache[key]);status='incompatible' if result['unreachable'] else 'unknown' if any(g['compatible'] is None for g in result['guards']) or result['binding_issues'] else 'no_contradiction_found'
   if status=='incompatible':badprefix.add(prefix['prefix_id']);incompatible=True
   facts.append(dict(fact_id='argfact4_'+uid(a.profile,prefix['prefix_id'],hid),profile=a.profile,ruby_prefix_id=prefix['prefix_id'],hop_id=hid,call_id=cid,method_id=mid,file=c['file'],line=c['line'],source_sha256=hashlib.sha256(src.data).hexdigest(),status=status,**result))
   target=hop.get('target_id');targetmd=methods.get(target) if hop.get('target_type')=='ruby_method' else None;incoming=None;incoming_mid=None
   if targetmd is None:continue
   kind='singleton' if c.get('receiver_kind') in ('constant','self_singleton') else 'instance';owners=repo.owner_candidates(c.get('receiver_class',''),c.get('namespace','')) if c.get('receiver_class') else set();direct=targetmd['namespace'] in owners and len(owners)==1 and targetmd['kind']==kind
   uncertain=[]
   if c.get('receiver_kind') not in ('constant','self_singleton','self_instance','constructor_result'):uncertain.append('receiver_not_exact_direct_or_lexical_self')
   if not direct:uncertain.append('receiver_owner_or_method_kind_not_exact')
   if len(targets.get(cid,()))!=1:uncertain.append('multiple_or_unresolved_dispatch_targets')
   if lookup.get(hop.get('edge_id')) in ('shadowed','unresolved'):uncertain.append('lookup_overlay_not_resolved')
   if result['arguments']['unresolved']:uncertain.append('argument_pack_unresolved')
   if incompatible:uncertain.append('earlier_selected_prefix_incompatible')
   if kind=='instance' and targetmd['namespace'] in repo.prepended:uncertain.append('prepend_receiver_order_unresolved')
   if not uncertain:incoming=copy.deepcopy(result['arguments']);incoming_mid=target
   bindings.append(dict(binding_id='argbind4_'+uid(a.profile,prefix['prefix_id'],hid,target),profile=a.profile,ruby_prefix_id=prefix['prefix_id'],hop_id=hid,source_call_id=cid,target_method_id=target,status='bound_under_exact_dispatch' if not uncertain else 'unknown_binding',reasons=uncertain,conditions=['Selected source target invocation assumed; constructor_result additionally assumes ordinary constructor protocol and declared result class'] if c.get('receiver_kind')=='constructor_result' else ['Selected exact source target invocation assumed'],arguments=copy.deepcopy(result['arguments']) if not uncertain else None,source_file=c['file'],source_line=c['line'],target_file=targetmd['file'],target_line=targetmd['line']))
 with (V/'tables'/f'{a.profile}_fixed_json_summaries_iteration4.jsonl').open('w') as out:
  for r in {r['summary_id']:r for r in repo.fixed.records}.values():out.write(json.dumps(r)+'\n')
 for name,rs in [('facts',facts),('bindings',bindings)]:
  with (V/'tables'/f'{a.profile}_ruby_argument_{name}_iteration4.jsonl').open('w') as f:
   for r in rs:f.write(json.dumps(r)+'\n')
 affected=[dict(path_id=p['path_id'],ruby_prefix_id=p['ruby_prefix_id'],reason='selected_Ruby_call_guard_incompatible_with_bound_source_values') for p in paths if p['ruby_prefix_id'] in badprefix]
 with (V/'tables'/f'{a.profile}_ruby_argument_affected_paths_iteration4.jsonl').open('w') as f:
  for r in affected:f.write(json.dumps(r)+'\n')
 fby=collections.defaultdict(list);bby=collections.defaultdict(list)
 for fact in facts:fby[fact['ruby_prefix_id']].append(fact)
 for binding in bindings:bby[binding['ruby_prefix_id']].append(binding)
 path_decisions=[]
 for path in paths:
  pid=path['ruby_prefix_id'];fs=fby[pid];bs=bby[pid];bad=[f for f in fs if f['status']=='incompatible'];guard_unknown=[f for f in fs if any(g['compatible'] is None for g in f['guards'])];transfers=[b for b in bs if b['status']=='unknown_binding']
  status='contradicted' if bad else 'unresolved' if guard_unknown or transfers else 'no_extracted_contradiction'
  selected=bad or guard_unknown
  path_decisions.append(dict(decision_id='argpath4_'+uid(a.profile,path['path_id']),profile=a.profile,path_id=path['path_id'],ruby_prefix_id=pid,status=status,reason='selected_call_guard_incompatible_with_bound_values' if bad else 'specific_guard_or_argument_transfer_unresolved' if guard_unknown or transfers else 'no_contradiction_in_examined_call_contexts',evidence=[dict(fact_id=f['fact_id'],call_id=f['call_id'],file=f['file'],line=f['line'],guards=f['guards'],formal_values=f['formal_values'],source_summaries=f['source_summaries']) for f in selected],unresolved_transfer_binding_ids=[b['binding_id'] for b in transfers],not_examined_call_ids=sorted(not_examined[pid]),analysis_scope='partially_examined' if not_examined[pid] else 'selected_prefix_examined',conditions=['Literal/builtin semantics and selected exact source dispatch; no runtime proof'],not_a_runtime_verdict=True))
 with (V/'tables'/f'{a.profile}_ruby_path_decisions_iteration4.jsonl').open('w') as f:
  for r in path_decisions:f.write(json.dumps(r)+'\n')
 report=dict(iteration=4,profile=a.profile,selected_prefixes=len(used),path_decision_statuses=dict(collections.Counter(r['status'] for r in path_decisions)),context_facts=len(facts),context_bindings=len(bindings),unique_call_contexts=len(cache),fact_statuses=dict(collections.Counter(r['status'] for r in facts)),binding_statuses=dict(collections.Counter(r['status'] for r in bindings)),binding_unresolved_reasons=dict(collections.Counter(x for r in bindings for x in r['reasons'])),incompatible_prefixes=len(badprefix),affected_baseline_paths=len(affected),sources=len(repo.sources),skipped=dict(reasons),elapsed_seconds=round(time.time()-start,2),limitations=['Selected frozen witness prefixes only; no whole-program graph regeneration.','Facts are conditional on exact selected source dispatch and normal builtin semantics, not execution proof.','Splats/kwargs forwarding, alias mutation, ambiguous dispatch, prepend ordering and unsupported control contexts remain unknown.','Request-origin/user influence is not modeled by this branch-compatibility pass.','Fixed-file JSON and memoized singleton root summaries require recognized ordinary parser and explicit normal-state conditions. Custom adapters/global option defaults remain unresolved.'])
 (V/'reports'/f'{a.profile}_ruby_arguments_iteration4.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if __name__=='__main__':main()
