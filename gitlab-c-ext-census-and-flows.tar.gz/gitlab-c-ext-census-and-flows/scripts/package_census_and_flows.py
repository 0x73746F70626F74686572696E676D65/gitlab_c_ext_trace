#!/usr/bin/env python3
"""Package frozen census3, binding4 and reviewed flows; no publication or iteration5."""
import gzip,hashlib,io,json,shutil,tarfile
from pathlib import Path
from package_v3_publication import digest,verify_manifest
R=Path('/workspace/gitlab_c_ext_v3');D=R/'publication/census-and-flows'
def main():
 required=['audit/candidate_census_iteration3/publication_freeze.json','reports/ruby_arguments_iteration4_manifest.json','reports/iteration4_graphql_freeze.json','reports/flow4_independent_assembly_review.json','reports/flow4_graphql_independent_assembly_review.json','reports/request_flow_index_iteration4_final_checksums.json']
 for n in required:assert (R/n).exists(),('pending final artifact',n)
 checks=[dict(manifest=n,verified_files=verify_manifest(R/n)) for n in required[:3]+[required[-1]]]
 for n in required[3:5]:assert json.loads((R/n).read_text())['status']=='PASS'
 for item in json.loads((R/required[2]).read_text()).get('frozen_inputs',[]):
  p=Path(item['path']);p=p if p.is_absolute() else R/p
  assert digest(p)==item['sha256']
 checks[2]['verified_files']+=len(json.loads((R/required[2]).read_text()).get('frozen_inputs',[]))
 priors=[R/'publication/gitlab-c-ext-v3.tar.gz',R/'publication/gitlab-c-ext-iteration3.tar.gz'];ph={str(p):digest(p) for p in priors}
 stage=D/'gitlab-c-ext-census-and-flows';D.mkdir(parents=True,exist_ok=True)
 if stage.exists():shutil.rmtree(stage)
 stage.mkdir();selected=set()
 patterns=['audit/candidate_census_iteration3/*','reports/*iteration4*.json','reports/*iteration4*.txt','reports/flow4*review.json','reports/request_flow_union_final*.json','tables/*iteration4*.jsonl','tables/flow4*review.jsonl','tables/request_flow_union_final*.jsonl','fixtures/*iteration4*','schemas/*iteration4*','scripts/*iteration4*.py','scripts/*census*.py','scripts/review_flow4*.py','scripts/package_census_and_flows.py','scripts/package_v3_publication.py','scripts/*flow_union*.py','tests/*iteration4*.py']
 for pat in patterns:
  for p in R.glob(pat):
   if p.is_file() and p.suffix not in ('.log','.pyc') and 'iteration5' not in str(p):selected.add(p)
 # The identical-status full Ruby ledgers remain explicitly referenced, not silently dropped.
 omit={f'{profile}_ruby_path_decisions_iteration4.jsonl' for profile in ('ce','ee')}
 omitted=[p for p in selected if p.name in omit];selected-=set(omitted)
 for p in sorted(selected):
  dst=stage/p.relative_to(R);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
 (stage/'omitted_local_artifacts.json').write_text(json.dumps([dict(path=str(p.relative_to(R)),durable_location=str(p),sha256=digest(p),bytes=p.stat().st_size,rows=sum(1 for _ in p.open('rb')),reason='zero per-path status changes; existing full iteration3 path ledger remains authoritative for census') for p in omitted],indent=2)+'\n')
 (stage/'prerequisites.json').write_text(json.dumps(dict(prior_archives=ph,source_root='/workspace/gitlab_c_ext_trace',analysis_root=str(R),audited_revision='5c88395340596b216070e4dcd52395a12ce9d27473b6bc60bf8719306865cdd2',standalone=False),indent=2)+'\n')
 (stage/'INDEX.txt').write_text((D/'INDEX.txt').read_text())
 catalog=[dict(path=str(p.relative_to(stage)),bytes=p.stat().st_size,sha256=digest(p),rows=sum(1 for _ in p.open('rb')) if p.suffix=='.jsonl' else None) for p in sorted(stage.rglob('*')) if p.is_file()]
 paths={x['path'] for x in catalog};assert sum(1 for p in paths if p.startswith('audit/candidate_census_iteration3/C') and p.endswith('_dossier.txt'))==151
 census=[json.loads(l) for l in (stage/'audit/candidate_census_iteration3/census_results.jsonl').open()];assert len(census)==151
 population=[json.loads(l) for l in (stage/'audit/candidate_census_iteration3/path_sample.jsonl').open()]
 assert {x['path_id'] for x in census}=={x['path']['path_id'] for x in population}
 assert len([json.loads(l) for l in (stage/'tables/request_flow_index_iteration4_final.jsonl').open()])==13
 assert not any('iteration5' in p for p in paths)
 (stage/'table_catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
 (stage/'package_validation.json').write_text(json.dumps(dict(status='PASS',freeze_checks=checks,census_records=151,census_dossiers=151,files=len(catalog),bytes=sum(x['bytes'] for x in catalog),scope='Frozen-file agreement, complete census membership, archive content checks; no runtime claim'),indent=2)+'\n')
 (stage/'SHA256SUMS').write_text(''.join(f'{digest(p)}  {p.relative_to(stage)}\n' for p in sorted(stage.rglob('*')) if p.is_file()))
 arc=R/'publication/gitlab-c-ext-census-and-flows.tar.gz'
 with arc.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0,compresslevel=9) as gz,tarfile.open(fileobj=gz,mode='w') as t:
  for p in sorted(stage.rglob('*')):
   if p.is_file():
    info=tarfile.TarInfo('gitlab-c-ext-census-and-flows/'+str(p.relative_to(stage)));info.size=p.stat().st_size;info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(p.read_bytes()))
 expected={'gitlab-c-ext-census-and-flows/'+str(p.relative_to(stage)):digest(p) for p in stage.rglob('*') if p.is_file()}
 with tarfile.open(arc,'r:gz') as t:actual={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers()}
 assert actual==expected
 assert all(digest(Path(p))==h for p,h in ph.items())
 result=dict(status='PASS',archive=str(arc),bytes=arc.stat().st_size,sha256=digest(arc),members=len(actual),prior_archives_preserved=True)
 (D/'archive_validation.json').write_text(json.dumps(result,indent=2)+'\n');(D/'SHA256SUMS').write_text(f"{result['sha256']}  {arc.name}\n");print(json.dumps(result))
if __name__=='__main__':main()
