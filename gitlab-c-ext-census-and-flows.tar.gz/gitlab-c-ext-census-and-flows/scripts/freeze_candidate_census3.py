import json,hashlib
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_v3');B=Path('/workspace/gitlab_c_ext_trace');D=R/'audit/candidate_census_iteration3';D.mkdir(parents=True,exist_ok=True)
def rows(p):
 with p.open()as f:
  for l in f:yield json.loads(l)
def idx(p,k):return {x[k]:x for x in rows(p)}
I=R/'iterations/iteration3';fm=json.loads((I/'freeze_manifest.json').read_text());pop={x['baseline_path_id']:x for x in rows(I/'path_decisions.jsonl')if x['status']=='candidate_not_disproved'};prior={}
for d in [B/'audit/end_to_end_20260930',R/'audit/holdout_20260930',R/'audit/holdout2_20260930',R/'audit/holdout3_20260930']:
 for x in rows(d/'path_sample.jsonl'):prior[x['path']['path_id']]=x['audit_id']
nt=idx(B/'tables/frontend_native_tails.jsonl','tail_id');nh=idx(B/'tables/frontend_native_hops.jsonl','hop_id');g=idx(B/'tables/gems.jsonl','gem_id');out=[]
for profile,root in [('ce',Path('/workspace/gitlab_c_ext_frontend_v2')),('ee',Path('/workspace/gitlab_c_ext_ee_profile'))]:
 t=root/'tables';en=idx(t/'frontend_entrypoints.jsonl','entrypoint_id');ex=idx(t/'frontend_exposure.jsonl','entrypoint_id');pr=idx(t/'frontend_ruby_prefixes.jsonl','prefix_id');rh=idx(t/'frontend_ruby_hops.jsonl','hop_id')
 for p in rows(t/'frontend_paths.jsonl'):
  if p['path_id']not in pop:continue
  hs=[rh[h]for h in pr[p['ruby_prefix_id']]['hops']];ns=[nh[h]for h in nt[p['native_tail_id']]['hops']]
  out.append(dict(profile=profile,root=str(root),path=p,entrypoint=en[p['entrypoint_id']],exposure=ex[p['entrypoint_id']],ruby_hops=hs,native_hops=ns,native_tail=nt[p['native_tail_id']],gem=g[p['gem_id']],length=len(hs)+len(ns),stratum=profile+'|'+en[p['entrypoint_id']]['kind']+'|'+g[p['gem_id']]['name'],prior_review_id=prior.get(p['path_id']),inclusion_probability=1,decision=pop[p['path_id']]))
out.sort(key=lambda x:(x['profile'],x['path']['path_id']))
for i,x in enumerate(out):x['audit_id']=f'C{i+1:03}'
p=D/'path_sample.jsonl';p.write_text(''.join(json.dumps(x)+'\n'for x in out));assert len(out)==151
(D/'census_freeze.json').write_text(json.dumps(dict(iteration_id=fm['iteration_id'],population='All frozen iteration3 candidate_not_disproved paths, both profiles; partial/rejected paths excluded by stated target population.',design='Full census, not novelty sample; inclusion1/no sampling uncertainty for frozen class. Shared-edge/reviewer uncertainty remains.',counts={s:sum(x['profile']==s for x in out)for s in ['ce','ee']},prior_review_overlap=sum(bool(x['prior_review_id'])for x in out),file=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2));print((D/'census_freeze.json').read_text())
