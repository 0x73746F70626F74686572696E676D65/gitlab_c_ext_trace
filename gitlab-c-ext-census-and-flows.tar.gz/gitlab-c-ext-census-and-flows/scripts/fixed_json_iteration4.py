"""Source-qualified fixed-file JSON and ordinary memoization summaries.
Never reads a path unless resolved beneath the pinned source root. No Ruby execution.
"""
import copy,hashlib,json,pathlib
from ruby_argument_flow_iteration4 import unknown,value
class FixedJSON:
 def __init__(self,repo,root):self.repo=repo;self.root=pathlib.Path(root).resolve();self.records=[];self.active=set()
 def record(self,src,n,status,reason,**extra):
  r=dict(file=src.file,line=n.start_point.row+1,byte_offset=n.start_byte,status=status,reason=reason,**extra);r['source_sha256']=hashlib.sha256(src.data).hexdigest();r['summary_id']='fixedjson4_'+hashlib.sha256(json.dumps(r,sort_keys=True).encode()).hexdigest()[:24];self.records.append(r);return r
 def builtin(self,src,n,env,depth):
  recv=src.text(src.field(n,'receiver')).lstrip(':');name=src.text(src.field(n,'method'));an=src.field(n,'arguments');args=list(an.named_children) if an else []
  if src.field(n,'block') is not None:return None
  if recv=='File' and name=='join':
   parts=[]
   for x in args:
    if x.type=='identifier' and src.text(x)=='__dir__':parts.append(str((self.root/src.file).parent))
    else:
     v=src.eval(x,env,depth+1)
     if v.get('kind')!='String' or 'literal' not in v:return unknown()
     parts.append(v['literal'])
   if not parts:return unknown()
   # Only model source-relative __dir__ anchored joins, avoiding platform/path coercion.
   if not args or src.text(args[0])!='__dir__' or any(pathlib.Path(p).is_absolute() for p in parts[1:]):return unknown()
   p=pathlib.Path(parts[0]).joinpath(*parts[1:]).resolve()
   if not p.is_relative_to(self.root):return unknown()
   return dict(kind='String',literal=str(p),fixed_path=str(p.relative_to(self.root)))
  if recv=='File' and name in ('read','binread'):
   if len(args)!=1:return unknown()
   v=src.eval(args[0],env,depth+1)
   if 'fixed_path' not in v:return unknown()
   p=self.root/v['fixed_path']
   if not p.is_file() or p.is_symlink() or p.stat().st_size>1024*1024:return unknown()
   try:data=p.read_bytes();literal=data.decode('utf-8')
   except (OSError,UnicodeError):return unknown()
   ev=self.record(src,n,'supported_conditional','fixed_source_file_read',data_file=v['fixed_path'],sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),conditions=['File bytes at read equal pinned source bytes; ordinary File semantics; successful normal return'])
   return dict(kind='String',literal=literal,fixed_file=ev)
  if (recv,name) in (('JSON','parse'),('JSON','parse!'),('Oj','strict_load')):
   if len(args)!=1:return unknown()
   v=src.eval(args[0],env,depth+1)
   if v.get('kind')!='String' or 'fixed_file' not in v or 'literal' not in v:return unknown()
   def no_constants(x):raise ValueError(x)
   def no_duplicates(xs):
    d={}
    for k,vv in xs:
     if k in d:raise ValueError('duplicate key')
     d[k]=vv
    return d
   try:obj=json.loads(v['literal'],parse_constant=no_constants,object_pairs_hook=no_duplicates)
   except (ValueError,TypeError):return unknown()
   kind='Hash' if isinstance(obj,dict) else 'Array' if isinstance(obj,list) else 'Nil' if obj is None else 'Boolean' if isinstance(obj,bool) else 'String' if isinstance(obj,str) else 'Integer' if isinstance(obj,int) else 'Float'
   ev=self.record(src,n,'supported_conditional','ordinary_JSON_root_type',parser_owner=recv,parser_method=name,root_kind=kind,file_evidence=v['fixed_file'],conditions=['Ordinary parser without replacement, custom object classes or object-addition hooks; successful normal return','Only root type summarized; mutable contents and callbacks not proven'])
   result=dict(kind=kind,fixed_json_summary=ev)
   if kind=='Hash':result.update(items={},closed=False)
   if kind=='Array':result.update(items=[],closed=False)
   return result
  return None
 def memo(self,src,method,metadata):
  body=src.field(method,'body');parts=[x for x in body.named_children if x.type!='comment'] if body else []
  if len(parts)!=1 or parts[0].type!='operator_assignment':return None
  stmt=parts[0];lhs=src.field(stmt,'left');rhs=src.field(stmt,'right')
  if not lhs or lhs.type!='instance_variable' or src.text(src.field(stmt,'operator'))!='||=' or metadata['kind']!='singleton':return None
  key=(metadata['namespace'],src.text(lhs))
  if key in self.active:return unknown()
  # Audit all source method definitions known for this exact owner, never ivar-name alone.
  writer=[];files=set()
  for m in self.repo.methods.values():
   if m['namespace']==metadata['namespace']:files.add(m['file'])
  dynamic_writes=[]
  for file in files:
   other=self.repo.source(file)
   def visit(q,owner=(),kind='singleton',method_kind='instance'):
    if q.type in ('class','module'):
     name=other.text(other.field(q,'name'));owner=tuple(name.lstrip(':').split('::')) if '::' in name else owner+(name,);kind='singleton';method_kind='instance'
    if q.type=='singleton_class':
     if other.text(other.field(q,'value'))!='self':return
     kind='singleton';method_kind='singleton'
    if q.type=='method':kind=method_kind
    if q.type=='singleton_method':
     if other.text(other.field(q,'object'))!='self':return
     kind='singleton'
    if '::'.join(owner)==metadata['namespace'] and kind=='singleton':
     left=other.field(q,'left')
     if q.type in ('assignment','operator_assignment') and left and other.text(left)==key[1]:writer.append(dict(file=file,line=q.start_point.row+1,byte_offset=q.start_byte))
     if q.type=='call':
      name=other.text(other.field(q,'method'));an=other.field(q,'arguments');aa=list(an.named_children) if an else []
      if name in ('instance_variable_set','remove_instance_variable','attr_writer','attr_accessor'):
       dynamic_writes.append(dict(file=file,line=q.start_point.row+1,operation=name,arguments=other.text(an)))
    for child in q.named_children:visit(child,owner,kind,method_kind)
   visit(other.tree.root_node)
  if dynamic_writes:
   self.record(src,stmt,'unresolved','same_owner_reflective_or_accessor_writes',writers=writer,dynamic_writes=dynamic_writes);return unknown()
  if len(writer)!=1 or writer[0]['file']!=src.file or writer[0]['byte_offset']!=stmt.start_byte:
   self.record(src,stmt,'unresolved','competing_or_missing_same_owner_writer',writers=writer);return unknown()
  self.active.add(key)
  try:result=src.eval(rhs,{},0)
  finally:self.active.remove(key)
  if 'fixed_json_summary' not in result:
   self.record(src,stmt,'unresolved','RHS_not_source_qualified_fixed_JSON',owner=metadata['namespace'],ivar=key[1],writers=writer);return unknown()
  ev=self.record(src,stmt,'supported_conditional','memoized_fixed_JSON_root',source_sha256=hashlib.sha256(src.data).hexdigest(),owner=metadata['namespace'],ivar=key[1],writers=writer,parser_summary=result['fixed_json_summary'],conditions=['Receiver is exact singleton owner','State initially nil/unset or value previously assigned by this memoizer','No external/reflection/top-level replacement of memoized field; no source method replacement','Ordinary file/parser semantics and successful normal return'])
  result=copy.deepcopy(result);result['memoized_summary']=ev
  src.flow_notes.append(ev);return result
