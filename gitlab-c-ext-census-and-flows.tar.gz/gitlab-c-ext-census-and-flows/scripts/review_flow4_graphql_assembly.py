#!/usr/bin/env python3
"""Independent frozen-flow structural checks and manually reviewed semantic verdicts."""
import json,hashlib,collections
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_v3');B=Path('/workspace/gitlab_c_ext_trace');cache={};errors=[];checks=0
spec={'tables/request_memory_flows_iteration4_graphql.jsonl':'44e53e4a032e1308dd26d3640addf35cf83c4a668a619e6b3be0c5aeac6794e2','tables/ruby_runtime_contracts_iteration3.jsonl':'d61f8d676e8dbe5ef7b146b3816564164f087cc3cb6d22b9c91fa2d3621d2a9f'}
def walk(x):
 global checks
 if isinstance(x,list):
  for v in x:walk(v)
 elif isinstance(x,dict):
  if x.get('file') and x.get('line') and ('excerpt'in x or 'source_text'in x):
   p=B/x['file']
   if p not in cache:cache[p]=p.read_bytes()
   data=cache[p];lines=data.decode(errors='replace').split('\n');n=x['line'];expected=x.get('excerpt',x.get('source_text'));actual='\n'.join(lines[n-1:x.get('end_line',n)])
   checks+=1
   if expected!=actual:errors.append(dict(file=str(p),line=n,kind='excerpt_mismatch'))
   digest=x.get('source_sha256',x.get('sha256'))
   if digest:
    checks+=1
    if hashlib.sha256(data).hexdigest()!=digest:errors.append(dict(file=str(p),kind='hash_mismatch'))
  for v in x.values():walk(v)

allrows=[]
for rel,sha in spec.items():
 data=(R/rel).read_bytes();checks+=1
 if hashlib.sha256(data).hexdigest()!=sha:errors.append(dict(file=rel,kind='frozen_input_hash'))
 rows=[json.loads(l)for l in data.splitlines()];walk(rows)
 if 'request_memory_flows'in rel:allrows+=rows
verdicts=[]
for f in allrows:
 verdicts.append(dict(flow_id=f['flow_id'],status='source_supported_conditional_flow',runtime_verified=False,source_recipe_not_automatic_graph_proof=True,terminal_site_id=f['terminal_site_id'],reviewed_chain='HTTP route→GitlabSchema Query.project→Project.packages→Package.pipelines resolver; optional String after preserved by ExternallyPaginatedArrayExtension; stored BatchLoader callback invoked by normal GraphQL lazy sync; default Base64Encoder decoder returns new decoded String; safe_parse/StreamValidator/Oj first unescaped key constructor.',callback_judgment='Registration is not invocation. Schema plugin registers BatchLoader::GraphQL sync; GraphQL after_lazy/interpreter schedules Lazy; Dataloader job invokes lazy.value; schema.sync_lazy public_sends sync; BatchLoader __sync/ensure_batched calls stored callback only when unsynced/not loaded. First selected uncached wrapper required because grouping by source_location,nil key allows another alias to populate batch first.',decoder_judgment='Default schema cursor_encoder is Base64Encoder; decode accepts nonce keyword without consulting it. URL alphabet/padding normalization then strict_decode64/unpack1(m0) returns decoded bytes. Illustrative eyJpZCI6IjEifQ== maps to ASCII object; no HTTP/application/runtime execution performed.',bounds='20MiB guard applies after Base64 decoding to decoded JSON. It does not bound earlier decoder allocation or prove encoded request size. Key span is derived from decoded/encoding-associated native input, not encoded cursor pointer.',native_and_core_conditions='Same frozen Ruby3.3.11 normal constructor and ASCII BINARY→UTF8 byte-preserving model independently reviewed previously. Normal lookup and loaded runtime versions, nonempty valid object JSON, successful callbacks/allocations required.',remaining_unknown=['request auth/read_project/read_package/read_pipeline/granular-scope admission','actual visible packages and response selection','runtime source/version/deployment match','alternative cursor encoder/execution engine overrides','multi-alias cache capture identity outside first-uncached case','actual request String encoding'],memory_control='Conditional content/derived byte extent only; no arbitrary native pointer, arbitrary allocation size, observed allocation or vulnerability claim.'))
report=dict(status='PASS'if not errors else'FAIL',frozen_inputs=spec,checks=checks,errors=errors,source_files_checked=len(cache),flows=len(verdicts),conditional_terminal_sites=len({r['terminal_site_id']for r in verdicts}),assembly_review='One CE GraphQL package-pipelines after-cursor conditional source recipe, including explicit stored callback invocation and strict Base64 decoder transfer. Existing Oj key site reused; automatic/full-runtime verification remains false.',independent_semantic_review={'registration':'Route/controller/schema root/Project packages/Package pipelines declarations and resolver construction inspected. Permissions are explicit prerequisites, not observed feasibility.','argument_transfer':'String scalar accepts String; custom connection extension yields unchanged args. Resolver captures after in registered callback and calls decode_cursor only on callback invocation.','callback':'Actual GraphQL/BatchLoader forcing chain inspected; first uncached wrapper constraint is necessary and retained.','decoder':'Default encoder nonce ignored; native Ruby strict m0 conversion inspected. Valid ASCII object example bypasses primitive shortcut and reaches validation-phase sc_parse.','constructor':'ActiveRecordArrayConnection default construction occurs before registration; normal return is a precondition. StreamValidator Class.new core model inherited from frozen review.','native':'No new native witness claimed; source-reviewed prior Oj hash_key rb_str_new path reused with runtime/encoding guards.'},warnings=['Handpicked conditional request recipe, separate from frozen151 candidate census; not a recall or global coverage estimate.','Assembly status is additive independent review; frozen original flow record remains unchanged.'])
(R/'reports/flow4_graphql_independent_assembly_review.json').write_text(json.dumps(report,indent=2));(R/'tables/flow4_graphql_independent_assembly_review.jsonl').write_text(''.join(json.dumps(x)+'\n'for x in verdicts));print(json.dumps(report,indent=2))
