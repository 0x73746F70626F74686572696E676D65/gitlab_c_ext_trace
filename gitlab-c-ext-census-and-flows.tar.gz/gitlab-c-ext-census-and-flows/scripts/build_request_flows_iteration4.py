#!/usr/bin/env python3
"""Assemble additive manually reviewed CE Slack contracts; no target execution.
Generic evidence/ID validation does not constitute independent semantic accuracy.
"""
import copy,hashlib,json,pathlib,collections
V=pathlib.Path('/workspace/gitlab_c_ext_v3');B=pathlib.Path('/workspace/gitlab_c_ext_trace')
def rows(p):return [json.loads(x) for x in p.read_text().splitlines() if x]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p,**kw):return dict(path=str(p.relative_to(V)),sha256=sha(p),**kw)
def write(p,x):p.write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in x))
def verify(obj):
 count=0
 if isinstance(obj,dict):
  if 'file' in obj and ('source_sha256' in obj or 'sha256' in obj):
   p=B/obj['file'];assert sha(p)==obj.get('source_sha256',obj.get('sha256')),p
   lines=p.read_text().splitlines();line=obj.get('line')
   if obj.get('excerpt'):
    assert obj['excerpt'] in p.read_text(),obj['file']
    if line and obj.get('end_line'):assert '\n'.join(lines[line-1:obj['end_line']])==obj['excerpt'],obj['file']
   count+=1
  for x in obj.values():count+=verify(x)
 elif isinstance(obj,list):
  for x in obj:count+=verify(x)
 return count

def main():
 priorpath=V/'tables/request_memory_flows_iteration3.jsonl';indexpath=V/'tables/request_flow_latest_index.jsonl';reviewpath=V/'tables/review_request_surface_candidates_iteration3.jsonl';candidatepath=V/'tables/request_surface_candidates_iteration3.jsonl';routepath=V/'tables/route_initializer_invocation_models_iteration3.jsonl'
 frozen={str(p.relative_to(V)):sha(p) for p in [priorpath,indexpath,V/'tables/request_memory_flows_iteration2.jsonl']}
 prior=rows(priorpath)[0];reviews={r['candidate_id']:r for r in rows(reviewpath)};candidates={r['candidate_id']:r for r in rows(candidatepath)};entries={r['entrypoint_id']:r for r in rows(pathlib.Path('/workspace/gitlab_c_ext_frontend_v2/tables/frontend_entrypoints.jsonl'))};routes={r['profile']:r for r in rows(routepath)}
 recipe=json.loads((V/'fixtures/request_flow_contracts_iteration4.json').read_text());out=[]
 keys=['gitlab_sha','argument_position_convention','registration_ids','typed_native_boundaries','constructor_bridges','terminal_site_id','terminal_primitive_ids','terminal_operation','terminal_arguments','encoding_alternatives','status','complete_source_parsed_path_claim','runtime_execution','vulnerability_claim','automatic_verified_label','memory_operation_semantics','historical_gap_disposition']
 for case in recipe['cases']:
  cid=case['candidate_id'];c=candidates[cid];r=reviews[cid];assert r['verdict']=='supported_conditional' and r['profile']=='ce';assert sha(candidatepath)==r['candidate_manifest_sha256'];assert len(c['entrypoint_ids'])==1;e=entries[c['entrypoint_ids'][0]]
  f={k:copy.deepcopy(prior[k]) for k in keys};f.update(flow_id='iteration4_'+cid,iteration=4,profile='ce',candidate_id=cid,baseline_entrypoint_id=e['entrypoint_id'],entrypoint=e,selected_route=r['http_route'],selected_action=e['route_segment'],surface='grape',manual_source_contract=case,request_source='params[:payload]',source_argument_position=1,source_identity=r['source_identity'],source_to_wrapper_transfer='Selected decoded form payload String directly supplies safe_parse positional argument 1 without options; symbolization and service execute after parse.',selected_input=recipe['selected_input'],auth_context=recipe['actor_constraint'],admission_conditions=r['admission_conditions']+recipe['additional_conditions'],review_unresolved=r['unresolved'],signature_scope=r['signature_scope'],signature_timestamp_qualification=r['signature_timestamp_qualification'],ordering=r['ordering'],string_type_proven_for_all_inputs=False,route_initializer_model_applicability={'reference':ref(routepath,model_id=routes['ce']['model_id']),'model':routes['ce'],'effect':'Conditional wrapper invocation only; route DSL completion, mounting and request admission still conditional.'},native_frontier_selection={'selected':'validation-phase Oj.sc_parse before adapter parse','discovery_candidate_later_registration_not_used':c['native_registration_id'],'discovery_candidate_later_modes_not_used':c['assumed_modes'],'reason':'safe_parse validates through StreamValidator before parse/Oj.load; do not transfer later load mode into sc_parse'},counting='One profile-bound route and selected request source per record; encoding alternatives are not extra paths. Both reuse one existing physical Oj constructor site; no global coverage estimate.')
  for branch in f['encoding_alternatives']:branch.pop('historical_candidate_encoding_link',None)
  evidence=[dict(copy.deepcopy(x),hop_id=f'{cid}_ruby_{i}',hop_kind='reviewed_request_route_or_Ruby_transfer',confidence='independently_reviewed_conditional_Ruby_segment') for i,x in enumerate(r['evidence'])]
  for x in prior['value_transfer_evidence']:
   if x['hop_kind']=='shared_wrapper_or_native_source_relation':
    x=copy.deepcopy(x);x['hop_id']=cid+'_nativechain_'+x['id'];evidence.append(x)
  f['value_transfer_evidence']=evidence;f['review_references']=[ref(reviewpath,candidate_id=cid),ref(priorpath,reused_native_contract_flow_id=prior['flow_id']),ref(candidatepath,candidate_id=cid)]
  assert f['registration_ids']==['reg_18db0790cf6239d7309a8480'];assert f['terminal_site_id']=='site_02ee522b09c10c1f06305d45';out.append(f)
 checks=sum(verify(r) for r in out);output=V/'tables/request_memory_flows_iteration4.jsonl';write(output,out)
 index=copy.deepcopy(rows(indexpath))
 for x in index:
  model=routes[x['profile']];x['additive_route_initializer_model_applicability']={'reference':ref(routepath,model_id=model['model_id']),'conditions':model['conditions'],'scope':model['supersedes_only'],'non_claims':model['non_claims']}
 for i,f in enumerate(out,1):
  index.append({'flow_id':f['flow_id'],'profile':'ce','original_iteration':4,'original_status':f['status'],'ledger_category':'conditional_source_flow','baseline_entrypoint_id':f['baseline_entrypoint_id'],'record_reference':{'path':str(output.relative_to(V)),'line':i,'file_sha256':sha(output),'flow_id':f['flow_id']},'current_route_evidence':{'classification':'source_registered_conditional_handler','selected_route':f['selected_route'],'evidence_location':'value_transfer_evidence and independent Slack review','runtime_exposure_proven':False},'registration_ids':f['registration_ids'],'terminal_site_id':f['terminal_site_id'],'terminal_primitive_ids':f['terminal_primitive_ids'],'actor_constraint':f['auth_context'],'current_runtime_execution_claim':False,'automatic_verified_label':False,'vulnerability_claim':False,'additive_route_initializer_model_applicability':f['route_initializer_model_applicability']})
 assert len({x['flow_id'] for x in index})==len(index)==12
 for x in index:
  rr=x['record_reference'];p=V/rr['path'];assert sha(p)==rr['file_sha256'];assert rows(p)[rr['line']-1]['flow_id']==x['flow_id']
 for p,h in frozen.items():assert sha(V/p)==h
 ip=V/'tables/request_flow_index_iteration4.jsonl';write(ip,index)
 report={'status':'pass_structural_source_hash_and_exact_excerpt_checks','new_profile_route_records':2,'new_profiles':{'ce':2},'new_native_physical_sites':0,'new_records_distinct_terminal_site_ids':1,'union_categories':dict(collections.Counter(x['ledger_category'] for x in index)),'union_profiles':dict(collections.Counter(x['profile'] for x in index)),'union_conditional_distinct_sites':len({x['terminal_site_id'] for x in index if x['ledger_category']=='conditional_source_flow'}),'source_evidence_checks':checks,'outputs':[dict(path=str(p.relative_to(V)),sha256=sha(p),bytes=p.stat().st_size) for p in [output,ip]],'preserved_frozen_inputs':frozen,'EE_promoted':False,'runtime_execution_or_vulnerability_claim':False,'independent_semantic_assembly_review':'pending separate reviewer; imported Ruby and shared native contracts independently reviewed'}
 (V/'reports/request_flow_iteration4_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
