import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from ruby_argument_flow_iteration4 import FlowSource,value,unknown

def walk(n):
 yield n
 for c in n.named_children:yield from walk(c)
class FlowTests(unittest.TestCase):
 def setup_flow(self,body,params='flag:',pos=None,kw=None):
  s=FlowSource('class Demo\ndef run('+params+'); '+body+'; end\nend');m=s.methods['run'][0];call=next(n for n in walk(m) if n.type=='call' and s.text(s.field(n,'method'))=='sink');env,issues=s.bind_explicit(m,dict(positional=pos or [],keywords=kw or {},unresolved=[]));return s,m,call,env,issues
 def check(self,body,**k):
  s,m,c,e,issues=self.setup_flow(body,**k);return s.env_at(m,c,e)
 def test_false_guard_rejects(self):self.assertTrue(self.check('sink() if flag',kw={'flag':value('Boolean',False)})['unreachable'])
 def test_false_unless_retains(self):self.assertFalse(self.check('sink() unless flag',kw={'flag':value('Boolean',False)})['unreachable'])
 def test_optional_keyword_false(self):self.assertTrue(self.check('sink() if flag',params='flag: false')['unreachable'])
 def test_unknown_entry_never_assumes_default(self):
  s,m,c,_,_=self.setup_flow('sink() if flag',params='flag: false');e,issues=s.bind_explicit(m,None);self.assertFalse(s.env_at(m,c,e)['unreachable'])
 def test_hash_not_string_case(self):self.assertTrue(self.check('case payload; when String; sink(); end',params='payload',pos=[{'kind':'Hash','items':{},'closed':True}])['unreachable'])
 def test_multi_when_accepts_hash(self):self.assertFalse(self.check('case payload; when String, Hash; sink(); end',params='payload',pos=[{'kind':'Hash','items':{},'closed':True}])['unreachable'])
 def test_else_after_known_when_rejects(self):self.assertTrue(self.check('case payload; when String; good(); else; sink(); end',params='payload',pos=[value('String','ok')])['unreachable'])
 def test_unknown_case_retains(self):self.assertFalse(self.check('case payload; when String; sink(); end',params='payload',pos=[unknown()])['unreachable'])
 def test_known_early_return(self):self.assertTrue(self.check('return if flag; sink()',kw={'flag':value('Boolean',True)})['unreachable'])
 def test_false_early_return_retains(self):self.assertFalse(self.check('return if flag; sink()',kw={'flag':value('Boolean',False)})['unreachable'])
 def test_unknown_branch_assignments_join(self):self.assertFalse(self.check('if other; flag = true; end; sink() if flag',params='flag:, other:',kw={'flag':value('Boolean',False),'other':unknown()})['unreachable'])
 def test_unknown_mutation_erases_hash_fact(self):self.assertFalse(self.check('change(payload); case payload; when String; sink(); end',params='payload',pos=[{'kind':'Hash','items':{},'closed':True}])['unreachable'])
 def test_closed_kwargs_parameter_binds(self):
  s,m,c,e,issues=self.setup_flow('sink() if flag',params='flag: false, **options',kw={'flag':value('Boolean',False)});self.assertFalse(issues);self.assertTrue(s.env_at(m,c,e)['unreachable']);self.assertEqual(e['options'],{'kind':'Hash','items':{},'closed':True})
 def test_helper_return_does_not_return_from_caller(self):
  s=FlowSource('class Demo; def helper; return true; end; def run; helper(); sink(); end; end');m=s.methods['run'][0];c=next(n for n in walk(m) if n.type=='call' and s.text(s.field(n,'method'))=='sink');self.assertFalse(s.env_at(m,c,{})['unreachable'])
 def test_block_shadowing_drops_known_false(self):self.assertFalse(self.check('things.each { |flag| sink() if flag }',kw={'flag':value('Boolean',False)})['unreachable'])
 def test_captured_immutable_flag_survives_block(self):self.assertTrue(self.check('things.each { |item| sink() if flag }',kw={'flag':value('Boolean',False)})['unreachable'])
 def test_written_flag_in_repeated_block_unknown(self):self.assertFalse(self.check('things.each { |item| sink() if flag; flag = true }',kw={'flag':value('Boolean',False)})['unreachable'])
 def test_elsif_guard(self):self.assertTrue(self.check('if false; skip(); elsif flag; sink(); end',kw={'flag':value('Boolean',False)})['unreachable'])
 def test_nil_predicate(self):self.assertTrue(self.check('sink() if payload.nil?',params='payload',pos=[value('String','x')])['unreachable'])
 def test_type_predicate(self):self.assertTrue(self.check('sink() if payload.is_a?(String)',params='payload',pos=[{'kind':'Hash','items':{},'closed':True}])['unreachable'])
 def test_unknown_call_block_assignment_invalidates_flag(self):self.assertFalse(self.check('items.each { flag = true }; sink() if flag',kw={'flag':value('Boolean',False)})['unreachable'])
 def test_unknown_shortcircuit_assignment_invalidates_flag(self):self.assertFalse(self.check('other && (flag = true); sink() if flag',params='flag:, other:',kw={'flag':value('Boolean',False),'other':unknown()})['unreachable'])
 def test_eval_invalidates_immutable_locals(self):self.assertFalse(self.check('eval("flag = true"); sink() if flag',kw={'flag':value('Boolean',False)})['unreachable'])
 def test_positional_keyword_alias_preserved(self):
  s=FlowSource('call(x, option: x)');c=next(n for n in walk(s.tree.root_node) if n.type=='call');p=s.argument_pack(c,{'x':{'kind':'Hash','items':{},'closed':True}});self.assertIs(p['positional'][0],p['keywords']['option'])
 def test_block_argument_conversion_invalidates_mutables(self):
  s=FlowSource('call(x, &callback)');c=next(n for n in walk(s.tree.root_node) if n.type=='call');p=s.argument_pack(c,{'x':{'kind':'Hash','items':{},'closed':True}});self.assertEqual(p['positional'][0]['kind'],'unknown')
 def test_keyword_pack(self):
  s=FlowSource('call(5, verify: false)');c=next(n for n in walk(s.tree.root_node) if n.type=='call');p=s.argument_pack(c,{});self.assertEqual(p['keywords']['verify'],value('Boolean',False));self.assertEqual(p['positional'],[value('Integer',5)])
 def test_closed_kwargs_remaining_keys(self):
  s,m,c,e,issues=self.setup_flow('sink() if options[:bad]',params='flag: false, **options',kw={'flag':value('Boolean',True),'other':value('String','x')});self.assertFalse(issues);self.assertEqual(set(e['options']['items']),{'other'});self.assertTrue(s.env_at(m,c,e)['unreachable'])
 def test_unknown_keyword_splat_not_bound(self):
  s=FlowSource('class Demo; def run(**options); end; end');e,issues=s.bind_explicit(s.methods['run'][0],dict(positional=[],keywords={},unresolved=['hash_splat_argument']));self.assertTrue(issues)
 def test_anonymous_kwargs_rest_unresolved(self):
  s=FlowSource('class Demo; def run(**); end; end');e,issues=s.bind_explicit(s.methods['run'][0],dict(positional=[],keywords={},unresolved=[]));self.assertTrue(issues)
 def test_kwargs_aliases_preserved(self):
  s=FlowSource('class Demo; def run(x, **opts); end; end');v={'kind':'Hash','items':{},'closed':True};e,issues=s.bind_explicit(s.methods['run'][0],dict(positional=[v],keywords={'alias':v},unresolved=[]));self.assertIs(e['x'],e['opts']['items']['alias'])
if __name__=='__main__':unittest.main()
