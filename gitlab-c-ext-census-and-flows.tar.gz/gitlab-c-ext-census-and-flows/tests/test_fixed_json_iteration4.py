import json,pathlib,sys,tempfile,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
from ruby_argument_flow_iteration4 import FlowSource
from fixed_json_iteration4 import FixedJSON
class Repo:
 def __init__(self,src):self.src=src;self.methods={'m':dict(namespace='Catalog',file=src.file)}
 def source(self,file):return self.src
class FixedTests(unittest.TestCase):
 def run_case(self,contents='{}',expr="JSON.parse(File.read(File.join(__dir__, 'data.json')))",extra=''):
  tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup);root=pathlib.Path(tmp.name);(root/'data.json').write_text(contents)
  src=FlowSource('class Catalog; def self.document; @cached ||= '+expr+'; end; '+extra+'; end','code.rb');repo=Repo(src);model=FixedJSON(repo,root);src.summary_resolver=model.builtin
  out=model.memo(src,src.methods['document'][0],dict(namespace='Catalog',kind='singleton'));return out,model
 def test_object_root(self):
  r,m=self.run_case();self.assertEqual(r['kind'],'Hash');self.assertFalse(r['closed']);self.assertIn('memoized_summary',r)
 def test_array_root(self):self.assertEqual(self.run_case('[]')[0]['kind'],'Array')
 def test_string_root(self):self.assertEqual(self.run_case('"value"')[0]['kind'],'String')
 def test_duplicate_keys_unknown(self):self.assertEqual(self.run_case('{"x":1,"x":2}')[0]['kind'],'unknown')
 def test_nonfinite_unknown(self):self.assertEqual(self.run_case('NaN')[0]['kind'],'unknown')
 def test_competing_write_unknown(self):self.assertEqual(self.run_case(extra='def self.replace; @cached = "x"; end')[0]['kind'],'unknown')
 def test_other_instance_field_not_same_receiver(self):self.assertEqual(self.run_case(extra='def replace; @cached = "x"; end')[0]['kind'],'Hash')
 def test_dynamic_path_unknown(self):self.assertEqual(self.run_case(expr='JSON.parse(File.read(path))')[0]['kind'],'unknown')
 def test_custom_options_unknown(self):self.assertEqual(self.run_case(expr="JSON.parse(File.read(File.join(__dir__, 'data.json')), object_class: Custom)")[0]['kind'],'unknown')
 def test_unknown_adapter_unknown(self):self.assertEqual(self.run_case(expr="Parser.parse(File.read(File.join(__dir__, 'data.json')))")[0]['kind'],'unknown')
 def test_oj_strict_root(self):self.assertEqual(self.run_case(expr="Oj.strict_load(File.read(File.join(__dir__, 'data.json')))")[0]['kind'],'Hash')
 def test_oj_unknown_mode_unmodeled(self):self.assertEqual(self.run_case(expr="Oj.load(File.read(File.join(__dir__, 'data.json')))")[0]['kind'],'unknown')
 def test_class_body_write_blocks_summary(self):self.assertEqual(self.run_case(extra='@cached = "replacement"')[0]['kind'],'unknown')
 def test_reflective_writer_blocks_summary(self):self.assertEqual(self.run_case(extra='def self.replace(x); instance_variable_set(:@cached,x); end')[0]['kind'],'unknown')
 def test_accessor_writer_blocks_summary(self):self.assertEqual(self.run_case(extra='class << self; attr_writer :cached; end')[0]['kind'],'unknown')
 def test_singleton_class_method_writer_blocks_summary(self):self.assertEqual(self.run_case(extra='class << self; def replace; @cached = "x"; end; end')[0]['kind'],'unknown')
if __name__=='__main__':unittest.main()
