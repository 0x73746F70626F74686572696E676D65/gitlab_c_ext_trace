"""Materialize manual source reviews of assigned candidate paths, not graph scoring."""
import json,hashlib,collections,datetime
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_trace');A=Path(__file__).parent
xs=[json.loads(s)for s in(A/'assignment_native_analysis.jsonl').read_text().splitlines()]
methods=json.loads((A/'target_methods.json').read_text());cache={}
def ev(f,line,radius=3):
 if f not in cache:
  b=(R/f).read_bytes();cache[f]=(b.decode(errors='replace').split('\n'),hashlib.sha256(b).hexdigest())
 ls,sha=cache[f];a=max(1,line-radius);z=min(len(ls),line+radius)
 return dict(file=f,line=line,start_line=a,end_line=z,sha256=sha,excerpt='\n'.join(ls[a-1:z]))
def extra(x):
 base='sources/gitlab/' if x['profile']=='ce'else'sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/'
 e=x['exposure'];out=[]
 if e['kind']=='grape':
  owner=e.get('owner');api=base+'lib/api/api.rb';lines=(R/api).read_text().split('\n');n=next((i+1 for i,s in enumerate(lines)if 'mount ::'+owner in s),None)
  if n:out.append(ev(api,n));out.append(ev(base+'config/routes/api.rb',9))
 if e['kind']=='graphql':
  out.append(ev(base+'app/graphql/types/query_type.rb',174 if 'project_type' in e['file']else 94 if 'group_type' in e['file']else 77))
  if 'workflow_event_type' in e['file']:out.append(ev(base+'ee/app/graphql/ee/types/query_type.rb',272))
 return out
pretty={'C015','C025','C006','C072','C109','C092','C125','C117'}
timezone={'C135','C082'}
conditions={
'C020':'Admin trust route and valid target/trusting users; upsert helper guards admit nonnil values; DateTime.now allocation follows successful clock/localtime.',
'C140':'EE admin trust route has the same direct service/model chain; valid users and nonnil upsert data admit DateTime.now allocation.',
'C131':'Smartcard route requires configured admission and successful persisted certificate user; store_active_session constructs SessionEnforcer and evaluates DateTime.now before update_active.',
'C047':'EventForward forward calls process_events then safe_parse(raw_post); select a nonempty valid encoded object/array within configured size/digit bounds to pass StreamValidator bypasses. sc_parse initializer runs before parsing.',
'C017':'Project field explicitly uses matching method; Requests.get_request constructs lookup keys and Redis hget callback calls safe_parse. Select nonnil stored JSON container that passes validator, not a missing-cache result.',
'C091':'EE Project field and same Requests helper chain; select nonnil Redis JSON container passing validator. Redis lookup success and field authorization conditional.',
'C007':'Authorized Terraform upload reads Workhorse-verified file data and calls StateParser.extract_serial; ScHandler is constructed then sc_parse called directly. Initializer memset precedes callbacks and parse errors.',
'C019':'Terraform upload must parse a present serial and acquire state lock. CarrierWaveStringFile inherits StringIO without overriding new; inherited strio_s_new forwards one data argument to rb_class_new_instance_kw unconditionally after optional warning.',
'C063':'Issue related-merge-request service obtains collection and passes it through same-class sort_by_iid then IssuableSorter lexical helpers. Nonempty project_ref group reaches VersionSorter protected-sort cleanup xfree; empty array returns earlier.',
'C102':'EE issues service calls lexical sorter then VersionSorter.sort(array) with a block. rb_ary_dup occurs even for empty input, before internal length branch.',
'C048':'MemoryReport middleware registered in initializer; performance_bar=memory and allowed user admit profiling. Successful MemoryProfiler report reaches no-argument StringIO.new; inherited constructor calls registered allocator and TypedData_Wrap_Struct.',
'C098':'Billing index constructs FetchSubscriptionPlansService. cached explicitly yields on cache miss; successful HTTP response body containing a valid JSON array/container reaches safe_parse validator sc_parse. Cache hit and connection failure skip tail.',
'C122':'Semantic-search update invokes metadata parser even if pre-update checks fail; nonblank scalar tested_model_metadata passing valid container/size/encoding guards reaches sc_parse before later field conversions.',
'C129':'EE Slack options route mounts explicitly; signature/filter admission plus nonnil scalar payload containing valid container JSON reaches safe_parse validator. Payload String selection is conditional, not inferred coercion.',
'C090':'Repository changelog route constructs ChangelogService using declared_params(include_missing:false); missing optional date evaluates DateTime.now default. Supplying date skips this edge.',
'C103':'EE WorkflowEvent compressed_checkpoint field calls matching method; truthy checkpoint.to_json and valid fixed compression level enter Zlib::Deflate.deflate. StringValue(src) executes; for actual String it need not allocate or copy.'}
for x in xs:
 id=x['audit_id'];gem=x['gem']['name']
 if gem=='charlock_holmes':
  conditions[id]='Mounted mail-room POST reads body then encode_utf8; choose bytes invalid after UTF8 retagging so early valid_encoding return does not skip detection. EncodingDetector constructor/default scan limit and detect registrations match. '
  if any(h.get('kind')=='c_call' for h in x['native_hops']):conditions[id]+='Detection requires nonbinary content and nonnull ICU match; selected result fields follow. ICU success conditional. Symbol/integer APIs may reuse immediates/interned values, so invocation is not allocation proof.'
  else:conditions[id]+='Allocator calloc and typed-data wrapping precede ICU setup; ordinary inherited Class#new allocation protocol required.'
 if gem=='stackprof':conditions[id]='Speedscope middleware is installed; flamegraph request and allowed user select run with explicit block, raw:true, aggregate:false and valid mode/interval. Start runs before block; ensure stop precedes results. Results fields require allocated frame table and stopped profiler; normal block return, no nested active profiler and successful start selected. Numeric conversion may return an immediate without allocation.'
 if gem=='date' and id not in conditions and id not in timezone:conditions[id]='Mounted internal personal_access_token route requires admitted shell actor and present expiry String. Date.parse one-argument defaults are compatible; StringValue and length/ASCII checks precede date__parse; valid date input passes fragment validation. Stack temporary/Hash/String allocations and direct calls match selected functions.'
 if id in pretty:conditions[id]='Route/controller/HTML format dispatch and Gitlab::Json.pretty_generate→::JSON.pretty_generate are source-backed, but the selected Oj mimic native registration is installed by optional oj_define_mimic_json activation, not ordinary Oj load. No production activation was found; Gitlab::Json explicitly documents ignoring Oj here. Native tail would be compatible with two args and empty opts if activated, but active Ruby-to-C binding is unresolved.'
 if id in timezone:conditions[id]='Selected ActiveSupport Date.current false arm requires Time.zone nil. Normal successful Rails/GitLab initialization assigns nonnil Time.zone_default and Time.zone returns thread zone OR default; GitLab initializer also reads Time.zone.name. Thus this exact fallback is contradicted under normal initialized application state. Alternate Time.zone.today path is not this frozen witness; arbitrary runtime mutations outside model remain unknown.'
 assert id in conditions,id
out=[]
for x in xs:
 id=x['audit_id'];status='unresolved'if id in pretty else'contradicted'if id in timezone else'supported_static_chain';hs=[]
 for i,h in enumerate(x['ruby_hops']+x['native_hops']):
  s='supported_static_edge';reason='Reviewed exact retained source call/registration and source target; subject to path-specific conditions below.'
  if h.get('kind')=='registration_to_function':reason='C registration binds the explicit Ruby API/allocator to named C function; activation and Class#new bridging evaluated separately.'
  elif h.get('kind')=='c_call':reason='Direct retained C call targets the displayed function; no name-only indirect callback substitution used.'
  elif h.get('kind')=='function_to_primitive':reason='Primitive API/declaration is present in enclosing target function. This is operation-site connectivity; actual allocation for conversions/interning is conditional.'
  elif h.get('method'):reason='Exact receiver/lexical wrapper and target definition checked in retained source; conditional normal Ruby dispatch, not mere same-name matching.'
  if id in pretty and (h.get('target_type')=='registration' or h.get('kind')=='registration_to_function'):s='unresolved';reason='Optional Oj mimic_JSON activation not established; ::JSON receiver alone does not prove this native implementation is installed.'
  if id in timezone and h.get('method')=='today':s='contradicted';reason=conditions[id]
  f=h.get('file');n=h.get('line');record=dict(index=i,hop_id=h.get('hop_id'),status=s,reason=reason,evidence=ev(f,n)if f and n else None)
  target=methods.get(h.get('to_id') or h.get('target_id'))
  if target:record['target_evidence']=ev(target['file'],target['line'],5)
  if h.get('target_file')and h.get('target_line'):record['target_evidence']=ev(h['target_file'],h['target_line'],5)
  hs.append(record)
 e=x['exposure'];support=extra(x)
 if id in timezone:
  support +=[ev('sources/ee_discovery/aro-local-test-2--kg-size-gitlab-2/config/initializers/time_zone.rb',9,8),ev('sources/wrappers/rails-7.2.3.1/activesupport/lib/active_support/railtie.rb',95,8),ev('sources/wrappers/rails-7.2.3.1/activesupport/lib/active_support/core_ext/time/zones.rb',14,3),ev('sources/wrappers/rails-7.2.3.1/railties/lib/rails/application/configuration.rb',52,2)]
 if id in pretty:support +=[ev(x['ruby_hops'][-1]['file'],110,7),ev('sources/gems/oj-3.17.6/ext/oj/oj.c',2288,2)]
 if id=='C019':support.append(ev('sources/gitlab/lib/carrier_wave_string_file.rb',3,12))
 if x['gem']['name']=='stackprof':support.append(ev(x['ruby_hops'][0]['file'],23,9));support.append(ev('sources/gems/stackprof-0.2.28/ext/stackprof/stackprof.c',394,9))
 out.append(dict(audit_id=id,path_id=x['path']['path_id'],profile=x['profile'],status=status,source_chain_semantics='Conditional static chain under ordinary retained bindings; never runtime/authentication/data-control proof.',wholechain_reason=conditions[id],per_hop=hs,exposure=dict(status='supported_source_declaration_conditional_activation',evidence=ev(e['file'],e['line'],4)),supplementary_evidence=support,runtime='unknown',authorization='unknown',request_data_control='unknown',primitive_effect='candidate API site; conversion/interning may allocate conditionally, stack declarations are not sink calls',independent_of_overlay_flags=True))
(A/'review_native_analysis.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n'for x in out))
r=dict(rows=len(out),statuses=dict(collections.Counter(x['status']for x in out)),hop_occurrences=sum(len(x['per_hop'])for x in out),source_files=len(cache),assignment_sha256=hashlib.sha256((A/'assignment_native_analysis.jsonl').read_bytes()).hexdigest(),review_sha256=hashlib.sha256((A/'review_native_analysis.jsonl').read_bytes()).hexdigest(),scope='Assigned 50 of151 frozen surviving candidates; not whole-graph precision. Conditional static support requires explicit listed conditions. No other census reviewers verdicts read.',frozen_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(A/'review_native_analysis_summary.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
