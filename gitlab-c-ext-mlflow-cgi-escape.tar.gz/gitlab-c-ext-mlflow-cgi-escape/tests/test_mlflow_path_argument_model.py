import pathlib,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
from mlflow_path_argument_model import transfer,PREFIX,TAIL,call_shape_guard,CALL_SHAPE
class TransferTests(unittest.TestCase):
 p=PREFIX+'1'+TAIL+'1/folder/file'
 def test_source_shape(self):self.assertTrue(call_shape_guard(CALL_SHAPE))
 def test_changed_dispatch_fails_source_guard(self):
  for old,new in [('CGI.escape','CGI.unescape'),('user_project, params','unknown_project, params'),('params[:file_path]','stored_file.path')]:self.assertFalse(call_shape_guard(CALL_SHAPE.replace(old,new)))
 def test_selected(self):
  r=transfer(self.p);self.assertEqual(r['argument_ascii'],'folder/file');self.assertEqual(r['argument_byte_length'],11);self.assertEqual(r['branch'],'else')
 def test_changed_current_path(self):self.assertEqual(transfer(self.p.replace('folder/file','a/b'))['argument_ascii'],'a/b')
 def test_wrong_verb(self):self.assertEqual(transfer(self.p,method='POST')['status'],'outside_selected_method')
 def test_no_glob(self):self.assertEqual(transfer(PREFIX+'1'+TAIL+'1/')['status'],'outside_selected_route')
 def test_candidate_branch(self):self.assertEqual(transfer(PREFIX+'1'+TAIL+'candidate:1/a')['status'],'candidate_branch_outside_selected_else')
 def test_other_version_outside(self):self.assertEqual(transfer(PREFIX+'1'+TAIL+'2/a')['status'],'outside_selected_version')
 def test_earlier_project_argument(self):self.assertEqual(transfer(self.p,project_argument_returns=False)['status'],'earlier_user_project_argument_unresolved')
 def test_gate_unknown(self):self.assertEqual(transfer(self.p,admitted=False)['status'],'admission_unresolved')
 def test_escaped_input_not_assumed(self):self.assertEqual(transfer(self.p+'%2f')['status'],'outside_literal_ascii_path_scope')
 def test_query_not_filename(self):self.assertEqual(transfer(self.p+'?file_path=other')['status'],'outside_literal_ascii_path_scope')
 def test_wrong_prefix(self):self.assertEqual(transfer(self.p.replace('/api/v4','/api/v3'))['status'],'outside_selected_route')
 def test_unicode_outside(self):self.assertEqual(transfer(self.p+'é')['status'],'outside_literal_ascii_path_scope')
if __name__=='__main__':unittest.main()
