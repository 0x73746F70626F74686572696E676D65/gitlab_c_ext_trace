import unittest,importlib.util,urllib.parse
from pathlib import Path
p=Path(__file__).parents[1]/'scripts/cgi_escape_contract_v1.py';s=importlib.util.spec_from_file_location('encoder',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class EncoderTests(unittest.TestCase):
 def test_witness(self):
  r=m.transfers(b'folder/file');self.assertEqual(r['output_hex'],b'folder%2Ffile'.hex());self.assertEqual(r['output_length'],13);self.assertEqual(r['events'][0]['capacity_argument'],11);self.assertEqual([e['count'] for e in r['events'][1:]],[6,3,4])
 def test_unreserved(self):self.assertEqual(m.transfers(b'AZaz09-._~')['events'],[])
 def test_empty(self):self.assertEqual(m.transfers(b'')['events'],[])
 def test_space(self):
  r=m.transfers(b'a b');self.assertEqual(r['output_hex'],b'a+b'.hex());self.assertEqual(r['events'][2]['line'],243)
 def test_space_no_plus(self):self.assertEqual(m.transfers(b' ',plus_escape=False)['output_hex'],b'%20'.hex())
 def test_literal_percent(self):self.assertEqual(m.transfers(b'%GG')['output_hex'],b'%25GG'.hex())
 def test_zero_slices(self):self.assertEqual([e.get('count') for e in m.transfers(b'/')['events'][1:]],[0,3,0])
 def test_all_byte_oracle(self):
  for n in range(256):
   data=bytes([n]);expected=urllib.parse.quote_from_bytes(data,safe='').replace('%20','+').encode('ascii');self.assertEqual(m.transfers(data)['output_hex'],expected.hex())
 def test_bounds(self):
  for data in [b'a/b/c',b'///',b'abc',b'%x \x00\xff',b'']:
   r=m.transfers(data);self.assertLessEqual(len(data),r['output_length']);self.assertLessEqual(r['output_length'],3*len(data))
   for e in r['events']:
    if e.get('source')=='input_slice':self.assertGreaterEqual(e['count'],0);self.assertLessEqual(e['start']+e['count'],len(data))
 def test_encoding_fallback(self):self.assertEqual(m.transfers(b'/',ascii_compatible=False)['status'],'ruby_super_fallback')
 def test_unknown_encoding(self):self.assertEqual(m.transfers(b'/',ascii_compatible=None)['events'],[])
 def test_unknown_bytes(self):self.assertEqual(m.transfers(None)['status'],'unresolved_input_bytes')
 def test_arity(self):
  for n in [0,2]:self.assertEqual(m.transfers(b'/',argc=n)['status'],'arity_error')
if __name__=='__main__':unittest.main()
