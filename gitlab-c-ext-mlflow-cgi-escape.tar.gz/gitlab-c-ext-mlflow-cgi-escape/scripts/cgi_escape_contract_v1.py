#!/usr/bin/env python3
"""Pure static byte transfer model of CGI0.5.1 encoder; no Ruby execution."""
import hashlib,json
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_trace');V=Path('/workspace/gitlab_c_ext_v3');C='sources/gems/cgi-0.5.1/ext/cgi/escape/escape.c';S='sources/runtime/ruby-v3_3_11/'
UNRESERVED=frozenset(b'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~')
def transfers(data,argc=1,ascii_compatible=True,plus_escape=True):
 if argc!=1:return {'status':'arity_error','events':[]}
 if ascii_compatible is False:return {'status':'ruby_super_fallback','events':[]}
 if ascii_compatible is not True:return {'status':'unresolved_input_encoding','events':[]}
 if data is None:return {'status':'unresolved_input_bytes','events':[]}
 assert isinstance(data,bytes)
 n=len(data);beg=0;dest=False;events=[];out=bytearray()
 for i,c in enumerate(data):
  if c in UNRESERVED:continue
  if not dest:events.append(dict(line=236,operation='rb_str_buf_new',capacity_argument=n));dest=True
  events.append(dict(line=239,operation='rb_str_cat',source='input_slice',start=beg,count=i-beg));out.extend(data[beg:i]);beg=i+1
  if plus_escape and c==32:
   events.append(dict(line=243,operation='rb_str_cat_cstr',source='fixed_literal_plus',count=1));out.extend(b'+')
  else:
   encoded=('%%%02X'%c).encode('ascii');events.append(dict(line=248,operation='rb_str_cat',source='encoded_fixed_stack_buffer',input_index=i,input_byte=c,count=3,bytes_hex=encoded.hex()));out.extend(encoded)
 if dest:
  events.append(dict(line=254,operation='rb_str_cat',source='input_slice',start=beg,count=n-beg));out.extend(data[beg:]);return dict(status='conditional_optimized_branch',events=events,output_hex=out.hex(),output_length=len(out),capacity_not_heap_bytes=True)
 return dict(status='dup_fallback_no_selected_constructor',events=[],output_hex=data.hex(),output_length=n)

def emit():
 ev=[];checks=0
 for f,a,b,anchors in [(C,1,9,['upper_hexdigits (ruby_hexdigits+16)']),(C,202,260,['url_unreserved_char','char buf[4]','RSTRING_LEN(str)','rb_str_buf_new(len)','i - beg','buf[1] = upper_hexdigits','rb_str_cat(dest, buf, 3)','len - beg','rb_str_dup(str)']),(C,373,385,['cgiesc_escape(VALUE self, VALUE str)','StringValue(str)','rb_enc_str_asciicompat_p(str)','optimized_escape(str, 1)','rb_call_super(1, &str)']),(C,461,487,['InitVM(escape)','"escape", cgiesc_escape, 1','rb_prepend_module','rb_extend_object']),('sources/gems/cgi-0.5.1/lib/cgi/escape.rb',169,176,["unless RUBY_ENGINE == 'truffleruby'","require 'cgi/escape.so'",'rescue LoadError']),(S+'include/ruby/ruby.h',231,231,['InitVM_##ext();']),(S+'util.c',38,38,['0123456789abcdef0123456789ABCDEF']),(S+'string.c',1508,1525,['STR_EMBEDDABLE_P(capa, 1)','ALLOC_N(char, (size_t)capa + 1)']),(S+'string.c',3195,3251,['str_buf_cat4','capa < total','RESIZE_CAPA_TERM','memcpy(sptr + olen, ptr, len)','if (len == 0) return str;'])]:
  raw=(R/f).read_bytes();text='\n'.join(raw.decode().split('\n')[a-1:b])
  for anchor in anchors:assert anchor in text,(f,a,anchor);checks+=1
  ev.append(dict(file=f,line=a,end_line=b,sha256=hashlib.sha256(raw).hexdigest(),excerpt=text,required_anchors=anchors))
 sites={236:('site_de2e21df8a22dfa2dac33af1','primitive_5af1cf04410bcb2d7ccab7c2'),239:('site_9a0a9643d59a4f3194ca8ca8','primitive_27bf0718b0e2c9ae464c90f4'),248:('site_ad6c8b4f8ed6aadff752d0ba','primitive_c828c793709514f52c31f2b5'),254:('site_438b27862f8fef4d791556d2','primitive_da0ce5412f2bc5276b9bbdcd')}
 witness=transfers(b'folder/file')
 for event in witness['events']:event['site_id'],event['primitive_id']=sites[event['line']]
 row=dict(model_id='cgi051_escape_path_capacity_v1',status='source_supported_conditional_native_argument_contract',gem='cgi',version='0.5.1',gem_id='f10b8e2bad57b6dc1c0961ba',registration_id='reg_209183df0a4895a658639247',c_function_id='fn_127f4a26d24eb7291838e57a',terminal_site_id=sites[236][0],terminal_primitive_id=sites[236][1],site_bindings=[dict(line=l,site_id=x[0],primitive_id=x[1]) for l,x in sites.items()],source_evidence=ev,witness=dict(input_ascii='folder/file',input_byte_length=11,output_ascii='folder%2Ffile',**witness),
 conditions=['Ordinary String with ASCII-compatible encoding reaches retained native CGI.escape, arity1; no method override/interposition.','Successful extension loading required: Ruby wrapper can rescue LoadError or select nonnative path on TruffleRuby. InitVM/extend/prepend source composition is not deployment proof.','Source bytes stable while scanned; allocations and normal String operations succeed.','Matching Ruby3.3.11 source implementation conditions capacity/copy behavior; deployed runtime/build unproven.'],
 argument_semantics={'capacity':'Input RSTRING_LEN11 before encoding, not output length13 or actual heapbytes.','prefix':'Source cstr+0,count6 derived from slash byte index6.','encoded':'Slash0x2f selects stack buf[4]: bytes percent+uppercasehex2F; append count3 fixed in source, content input-derived. Stack size4 is fixed, not user-selected.','tail':'Source cstr+7,count11-7=4 (file), derived positions.','bounds':'For general byte strings, each unreserved byte remains1; space→plus1 when enabled; otherbytes→percenthex3. n≤outputbytes≤3n mathematically, subject to allocation/overflow checks; not a safety or exactheap proof.','storage':'rb_str_buf_new uses embedded GC storage or separate buffer. Appends may grow capacity when total exceeds available capacity; output13>requested11 does NOT prove a growth allocation because actual embedded capacity can exceed request.','encoding':'Output preserves original encoding association; no runtime accept_charset lookup for this encoder. ASCII-incompatible input calls super.','zero_counts':'First/adjacent/end escapedbytes may yield0-count slice calls, which are invocations but not positive copies under Ruby rb_str_cat.'},
 alternatives=['All-unreserved or empty input: rb_str_dup fallback, not selected constructor.','Space uses plus append at243, not selected encoded-byte append248.','Percent is encoded as %25; malformed-percent decoding is irrelevant to encoder.','Non-ASCII bytes in ASCII-compatible encoding are encoded bytewise; no Unicode codepoint-length claim.'],
 limits=['One encoder mechanism with four physical terminal callsites, not four mechanisms.','Frontend current-path provenance joined separately; no artifact-file content influence claimed.','No new baseline IDs/taint graph changes; synthetic model fixtures do not execute extension.'])
 out=V/'tables/cgi_escape_native_contract_v1.jsonl';out.write_text(json.dumps(row,sort_keys=True)+'\n')
 (V/'reports/cgi_escape_native_contract_v1.json').write_text(json.dumps(dict(model_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),required_anchor_checks=checks,source_evidence_records=len(ev),mechanisms=1,terminal_sites=4,independent_review='pending',witness=row['witness']),indent=2)+'\n')
 (V/'reports/cgi_escape_native_schema_v1.json').write_text(json.dumps(dict(table='cgi_escape_native_contract_v1',primary_key='model_id',foreign_keys={'site_bindings.site_id':'primitive_sites.site_id','site_bindings.primitive_id':'c_primitives.primitive_id','registration_id':'c_registrations.registration_id'},events='Ordered static-model API invocations with argument provenance; no dynamic counts or exact heapbytes'),indent=2)+'\n')
if __name__=='__main__':emit()
