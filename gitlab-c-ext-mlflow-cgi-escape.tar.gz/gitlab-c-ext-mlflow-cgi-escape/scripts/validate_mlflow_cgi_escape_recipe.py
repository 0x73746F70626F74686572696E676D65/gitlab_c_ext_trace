import pathlib,json,hashlib
from mlflow_path_argument_model import transfer,call_shape_guard
V=pathlib.Path(__file__).resolve().parents[1];B=pathlib.Path('/workspace/gitlab_c_ext_trace');r=json.loads((V/'tables/mlflow_cgi_escape_request_recipe.jsonl').read_text());checks=0
for e in r['source_evidence']:
 d=(B/e['file']).read_bytes();assert hashlib.sha256(d).hexdigest()==e['sha256'];assert '\n'.join(d.decode().splitlines()[e['line']-1:e['end_line']])==e['excerpt'];checks+=2
assert transfer(r['selected_request']['path'])==r['selected_transfer'];checks+=1
assert call_shape_guard((B/r['selected_ruby_call']['file']).read_text());checks+=1
assert not r['native_contract_attached'] and not r['complete_current_request_to_native_memory_promotion'] and not r['runtime_execution'] and not r['frozen_graphs_mutated'];checks+=1
out=dict(status='pass',checks=checks,errors=0,native_transfer_claims=False,independent_assembly_review_pending=True);(V/'reports/mlflow_cgi_escape_recipe_validation.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
