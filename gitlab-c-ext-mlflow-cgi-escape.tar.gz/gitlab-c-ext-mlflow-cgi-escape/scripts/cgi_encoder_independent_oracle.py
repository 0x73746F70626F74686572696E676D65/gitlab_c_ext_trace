"""Independent finite abstract-event oracle, Python only; no CGI/Ruby execution.
Derived as reserved-position segmentation, rather than native loop simulation.
"""
import json,hashlib
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');A=V/'audit/cgi_encoder_independent'
UNRESERVED=frozenset(b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~')
def oracle(data,plus=False,ascii_compatible=True):
 if not ascii_compatible:return {'branch':'super','output_hex':None,'events':[]}
 cuts=[i for i,b in enumerate(data) if b not in UNRESERVED]
 if not cuts:return {'branch':'duplicate','output_hex':data.hex(),'events':[{'kind':'rb_str_dup','line':259,'input_length':len(data)}]}
 events=[{'kind':'rb_str_buf_new','line':236,'capacity_hint':len(data)}];parts=[]
 for n,i in enumerate(cuts):
  start=cuts[n-1]+1 if n else 0;chunk=data[start:i];parts.append(chunk)
  events.append({'kind':'rb_str_cat','line':239,'source':'input','offset':start,'length':len(chunk),'bytes_hex':chunk.hex()})
  chunk=b'+' if plus and data[i]==32 else ('%%%02X'%data[i]).encode();parts.append(chunk)
  events.append({'kind':'rb_str_cat_cstr' if plus and data[i]==32 else 'rb_str_cat','line':243 if plus and data[i]==32 else 248,'source':'literal' if plus and data[i]==32 else 'stack_encoded','length':len(chunk),'bytes_hex':chunk.hex()})
 start=cuts[-1]+1;chunk=data[start:];parts.append(chunk);events.append({'kind':'rb_str_cat','line':254,'source':'input','offset':start,'length':len(chunk),'bytes_hex':chunk.hex()})
 return {'branch':'optimized','output_hex':b''.join(parts).hex(),'events':events}
def cases():
 seeds=[('empty',b''),('all_unreserved',b'AZaz09-._~'),('space',b' '),('percent',b'%'),('slash',b'/'),('nul',b'\0'),('high_bytes',bytes([128,255])),('utf8_multibyte',b'\xc3\xa9'),('leading_reserved',b'/abc'),('trailing_reserved',b'abc/'),('adjacent_reserved',b'a/%b'),('space_percent_slash',b' %/'),('selected_witness',b'folder/file'),('already_percent_escaped',b'%2F')]
 for name,data in seeds:
  for plus in [False,True]:yield {'case_id':name+('_form' if plus else '_uri'),'input_hex':data.hex(),'plus_escape':plus,'ascii_compatible':True,'expected':oracle(data,plus)}
 for name,data in [('utf16le_ascii_text',b'a\0/\0'),('empty_incompatible',b'')]:yield {'case_id':name,'input_hex':data.hex(),'plus_escape':False,'ascii_compatible':False,'expected':oracle(data,False,False)}
def main():
 A.mkdir(exist_ok=True);records=list(cases());p=A/'predefined_cases.jsonl';p.write_text(''.join(json.dumps(r)+'\n' for r in records)); source=Path('/workspace/gitlab_c_ext_trace/sources/gems/cgi-0.5.1/ext/cgi/escape/escape.c')
 (A/'expectation_freeze.json').write_text(json.dumps({'status':'PRECOMPARISON_EXPECTATIONS','cases':len(records),'cases_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_ranges':[[202,259],[373,384],[424,435],[471,488]],'model_source':'Reserved-position segmentation of retained C branch rules. No target runtime or prior producer implementation used. Producer selected folder/file witness disclosed before expectation freeze.','boundaries':['ASCII-compatible encoding is supplied branch fact, not inferred from bytes; UTF16 excluded even for textual ASCII','Native module activation, default registrations, StringValue coercion, allocation success remain conditions','Zero-length append calls retained as invocations without positive byte-copy claim','Capacity is initial hint, output growth and exact heap bytes differ; output length formula depends on plus mode','Invalid UTF8 bytes can still use ASCII-compatible native branch; no Unicode decode/transcode claimed']},indent=2)+'\n')
 print(len(records))
if __name__=='__main__':main()
