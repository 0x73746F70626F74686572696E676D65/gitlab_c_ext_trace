#!/usr/bin/env python3
"""Add four reviewed terminal records for one MLflow CGI encoder source case; no baseline mutation."""
import argparse,copy,hashlib,json,collections
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');B=Path('/workspace/gitlab_c_ext_trace')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return [json.loads(l) for l in p.open() if l.strip()]
def ref(n):return {'path':n,'sha256':sha(V/n)}
def write(n,r):
 p=V/n;p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');return p
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--assembly-review',required=True);ap.add_argument('--assembly-review-sha256',required=True);args=ap.parse_args()
 review_name=args.assembly_review;assembly=json.loads((V/review_name).read_text());assert sha(V/review_name)==args.assembly_review_sha256
 assert assembly['status']=='PASS_supported_conditional_source_chain', 'Independent whole-chain review required'
 assembly_name=review_name
 recipe_name='tables/mlflow_cgi_escape_request_recipe.jsonl';recipe=rows(V/recipe_name)[0]
 native_name='tables/cgi_escape_native_contract_v1.jsonl';native=rows(V/native_name)[0]
 assert sha(V/recipe_name) in json.dumps(assembly) and sha(V/native_name) in json.dumps(assembly), 'Review must bind exact recipe and contract'
 nr={'path':'reports/mlflow_cgi_escape_native_independent_review.json'};native_review=json.loads((V/nr['path']).read_text());assert native_review['status']=='PASS_conditional_native_source_contract'
 supplement=ref('reports/mlflow_cgi_escape_path_provenance_boundary.txt')
 forcing=assembly['required_supplement'];assert sha(V/forcing['path'])==forcing['sha256'];assert sha(V/nr['path'])==assembly['native_review_sha256']
 assert sha(V/'reports/mlflow_cgi_escape_recipe_freeze.json')==assembly['freeze_sha256']
 prior_name='tables/request_flow_index_cgi_final.jsonl';prior_hash=sha(V/prior_name);prior=rows(V/prior_name);assert len(prior)==25
 events=native['witness']['events'];assert [(x['line'],x.get('count',x.get('capacity_argument'))) for x in events]==[(236,11),(239,6),(248,3),(254,4)]
 bindings={r['site_id']:r for r in native['site_bindings']};assert len(bindings)==4
 sites={r['site_id']:r for r in rows(B/'tables/primitive_sites.jsonl') if r['site_id'] in bindings}
 primitives={r['primitive_id']:r for r in rows(B/'tables/c_primitives.jsonl') if r['primitive_id'] in {e['primitive_id'] for e in events}}
 regs={r['registration_id']:r for r in rows(B/'tables/c_registrations.jsonl') if r['registration_id']==native['registration_id']};assert len(regs)==1
 source_binding=[]
 for e in events:
  s=sites[e['site_id']];p=primitives[e['primitive_id']];assert s['line']==e['line']==p['line'];assert s['operation']==e['operation'];assert native['gem_id'] in s['gem_ids'];assert sha(B/s['canonical_source_path'])==s['source_sha256'];source_binding.append({'site':s,'primitive':p})
 chosen=[dict(file=recipe['selected_ruby_call']['file'],line=56,method='GET',path=recipe['selected_request']['path'],runtime_exposure_proven=False)]
 mechanism='cgi_percent_escape_path_native_buffer_and_append';case='mlflow_artifact_path_cgi_escape';flow_name='tables/mlflow_cgi_escape_terminal_flows.jsonl';new=[]
 for e,role in zip(events,['input_capacity','literal_prefix','encoded_byte','literal_tail']):
  flow=copy.deepcopy(recipe);flow['historical_recipe_status']=flow.pop('status');flow['historical_recipe_review_status']=flow.pop('review_status',None);flow['review_status']='independent_selected_encoder_chain_pass';flow.update(flow_id=recipe['recipe_id']+'_'+role,case_id=case,status='source_supported_conditional_recipe_with_independent_review',gitlab_sha='8d0e57e5f49543c53614b299aef70f7e5bb916ac',entrypoint_kind='grape_endpoint',phase='mlflow_artifact_get_argument_path_escape',selected_route_binding=chosen[0],source_recipe_reference=ref(recipe_name),independent_assembly_review=ref(assembly_name),path_provenance_boundary=supplement,required_forcing_supplement=forcing,native_contract_reference=ref(native_name),native_semantics=copy.deepcopy(native),terminal_site_id=e['site_id'],terminal_primitive_ids=[e['primitive_id']],registration_ids=[native['registration_id']],terminal_operation=e['operation'],terminal_event=copy.deepcopy(e),argument_position_convention='1-based C primitive arguments',counting='One source case/mechanism represented by four existing physical terminal sites; not four independent routes or mechanisms.',vulnerability_claim=False)
  if role=='input_capacity':flow['terminal_arguments']=[{'position':1,'value':11,'influence':'derived_capacity_hint','derivation':'RSTRING_LEN(pathname folder/file)=11; output13 and actual heap bytes are distinct'}]
  else:flow['terminal_arguments']=[{'position':2,'influence':'request_derived_content','source':e['source'],'start':e.get('start'),'bytes_hex':e.get('bytes_hex')},{'position':3,'value':e['count'],'influence':'source_fixed_count' if role=='encoded_byte' else 'derived_length_or_count','derivation':'fixed char buf[4] encodes selected slash as %2F; append count3 is source-fixed, content request-derived' if role=='encoded_byte' else 'selected input scan offsets; prefix6 or remaining input11-7=4'}]
  flow['conditions']=recipe['conditions']+native['conditions'];flow['historical_frontend_only_flags']={k:flow.pop(k,None) for k in ['native_contract_attached','complete_current_request_to_native_memory_promotion']};flow['native_contract_attached']=True;flow['complete_automatic_source_path_claim']=False
  flow['selected_route_binding_qualification']='Selected mounted Grape artifact GET wildcard; PATH_INFO is not original wire-byte provenance.'
  new.append(flow)
 (V/flow_name).write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in new))
 out=copy.deepcopy(prior)
 for i,f in enumerate(new,1):
  out.append(dict(flow_id=f['flow_id'],profile='ce',gitlab_sha=f['gitlab_sha'],scope_ledger='primary_source_profile',ledger_category='conditional_source_flow',original_status=f['status'],record_reference=dict(path=flow_name,file_sha256=sha(V/flow_name),line=i,flow_id=f['flow_id']),frontend_source_case_family=case,frontend_phase_case_id=case,frontend_phase=f['phase'],conditional_memory_influence_mechanism=mechanism,terminal_site_id=f['terminal_site_id'],terminal_primitive_ids=f['terminal_primitive_ids'],terminal_operation=f['terminal_operation'],registration_ids=f['registration_ids'],influence_class=[x['influence'] for x in f['terminal_arguments']],current_route_evidence=dict(selected_route=f['selected_request']['path'],source_binding=chosen[0],runtime_exposure_proven=False),source_model_applicability=dict(source_recipe_reference=ref(recipe_name),native_contract_reference=ref(native_name),path_provenance_boundary=supplement,required_forcing_supplement=forcing,independent_assembly_review=ref(args.assembly_review),conditions=f['conditions']),automatic_verified_label=False,current_runtime_execution_claim=False,vulnerability_claim=False,counting_qualification=f['counting']))
 assert len(out)==len({x['flow_id'] for x in out})==29
 checks=[];cache={}
 for x in out:
  rr=x['record_reference'];p=V/rr['path'];assert sha(p)==rr['file_sha256'];cache.setdefault(str(p),rows(p));f=cache[str(p)][rr['line']-1]
  for k in ['flow_id','profile','terminal_site_id']:assert f[k]==x[k]
  checks.append({'flow_id':x['flow_id'],'hash_line_id_profile_site':'PASS'})
 primary=[r for r in out if r['ledger_category']=='conditional_source_flow'];partial=[r for r in out if r['ledger_category']=='partial'];aux=[r for r in out if r['ledger_category']=='auxiliary_version_conditioned_flow'];main_sites={r['terminal_site_id'] for r in primary};old_sites={r['terminal_site_id'] for r in prior if r['ledger_category']=='conditional_source_flow'}
 counts=dict(total_reference_rows=len(out),main_conditional_terminal_flow_records=len(primary),main_partial_records=len(partial),main_conditional_by_profile=dict(collections.Counter(r['profile'] for r in primary)),main_conditional_physical_sites=len(main_sites),main_conditional_native_mechanisms=len({r['conditional_memory_influence_mechanism'] for r in primary}),auxiliary_version_conditioned_flows=len(aux),auxiliary_physical_sites=len({r['terminal_site_id'] for r in aux}),new_conditional_terminal_records=4,new_source_cases=1,new_conditional_physical_sites=len(main_sites-old_sites),new_native_mechanisms=1,main_conditional_source_case_families=len({r['frontend_source_case_family'] for r in primary}),independent_external_route_count=None,actual_deployed_union_proven=False)
 assert [counts[k] for k in ['main_conditional_terminal_flow_records','main_partial_records','main_conditional_physical_sites','main_conditional_native_mechanisms','auxiliary_version_conditioned_flows']]==[26,2,13,6,1]
 output='tables/request_flow_index_mlflow_final.jsonl';(V/output).write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in out));assert sha(V/prior_name)==prior_hash
 base='reports/request_flow_index_mlflow_final_';paths=[V/output,V/flow_name]
 paths.append(write(base+'counts.json',{'counts':counts,'main_sites':sorted(main_sites),'new_sites':sorted(main_sites-old_sites),'not_recall_estimate':True}))
 paths.append(write(base+'integrity.json',dict(status='PASS',checks=checks,native_existing_id_checks=source_binding,registration=regs[native['registration_id']],prior_index_sha256_preserved=prior_hash,input_references=[ref(prior_name),ref(recipe_name),ref(native_name),ref(assembly_name),supplement,forcing,ref(args.assembly_review)],frozen_inputs_mutated=False)))
 paths.append(write(base+'schema.json',dict(table=output,primary_key='flow_id',flow_table=flow_name,reference='V3-relative path+whole-file SHA256+1-based line+flow_id; profile/site exact joins',argument_positions='1-based C primitive arguments',scope='Four physical terminal records, one source case/mechanism; conditional dispatch and runtime assumptions retained')))
 paths.append(write('schemas/mlflow_cgi_escape_terminal_flows.schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','type':'object','required':['flow_id','profile','terminal_site_id','terminal_primitive_ids','terminal_arguments','path_provenance_boundary','native_contract_reference'],'properties':{'flow_id':{'type':'string'},'profile':{'const':'ce'},'runtime_execution':{'const':False},'automatic_verified_label':{'const':False},'terminal_site_id':{'type':'string'},'terminal_arguments':{'type':'array','minItems':1}}}))
 paths.append(Path(__file__));write(base+'checksums.json',{'files':[dict(path=str(p.relative_to(V)),sha256=sha(p),bytes=p.stat().st_size) for p in paths],'reproduce_command':f'python scripts/build_request_flow_union_mlflow.py --assembly-review {args.assembly_review} --assembly-review-sha256 {args.assembly_review_sha256}'})
 print(json.dumps(counts))
if __name__=='__main__':main()
