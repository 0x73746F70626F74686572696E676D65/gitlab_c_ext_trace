"""Independent CGI event comparison; executes Python models only, never CGI."""
import json,hashlib,sys,itertools
from pathlib import Path
V=Path('/workspace/gitlab_c_ext_v3');B=Path('/workspace/gitlab_c_ext_trace');A=V/'audit/cgi_encoder_independent';sys.path.insert(0,str(V/'scripts'))
from cgi_encoder_independent_oracle import oracle
from cgi_escape_contract_v1 import transfers

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return [json.loads(x) for x in p.read_text().splitlines()]
checks=[];errors=[]
def compare(case,data,plus,compatible=True):
 expected=oracle(data,plus,compatible);actual=transfers(data,ascii_compatible=compatible,plus_escape=plus);out=[]
 for e in expected['events']:
  if e['kind']=='rb_str_dup':continue # producer explicitly scopes selected-constructor events; duplicate branch distinct
  q=dict(line=e['line'],operation=e['kind'])
  if e['kind']=='rb_str_buf_new':q['capacity_argument']=e['capacity_hint']
  else:
   q['count']=e['length'];q['source']={'input':'input_slice','stack_encoded':'encoded_fixed_stack_buffer','literal':'fixed_literal_plus'}[e['source']]
   if e['source']=='input':q['start']=e['offset']
   elif e['source']=='stack_encoded':q['bytes_hex']=e['bytes_hex']
  out.append(q)
 normalized=[{k:v for k,v in e.items() if k not in ('input_index','input_byte')} for e in actual['events']]
 status={'super':'ruby_super_fallback','duplicate':'dup_fallback_no_selected_constructor','optimized':'conditional_optimized_branch'}[expected['branch']]
 ok=actual['status']==status and normalized==out and (expected['output_hex'] is None or actual['output_hex']==expected['output_hex'])
 if expected['output_hex'] is not None:ok=ok and actual['output_length']==len(bytes.fromhex(expected['output_hex']))
 record=dict(case_id=case,input_hex=data.hex(),plus_escape=plus,ascii_compatible=compatible,expected_branch=expected['branch'],events_compared=len(out),passed=ok)
 if not ok:record.update(expected=expected,actual=actual);errors.append(record)
 checks.append(record)
for c in rows(A/'predefined_cases.jsonl'):compare(c['case_id'],bytes.fromhex(c['input_hex']),c['plus_escape'],c['ascii_compatible'])
for byte in range(256):
 for plus in [False,True]:compare(f'byte{byte}_{plus}',bytes([byte]),plus)
for a,b in itertools.product([0,32,37,47,65,126,127,128,255],repeat=2):
 for plus in [False,True]:compare(f'pair{a}_{b}_{plus}',bytes([a,b]),plus)
boundaries=[]
for name,kwargs,status in [('arity0',{'argc':0},'arity_error'),('arity2',{'argc':2},'arity_error'),('unknown_encoding',{'ascii_compatible':None},'unresolved_input_encoding'),('unknown_bytes',{'data':None},'unresolved_input_bytes')]:
 args=dict(data=b'folder/file');args.update(kwargs);actual=transfers(**args);ok=actual['status']==status and not actual['events'];boundaries.append(dict(case=name,expected=status,actual=actual,passed=ok));assert ok
contract=rows(V/'tables/cgi_escape_native_contract_v1.jsonl')[0];w=contract['witness'];ev=w['events'];assert w['input_ascii']=='folder/file' and w['input_byte_length']==11 and w['output_ascii']=='folder%2Ffile';assert [(x['line'],x.get('capacity_argument',x.get('count'))) for x in ev]==[(236,11),(239,6),(248,3),(254,4)]
source_evidence=[]
for f,a,b in [('sources/gems/cgi-0.5.1/ext/cgi/escape/escape.c',202,260),('sources/gems/cgi-0.5.1/ext/cgi/escape/escape.c',373,385),('sources/gems/cgi-0.5.1/ext/cgi/escape/escape.c',424,435),('sources/gems/cgi-0.5.1/ext/cgi/escape/escape.c',471,488),('sources/gems/cgi-0.5.1/lib/cgi/escape.rb',169,176),('sources/gems/cgi-0.5.1/ext/cgi/escape/escape.c',29,34),('sources/runtime/ruby-v3_3_11/string.c',3195,3251)]:
 p=B/f;source_evidence.append(dict(file=f,line=a,end_line=b,sha256=sha(p),excerpt='\n'.join(p.read_text().split('\n')[a-1:b])))
freeze=json.loads((V/'reports/cgi_escape_native_freeze_v1.json').read_text())
for f in freeze['files']:assert sha(V/f['path'])==f['sha256']
# Actual registration/site references, not merely model flags.
reg=next(r for r in rows(B/'tables/c_registrations.jsonl') if r['registration_id']==contract['registration_id']);assert reg['line']==483
siteidx={r['site_id']:r for r in rows(V/'tables/primitive_sites.jsonl')} if (V/'tables/primitive_sites.jsonl').exists() else {r['site_id']:r for r in rows(B/'tables/primitive_sites.jsonl')}
for s in contract['site_bindings']:assert siteidx[s['site_id']]['line']==s['line']
(A/'comparison_cases.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in checks))
report=dict(status='PASS' if not errors else 'FAIL',producer_contract_sha256=sha(V/'tables/cgi_escape_native_contract_v1.jsonl'),producer_freeze_sha256=sha(V/'reports/cgi_escape_native_freeze_v1.json'),precomparison_freeze_sha256=sha(A/'expectation_freeze.json'),static_model_cases=len(checks),boundary_cases=boundaries,event_comparisons=sum(x['events_compared'] for x in checks),errors=errors,source_evidence=source_evidence,registration_source=reg,selected_witness=dict(input_length=11,output_length=13,capacity_hint=11,prefix_count=6,encoded_stack_count=3,tail_count=4),findings=['Independent reserved-position segmentation agrees on ordered capacity and append events, including zero-count slices and encoded bytes—not just final text.','Empty/all-unreserved input takes rb_str_dup and does not visit selected constructor/appends. Producer events intentionally omit dup API; branch flag preserves distinction.','Space plus form uses line243 with1byte; URI mode uses line248 withpercent20 length3. Percent/slash/NUL/high bytes each percent-encode unsigned bytes. UTF8 multibyte content is treated bytewise.','ASCII-compatible encoding is a supplied/native branch fact, not inferred from bytes. ASCII-incompatible calls super; unknown encoding/bytes or wrong arity produce no modeled native events.','Extension require can fail/rescue or be skipped on TruffleRuby; retained registration evidence does not prove selected backend activation.','Input capacity11 differs from output13 and exact heapbytes. Embedded reserve may avoid growth. Zero-count rb_str_cat is invocation without positive copy; stack buffer4/count3 fixed.','Source preserve_original_state copies encoding association only; no universal pointer identity, frozen-state preservation or charset-variable lookup claimed.'],limits=['Finite static oracle checks source-modeled byte transfer, not executed C/runtime or whole-program accuracy.','Frontend path/string origin and runtime request admission require separate assembly review.','Allocation success, stable input bytes, retained native method/encoding dispatch and Ruby build/runtime equivalence remain explicit conditions.'],runtime_execution=False)
(A/'review.json').write_text(json.dumps(report,indent=2)+'\n');paths=[A/n for n in ['predefined_cases.jsonl','expectation_freeze.json','comparison_cases.jsonl','review.json']]+[Path(__file__),V/'scripts/cgi_encoder_independent_oracle.py'];(A/'review_freeze.json').write_text(json.dumps({'files':{str(p.relative_to(V)):sha(p) for p in paths}},indent=2)+'\n');print(json.dumps({k:report[k] for k in ['status','static_model_cases','event_comparisons','errors','selected_witness']}))
