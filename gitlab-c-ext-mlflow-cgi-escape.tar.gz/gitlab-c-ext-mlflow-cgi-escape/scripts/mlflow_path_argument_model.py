"""Selected ordinary-ASCII pathname transfer model; no Ruby or HTTP execution."""
import re
PREFIX='/api/v4/projects/'
TAIL='/ml/mlflow/api/2.0/mlflow-artifacts/artifacts/'
def transfer(path,*,method='GET',admitted=True,project_argument_returns=True):
 if method!='GET':return dict(status='outside_selected_method')
 if not admitted:return dict(status='admission_unresolved')
 if not isinstance(path,str) or not path.isascii() or any(x in path for x in ['%','?','#','\\']):return dict(status='outside_literal_ascii_path_scope')
 match=re.fullmatch(re.escape(PREFIX)+r'([0-9]+)'+re.escape(TAIL)+r'([^/]+)/(.+)',path)
 if not match:return dict(status='outside_selected_route')
 project,version,glob=match.groups()
 if version.startswith('candidate:'):return dict(status='candidate_branch_outside_selected_else')
 if version!='1':return dict(status='outside_selected_version')
 if not project_argument_returns:return dict(status='earlier_user_project_argument_unresolved')
 return dict(status='conditional_current_path_argument',project_id=project,model_version=version,argument_ascii=glob,argument_byte_length=len(glob.encode('ascii')),branch='else',argument_index=1,trace=['route wildcard captures current PATH_INFO suffix','routing_args merged into request params','model_version has no candidate: prefix','user_project argument completes','params[:model_version] argument read','CGI.escape(params[:file_path]) evaluated','find_model_artifact body not entered yet'],source_kind='current request pathname, not artifact contents or stored filename')

CALL_SHAPE = """if candidate_version?(params[:model_version])
version = params[:model_version].delete_prefix(CANDIDATE_PREFIX)
present_package_file!(find_run_artifact(user_project, version, CGI.escape(params[:file_path])))
else
present_package_file!(find_model_artifact(user_project, params[:model_version],
CGI.escape(params[:file_path])))
end"""
def call_shape_guard(source):
 normalized='\n'.join(line.strip() for line in source.splitlines() if line.strip())
 return normalized.count(CALL_SHAPE)==1
