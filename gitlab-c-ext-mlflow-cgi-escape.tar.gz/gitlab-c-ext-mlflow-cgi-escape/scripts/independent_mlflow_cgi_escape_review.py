"""Independent static source/byte-model review; no application/native runtime execution."""
import pathlib,json,hashlib,sys,itertools,importlib.util
V=pathlib.Path(__file__).resolve().parents[1];B=pathlib.Path('/workspace/gitlab_c_ext_trace');sys.path.insert(0,str(V/'scripts'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify_evidence(es):
 n=0
 for e in es:
  p=B/e['file'];assert sha(p)==e['sha256'];assert '\n'.join(p.read_text().splitlines()[e['line']-1:e['end_line']])==e['excerpt'];n+=2
 return n
def native():
 freeze=V/'reports/cgi_escape_native_freeze_v1.json';f=json.loads(freeze.read_text());checks=0
 for x in f['files']:assert sha(V/x['path'])==x['sha256'];checks+=1
 p=V/'tables/cgi_escape_native_contract_v1.jsonl';c=json.loads(p.read_text());checks+=verify_evidence(c['source_evidence'])
 import cgi_escape_contract_v1 as m
 unreserved=set(b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~');cases=0
 for size in range(5):
  for xs in itertools.product(b'aZ0/% \xff',repeat=size):
   data=bytes(xs)
   for plus in (False,True):
    expected=b''.join(bytes([v]) if v in unreserved else b'+' if v==32 and plus else ('%%%02X'%v).encode() for v in data)
    got=m.transfers(data,plus_escape=plus);assert got['output_hex']==expected.hex();assert bool(got['events'])==any(v not in unreserved for v in data);cases+=1
    if got['events']:assert got['events'][0]['capacity_argument']==len(data)
 for args in ({'argc':0},{'argc':2},{'ascii_compatible':False},{'ascii_compatible':None}):assert not m.transfers(b'folder/file',**args)['events'];checks+=1
 assert m.transfers(b'file')['status']=='dup_fallback_no_selected_constructor'
 assert [e.get('count') for e in m.transfers(b'folder/file')['events'][1:]]==[6,3,4]
 assert m.transfers(b'%')['output_hex']==b'%25'.hex()
 assert any(e['operation']=='rb_str_cat_cstr' for e in m.transfers(b'a b')['events'])
 r=dict(status='PASS_conditional_native_source_contract',contract_sha256=sha(p),freeze_sha256=sha(freeze),source_hash_excerpt_checks=checks,independent_finite_cases=cases,oracle='Independent bytewise unreserved/space/percent-uppercase expansion across length0–4 over aZ0/% space FF, both plus modes.',manual_source_findings=['cgiesc_escape StringValue and ASCII-compatible guard selects optimized_escape(str,1), otherwise super; no accept_charset dependency.','Actual native load→InitVM macro→escape registration→composition under ordinary no replacement conditions.','folder/file raw11 slashoffset6 generates capacity11,prefix6,stackpercent2F count3,tail4 and output13.','Stack buf4 fixed, requested capacity11 not exactheapbytes and output13 not necessarily buffer growth.','Unreserved/empty fallback duplicates and space uses distinct plus append; literal percent encodes, never decoder malformed branch.'],runtime_execution=False,frontend_status='pending_frozen_recipe')
 out=V/'reports/mlflow_cgi_escape_native_independent_review.json';out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(status=r['status'],sha256=sha(out),finite_cases=cases)))
if __name__=='__main__':native()
