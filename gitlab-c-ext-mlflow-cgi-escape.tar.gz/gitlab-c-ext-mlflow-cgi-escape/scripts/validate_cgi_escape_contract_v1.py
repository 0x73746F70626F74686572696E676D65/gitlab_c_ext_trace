#!/usr/bin/env python3
import json,hashlib,unittest
from pathlib import Path
R=Path('/workspace/gitlab_c_ext_trace');V=Path('/workspace/gitlab_c_ext_v3');row=json.loads((V/'tables/cgi_escape_native_contract_v1.jsonl').read_text());checks=0
sites={x['site_id']:x for x in map(json.loads,(R/'tables/primitive_sites.jsonl').open())};ps={x['primitive_id']:x for x in map(json.loads,(R/'tables/c_primitives.jsonl').open())};regs={x['registration_id']:x for x in map(json.loads,(R/'tables/c_registrations.jsonl').open())}
reg=regs[row['registration_id']];assert reg['ruby_name']=='escape' and reg['c_function_expression']=='cgiesc_escape' and reg['gem_id']==row['gem_id'];checks+=1
for binding in row['site_bindings']:
 site=sites[binding['site_id']];prim=ps[binding['primitive_id']]
 assert site['line']==prim['line']==binding['line'];assert site['operation']==prim['primitive'];assert row['gem_id'] in site['gem_ids'];checks+=3
for e in row['source_evidence']:
 d=(R/e['file']).read_bytes();assert hashlib.sha256(d).hexdigest()==e['sha256'];text='\n'.join(d.decode().split('\n')[e['line']-1:e['end_line']]);assert text==e['excerpt'];checks+=2
 for anchor in e['required_anchors']:assert anchor in text;checks+=1
result=unittest.TextTestRunner().run(unittest.defaultTestLoader.discover(str(V/'tests'),pattern='test_cgi_escape_contract_v1.py'));assert result.wasSuccessful()
report=dict(checks=checks,errors=0,tests=result.testsRun,source_execution=False,limits='Static model fixtures and join/source checks; independent semantic review separate.')
(V/'reports/cgi_escape_native_validation_v1.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
