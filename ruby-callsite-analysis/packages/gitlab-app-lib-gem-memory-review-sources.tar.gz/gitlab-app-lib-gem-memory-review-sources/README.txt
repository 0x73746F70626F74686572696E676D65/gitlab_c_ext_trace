Source review bundle for saved GitLab Ruby-to-native memory flows.
Scope: callsites whose source path starts app/, lib/, ee/app/, or ee/lib/.
callsites/: one original JSON per selected Ruby callsite; callsites.jsonl aggregates them.
chains/: only their complete original saved C flow witness JSONs.
sources/: complete files cited by those C chains, Ruby wrapper evidence, and resolvable local includes.
Every retained source file has its original bytes and line numbering, not extracted snippets.
flow-source-map.jsonl maps C witnesses and Ruby callsites to their complete source files.
source-packages.json pins published gem versions/package hashes and upstream Git commits/gitlinks.
source-files.jsonl lists source SHA256s and inclusion reasons.
include-dependencies.jsonl records local header resolution and external/missing/ambiguous includes.
This is a review source slice, not a buildable checkout or a new tracing run.
Published gems and recorded upstream Git variants are distinct; use the package identity in each chain.
The original C interrupted-checkpoint status is retained in every chain.
