#!/usr/bin/env python3
"""Deterministic compact V3 companion. No network, publishing, or source mutation."""
import argparse,gzip,hashlib,io,json,shutil,tarfile
from pathlib import Path
ROOT=Path('/workspace/gitlab_c_ext_v3');PUB=ROOT/'publication'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify_manifest(path):
 r=json.loads(path.read_text());files=r.get('files',{})
 if isinstance(files,dict):entries=[dict(v,file=k) for k,v in files.items()]
 else:entries=files
 entries+=r.get('inputs',[])+r.get('outputs',[])
 for e in entries:
  n=e.get('file',e.get('path'));p=Path(n);p=p if p.is_absolute() else ROOT/p
  if 'sha256' in e:assert digest(p)==e['sha256'],('freeze mismatch',str(path),n)
 return len(entries)
def main(provisional=False):
 PUB.mkdir(exist_ok=True);stage=PUB/'gitlab-c-ext-v3'
 if stage.exists():shutil.rmtree(stage)
 stage.mkdir();selected=set()
 def add(pattern):
  for p in ROOT.glob(pattern):
   if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.log'):selected.add(p)
 for p in ['ANALYSIS_CONTRACT.txt','BACKLOG.json','scripts/*.py','tests/*.py','fixtures/*','schemas/*','iterations/iteration1_1/*','iterations/iteration2/*','audit/holdout_20260930/*','reports/*.json','reports/*methodology*','reports/*contract*','reports/frontend_coverage_changes.txt','profiles/*/reports/*.json','profiles/*/reports/request_argument_review_dossiers.txt','profiles/*/tables/route_scope_*.jsonl','profiles/*/tables/controller_callback_*.jsonl','profiles/*/tables/ruby_super_demands.jsonl','profiles/*/tables/request_arg_candidates.jsonl','tables/*lookup*.jsonl','tables/*super_iteration2*.jsonl','tables/*iteration2*.jsonl','tables/*iteration1_1*.jsonl','tables/ruby_deferred_regions.jsonl','tables/flow_ruby_independent_review.jsonl']:add(p)
 # Keep compact lineage and reviewed results; excluded artifacts remain in the saved environment.
 excluded={'native_guard_engine.py','check_native_guards.py','test_native_guard_engine.py','native_guard_coverage.json','native_iteration1_freeze.json','baseline_files.jsonl'}
 selected={p for p in selected if p.name not in excluded and not p.name.endswith('.log') and 'iteration3' not in p.name}
 checks=[]
 for rel in ['reports/lookup_iteration1_manifest.json','reports/super_iteration2_manifest.json','reports/native_iteration1_1_freeze.json','iterations/iteration1_1/freeze_manifest.json']:
  p=ROOT/rel;checks.append(dict(manifest=rel,verified_files=verify_manifest(p)))
 if not provisional:
  for rel in ['iterations/iteration2/freeze_manifest.json','reports/native_iteration2_freeze.json']:
   assert (ROOT/rel).exists(),('pending freeze',rel)
  report=json.loads((ROOT/'reports/request_flow_iteration2_validation.json').read_text())
  assert not any('pending' in s for s in report.get('states',{})), 'EE flow review still pending'
 for rel in ['reports/native_iteration2_freeze.json','iterations/iteration2/freeze_manifest.json']:
  if (ROOT/rel).exists():checks.append(dict(manifest=rel,verified_files=verify_manifest(ROOT/rel)))
 omit_names={'controller_callback_demands.jsonl','ruby_super_demands.jsonl','ruby_argument_facts_iteration2.jsonl'}
 omitted=[p for p in selected if p.name in omit_names or p==ROOT/'iterations/iteration1_1/path_decisions.jsonl']
 selected-=set(omitted)
 (stage/'omitted_local_artifacts.json').write_text(json.dumps([dict(path=str(p.relative_to(ROOT)),durable_location=str(p),bytes=p.stat().st_size,sha256=digest(p),reason='redundant raw inventory or intermediate overlay; retained locally') for p in sorted(omitted)],indent=2)+'\n')
 for p in sorted(selected):
  target=stage/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
 index=(PUB/'V3_INDEX.txt').read_text();(stage/'INDEX.txt').write_text(index+'\nPackage state: '+('PROVISIONAL; pending final freeze/review. Not for publication.' if provisional else 'Final staging; see catalogs and freeze manifests.')+'\n')
 catalog=[]
 for p in sorted(stage.rglob('*')):
  if not p.is_file():continue
  catalog.append(dict(path=str(p.relative_to(stage)),bytes=p.stat().st_size,sha256=digest(p),rows=sum(1 for _ in p.open('rb')) if p.suffix=='.jsonl' else None))
 (stage/'table_catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
 (stage/'package_validation.json').write_text(json.dumps(dict(status='PASS',provisional=provisional,freeze_checks=checks,files=len(catalog),bytes=sum(x['bytes'] for x in catalog),scope='Hashes, frozen manifest agreement and archive membership; not semantic analysis validation.'),indent=2)+'\n')
 sums=''.join(f'{digest(p)}  {p.relative_to(stage)}\n' for p in sorted(stage.rglob('*')) if p.is_file());(stage/'SHA256SUMS').write_text(sums)
 archive=PUB/('gitlab-c-ext-v3-provisional.tar.gz' if provisional else 'gitlab-c-ext-v3.tar.gz')
 with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0,compresslevel=9) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
  for p in sorted(stage.rglob('*')):
   if not p.is_file():continue
   info=tarfile.TarInfo('gitlab-c-ext-v3/'+str(p.relative_to(stage)));info.size=p.stat().st_size;info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(p.read_bytes()))
 expected={'gitlab-c-ext-v3/'+str(p.relative_to(stage)):digest(p) for p in stage.rglob('*') if p.is_file()}
 with tarfile.open(archive,'r:gz') as tar:
  actual={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers()}
 assert actual==expected,'archive content mismatch'
 result=dict(status='PASS',archive=str(archive),bytes=archive.stat().st_size,sha256=digest(archive),member_count=len(actual),provisional=provisional,under_20_MB=archive.stat().st_size<20_000_000)
 (PUB/'archive_validation.json').write_text(json.dumps(result,indent=2)+'\n');(PUB/'SHA256SUMS').write_text(f"{result['sha256']}  {archive.name}\n");print(json.dumps(result))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--provisional',action='store_true');main(a.parse_args().provisional)
